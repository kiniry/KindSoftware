using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace autoxt
{
	public partial class Find : Form
	{

		private bool ok = false;

		public Find()
		{
			InitializeComponent();
		}

		public DialogResult Show(IWin32Window owner, string findValue)
		{	
			
			txtFind.Text = findValue;
			ShowDialog(owner);

			if(ok == true)
				return DialogResult.OK;
			
			return DialogResult.Cancel;

		}

		public string findValue { get { return txtFind.Text; } }

		private void cmdOk_Click(object sender, EventArgs e)
		{
			ok = true;
			this.Visible = false;
		}

		private void cmdCancel_Click(object sender, EventArgs e)
		{
			this.Visible = false;
		}

		private void txtFind_Enter(object sender, EventArgs e)
		{
			txtFind.SelectAll();
		}

	}
}