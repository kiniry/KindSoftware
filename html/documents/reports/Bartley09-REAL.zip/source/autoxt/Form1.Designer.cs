namespace autoxt
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if(disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.tmrUpdate = new System.Windows.Forms.Timer(this.components);
			this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
			this.stsStatus = new System.Windows.Forms.StatusStrip();
			this.lblStatus = new System.Windows.Forms.ToolStripStatusLabel();
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.splitContainer2 = new System.Windows.Forms.SplitContainer();
			this.txtMachine = new System.Windows.Forms.RichTextBox();
			this.txtInput = new System.Windows.Forms.RichTextBox();
			this.splitContainer3 = new System.Windows.Forms.SplitContainer();
			this.txtOutput = new System.Windows.Forms.RichTextBox();
			this.splitContainer4 = new System.Windows.Forms.SplitContainer();
			this.tvwAST = new System.Windows.Forms.TreeView();
			this.txtCode = new System.Windows.Forms.RichTextBox();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuNew = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
			this.mnuFileOpen = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuFileSave = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
			this.mnuExit = new System.Windows.Forms.ToolStripMenuItem();
			this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuEditFind = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuEditFindNext = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuEditReplace = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
			this.mnuEditCopyPrecedenceList = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuEditCopyStateList = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuCopyParser = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuCopyFSA = new System.Windows.Forms.ToolStripMenuItem();
			this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuHelpNotes = new System.Windows.Forms.ToolStripMenuItem();
			this.dlgOpen = new System.Windows.Forms.OpenFileDialog();
			this.dlgSave = new System.Windows.Forms.SaveFileDialog();
			this.toolStripContainer1.BottomToolStripPanel.SuspendLayout();
			this.toolStripContainer1.ContentPanel.SuspendLayout();
			this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
			this.toolStripContainer1.SuspendLayout();
			this.stsStatus.SuspendLayout();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.splitContainer2.Panel1.SuspendLayout();
			this.splitContainer2.Panel2.SuspendLayout();
			this.splitContainer2.SuspendLayout();
			this.splitContainer3.Panel1.SuspendLayout();
			this.splitContainer3.Panel2.SuspendLayout();
			this.splitContainer3.SuspendLayout();
			this.splitContainer4.Panel1.SuspendLayout();
			this.splitContainer4.Panel2.SuspendLayout();
			this.splitContainer4.SuspendLayout();
			this.menuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// tmrUpdate
			// 
			this.tmrUpdate.Interval = 500;
			this.tmrUpdate.Tick += new System.EventHandler(this.tmrUpdate_Tick);
			// 
			// toolStripContainer1
			// 
			// 
			// toolStripContainer1.BottomToolStripPanel
			// 
			this.toolStripContainer1.BottomToolStripPanel.Controls.Add(this.stsStatus);
			// 
			// toolStripContainer1.ContentPanel
			// 
			this.toolStripContainer1.ContentPanel.Controls.Add(this.splitContainer1);
			this.toolStripContainer1.ContentPanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(994, 613);
			this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
			this.toolStripContainer1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.toolStripContainer1.Name = "toolStripContainer1";
			this.toolStripContainer1.Size = new System.Drawing.Size(994, 659);
			this.toolStripContainer1.TabIndex = 0;
			this.toolStripContainer1.Text = "toolStripContainer1";
			// 
			// toolStripContainer1.TopToolStripPanel
			// 
			this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.menuStrip1);
			// 
			// stsStatus
			// 
			this.stsStatus.Dock = System.Windows.Forms.DockStyle.None;
			this.stsStatus.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
			this.stsStatus.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblStatus});
			this.stsStatus.Location = new System.Drawing.Point(0, 0);
			this.stsStatus.Name = "stsStatus";
			this.stsStatus.Size = new System.Drawing.Size(994, 22);
			this.stsStatus.TabIndex = 0;
			// 
			// lblStatus
			// 
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Size = new System.Drawing.Size(979, 17);
			this.lblStatus.Spring = true;
			this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// splitContainer1
			// 
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.Location = new System.Drawing.Point(0, 0);
			this.splitContainer1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.splitContainer1.Name = "splitContainer1";
			// 
			// splitContainer1.Panel1
			// 
			this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
			// 
			// splitContainer1.Panel2
			// 
			this.splitContainer1.Panel2.Controls.Add(this.splitContainer3);
			this.splitContainer1.Size = new System.Drawing.Size(994, 613);
			this.splitContainer1.SplitterDistance = 482;
			this.splitContainer1.SplitterWidth = 5;
			this.splitContainer1.TabIndex = 1;
			// 
			// splitContainer2
			// 
			this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer2.Location = new System.Drawing.Point(0, 0);
			this.splitContainer2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.splitContainer2.Name = "splitContainer2";
			this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// splitContainer2.Panel1
			// 
			this.splitContainer2.Panel1.Controls.Add(this.txtMachine);
			// 
			// splitContainer2.Panel2
			// 
			this.splitContainer2.Panel2.Controls.Add(this.txtInput);
			this.splitContainer2.Size = new System.Drawing.Size(482, 613);
			this.splitContainer2.SplitterDistance = 477;
			this.splitContainer2.SplitterWidth = 5;
			this.splitContainer2.TabIndex = 1;
			// 
			// txtMachine
			// 
			this.txtMachine.AcceptsTab = true;
			this.txtMachine.DetectUrls = false;
			this.txtMachine.Dock = System.Windows.Forms.DockStyle.Fill;
			this.txtMachine.EnableAutoDragDrop = true;
			this.txtMachine.Location = new System.Drawing.Point(0, 0);
			this.txtMachine.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.txtMachine.Name = "txtMachine";
			this.txtMachine.Size = new System.Drawing.Size(482, 477);
			this.txtMachine.TabIndex = 3;
			this.txtMachine.Text = "";
			this.txtMachine.WordWrap = false;
			this.txtMachine.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBox_positionChanged);
			this.txtMachine.MouseUp += new System.Windows.Forms.MouseEventHandler(this.txtBox_positionChanged);
			this.txtMachine.Enter += new System.EventHandler(this.txtMachine_Enter);
			this.txtMachine.MouseDown += new System.Windows.Forms.MouseEventHandler(this.txtBox_positionChanged);
			this.txtMachine.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtBox_positionChanged);
			this.txtMachine.TextChanged += new System.EventHandler(this.txtMachine_TextChanged);
			// 
			// txtInput
			// 
			this.txtInput.AcceptsTab = true;
			this.txtInput.Dock = System.Windows.Forms.DockStyle.Fill;
			this.txtInput.Location = new System.Drawing.Point(0, 0);
			this.txtInput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.txtInput.Name = "txtInput";
			this.txtInput.Size = new System.Drawing.Size(482, 131);
			this.txtInput.TabIndex = 0;
			this.txtInput.Text = "";
			this.txtInput.WordWrap = false;
			this.txtInput.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBox_positionChanged);
			this.txtInput.MouseUp += new System.Windows.Forms.MouseEventHandler(this.txtBox_positionChanged);
			this.txtInput.Enter += new System.EventHandler(this.txtInput_Enter);
			this.txtInput.MouseDown += new System.Windows.Forms.MouseEventHandler(this.txtBox_positionChanged);
			this.txtInput.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtBox_positionChanged);
			this.txtInput.TextChanged += new System.EventHandler(this.txtInput_TextChanged);
			// 
			// splitContainer3
			// 
			this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer3.Location = new System.Drawing.Point(0, 0);
			this.splitContainer3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.splitContainer3.Name = "splitContainer3";
			this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// splitContainer3.Panel1
			// 
			this.splitContainer3.Panel1.Controls.Add(this.txtOutput);
			// 
			// splitContainer3.Panel2
			// 
			this.splitContainer3.Panel2.Controls.Add(this.splitContainer4);
			this.splitContainer3.Size = new System.Drawing.Size(507, 613);
			this.splitContainer3.SplitterDistance = 117;
			this.splitContainer3.SplitterWidth = 5;
			this.splitContainer3.TabIndex = 0;
			// 
			// txtOutput
			// 
			this.txtOutput.Dock = System.Windows.Forms.DockStyle.Fill;
			this.txtOutput.Location = new System.Drawing.Point(0, 0);
			this.txtOutput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.txtOutput.Name = "txtOutput";
			this.txtOutput.Size = new System.Drawing.Size(507, 117);
			this.txtOutput.TabIndex = 1;
			this.txtOutput.Text = "";
			this.txtOutput.WordWrap = false;
			this.txtOutput.Enter += new System.EventHandler(this.txtOutput_Enter);
			// 
			// splitContainer4
			// 
			this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer4.Location = new System.Drawing.Point(0, 0);
			this.splitContainer4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.splitContainer4.Name = "splitContainer4";
			this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// splitContainer4.Panel1
			// 
			this.splitContainer4.Panel1.Controls.Add(this.tvwAST);
			// 
			// splitContainer4.Panel2
			// 
			this.splitContainer4.Panel2.Controls.Add(this.txtCode);
			this.splitContainer4.Size = new System.Drawing.Size(507, 491);
			this.splitContainer4.SplitterDistance = 355;
			this.splitContainer4.SplitterWidth = 5;
			this.splitContainer4.TabIndex = 0;
			// 
			// tvwAST
			// 
			this.tvwAST.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tvwAST.Location = new System.Drawing.Point(0, 0);
			this.tvwAST.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.tvwAST.Name = "tvwAST";
			this.tvwAST.Size = new System.Drawing.Size(507, 355);
			this.tvwAST.TabIndex = 1;
			this.tvwAST.Enter += new System.EventHandler(this.tvwAST_Enter);
			// 
			// txtCode
			// 
			this.txtCode.Dock = System.Windows.Forms.DockStyle.Fill;
			this.txtCode.Location = new System.Drawing.Point(0, 0);
			this.txtCode.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.txtCode.Name = "txtCode";
			this.txtCode.Size = new System.Drawing.Size(507, 131);
			this.txtCode.TabIndex = 0;
			this.txtCode.Text = "";
			this.txtCode.Enter += new System.EventHandler(this.txtCode_Enter);
			// 
			// menuStrip1
			// 
			this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.helpToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(994, 24);
			this.menuStrip1.TabIndex = 0;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// fileToolStripMenuItem
			// 
			this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuNew,
            this.toolStripMenuItem1,
            this.mnuFileOpen,
            this.mnuFileSave,
            this.mnuFileSaveAs,
            this.toolStripMenuItem2,
            this.mnuExit});
			this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
			this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
			this.fileToolStripMenuItem.Text = "&File";
			// 
			// mnuNew
			// 
			this.mnuNew.Name = "mnuNew";
			this.mnuNew.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
			this.mnuNew.Size = new System.Drawing.Size(148, 22);
			this.mnuNew.Text = "New";
			this.mnuNew.Click += new System.EventHandler(this.mnuNew_Click);
			// 
			// toolStripMenuItem1
			// 
			this.toolStripMenuItem1.Name = "toolStripMenuItem1";
			this.toolStripMenuItem1.Size = new System.Drawing.Size(145, 6);
			// 
			// mnuFileOpen
			// 
			this.mnuFileOpen.Name = "mnuFileOpen";
			this.mnuFileOpen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
			this.mnuFileOpen.Size = new System.Drawing.Size(148, 22);
			this.mnuFileOpen.Text = "&Open..";
			this.mnuFileOpen.Click += new System.EventHandler(this.mnuFileOpen_Click);
			// 
			// mnuFileSave
			// 
			this.mnuFileSave.Name = "mnuFileSave";
			this.mnuFileSave.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
			this.mnuFileSave.Size = new System.Drawing.Size(148, 22);
			this.mnuFileSave.Text = "&Save";
			this.mnuFileSave.Click += new System.EventHandler(this.mnuFileSave_Click);
			// 
			// mnuFileSaveAs
			// 
			this.mnuFileSaveAs.Name = "mnuFileSaveAs";
			this.mnuFileSaveAs.ShortcutKeys = System.Windows.Forms.Keys.F12;
			this.mnuFileSaveAs.Size = new System.Drawing.Size(148, 22);
			this.mnuFileSaveAs.Text = "Save &as..";
			this.mnuFileSaveAs.Click += new System.EventHandler(this.mnuFileSaveAs_Click);
			// 
			// toolStripMenuItem2
			// 
			this.toolStripMenuItem2.Name = "toolStripMenuItem2";
			this.toolStripMenuItem2.Size = new System.Drawing.Size(145, 6);
			// 
			// mnuExit
			// 
			this.mnuExit.Name = "mnuExit";
			this.mnuExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
			this.mnuExit.Size = new System.Drawing.Size(148, 22);
			this.mnuExit.Text = "E&xit";
			this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
			// 
			// editToolStripMenuItem
			// 
			this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuEditFind,
            this.mnuEditFindNext,
            this.mnuEditReplace,
            this.toolStripMenuItem3,
            this.mnuEditCopyPrecedenceList,
            this.mnuEditCopyStateList,
            this.mnuCopyParser,
            this.mnuCopyFSA});
			this.editToolStripMenuItem.Name = "editToolStripMenuItem";
			this.editToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
			this.editToolStripMenuItem.Text = "&Edit";
			// 
			// mnuEditFind
			// 
			this.mnuEditFind.Name = "mnuEditFind";
			this.mnuEditFind.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
			this.mnuEditFind.Size = new System.Drawing.Size(174, 22);
			this.mnuEditFind.Text = "&Find";
			this.mnuEditFind.Click += new System.EventHandler(this.mnuEditFind_Click);
			// 
			// mnuEditFindNext
			// 
			this.mnuEditFindNext.Name = "mnuEditFindNext";
			this.mnuEditFindNext.ShortcutKeys = System.Windows.Forms.Keys.F3;
			this.mnuEditFindNext.Size = new System.Drawing.Size(174, 22);
			this.mnuEditFindNext.Text = "Find &next";
			this.mnuEditFindNext.Click += new System.EventHandler(this.mnuEditFindNext_Click);
			// 
			// mnuEditReplace
			// 
			this.mnuEditReplace.Name = "mnuEditReplace";
			this.mnuEditReplace.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
			this.mnuEditReplace.Size = new System.Drawing.Size(174, 22);
			this.mnuEditReplace.Text = "&Replace";
			this.mnuEditReplace.Click += new System.EventHandler(this.mnuEditReplace_Click);
			// 
			// toolStripMenuItem3
			// 
			this.toolStripMenuItem3.Name = "toolStripMenuItem3";
			this.toolStripMenuItem3.Size = new System.Drawing.Size(171, 6);
			// 
			// mnuEditCopyPrecedenceList
			// 
			this.mnuEditCopyPrecedenceList.Name = "mnuEditCopyPrecedenceList";
			this.mnuEditCopyPrecedenceList.Size = new System.Drawing.Size(174, 22);
			this.mnuEditCopyPrecedenceList.Text = "Copy precedence list";
			this.mnuEditCopyPrecedenceList.Click += new System.EventHandler(this.mnuEditCopyPrecedenceList_Click);
			// 
			// mnuEditCopyStateList
			// 
			this.mnuEditCopyStateList.Name = "mnuEditCopyStateList";
			this.mnuEditCopyStateList.Size = new System.Drawing.Size(174, 22);
			this.mnuEditCopyStateList.Text = "Copy state list";
			this.mnuEditCopyStateList.Click += new System.EventHandler(this.mnuEditCopyStateList_Click);
			// 
			// mnuCopyParser
			// 
			this.mnuCopyParser.Name = "mnuCopyParser";
			this.mnuCopyParser.Size = new System.Drawing.Size(174, 22);
			this.mnuCopyParser.Text = "Copy parser";
			this.mnuCopyParser.Click += new System.EventHandler(this.mnuCopyParser_Click);
			// 
			// mnuCopyFSA
			// 
			this.mnuCopyFSA.Name = "mnuCopyFSA";
			this.mnuCopyFSA.Size = new System.Drawing.Size(174, 22);
			this.mnuCopyFSA.Text = "Copy FSA";
			this.mnuCopyFSA.Click += new System.EventHandler(this.mnuCopyFSA_Click);
			// 
			// helpToolStripMenuItem
			// 
			this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuHelpNotes});
			this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
			this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
			this.helpToolStripMenuItem.Text = "&Help";
			// 
			// mnuHelpNotes
			// 
			this.mnuHelpNotes.Name = "mnuHelpNotes";
			this.mnuHelpNotes.ShortcutKeys = System.Windows.Forms.Keys.F1;
			this.mnuHelpNotes.Size = new System.Drawing.Size(121, 22);
			this.mnuHelpNotes.Text = "Notes";
			this.mnuHelpNotes.Click += new System.EventHandler(this.mnuHelpNotes_Click);
			// 
			// dlgOpen
			// 
			this.dlgOpen.AddExtension = false;
			this.dlgOpen.DefaultExt = "txt";
			this.dlgOpen.Filter = "Text files (*.txt)|*.txt|All Files (*.*)|*.*";
			// 
			// dlgSave
			// 
			this.dlgSave.DefaultExt = "txt";
			this.dlgSave.Filter = "Text files (*.txt)|*.txt|All Files (*.*)|*.*";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(994, 659);
			this.Controls.Add(this.toolStripContainer1);
			this.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.MainMenuStrip = this.menuStrip1;
			this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.Name = "Form1";
			this.Text = "Untitled";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
			this.toolStripContainer1.BottomToolStripPanel.ResumeLayout(false);
			this.toolStripContainer1.BottomToolStripPanel.PerformLayout();
			this.toolStripContainer1.ContentPanel.ResumeLayout(false);
			this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
			this.toolStripContainer1.TopToolStripPanel.PerformLayout();
			this.toolStripContainer1.ResumeLayout(false);
			this.toolStripContainer1.PerformLayout();
			this.stsStatus.ResumeLayout(false);
			this.stsStatus.PerformLayout();
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel2.ResumeLayout(false);
			this.splitContainer1.ResumeLayout(false);
			this.splitContainer2.Panel1.ResumeLayout(false);
			this.splitContainer2.Panel2.ResumeLayout(false);
			this.splitContainer2.ResumeLayout(false);
			this.splitContainer3.Panel1.ResumeLayout(false);
			this.splitContainer3.Panel2.ResumeLayout(false);
			this.splitContainer3.ResumeLayout(false);
			this.splitContainer4.Panel1.ResumeLayout(false);
			this.splitContainer4.Panel2.ResumeLayout(false);
			this.splitContainer4.ResumeLayout(false);
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Timer tmrUpdate;
		private System.Windows.Forms.ToolStripContainer toolStripContainer1;
		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.SplitContainer splitContainer2;
		private System.Windows.Forms.RichTextBox txtMachine;
		private System.Windows.Forms.RichTextBox txtInput;
		private System.Windows.Forms.SplitContainer splitContainer3;
		private System.Windows.Forms.RichTextBox txtOutput;
		private System.Windows.Forms.SplitContainer splitContainer4;
		private System.Windows.Forms.TreeView tvwAST;
		private System.Windows.Forms.RichTextBox txtCode;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem mnuFileOpen;
		private System.Windows.Forms.ToolStripMenuItem mnuFileSave;
		private System.Windows.Forms.ToolStripMenuItem mnuFileSaveAs;
		private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
		private System.Windows.Forms.ToolStripMenuItem mnuExit;
		private System.Windows.Forms.OpenFileDialog dlgOpen;
		private System.Windows.Forms.SaveFileDialog dlgSave;
		private System.Windows.Forms.ToolStripMenuItem mnuNew;
		private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
		private System.Windows.Forms.StatusStrip stsStatus;
		private System.Windows.Forms.ToolStripStatusLabel lblStatus;
		private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem mnuEditReplace;
		private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem mnuHelpNotes;
		private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
		private System.Windows.Forms.ToolStripMenuItem mnuEditCopyPrecedenceList;
		private System.Windows.Forms.ToolStripMenuItem mnuEditCopyStateList;
		private System.Windows.Forms.ToolStripMenuItem mnuCopyParser;
		private System.Windows.Forms.ToolStripMenuItem mnuEditFind;
		private System.Windows.Forms.ToolStripMenuItem mnuEditFindNext;
		private System.Windows.Forms.ToolStripMenuItem mnuCopyFSA;

	}
}

