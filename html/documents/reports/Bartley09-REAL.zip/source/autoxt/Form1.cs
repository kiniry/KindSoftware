using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;

namespace autoxt
{

	public partial class Form1 : Form
	{

		bool loaded = true;
		bool internalUpdate = false;
		bool isDirty = false;
		string filename = null;
		int uniqueId = 0;
		string startState = null;
		List<string> finalStates = null;
		const int autoRefresh = 1500;
		string format = "00";
		CurrentStateAndStack pseudoEndState = new CurrentStateAndStack(null);
		string codesep = @"//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\";
		string findString = null;
		RichTextBox txtActive = null;
		TreeView tvwActive = null;

		#region UI
		[DllImport("user32.dll")]
		private static extern int SendMessage(IntPtr hwndLock, Int32 wMsg, Int32 wParam, ref Point pt);

		public Form1()
		{
			InitializeComponent();
		}
		private void txtMachine_TextChanged(object sender, EventArgs e)
		{
			invalidateParse();
			if(internalUpdate == false)
			{	this.Text = filename + " *";
				isDirty = true;
			}
		}
		private void txtInput_TextChanged(object sender, EventArgs e)
		{
			invalidateParse();
			if(internalUpdate == false)
			{	this.Text = filename + " *";
				isDirty = true;
			}
		}
		private void Form1_Load(object sender, EventArgs args)
		{
		}
		private void Form1_FormClosing(object sender, FormClosingEventArgs args)
		{
			if(isDirty == true)
				switch(MessageBox.Show(this, "Save changes?", "Save changes?", MessageBoxButtons.YesNoCancel))
				{	case DialogResult.Yes:
						if(save() == false)
							if(MessageBox.Show(this, "Save failed. Quit anyway?", "Quit?", MessageBoxButtons.YesNo) != DialogResult.Yes)
								args.Cancel = true;
					break;
					case DialogResult.No: break;
					case DialogResult.Cancel: args.Cancel = true; break;
				}

		}
		private void tmrUpdate_Tick(object sender, EventArgs e)
		{
			tmrUpdate.Enabled = false;
			parse();
			txtOutput.BackColor = tvwAST.BackColor = txtCode.BackColor = Color.FromKnownColor(KnownColor.Window);
		}
		private void mnuNew_Click(object sender, EventArgs e)
		{
			if(isDirty == true)
				switch(MessageBox.Show(this, "Save changes?", "Save changes?", MessageBoxButtons.YesNoCancel))
				{	case DialogResult.Yes: save(); break;
					case DialogResult.No: break;
					case DialogResult.Cancel: return;
				}
			txtMachine.Text = "";
			txtInput.Text = "";
			filename = null;
			isDirty = false;
			this.Text = "Untitled";
		}
		private void mnuFileOpen_Click(object sender, EventArgs e)
		{
			if(isDirty == true)
				switch(MessageBox.Show(this, "Save changes?", "Save changes?", MessageBoxButtons.YesNoCancel))
				{	case DialogResult.Yes: save(); break;
					case DialogResult.No: break;
					case DialogResult.Cancel: return;
				}
			load();
		}
		private void mnuFileSave_Click(object sender, EventArgs e)
		{
			save();
		}
		private void mnuFileSaveAs_Click(object sender, EventArgs e)
		{
			saveAs();
		}
		private void mnuExit_Click(object sender, EventArgs e)
		{
			Close();
		}
		private void load()
		{

			if(dlgOpen.ShowDialog() == DialogResult.OK)
			{

				loaded = false;
				filename = dlgOpen.FileName;
				StreamReader sr = null;
				try
				{
					sr = new StreamReader(dlgOpen.FileName);

					txtMachine.Text = "";
					txtInput.Text = "";

					string line;
					int mode = 0;
					while((line = sr.ReadLine()) != null)
					{
						if(line == "#machine")
							mode = 0;
						else
						if(line == "#input")
							mode = 1;
						else
						if(mode == 0)
							txtMachine.Text += line + "\n";
						else
						if(mode == 1)
							txtInput.Text += line + "\n";
					}
				}
				catch(Exception e)
				{	output("Error loading: " + e.ToString());
				}
				finally
				{	sr.Close();
					loaded = true;
					parse();
					this.Text = filename;
					isDirty = false;
				}

			}

		}
		private bool save()
		{

			if(filename == null)
				return saveAs();

			StreamWriter sw = null;
			try
			{
				sw = new StreamWriter(filename);
				sw.WriteLine("#machine");
				string[] lines = txtMachine.Text.Trim().Split('\n');
				foreach(string line in lines)
					sw.WriteLine(line);
				sw.WriteLine("#input");
				lines = txtInput.Text.Trim().Split('\n');
				foreach(string line in lines)
					sw.WriteLine(line);
			}
			catch(Exception e)
			{	MessageBox.Show("Failed to save because " + e.ToString());
				return false;
			}
			finally
			{	sw.Close();
			}

			this.Text = filename;
			isDirty = false;
			return true;

		}
		private bool saveAs()
		{

			if(dlgSave.ShowDialog() == DialogResult.OK)
			{	filename = dlgSave.FileName;
				return save();
			}

			return false;

		}
		private void txtBox_positionChanged(object sender, KeyEventArgs e)
		{	outputPosition((RichTextBox)sender);
		}
		private void txtBox_positionChanged(object sender, MouseEventArgs e)
		{	outputPosition((RichTextBox)sender);
		}
		private void outputPosition(RichTextBox txtBox)
		{	lblStatus.Text = txtBox.GetLineFromCharIndex(txtBox.SelectionStart) + ", " + (txtBox.SelectionStart - txtBox.GetFirstCharIndexOfCurrentLine());
		}
		private void txtMachine_Enter(object sender, EventArgs e)
		{
			txtActive = txtMachine;
			tvwActive = null;
		}
		private void txtInput_Enter(object sender, EventArgs e)
		{
			txtActive = txtInput;
			tvwActive = null;
		}
		private void txtCode_Enter(object sender, EventArgs e)
		{
			txtActive = txtCode;
			tvwActive = null;
		}
		private void txtOutput_Enter(object sender, EventArgs e)
		{
			txtActive = txtOutput;
			tvwActive = null;
		}
		private void tvwAST_Enter(object sender, EventArgs e)
		{
			txtActive = txtMachine;
			tvwActive = tvwAST;
		}
		private void mnuEditFind_Click(object sender, EventArgs e)
		{	Find frmFind = new Find();

			string look = Clipboard.GetText();
			if(tvwActive != null)
				look = tvwActive.SelectedNode.Text;
			else
			if(txtActive != null)
				look = txtActive.SelectedText;

			if(frmFind.Show(this, look) == DialogResult.OK)
			{	findString = frmFind.findValue;
				mnuEditFindNext_Click(sender, e);
			}

		}
		private void mnuEditFindNext_Click(object sender, EventArgs e)
		{	
			
			if(findString == null)
				mnuEditFind_Click(sender, e);
			else
			if(findString != null && txtActive != null)
			{

				int oindex = txtActive.SelectionStart + txtActive.SelectionLength;
				int index;

				index = txtActive.Text.IndexOf(findString, oindex);

				if(index == -1)
				{	index = txtActive.Text.IndexOf(findString);
					if(index >= oindex)
						lblStatus.Text += "No more";
				}

				if(index == -1)
					lblStatus.Text += "Not found";

				if(index != -1)
				{	txtActive.SelectionStart = index;
					txtActive.SelectionLength = findString.Length;
				}

			}

		}
		private void mnuEditReplace_Click(object sender, EventArgs e)
		{	Replace frmReplace = new Replace();

			if(frmReplace.Show(this, txtMachine.SelectedText, Clipboard.GetText()) == DialogResult.OK)
				if(Regex.IsMatch(txtMachine.Text, "\\b" + frmReplace.newValue + "\\b") == false)
					txtMachine.Text = Regex.Replace(txtMachine.Text, "\\b" + frmReplace.oldValue + "\\b", frmReplace.newValue);
				else
					MessageBox.Show(frmReplace.newValue + " already exists and will conflict if replaced");

		}
		private void mnuHelpNotes_Click(object sender, EventArgs e)
		{
			Help frmHelp = new Help();
			frmHelp.ShowDialog(this);
		}
		private void mnuEditCopyPrecedenceList_Click(object sender, EventArgs e)
		{
			string[] parts = txtCode.Text.Split(new string[] {codesep}, StringSplitOptions.None);
			parts[0] = parts[0].TrimStart();
			Clipboard.SetText(parts[0]);
			Clipboard.GetText();
			MessageBox.Show("Copied " + parts[0].Length + " characters");
		}
		private void mnuEditCopyStateList_Click(object sender, EventArgs e)
		{
			string[] parts = txtCode.Text.Split(new string[] {codesep}, StringSplitOptions.None);
			parts[1] = parts[1].TrimStart();
			Clipboard.SetText(parts[1]);
			Clipboard.GetText();
			MessageBox.Show("Copied " + parts[1].Length + " characters");
		}
		private void mnuCopyParser_Click(object sender, EventArgs e)
		{
			string[] parts = txtCode.Text.Split(new string[] {codesep}, StringSplitOptions.None);
			parts[2] = parts[2].TrimStart();
			Clipboard.SetText(parts[2]);
			Clipboard.GetText();
			MessageBox.Show("Copied " + parts[2].Length + " characters");
		}
		private void mnuCopyFSA_Click(object sender, EventArgs e)
		{
			string[] parts = txtCode.Text.Split(new string[] {codesep}, StringSplitOptions.None);
			parts[3] = parts[3].TrimStart();
			Clipboard.SetText(parts[3]);
			Clipboard.GetText();
			MessageBox.Show("Copied " + parts[3].Length + " characters");
		}
		#endregion

		#region Admin
		private void invalidateParse()
		{
			if(internalUpdate == true)
				return;
			txtOutput.BackColor = tvwAST.BackColor = txtCode.BackColor = Color.Pink;
			tmrUpdate.Enabled = false;
			tmrUpdate.Interval = autoRefresh;
			tmrUpdate.Enabled = true;
		}
		private void output(string message)
		{
			txtOutput.Text += message + "\n";
		}
		private string[] trim(string[] original)
		{
			string[] update = new string[original.Length];
			for(int index = 0; index < original.Length; index++)
				update[index] = original[index].Trim();
			return update;
		}
		private StringBuilder generateBuilder = new StringBuilder();
		private void generate()
		{	txtCode.Text += generateBuilder.ToString();
			generateBuilder = new StringBuilder();
		}
		private void generate(string code)
		{	generateBuilder.AppendLine(code);
		}
		private void generateEx(string code)
		{	generateBuilder.Append(code);
		}
		private void generateError(string error)
		{	generateBuilder.Insert(0, error);
		}
		#endregion

		#region ParseMachine
		private void parse()
		{
			if(loaded == true)
				parse(txtMachine.Text, txtInput.Text);
		}
		private void parse(string machine, string input)
		{
			Mappings mappings;

			txtOutput.Text = "";
			txtCode.Text = "";
			prettyPrint();
			generate("package real.ast;");
			generate("");
			generate("/*");
			generate(" * @author autogenerated from autoxt");
			generate(" */");
			generate("public class AstPrecedenceList");
			generate("{   public static final int AST_NONE = -1;");
			mappings = parseMachine(machine);
			generate("}");
			generate(codesep);
			parseInput(mappings, input);
			generateCode(mappings);


		}
		private void prettyPrint()
		{
			StringBuilder rtf = new StringBuilder();
			int index;
			List<string> macroNames = new List<string>();

			rtf.Append(@"{\rtf1\ansi\ansicpg1252\deff0\deflang2057{\fonttbl{\f0\fnil\fcharset0 Courier New;}\colortbl;");
			rtf.Append(@"\red0\green0\blue0;");			// 1. Normal
			rtf.Append(@"\red195\green195\blue195;");	// 2. Comment
			rtf.Append(@"\red0\green0\blue255;");		// 3. State identifier
			rtf.Append(@"\red127\green127\blue127;");	// 4. Operator
			rtf.Append(@"\red127\green0\blue0;");		// 5. Macro name
			rtf.Append(@"\red255\green0\blue0;");		// 6. Special character
			rtf.AppendLine("}");
			rtf.Append(@"\viewkind4\uc1\pard\f0\fs17 ");
			foreach(string constLine in txtMachine.Lines)
			{	string Line = constLine.Replace(@"\", @"\\").Replace("{", @"\{").Replace("}", @"\}");

				if((index = Line.IndexOf("##")) != -1)
					Line = Line.Insert(index, @"\cf2 ");

				foreach(string macroName in macroNames)
					Line = Regex.Replace(Line, @"\b" + macroName + @"\b\s*", @"\cf5 $0\cf1 ");

				if(Line.Contains(":=") == true)
				{
					macroNames.Add(trim(Line.Split(new string[] { ":=" }, StringSplitOptions.None))[0]);
					Line = Line.Insert(0, @"\cf5 ");
					Line = Regex.Replace(Line, @":=\s*", @"\cf4 $0\cf1 ");
				}
				else
				if(Line.Contains("->") == true)
				{

					index = Line.IndexOf("->") - 1;
					int indexex = Line.LastIndexOf(",", index) + 1;
					if(indexex != -1)
					{

						while(indexex < index && Line[indexex] <= 0x20)
							indexex++;
						while(index > indexex && Line[index] <= 0x20)
							index--;

						if(indexex <= index)
						{
							string Buffer = " " + Regex.Replace(Line.Substring(indexex, index - indexex + 1), @"^(\[.*?\])", @"\cf6 $1\cf1 ");
							Buffer = Regex.Replace(Buffer, @"([^\\])(-|\*|�|\$|�|%|#)", @"$1\cf6 $2\cf1 ");
							Line = Line.Remove(indexex, index - indexex + 1).Insert(indexex, Buffer.Substring(1));
							
							//Line = Line.Remove(indexex + 1, index - indexex).Insert(indexex + 1, Regex.Replace(Line, @"([^\\]|^)(-|\*|�|$|�|%|^\[|^\])", @"$1\cf6 $2\cf1 "));
						}

					}

					Line = Regex.Replace(Line, @"->\s*", @"\cf4 $0\cf3 ");
					Line = Line.Insert(0, @"\cf3 ");
					if((index = Line.IndexOf(",")) != -1)
						Line = Line.Insert(index, @"\cf1 ");
					index = Line.IndexOf("->");
					if((index = Line.IndexOf(",", index)) != -1)
						Line = Line.Insert(index, @"\cf1 ");

				}
				else
				if(Line.Contains("=>") == true)
				{
					Line = Regex.Replace(Line, @"=>\s*", @"\cf4 $0\cf3 ");
					Line = Line.Insert(0, @"\cf3 ");
					if((index = Line.IndexOf(",")) != -1)
						Line = Line.Insert(index, @"\cf1 ");
					index = Line.IndexOf("=>");
					if((index = Line.IndexOf(",", index)) != -1)
						if((index = Line.IndexOf(",", index + 1)) != -1)
							Line = Line.Insert(index, @"\cf1 ");
				}
				else
				if(Line.Contains("@=") == true)
				{
					Line = Regex.Replace(Line, @"@=\s*", @"\cf4 $0\cf3 ");
				}

				Line = Line.Insert(0, @"\cf1 ");

				//Line = Regex.Replace(Line, @"\s\s+", @"\cb5$0\cb0");

				rtf.Append(Line);
				rtf.AppendLine(@"\par");

			}
			rtf.AppendLine(@"}");

			internalUpdate = true;
			Point pt = new Point();
			SendMessage(txtMachine.Handle, 0x0400 + 221, 0, ref pt);
			int start = txtMachine.SelectionStart;
			int length = txtMachine.SelectionLength;
			txtMachine.Rtf = rtf.ToString();
			txtMachine.SelectionStart = start;
			txtMachine.SelectionLength = length;
			SendMessage(txtMachine.Handle, 0x0400 + 222, 0, ref pt);
			internalUpdate = false;

		}
		private Mappings parseMachine(string machine)
		{
			Mappings mappings = new Mappings();
			uniqueId = 0;

			try
			{

				// Split the machine into each of it's rules (one rule per line)
				string[] machineStatements = machine.Split('\n');
				string machineStatement = "";
				Macros macros = new Macros();
				bool doMerge = false;
				bool wantMerge = false;
				foreach(string constMachineStatement in machineStatements)
				{

					// Remove comments from statement
					string machineStatementTest = Regex.Replace(constMachineStatement, @"([^\\]|^)##.*", "$1").Trim();

					if(machineStatementTest.EndsWith("\\") == true)
					{	wantMerge = true;
						machineStatementTest.TrimEnd();
						machineStatementTest = machineStatementTest.Remove(machineStatementTest.Length - 1);
					}
					else
						wantMerge = false;

					if(doMerge == false)
						machineStatement = machineStatementTest;
					else
					{	machineStatement += machineStatementTest;
						doMerge = false;
					}

					if(wantMerge == true)
					{	doMerge = true;
						continue;
					}

					// Skip empty lines and comment lines (begin with #)
					if(machineStatementTest.Trim().Length == 0)
						continue;

					foreach(KeyValuePair<string, string> macro in macros)
						machineStatement = Regex.Replace(machineStatement, "\\b" + macro.Key + "\\b", macro.Value);

					try
					{

						if(machineStatement.Contains("=>") == true)
							parseTransitionEx(mappings, machineStatement);
						else
						if(machineStatement.Contains("->") == true)
							parseTransition(mappings, machineStatement);
						else
						if(machineStatement.Contains(":=") == true)
							parseMacro(macros, machineStatement);
						else
						if(machineStatement.Contains("@=") == true)
							parsePreprocess(machineStatement);

					}
					catch(Exception e)
					{	
						output("#EX# " + e.ToString());
					}

				}

			}
			catch(Exception e)
			{	
				output("#EX# " + e.ToString());
			}

			outputStates(mappings);
			validateParse(mappings);
			deterministic(mappings);

			return mappings;

		}
		private void parseTransition(Mappings mappings, string machineStatement)
		{

			// Split the rule into left and right parts (left=condition, right=action)
			string[] currentNextString = machineStatement.Split(new string[] { "->" }, StringSplitOptions.None);
			// Split left part into currentStateAndStack and symbol-list
			string[] lparts = currentNextString[0].Split(new char[] { ',' }, 2);
			string removed = null;

			CurrentState currentState;
			lparts[0] = lparts[0].Trim();
			lparts[1] = lparts[1].Trim();

			// Set the specified currentStateAndStack as the active currentStateAndStack (creating it first if necessary)
			if(mappings.ContainsKey(lparts[0]) == false)
			{
				currentState = mappings[lparts[0]] = new CurrentState();
				currentState.stateName = lparts[0];
			}
			else
				currentState = mappings[lparts[0]];

			// Parpare to parse symbols
			NextState nextState = null;
			bool range = false;
			char symbol = char.MinValue;
			char esymbol;

			// Prepare the next currentStateAndStack; the currentStateAndStack that will be reached by transitioning through any one of the symbols matched
			//	This is set once and several transitions are created, one for each symbol, and each one is linked to this one next currentStateAndStack
			nextState = new NextState();
			string[] rparts = currentNextString[1].Split(new char[] { ',' }, 2);
			// If the transition currentStateAndStack also specifies a return currentStateAndStack, split it and store as a call to currentStateAndStack, return to return-currentStateAndStack
			string[] cparts = rparts[0].Split(':');
			if(cparts.Length == 2)
			{	nextState.stateName = cparts[0].Trim();
				nextState.returnStateName = cparts[1].Trim();
			}
			else
			{	nextState.stateName = rparts[0].Trim();
				nextState.isError = nextState.stateName.Length == 0;
			}

			if(rparts.Length > 1)
				nextState.action = rparts[1].Trim();
			else
				nextState.action = "";

			// If a \ is read (it's a control symbol) then the next symbol is going to be a special symbol
			//	This will be true when the next symbol to be read is to be a special symbol
			bool control = false;

			// If a / is read then switch in/out of remove mode (where a regular expression can be defined
			//	that will remove symbols, so /b-d/a-e will use symbols a-e but remove symbols b-d (so will be
			//	a, e)
			bool remove = false;
			// Regular expression for removal - any symbol that matches the string is removed
			string removeRegEx = "";

			// If a # is read, the next 3 characters are the decimal ASCII number of the symbol to add
			int code = -1;
			char ascii = (char)0;

			// Parse the transition symbol list
			for(int i = 0; i < lparts[1].Length; i++)
			{

				// Read the symbol
				esymbol = lparts[1][i];


				if(code > -1)
				{	ascii += (char)((esymbol - '0') * Math.Pow(10, code));
					code--;
					if(code == -1)
					{	esymbol = ascii;
						ascii = (char)0;
						control = true;
					}
					else
						continue;
				}

				// Process special symbols

				// Deal with special symbols
				//	Special symbols are made literal by prefixing with the (special) control '\' symbol
				// Read a control symbol, next symbol is the important one, so 'continue' over this one
				if(esymbol == '\\' && control == false)
				{	control = true;
					continue;
				}

				if(control == false)
					if(esymbol == '[')
					{	remove = true;
						removeRegEx = "[";
						continue;
					}
					else
					if(esymbol == ']')
					{	remove = false;
						removeRegEx += "]";
						continue;
					}

				if(remove == true)
				{	removeRegEx += esymbol;
					if(control == true)
						control = false;
					continue;
				}

				// When the control symbol '\' is read, the next symbol is a literal.
				//	i.e., a-d is range a, b, c, d; a\-d is a, literal -, d (a, -, d)
				if(control == true)
					// Do nothing; basically this by-passes the special processing done below, so it becomes a literal
					control = false;
				else
				// Read a range symbol, previous symbol is start, next symbol is end (inclusive)
				if(esymbol == '-')
				{	range = true;
					continue;
				}
				else
				if(esymbol == '%')
				{	code = 2;
					continue;
				}
				else
				if(esymbol == '�')
					esymbol = SpecialSymbolTable.Epsilon;
				else
				if(esymbol == '$')
					esymbol = SpecialSymbolTable.Else;
				else
				if(esymbol == '�')
					esymbol = SpecialSymbolTable.ConsumeElse;
				else
				if(esymbol == '*')
					esymbol = SpecialSymbolTable.All;
				else
				if(esymbol == '#')
					esymbol = SpecialSymbolTable.EOF;


				// Process literal symbols


				// Symbol is stored as end symbol initally, then moved to the start symbol and stored. That way, if
				//	a range is set, the start symbol will still be loaded into the start (and now that it's determined
				//	to be a range, not overwritten by the end symbol (so symbol=esymbol only happens if it's not a range).
				//	If it is a range, the symbol is incremented by one also, this is because the symbol will already have
				//	been stored when it was first read. e.g., a-d, read a, store a, read -, set range mode, read d, being
				//	in range mode, a (still stored in symbol) is start, and d (only stored in esymbol) is end, then a is
				//	incremented to b and b, c, d is stored (along with a which was stored previously)
				if(range == false)
					symbol = esymbol;
				else
					symbol++;

				if(esymbol == SpecialSymbolTable.All)
				{	symbol = (char)0;
					esymbol = (char)255;
				}

				// Store ranges as each symbol individually
				for(char s = symbol; s <= esymbol; s++)
				{

					if(removeRegEx.Length != 0 && Regex.IsMatch(s.ToString(), removeRegEx) == true)
					{	if(removed == null)
							removed = s.ToString();
						else
							removed += ", " + s;
						continue;
					}

					// Add a list of currentStateAndStackList which are reachable by this single symbol
					NextStates nextStates;
					if(currentState.map.ContainsKey(s) == false)
						nextStates = currentState.map[s] = new NextStates();
					else
						nextStates = currentState.map[s];
					nextStates.states.Add(nextState);

				}

				// Disable range mode
				range = false;

			}

			if(removed != null)
				output("Removed symbols: (" + removed + ")");

		}
		private void parseTransitionEx(Mappings mappings, string machineStatement)
		{

			string[] currentNextString = machineStatement.Split(new string[] { "=>" }, StringSplitOptions.None);
			string[] lparts = trim(currentNextString[0].Split(new char[] { ',' }, 3));
			string[] rparts = trim(currentNextString[1].Split(new char[] { ',' }, 3));
			string name = lparts[0];
			string nextName;
			string[] actionGroups;
			string actions = null;
			string actionsOnSuccess = null;
			string actionsOnStart = null;
			string actionsOnFail = null;

			if(lparts.Length != 2 && lparts.Length != 3)
			{	output("error: bad l-part in " + machineStatement);
				return;
			}

			if(rparts.Length < 2)
			{	output("error: bad r-part in " + machineStatement);
				return;
			}

			// If any actions are defined, split them up into their groups
			if(rparts.Length >= 3)
			{	actionGroups = trim(rparts[2].Split(';'));
				actionsOnSuccess = (actionGroups.Length > 1 ? actionGroups[1] : actionGroups[0]);
				actionsOnStart = (actionGroups.Length > 1 ? actionGroups[0] : null);
				actionsOnFail = (actionGroups.Length > 2 ? actionGroups[2] : null);
			}

			actions = actionsOnStart;
			for(int i = 0; i < lparts[1].Length; i++)
			{

				if(i < lparts[1].Length - 1 || lparts.Length == 3)
				{	nextName = "_" + uniqueId.ToString(format);
					uniqueId++;
				}
				else
				{	nextName = rparts[0];
					actions = actionsOnSuccess;
				}

				// Must match while reading characters
				newMachineStatement(mappings, name, lparts[1][i].ToString(), nextName, (i == 0 ? null : rparts[1]), actions, actionsOnFail);

				name = nextName;
				actions = null;

			}

			if(lparts.Length == 3)
			{

				nextName = rparts[0];
				// Must mismatch at end (as last character will be what it should not be)
				newMachineStatement(mappings, name, lparts[2], rparts[1], nextName, actionsOnFail, actionsOnSuccess);

			}


		}
		private void newMachineStatement(Mappings mappings, string name, string symbol, string matchNext, string mismatchNext, string matchActions, string mismatchActions)
		{	string newMachineStatement;

			newMachineStatement = name + ", " + symbol + " -> " + matchNext + (matchActions != null ? ", " + matchActions : "");;
			parseTransition(mappings, newMachineStatement);
//			output("New mapping: " + newMachineStatement);
			if(mismatchNext != null)
			{	newMachineStatement = name + ", $ -> " + mismatchNext + (mismatchActions != null ? ", " + mismatchActions : "");
				parseTransition(mappings, newMachineStatement);
//				output("New mapping: " + newMachineStatement);
			}

		}
		private void parseMacro(Macros macros, string machineStatement)
		{

			string[] parts = machineStatement.Split(new string[] { ":=" }, StringSplitOptions.None);
			macros[parts[0].Trim()] = parts[1].Trim();
			string pre = parts[1].Trim();
			if(pre.StartsWith("i") == true
			|| pre.StartsWith("o") == true
			|| pre.StartsWith("m") == true)
				pre = pre.Substring(1).Trim();
			int result;
			if(int.TryParse(pre, out result) == true)
				generate("    public static final int " + parts[0].Trim() + " = " + (result == -1 ? "AST_NONE" : result.ToString()) + ";");

		}
		private void parsePreprocess(string machineStatement)
		{

			string[] parts = trim(machineStatement.Split(new string[] { "@=" }, StringSplitOptions.None));

			if(parts[0] == "start")
				startState = parts[1];
			else
			if(parts[0] == "final")
				finalStates = new List<string>(trim(parts[1].Split(',')));

		}
		private void outputStates(Mappings mappings)
		{	Set names = new Set();
			foreach(KeyValuePair<string, CurrentState> cs in mappings)
				names.Add(cs.Key.TrimEnd('0', '1', '2', '3', '4', '5', '6', '7', '8', '9'));
			output("States in use: " + names);
		}
		private void validateParse(Mappings mappings)
		{
			List<string> used = new List<string>();
			used.Add(startState);
			// Check that all currentStateAndStackList specified as transition currentStateAndStackList exist as actual currentStateAndStackList (no where to go if not)
			Set notExist = new Set();
			Set notExistRetrun = new Set();
			Set badReturn = new Set();
			Set notUsed = new Set();
			foreach(KeyValuePair<string, CurrentState> cs in mappings)
				foreach(KeyValuePair<char, NextStates> ns in cs.Value.map)
					foreach(NextState s in ns.Value.states)
					{
						if(s.action == "error")
							continue;
						if(s.stateName.Length != 0 && mappings.ContainsKey(s.stateName) == false && finalStates.Contains(s.stateName) == false)
							notExist.Add(s.stateName);
						if(s.returnStateName.Length != 0 && mappings.ContainsKey(s.returnStateName) == false)
							notExistRetrun.Add(s.returnStateName);
						if(s.stateName.Length == 0 && s.returnStateName.Length != 0)
							badReturn.Add(cs.Key + ":" + ns.Key);
						// Add the called currentStateAndStack to the list of used currentStateAndStackList. Any actual currentStateAndStackList found that are not in this list
						//	are not used
						if(used.Contains(s.stateName) == false)
							used.Add(s.stateName);
						if(used.Contains(s.returnStateName) == false)
							used.Add(s.returnStateName);
					}

			// Check that all currentStateAndStackList specified as actual currentStateAndStackList were used by a transition currentStateAndStack (useless currentStateAndStackList if not)
			foreach(KeyValuePair<string, CurrentState> cs in mappings)
				if(used.Contains(cs.Key) == false)
					notUsed.Add(cs.Key);

			//if(notExist != null) output("Not exist: (" + notExist + ")");
			if(notExist.hasItems == true) output("Not exist: " + notExist);
			if(notExistRetrun.hasItems == true) output("Return not exist: " + notExistRetrun);
			if(badReturn.hasItems == true) output("Bad return, no call: " + badReturn);
			if(notUsed.hasItems == true) output("Not used: " + notUsed);

		}
		private void deterministic(Mappings mappings)
		{

			foreach(CurrentState fromState in mappings.Values)
				foreach(KeyValuePair<char, NextStates> map in fromState.map)
					if(map.Value.states.Count != 1)
					{	output("Non-deterministic from " + fromState.stateName + " on " + map.Key + " : goes to " + map.Value.states.Count + " states..");
						foreach(NextState toState in map.Value.states)
							output("  " + toState.stateName);
					}

		}
		#endregion

		#region ParseInput
		private void parseInput(Mappings map, string input)
		{
			ParseData pd = new ParseData();
			pd.map = map;
			pd.input = input;

			// Don't do a pasing when 
			internalUpdate = true;

			// Clear the AST
			tvwAST.Nodes.Clear();

			pd.index = 0;
			// Where scanned data is stored by name (number, identifier, etc)
			pd.store = new SymbolStore();
			// List of current currentStateAndStackList active in the non-deterministic automaton
			pd.currentStateAndStackList = new List<CurrentStateAndStack>();
			// List of next currentStateAndStackList that will become active after all possible non-deterministic transitions have been followed
			List<CurrentStateAndStack> nextStateAndStackList;
			// Stack of AST nodes
			pd.stateStack = new StateStack();
			// Stack of characters read that need to be matched, such as ( { [ with ] } )
			pd.symbolStack = new SymbolStack();
			// Whether parsing is still successful
			bool success = true;
			// The current node in the AST from which new nodes are added
			pd.activeNode = tvwAST.Nodes.Add("Root (-1)");
			pd.activeNode.Tag = -1;
			pd.stateStack.Push(pd.activeNode);
			// When an open bracket is reached, the next node is appended. When a close bracket is reached, the next node is inserted
			//	This == false means appends (new node is child of this), true means insert (this node is child of new, new takes this node's position)
			pd.insert = false;
			bool consume = true;
			pd.killwhitey = true;
			int misconsumed = 0;
			int contIndex = 0;
			bool yeay = false;

			// Remember the selection before changing it; it is changed to set colours
			int start = txtInput.SelectionStart;
			int length = txtInput.SelectionLength;
			txtInput.SelectAll();
			txtInput.SelectionBackColor = Color.FromKnownColor(KnownColor.Window);

			try
			{

				output("� == epsilon transition ; $ == else transition ; � == else (consume) transition");
				output("");

				// Before starting, prepare the start currentStateAndStack
				if(startState != null && map.ContainsKey(startState) == true)
					pd.currentStateAndStackList.Add(new CurrentStateAndStack(map[startState]));
				else
					output("No start state");

				// Loop until all input is consumed
				while(pd.index <= input.Length || pd.symbol == SpecialSymbolTable.EOF && consume == false)
				{

					if(contIndex++ >= 500)
						if(MessageBox.Show(this, "Taking a long time.. Continue working?", "Continue?", MessageBoxButtons.YesNo) == DialogResult.No)
							success = false;
						else
							contIndex = 0;

					consume = true;

					// Read and highlight the next symbol from the input
					if(pd.index < input.Length)
						pd.symbol = input[pd.index];
					else
						pd.symbol = SpecialSymbolTable.EOF;
					txtInput.SelectionStart = pd.index;
					txtInput.SelectionLength = 1;

					// Ignore outright all white-space characters ( [ a b + c ] === [ab+c] )
					//	Can be disabled where needed, e.g., when parsing in strings "a b"
					if(pd.symbol <= ' ' && pd.killwhitey == true)
					{	pd.index++;
						txtInput.SelectionBackColor = Color.Gray;
						continue;
					}

					// Output an unwind message
					pd.output = " �  ";

					// Add all epsilon currentStateAndStackList from the current currentStateAndStackList
					success = unwindStates(pd);
					// Clear out the next transition currentStateAndStack list
					nextStateAndStackList = new List<CurrentStateAndStack>();

					// If epsilon transitions were added, output which ones
					if(pd.output.Length != 4)
						output(pd.output);

					// Add the symbol read followed by a set of currently active currentStateAndStackList
					if(pd.index < input.Length)
						pd.output = "'" + input[pd.index] + ", " + pd.symbol + "' ";
					else
						pd.output = "'EOF, EOF' ";
					pd.output += "{";
					bool first = true;
					foreach(CurrentStateAndStack currentStateAndStack in pd.currentStateAndStackList)
					{	if(first == true) first = false; else pd.output += ", ";
						pd.output += currentStateAndStack.state.stateName;
						bool worst = true;
						if(currentStateAndStack.stack.Count > 0)
						{	pd.output += "(";
							foreach(string item in currentStateAndStack.stack)
							{	if(worst == true) worst = false; else pd.output += ", ";
								pd.output += item;
							}
							pd.output += ")";
						}
					}
					pd.output += "} -> ";

					// Output (and add to transition list) all currentStateAndStackList reachable from the current matching the current symbol
					pd.output += "{";
					first = true;
					foreach(CurrentStateAndStack currentStateAndStack in pd.currentStateAndStackList)
						if(currentStateAndStack.state.map.ContainsKey(pd.symbol) == true)
							foreach(NextState nextState in currentStateAndStack.state.map[pd.symbol].states)
							{	if(first == true) first = false; else pd.output += ", ";
								if(nextState.isError == true)
								{	pd.output += nextState.action;
									success = false;
								}
								else
								if(nextState.IsNormal == true)
									pd.output += nextState.stateName;
								else
								if(nextState.IsCall == true)
									pd.output += ">" + nextState.stateName;
								else
								if(nextState.IsReturn == true)
									pd.output += "<" + currentStateAndStack.stack.Peek();
								addNextState(currentStateAndStack, nextStateAndStackList, map, nextState);
								if(actionExecute(pd, pd.symbol, trim(nextState.action.Split(','))) == false)
									success = false;
							}
						else
						{

							// If no symbol matched in the current currentStateAndStack, and an else transition exists, follow it
							if(currentStateAndStack.state.map.ContainsKey(SpecialSymbolTable.Else) == true)
							{
								pd.output = " $ " + pd.output.Substring(3);
								foreach(NextState nextState in currentStateAndStack.state.map[SpecialSymbolTable.Else].states)
								{	if(first == true) first = false; else pd.output += ", ";
									if(nextState.isError == true)
									{	pd.output += nextState.action;
										success = false;
									}
									else
									if(nextState.IsNormal == true)
										pd.output += nextState.stateName;
									else
									if(nextState.IsCall == true)
										pd.output += ">" + nextState.stateName;
									else
									if(nextState.IsReturn == true)
										pd.output += "<" + currentStateAndStack.stack.Peek();
									addNextState(currentStateAndStack, nextStateAndStackList, map, nextState);
									if(actionExecute(pd, SpecialSymbolTable.Else, trim(nextState.action.Split(','))) == false)
										success = false;
									consume = false;
								}
							}

							// If no symbol matched in the current currentStateAndStack, and an consuming else transition exists, follow it
							if(currentStateAndStack.state.map.ContainsKey(SpecialSymbolTable.ConsumeElse) == true)
							{
								pd.output = " � " + pd.output.Substring(3);
								foreach(NextState nextState in currentStateAndStack.state.map[SpecialSymbolTable.ConsumeElse].states)
								{	if(first == true) first = false; else pd.output += ", ";
									if(nextState.isError == true)
									{	pd.output += nextState.action;
										success = false;
									}
									else
									if(nextState.IsNormal == true)
										pd.output += nextState.stateName;
									else
									if(nextState.IsCall == true)
										pd.output += ">" + nextState.stateName;
									else
									if(nextState.IsReturn == true)
										pd.output += "<" + currentStateAndStack.stack.Peek();
									addNextState(currentStateAndStack, nextStateAndStackList, map, nextState);
									if(actionExecute(pd, SpecialSymbolTable.ConsumeElse, trim(nextState.action.Split(','))) == false)
										success = false;
								}
							}

						}
					pd.output += "}";
					output(pd.output);

					// If no new currentStateAndStackList was reached, then there were no transitions in all current currentStateAndStackList that matched or 'elsed' the current symbol, so
					//	there's nowhere to go - output error and end parsing
					if(nextStateAndStackList.Count == 0/* && pd.symbol == SpecialSymbolTable.EOF*/)
					{	output("Error: no more states");
						success = false;
					}
					else
					if(pd.symbol == SpecialSymbolTable.EOF && nextStateAndStackList.Contains(pseudoEndState) == true)
					{	output("Yeay! parsed");
						yeay = true;
					}

					// Colour the symbol depending on whether it was successfully parsed
					if(success == true)
						txtInput.SelectionBackColor = Color.Green;
					else
						txtInput.SelectionBackColor = Color.Red;

					// Sanity check!

					// If a symbol has not been consumed in the last N consecutive runs of the loop, it's probably a bug. Generated error and stop parsing
					if(consume == false)
						misconsumed++;
					else
						misconsumed = 0;

					if(misconsumed >= 50)
					{	output("Misconsumed 50 times! Stopping");
						success = false;
					}

					// If there are lots of entries added to the 
					if(nextStateAndStackList.Count > 50)
					{	output("NDFSA is tracking more than 50 branches! Stopping!");
						success = false;
					}


					// Exit the loop if there were parse errors
					if(success == false)
						break;

					// Go to the next symbol
					if(consume == true)
						pd.index++;
					// Replace the set of current currentStateAndStackList with the new set of transition currentStateAndStackList
					pd.currentStateAndStackList = nextStateAndStackList;

				}

			}
			catch(Exception e)
			{
				output("Failed parse because + " + e.ToString());
				output(pd.output);
				success = false;
			}

			if(yeay == false && success == true)
			{	output("Error: no more input");
				success = false;
			}


			// Restore selection
			txtInput.SelectionStart = start;
			txtInput.SelectionLength = length;

			if(success == false)
				txtOutput.Text = "##ERRORS##\n" + txtOutput.Text;

			internalUpdate = false;

		}
		private void addNextState(CurrentStateAndStack currentStateAndStack, List<CurrentStateAndStack> nextStateAndStackList, Mappings map, NextState nextState)
		{
			

			if(nextState.IsNormal == true)
				if(map.ContainsKey(nextState.stateName) == false && finalStates.Contains(nextState.stateName) == true)
					nextStateAndStackList.Add(pseudoEndState);
				else
					nextStateAndStackList.Add(new CurrentStateAndStack(map[nextState.stateName], currentStateAndStack.stack));
			else
			if(nextState.IsCall == true)
				if(map.ContainsKey(nextState.stateName) == false && finalStates.Contains(nextState.stateName) == true)
					nextStateAndStackList.Add(pseudoEndState);
				else
				// Passing the last parameter pushes that entry onto the cloned symbolStack after cloning so as not to affect this 'current' symbolStack
					nextStateAndStackList.Add(new CurrentStateAndStack(map[nextState.stateName], currentStateAndStack.stack, nextState.returnStateName));
			else
			if(nextState.IsReturn == true)
				if(map.ContainsKey(currentStateAndStack.stack.Peek()) == false && finalStates.Contains(currentStateAndStack.stack.Peek()) == true)
					nextStateAndStackList.Add(pseudoEndState);
				else
					// Passing null as the last parameter clones the symbolStack and pops the top element; it is not popped here as
					//	this state may be used again for a different transition so the symbolStack must remain unaffected here
					nextStateAndStackList.Add(new CurrentStateAndStack(map[currentStateAndStack.stack.Peek()], currentStateAndStack.stack, null)); // null has meaning here and is not the same as not passing a second parameter
				
		}
		private bool actionExecute(ParseData pd, char symbol, string[] action)
		{

			int i = 0;
			while(i < action.Length)
			{

				if(action[i] == "whitespace")
				{
					if(action[i + 1] == "parse")
						pd.killwhitey = false;
					else
					if(action[i + 1] == "ignore")
						pd.killwhitey = true;
					else
					{	output("Error, whitespace mode must be either 'parse' or 'ignore'");
						return false;
					}
					i += 2;
				}
				else
				if(action[i] == "start")
				{
					pd.start = pd.index;
					i++;
				}
				else
				if(action[i] == "stop")
				{
					pd.stop = pd.index;
					i++;
				}
				else
				if(action[i] == "symbol_push")
				{
					pd.symbolStack.Push(action[i + 1][0]);
					pd.output += " s_push('" + action[i + 1][0] + "', " + pd.symbolStack.Count + ")";
					i += 2;
				}
				else
				if(action[i] == "symbol_pop")
				{
					char top = pd.symbolStack.Pop();
					pd.output += " s_pop('" + action[i + 1][0] + "', '" + top + "', " + pd.symbolStack.Count + ")";
					if(top != action[i + 1][0])
					{
						output("Error, expected " + top + ", found " + action[i + 1].Trim()[0]);
						return false;
					}
					i += 2;
				}
				else
				if(action[i] == "push")
				{
					pd.stateStack.Push(pd.activeNode);
					pd.output += " push('" + pd.activeNode.Text + "')";
					pd.output += " {";
					bool first = true;
					foreach(TreeNode node in pd.stateStack.ToArray())
					{	if(first == true) first = false; else pd.output += ", ";
						pd.output += node.Text;
					}
					pd.output += "}";
					i++;
				}
				else
				if(action[i] == "pop")
				{
					pd.activeNode = pd.stateStack.Pop();
					pd.output += " pop('" + pd.activeNode.Text + "')";
					pd.insert = true;
					pd.output += " {";
					bool first = true;
					foreach(TreeNode node in pd.stateStack.ToArray())
					{	if(first == true) first = false; else pd.output += ", ";
						pd.output += node.Text;
					}
					pd.output += "}";
					i++;
				}
				else
				if(action[i] == "top")
				{
					pd.activeNode = pd.stateStack.Peek();
					pd.output += " top('" + pd.activeNode.Text + "')";
					pd.insert = false;
					i++;
				}
				else
				if(action[i] == "navigate")
				{	int child;

					pd.output += " nav('" + pd.activeNode.Text + ", ";
					if(action[i + 1] == "parent")
						pd.activeNode = pd.activeNode.Parent;
					else
					if(action[i + 1] == "next")
						pd.activeNode = pd.activeNode.NextNode;
					else
					if(action[i + 1] == "prev")
						pd.activeNode = pd.activeNode.PrevNode;
					else
					if(int.TryParse(action[i + 1], out child) == true)
						if(child >= 0)
							pd.activeNode = pd.activeNode.Nodes[child];
						else
							pd.activeNode = pd.activeNode.Nodes[pd.activeNode.Nodes.Count - child];
					else
					{	output("Error, navigate must be 'parent', 'next', 'prev', or -N..(N-1)");
						return false;
					}
					pd.output += pd.activeNode.Text + ")";
					i += 2;
				}
				else
				if(action[i] == "node")
				{	
					// Get modifier (append, merge, insert)
					NodeMode nodemode = NodeMode.append;
					int insertIndex = -1;
					if(action[i + 1][0] == 'm')
					{	action[i + 1] = action[i + 1].Substring(1);
						nodemode = NodeMode.merge;
					}
					else
					if(action[i + 1][0] == 'i')
					{	action[i + 1] = action[i + 1].Substring(1);
						nodemode = NodeMode.insert;
					}
					else
					if(action[i + 1][0] == 'o')
					{	action[i + 1] = action[i + 1].Substring(1);
						pd.insert = true;
						nodemode = NodeMode.overwrite;
					}
					// Log message
					pd.output += " node([" + nodemode.ToString() + "] " + action[i + 1] + ", " + action[i + 2] + ")";
					// Remember children if an insert is to be done
					TreeNode childNode = null;

					// Look for a place to add the node

					// If the node being added is not a special (start bracket) node
					if(int.Parse(action[i + 1]) != -1)
						// If the node being added is a special (close brackey) node
						if(int.Parse(action[i + 1]) == -2)
						{	pd.output += pd.activeNode.Text;
							// Search for the start bracket and set it up (insert=true) so that the next node added
							//	will be added as a parent to this start bracket node
							while((int)pd.activeNode.Tag != -1)
							{	childNode = pd.activeNode;
								pd.activeNode = pd.activeNode.Parent;
							}
							pd.insert = true;
						}
						else
						// If the node being added is a typical node
							// Search until a node of lower or equal importance is found (up until a start bracket)
							//  and set the last looked at node as the child to the new node to be added (which is
							//	appended to this node and the child is appened to it)
							while
							(	(int)pd.activeNode.Tag != -1
							 &&(nodemode != NodeMode.insert && ((int)pd.activeNode.Tag) > int.Parse(action[i + 1])
							 ||	nodemode == NodeMode.insert && ((int)pd.activeNode.Tag) >= int.Parse(action[i + 1]))
							){	childNode = pd.activeNode;
								pd.activeNode = pd.activeNode.Parent;
							}
					else
						if(nodemode == NodeMode.merge)
							while((int)pd.activeNode.Tag != -1)
							{	childNode = pd.activeNode;
								pd.activeNode = pd.activeNode.Parent;
							}

					// Add the node

					// Only add the node if the node added is not actually a search for start bracket command
					if(int.Parse(action[i + 1]) != -2)
					{
						// Extension: split on ; so a store can be referenced (AST.STORE)
						string[] pars = action[i + 2].Split('.');
						// If a store is referenced, capture the store's value and clear it
						if(pars.Length > 1)
						{	string name = pars[1];
							if(name == "*")
							{	if(pd.start >= pd.stop)
									pd.stop = pd.index;
								pars[1] = pd.input.Substring(pd.start, pd.stop - pd.start);
							}
							else
							{
								pars[1] = pd.store[name];
								pd.store[name] = "";
							}
						}
						// If the previous node added was a search start bracket command, the next node will be in insert mode
						//	so insert this node in place of the current (start bracket) node
						if(pd.insert == true)
						{	// Only insert once per search start bracket command
							pd.insert = false;
							// Search start bracket command will have set the activenode as the bracket node, so it's becoming the child
							//	and the new node is taking its place
							childNode = pd.activeNode;
							pd.activeNode = pd.activeNode.Parent;
							// Because the search start bracket command placed a *'d item as the active item, the previous search for
							//	ordering didn't happen (as it stops when it hits a *'d item) so do a special-case search for correct
							//	ordering. i.e., this item may become a grandparent of this item (and not do the insert, but a typical
							//	append (except above the start bracket node))
							if(int.Parse(action[i + 1]) != -1)
								while
								(	(int)pd.activeNode.Tag != -1
								 &&(nodemode != NodeMode.insert && ((int)pd.activeNode.Tag) > int.Parse(action[i + 1])
								 ||	nodemode == NodeMode.insert && ((int)pd.activeNode.Tag) >= int.Parse(action[i + 1]))
								){	childNode = pd.activeNode;
									pd.activeNode = pd.activeNode.Parent;
								}
							else
								childNode = null;

							if(childNode != null)
								insertIndex = pd.activeNode.Nodes.IndexOf(childNode);

						}

						// Do actual adding of node

						// merge (reuse the current node if it has the same name)
						if(nodemode == NodeMode.merge && same(pd.activeNode.Text, pars[0]) == true)
							;
						else
						// insert (make parent a grandparent, insert a new parent, and make active the first child (happens later))
						if(nodemode == NodeMode.insert && same(pd.activeNode.Text, pars[0]) == true)
						{	childNode = pd.activeNode;
							pd.activeNode = pd.activeNode.Parent.Nodes.Add(pars[0] + (pars.Length > 1 ? " [" + pars[1] + "]" : "") + " (" + action[i + 1] + ")");
						}
						// append (add a child and make active the first child (happens later))
						else
						if(insertIndex != -1)
							pd.activeNode = pd.activeNode.Nodes.Insert(insertIndex, pars[0] + (pars.Length > 1 ? " [" + childNode.Text + "]" : "") + " (" + action[i + 1] + ")");
						else
							pd.activeNode = pd.activeNode.Nodes.Add(pars[0] + (pars.Length > 1 ? " [" + pars[1] + "]" : "") + " (" + action[i + 1] + ")");
						pd.activeNode.EnsureVisible();

						// If a child has been identified, it means the child needs to be resituated in the new active node (new created node)
						if(childNode != null)
						{	childNode.Remove();
							if(nodemode != NodeMode.overwrite)
							{	pd.activeNode.Nodes.Add(childNode);
								childNode.EnsureVisible();
							}
							else
							if(nodemode == NodeMode.overwrite)
							{	TreeNode[] nodes = new TreeNode[childNode.Nodes.Count];
								childNode.Nodes.CopyTo(nodes, 0);
								pd.activeNode.Nodes.AddRange(nodes);
							}
						}

						// Give the node a ordering value
						if(pd.activeNode.Tag == null)
							pd.activeNode.Tag = int.Parse(action[i + 1]);

					}
					i += 3;
				}
				else
				if(action[i] == "error")
				{	pd.output += "** error : " + action[i + 1];
					return false;
				}
				else
				if(action[i] == "store")
				{
					if(pd.store.ContainsKey(action[i + 1]) == false)
						pd.store[action[i + 1]] = "";
					pd.store[action[i + 1]] += pd.symbol;
					pd.output += " store('" + action[i + 1] + "', '" + pd.store[action[i + 1]] + "')";
					i += 2;
				}
				else
					i = action.Length;

			}

			return true;
		}
		private bool unwindStates(ParseData pd)//Mappings map, List<CurrentStateAndStack> currentStateAndStackList, SymbolStore store, SymbolStack stack, char symbol, ref string o, ref TreeNode activeNode, ref bool killwhitey)
		{	int index = 0;
			//bool insert = false;

			// Find all epsilon transitions from current state and add those to the current state

			while(index < pd.currentStateAndStackList.Count)
			{

				CurrentStateAndStack currentStateAndStack = pd.currentStateAndStackList[index];

				try
				{

					if(currentStateAndStack.state.map.ContainsKey(SpecialSymbolTable.Epsilon) == true)
					{
						pd.output += "(" + currentStateAndStack.state.stateName + ") {";
						bool first = true;
						foreach(NextState nextState in currentStateAndStack.state.map[SpecialSymbolTable.Epsilon].states)
						{	if(first == true) first = false; else pd.output += ", ";
								pd.output += nextState.stateName;
							// Add epsilon currentStateAndStackList off current currentStateAndStackList back into current currentStateAndStackList
							addNextState(currentStateAndStack, pd.currentStateAndStackList, pd.map, nextState);
							if(actionExecute(pd, SpecialSymbolTable.Epsilon, trim(nextState.action.Split(','))) == false)
								return false;
						}
						pd.output += "}";
					}

				}
				catch(Exception e)
				{	output("Error unwinding " + currentStateAndStack.state.stateName + " because " + e.ToString());
				}

				index++;

			}

			return true;

		}
		private bool same(string existing, string created)
		{
			if(existing.Length == created.Length)
				return existing == created;
			else
			if(existing.Length > created.Length)
				return existing.Substring(0, created.Length + 1) == created + " ";
			else
				return false;
		}
		#endregion

		#region GenerateCode
		private void generateCode(Mappings mappings)
		{

			try
			{

				generate("package real.parser;");
				generate("");
				generate("/**");
				generate(" * @author autogenerated from autoxt");
				generate(" */");
				generate("public enum ParseStateList");
				generate("{");
				generateStateList(mappings);
				generate("}");

				generate(codesep);

				generate("package real.parser;");
				generate("");
				generate("import real.ast.AstNode;");
				generateImports(mappings);
				generate("");
				generate("/**");
				generate(" * @author autogenerated from autoxt");
				generate(" */");
				generate("public class RealParser extends Parser");
				generate("{");
				generate("    ");
//				generateAssert(mappings);
//				generate("    @Override");
//				generate("    AstNode createRootAstNode()");
//				generate("    {   return new AstNodeStatementList();");
//				generate("    }");
//				generate("    ");
				generate("    @Override");
				generate("    protected ParseStateList getStartState()");
				generate("    {   return ParseStateList." + startState + ";");
				generate("    }");
				generate("    ");
				generate("    @Override");
				generate("    protected void parseSymbol() throws ParserException");
				generate("    {");
				generate("        ");
//				generateAssertCall();
				generate("        switch(getParseState())");
				generate("        {");
				generate("        ");
				generateStates(mappings);
				generate("        }");
				generate("        ");
				generate("    }");
				generate("    ");
				generate("}");

				generate(codesep);

				generateFSADraw(mappings);

				generate();

			}
			catch(Exception e)
			{
				generateError("*** " + e.ToString() + " ***");
				generate();
			}

		}

		private void generateStateList(Mappings mappings)
		{

			Dictionary<string, bool> builder = new Dictionary<string, bool>();

			foreach(CurrentState currentState in mappings.Values)
				builder.Add(currentState.stateName, true);

			string[] names = new string[builder.Count];
			builder.Keys.CopyTo(names, 0);
			Array.Sort(names);

			StringBuilder stateList = new StringBuilder();
			foreach(string name in names)
			{	if(stateList.Length + name.Length + 2 >= 77)
				{	generate("   " + stateList.ToString());
					stateList = new StringBuilder();
				}
				stateList.Append(" " + name + ",");
			}
			if(stateList.Length != 0)
				generate("   " + stateList.ToString());

		}
		private string[] getAstNodeNames(Mappings mappings)
		{	return getAstNodeNames(mappings, false);
		}
		private string[] getAstNodeNames(Mappings mappings, bool addIdentifier)
		{

			Dictionary<string, bool> Builder = new Dictionary<string, bool>();
			int wait = 0;
			string pre = "";

			if(addIdentifier == true)
				Builder.Add("AstNodeIdentifier", true);

			foreach(CurrentState currentState in mappings.Values)
				foreach(NextStates nextStates in currentState.map.Values)
					foreach(NextState nextState in nextStates.states)
						foreach(string action in trim(nextState.action.Split(',')))
							if(wait <= 0)
							{	if(action == "node")
									wait = 2;
							}
							else
							if(--wait == 1)
								pre = action.Trim();
							else
							if(wait == 0)
							{
								string a = action.Trim(new char[] { ' ', '.', '*' }) + "," + pre;
								if(Builder.ContainsKey(a) == false)
									Builder.Add(a, true);
							}

			string[] AstNodeNames = new string[Builder.Count];
			Builder.Keys.CopyTo(AstNodeNames, 0);
			Array.Sort(AstNodeNames);

			return AstNodeNames;

		}
		private void generateImports(Mappings mappings)
		{	string[] astNodeNames = getAstNodeNames(mappings, true);
			string lastAstNodeName = "";

			foreach(string AstNodeName in astNodeNames)
			{	if(lastAstNodeName != AstNodeName.Split(',')[0])
				{	lastAstNodeName = AstNodeName.Split(',')[0];
					generate("import real.ast." + lastAstNodeName + ";");
				}
			}
			
		}
		private void generateAssert(Mappings mappings)
		{	string[] AstNodeNames = getAstNodeNames(mappings);

			generate("    private void assertPrecedence()");
			generate("    {");
			generate("    ");

			foreach(string AstNodeName in AstNodeNames)
				generate("        assert new " + AstNodeName.Split(',')[0] + "().getPrecedence() == " + AstNodeName.Split(',')[1] + ";");

			generate("    ");
			generate("    }");
			generate("    ");

		}
		private void generateAssertCall()
		{	generate("        assertPrecedence();");
			generate("        ");
		}
		private void generateStates(Mappings mappings)
		{

			Dictionary<string, bool> builder = new Dictionary<string, bool>();

			foreach(CurrentState currentState in mappings.Values)
				builder.Add(currentState.stateName, true);

			string[] names = new string[builder.Count];
			builder.Keys.CopyTo(names, 0);
			//Array.Sort(names);

			foreach(string name in names)
				generateState(mappings, name);

		}
		private void generateState(Mappings mappings, string name)
		{	bool anyStates = false;
			CurrentState currentState = mappings[name];
			Dictionary<NextState, List<StateRange>> orGroup = new Dictionary<NextState, List<StateRange>>();
			
			generate("            case " + name + ":");
			generate("                parserTrace(\"(" + name + ", \" + getSymbol() + \") .. { \");");

			foreach(StateRange stateRange in generateStateRanges(currentState))
			{	if(orGroup.ContainsKey(stateRange.nextStates[0]) == false)
					orGroup[stateRange.nextStates[0]] = new List<StateRange>();
				orGroup[stateRange.nextStates[0]].Add(stateRange);
			}
			
			foreach(KeyValuePair<NextState, List<StateRange>> keyValue in orGroup)
			{	bool first = true;
				if(anyStates == true)
					generate("                else");

				generateEx("                if(");
				foreach(StateRange stateRange in keyValue.Value)
				{	
					string startOut;
					string stopOut;
					if(first == false)
					{	generate("");
						generateEx("                || ");
					}
					else
						first = false;
					startOut = generateSymbolFix(stateRange.start >= 32 && stateRange.start <= 127 ? "'" + stateRange.start + "'" : "(char)" + (int)stateRange.start);
					stopOut = generateSymbolFix(stateRange.stop >= 32 && stateRange.stop <= 127 ? "'" + stateRange.stop + "'" : "(char)" + (int)stateRange.stop);
					if(stateRange.start == stateRange.stop)
						generateEx("getSymbol() == " + startOut);
					else
						generateEx("getSymbol() >= " + startOut + " && getSymbol() <= " + stopOut);
					anyStates = true;
				}
				generate(")");
				generateTransition(keyValue.Key, true, false);
			}
			if(anyStates == true)
				generate("                else");

/*			if(currentState.map.ContainsKey(SpecialSymbolTable.EOF) != true)
			{	generate("                if(getSymbol() == SpecialSymbol.EOF)");
				generate("                    throwParserException");
				generate("                    (   \"Unexpected end of file.\"");
				generate("                    );");
				generate("                else");
				anyStates = true;
			}*/

			if(currentState.map.ContainsKey(SpecialSymbolTable.Else) == true)
				generateTransition(currentState.map[SpecialSymbolTable.Else].states[0], anyStates, true);
			else
			if(currentState.map.ContainsKey(SpecialSymbolTable.All) == true
			|| currentState.map.ContainsKey(SpecialSymbolTable.ConsumeElse) == true
			|| currentState.map.ContainsKey(SpecialSymbolTable.Epsilon) == true
			|| currentState.map.ContainsKey(SpecialSymbolTable.None) == true)
				throw new Exception("Not implemented (Special symbol)");
			else
			{	if(currentState.map.ContainsKey(SpecialSymbolTable.EOF) == true)
					generate("                if(getSymbol() != SpecialSymbol.EOF)");
				generate("                    throwParserException");
				if(currentState.map.ContainsKey(SpecialSymbolTable.EOF) == true)
					generate("                    (   \"Symbol [" + name + ":\" + getSymbol() + \"] unexpected at this time.\"");
				else
				{	generate("                    (   \"Symbol [" + name + ":\"");
					generate("                     +  (getSymbol() != SpecialSymbol.EOF ? getSymbol() : \"EOF\")");
					generate("                     + \"] unexpected at this time.\"");
				}
				generate("                    );");
			}

			generate("                parserTraceln(\"} .. (\" + getParseState() + \")\");");
			generate("                break;");
			generate("            ");

		}
		private string generateSymbolFix(string symbol)
		{	if(symbol == @"'\'") symbol = @"'\\'";
			if(symbol == @"'''") symbol = @"'\''";
			return symbol;
		}
		private void generateTransition(NextState nextState, bool anyStates, bool elseTransition)
		{	string strIndent = "";
			bool action = nextState.action.Trim().Length != 0;
			// Can add actions without { } if no indent is required

			if(nextState.isError == false)
			{

				if(elseTransition == false && action == false && anyStates == true)
					strIndent = "                    ";
				else
				if(anyStates == true && (elseTransition == false && action == true || elseTransition == true))
					strIndent = "                {   ";
				else
				if(elseTransition == true && anyStates == false)
					strIndent = "                ";
				else
					throw new Exception("Unknown state: e=" + elseTransition + "; a=" + action + "; s=" + anyStates);
				
				if(nextState.IsCall == true)
					generate(strIndent + "setParseStateAndPush(ParseStateList." + nextState.stateName + ", ParseStateList." + nextState.returnStateName + ");");
				else
				if(nextState.IsNormal == true)
					generate(strIndent + "setParseState(ParseStateList." + nextState.stateName + ");");
				else
				if(nextState.IsReturn == true)
					generate(strIndent + "popAndSetParseState();");

				if(anyStates == true && (elseTransition == false && action == true || elseTransition == true))
					strIndent = "                    ";

				if(elseTransition == true)
					generate(strIndent + "dontConsume();");
				if(action == true)
					generateAction(trim(nextState.action.Split(',')), strIndent);

				if(anyStates == true && (elseTransition == false && action == true || elseTransition == true))
					generate("                }");

			}
			else
				generate("                    throwParserException(\"" + nextState.action + "\");");
			
		}
		private void generateAction(string[] action, string strIndent)
		{

			foreach(string act in action)
				Console.Write(act + ", ");
			Console.WriteLine();


			int i = 0;
			while(i < action.Length)
			{

				if(action[i] == "whitespace")
				{	if(action[i + 1] == "parse")
						generate(strIndent + "consumeWhitespace();");
					else
					if(action[i + 1] == "ignore")
						generate(strIndent + "dontConsumeWhitespace();");
					i += 2;
				}
				else
				if(action[i] == "start")
				{	generate(strIndent + "startExtract();");
					i++;
				}
				else
				if(action[i] == "stop")
				{	generate(strIndent + "stopExtract();");
					i++;
				}
				else
				if(action[i] == "symbol_push")
				{	i += 2;
					throw new Exception("Not implemented (symbol_push)");
				}
				else
				if(action[i] == "symbol_pop")
				{	i += 2;
					throw new Exception("Not implemented (symbol_pop)");
				}
				else
				if(action[i] == "push")
				{	generate(strIndent + "pushActiveAstNode();");
					i++;
				}
				else
				if(action[i] == "pop")
				{	generate(strIndent + "popActiveAstNode();");
					i++;
				}
				else
				if(action[i] == "top")
				{	generate(strIndent + "topActiveAstNode();");
					i++;
				}
				else
				if(action[i] == "navigate")
				{	int child = 0;
					if(action[i + 1] == "parent")
						generate(strIndent + "navigateActiveAstNode(NavigateAstNodeMode.PARENT);");
					else
					if(action[i + 1] == "next")
						throw new Exception("Not implemented (navigate.NEXT);");
					else
					if(action[i + 1] == "prev")
						throw new Exception("Not implemented (navigate.PREV);");
					else
					if(int.TryParse(action[i + 1], out child) == true)
						generate(strIndent + "navigateActiveAstNode(" + child + ");");
					i += 2;
				}
				else
				if(action[i] == "node")
				{	NodeMode nodeMode = NodeMode.append;
					Console.WriteLine(action[i + 1]);
					if(action[i + 1][0] == 'm')
						throw new Exception("Not implemented (mergeAstNode)");
					else
					if(action[i + 1][0] == 'i')
					{	action[i + 1] = action[i + 1].Substring(1).Trim();
						nodeMode = NodeMode.insert;
					}
					else
					if(action[i + 1][0] == 'o')
					{	action[i + 1] = action[i + 1].Substring(1).Trim();
						nodeMode = NodeMode.overwrite;
					}

					if(int.Parse(action[i + 1]) == -2)
						throw new Exception("Not implemented (search bracket)");

					string[] names = action[i + 2].Split('.');
					string store = "";
					if(names.Length > 1)
						store = names[1].Trim();

					if(store.Length != 0)
						if(store != "*")
							throw new Exception("Not implemented (named store)");
						else
							if(nodeMode == NodeMode.overwrite)
								store = "((AstNodeIdentifier)getActiveAstNode()).getName()";
							else
								store = "getExtract()";
					if(nodeMode != NodeMode.overwrite)
						generate(strIndent + nodeMode + "AstNode(new " + names[0] + "(" + store + "));");
					else
					{	if(store.Trim().Length != 0)
						{	generate(strIndent + "replaceAstNode");
							generate(strIndent + "(   new " + names[0]);
							generate(strIndent + "    (   " + store);
							generate(strIndent + "    )");
							generate(strIndent + ");");
						}
						else
							generate(strIndent + "replaceAstNode(new " + names[0] + "());");
					}

					i += 3;
				}
				else
				if(action[i] == "error")
				{	generate(strIndent + "throwParserException(\"" + action[i + 1] + "\");");
					i += 2;
				}
				else
				if(action[i] == "store")
				{	i += 2;
					throw new Exception("Not implemented (store)");
				}
				else
					throw new Exception("Unknown action " + action[i]);
//					i = action.Length;

			}
		}
		private List<StateRange> generateStateRanges(CurrentState currentState)
		{	List<StateRange> stateRanges = new List<StateRange>();
			StateRange stateRange = null;

			char[] mappings = new char[currentState.map.Count];
			currentState.map.Keys.CopyTo(mappings, 0);
			Array.Sort(mappings);
			char lastMapping = SpecialSymbolTable.None;

			foreach(char mapping in mappings)
			{

				if(mapping > 255)
					break;

				List<NextState> nextStates = currentState.map[mapping].states;
				List<NextState> lastNextStates = null;
				if(currentState.map.ContainsKey(lastMapping) == true)
					lastNextStates = currentState.map[lastMapping].states;

				if(nextStates.Count != 1 || lastNextStates != null && lastNextStates.Count != 1)
					throw new Exception("Non-deterministic!");

				NextState nextState = nextStates[0];
				NextState lastNextState = lastNextStates != null ? lastNextStates[0] : null;

				if(mapping != lastMapping + 1 || nextState != lastNextState)
				{

					if(stateRange != null)
					{	stateRange.stop = lastMapping;
						stateRanges.Add(stateRange);
					}

					stateRange = new StateRange();
					stateRange.start = mapping;
					stateRange.nextStates = nextStates;

				}

				lastMapping = mapping;

			}

			if(stateRange != null)
			{	stateRange.stop = lastMapping;
				stateRanges.Add(stateRange);
			}

			return stateRanges;

		}
		private void generateFSADraw(Mappings mappings)
		{
			
			generateEx(startState);
			foreach(string finalState in finalStates)
				generateEx(", " + finalState);
			generate("");

			foreach(CurrentState currentState in mappings.Values)
			{

				List<StateRange> stateRanges = generateStateRanges(currentState);

				foreach(StateRange stateRange in stateRanges)
				{	string startOut;
					string stopOut;
					startOut = generateSymbolFix(stateRange.start >= 32 && stateRange.start <= 127 ? stateRange.start.ToString() : "[" + (int)stateRange.start + "]");
					stopOut = generateSymbolFix(stateRange.stop >= 32 && stateRange.stop <= 127 ? stateRange.stop.ToString() : "[" + (int)stateRange.stop + "]");
					generateEx(currentState.stateName);
					generateEx(", ");
					if(stateRange.start == stateRange.stop)
						generateEx(startOut);
					else
						generateEx(startOut + "-" + stopOut);
					generateFSADrawTransition(stateRange.nextStates[0]);
					generate("");
				}
				if(currentState.map.ContainsKey(SpecialSymbolTable.Else) == true)
				{	generateEx(currentState.stateName);
					generateEx(", ELSE");
					generateFSADrawTransition(currentState.map[SpecialSymbolTable.Else].states[0]);
					generate("");
				}
				if(currentState.map.ContainsKey(SpecialSymbolTable.EOF) == true)
				{	generateEx(currentState.stateName);
					generateEx(", EOF");
					generateFSADrawTransition(currentState.map[SpecialSymbolTable.EOF].states[0]);
					generate("");
				}
			}

		}
		private void generateFSADrawTransition(NextState nextState)
		{
			generateEx(" -> ");
			if(nextState.IsError == true)
				generateEx("***");
			else
			if(nextState.IsCall == true)
				generateEx(nextState.stateName + ", " + nextState.returnStateName);
			else
			if(nextState.IsReturn == true)
				generateEx(",");
			else
			if(nextState.IsNormal == true)
				generateEx(nextState.stateName);
		}
		class StateRange
		{	public char start;
			public char stop;
			public List<NextState> nextStates;
		}
		#endregion
	}

	#region TypeDef
	class Mappings : Dictionary<string, CurrentState> { };
	class Macros : Dictionary<string, string> { };
	class SymbolStore : Dictionary<string, string> { };
	class SymbolStack : Stack<char> { };
	class StateStack : Stack<TreeNode> { }
	class Set
	{

		private Dictionary<string, bool> _set = new Dictionary<string, bool>();

		public void Add(string item)
		{	_set[item] = true;
		}

		public bool hasItems { get { return _set.Count != 0; } }

		public override string ToString()
		{
			string output = null;
			List<string> items = new List<string>();
			foreach(string item in _set.Keys)
				items.Add(item);
			items.Sort();
			foreach(string item in items)
				output = (output == null ? "" : output + ", ") + item;
			if(output != null)
				output = "(" + output + ")";
			else
				return "{Set empty}";
			return output;
		}

	}
	#endregion

	#region ParseInputHelp
	enum NodeMode
	{	// Append it after a node of equal or lower significance
		append,
		// Merge it with an existing node of equal significance and type
		merge,
		// Insert it before an existing node of equal significance and type
		insert,
		// Overwrite a node with this node (don't touch branch)
		overwrite,
	};
	static class SpecialSymbolTable
	{	public const char Epsilon = (char)256;
		public const char Else = (char)257;
		public const char ConsumeElse = (char)258;
		public const char All = (char)259;	// Accepts every character
		public const char None = (char)260;
		public const char EOF = (char)270;
	}
	class CurrentStateAndStack
	{	public CurrentStateAndStack(CurrentState currentState)
		{	this.state = currentState;
			stack = new Stack<string>();
		}
		public CurrentStateAndStack(CurrentState currentState, Stack<string> cloneStack)
		{	this.state = currentState;
			stack = new Stack<string>(new Stack<string>(cloneStack));
		}
		public CurrentStateAndStack(CurrentState currentState, Stack<string> cloneStack, string modifyStack)
		{	this.state = currentState;
			stack = new Stack<string>(new Stack<string>(cloneStack));
			if(modifyStack != null)
				stack.Push(modifyStack);
			else
				stack.Pop();
		}
		/// <summary>The current currentStateAndStack which contains information that doesn't change regardless of how many times it's used (unlike the return symbolStack which does)</summary>
		public CurrentState state;
		/// <summary>The call symbolStack of this current currentStateAndStack. All currentStateAndStackList followed off this currentStateAndStack clone the return symbolStack and push or pop their own
		/// entries without affecting other currentStateAndStackList that also cloned off this currentStateAndStack (each transition branch keeps its own call symbolStack). If a mapping
		/// is reached that requires a return, the top of the symbolStack is popped and used as the destination currentStateAndStack for that map (and the symbolStack is
		/// cloned into the returned 'current' currentStateAndStack (which will be the symbolStack excluding the popped entry))</summary>
		public Stack<string> stack;
	}
	class CurrentState
	{	/// <summary>Information; map dictionary will map a name to a CurrentState, that name will be the same as this stateName</summary>
		public string stateName;
		/// <summary>A transition map to a next currentStateAndStack through a symbol</summary>
		public Dictionary<char, NextStates> map = new Dictionary<char, NextStates>();
	}
	class NextStates
	{	/// <summary>A single symbol can transition to several next currentStateAndStackList</summary>
		public List<NextState> states = new List<NextState>();
	}
	class NextState
	{	/// <summary>A custom action to perform when transitioning to the next currentStateAndStack</summary>
		public string action;
		/// <summary>The name of the next currentStateAndStack to transition to. If this is blank, the name from the top of the current currentStateAndStack's symbolStack is used instead</summary>
		public string stateName = "";
		/// <summary>The currentStateAndStack to push to the current currentStateAndStack's symbolStack when transitioning to the next currentStateAndStack (and returned to when a currentStateAndStack is reached with no next currentStateAndStack
		/// and no return currentStateAndStack (so is taken by popping off the symbolStack))</summary>
		public string returnStateName = "";
		public bool isError = false;
		/// <summary>Normal switches currentStateAndStackList without use of call symbolStack, has a currentStateAndStack name, but no return currentStateAndStack name</summary>
		public bool IsNormal { get { return stateName.Length != 0 && returnStateName.Length == 0; } }
		/// <summary>Will perform a call if a currentStateAndStack to call, and a currentStateAndStack to return to, are both specified</summary>
		public bool IsCall { get { return stateName.Length != 0 && returnStateName.Length != 0; } }
		/// <summary>Will perform a return if no currentStateAndStack to call and no currentStateAndStack to return is specified</summary>
		public bool IsReturn { get { return stateName.Length == 0 && returnStateName.Length == 0; } }
		// It is an error to have a return currentStateAndStack specified, but no currentStateAndStack specified (could have made it so it is treated as a normal currentStateAndStack switch, but don't want to add the logic)
		public bool IsError { get { return isError; } }
	}
	class ParseData
	{	public SymbolStore store;
		public StateStack stateStack;
		public SymbolStack symbolStack;
		public char symbol;
		public string output;
		public TreeNode activeNode;
		public bool insert;
		public bool killwhitey;
		public Mappings map;
		public List<CurrentStateAndStack> currentStateAndStackList;
		public int start;
		public int stop;
		public int index;
		public string input;
	}
	#endregion

}