namespace autoxt
{
	partial class Replace
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if(disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtNew = new System.Windows.Forms.TextBox();
			this.txtOld = new System.Windows.Forms.TextBox();
			this.lblOld = new System.Windows.Forms.Label();
			this.lblNew = new System.Windows.Forms.Label();
			this.cmdOk = new System.Windows.Forms.Button();
			this.cmdCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txtNew
			// 
			this.txtNew.Location = new System.Drawing.Point(64, 32);
			this.txtNew.Name = "txtNew";
			this.txtNew.Size = new System.Drawing.Size(328, 21);
			this.txtNew.TabIndex = 3;
			this.txtNew.Enter += new System.EventHandler(this.txtNew_Enter);
			// 
			// txtOld
			// 
			this.txtOld.Location = new System.Drawing.Point(64, 8);
			this.txtOld.Name = "txtOld";
			this.txtOld.Size = new System.Drawing.Size(328, 21);
			this.txtOld.TabIndex = 1;
			this.txtOld.Enter += new System.EventHandler(this.txtOld_Enter);
			// 
			// lblOld
			// 
			this.lblOld.AutoSize = true;
			this.lblOld.Location = new System.Drawing.Point(8, 11);
			this.lblOld.Name = "lblOld";
			this.lblOld.Size = new System.Drawing.Size(49, 13);
			this.lblOld.TabIndex = 0;
			this.lblOld.Text = "Replace:";
			// 
			// lblNew
			// 
			this.lblNew.AutoSize = true;
			this.lblNew.Location = new System.Drawing.Point(8, 35);
			this.lblNew.Name = "lblNew";
			this.lblNew.Size = new System.Drawing.Size(33, 13);
			this.lblNew.TabIndex = 2;
			this.lblNew.Text = "With:";
			// 
			// cmdOk
			// 
			this.cmdOk.Location = new System.Drawing.Point(240, 56);
			this.cmdOk.Name = "cmdOk";
			this.cmdOk.Size = new System.Drawing.Size(72, 24);
			this.cmdOk.TabIndex = 4;
			this.cmdOk.Text = "Ok";
			this.cmdOk.UseVisualStyleBackColor = true;
			this.cmdOk.Click += new System.EventHandler(this.cmdOk_Click);
			// 
			// cmdCancel
			// 
			this.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.cmdCancel.Location = new System.Drawing.Point(320, 56);
			this.cmdCancel.Name = "cmdCancel";
			this.cmdCancel.Size = new System.Drawing.Size(72, 24);
			this.cmdCancel.TabIndex = 5;
			this.cmdCancel.Text = "Cancel";
			this.cmdCancel.UseVisualStyleBackColor = true;
			this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
			// 
			// Replace
			// 
			this.AcceptButton = this.cmdOk;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.cmdCancel;
			this.ClientSize = new System.Drawing.Size(400, 88);
			this.Controls.Add(this.cmdCancel);
			this.Controls.Add(this.cmdOk);
			this.Controls.Add(this.lblNew);
			this.Controls.Add(this.lblOld);
			this.Controls.Add(this.txtOld);
			this.Controls.Add(this.txtNew);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "Replace";
			this.ShowInTaskbar = false;
			this.Text = "Replace..";
			this.Load += new System.EventHandler(this.frmReplace_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txtNew;
		private System.Windows.Forms.TextBox txtOld;
		private System.Windows.Forms.Label lblOld;
		private System.Windows.Forms.Label lblNew;
		private System.Windows.Forms.Button cmdOk;
		private System.Windows.Forms.Button cmdCancel;
	}
}