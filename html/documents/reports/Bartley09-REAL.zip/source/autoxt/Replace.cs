using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace autoxt
{
	public partial class Replace : Form
	{

		private bool ok = false;

		public Replace()
		{
			InitializeComponent();
		}

		private void frmReplace_Load(object sender, EventArgs e)
		{

		}

		public DialogResult Show(IWin32Window owner, string oldValue, string newValue)
		{	
			
			txtOld.Text = oldValue;
			txtNew.Text = newValue;
			ShowDialog(owner);

			if(ok == true)
				return DialogResult.OK;
			
			return DialogResult.Cancel;

		}

		public string oldValue { get { return txtOld.Text; } }
		public string newValue { get { return txtNew.Text; } }

		private void cmdOk_Click(object sender, EventArgs e)
		{
			ok = true;
			this.Visible = false;
		}

		private void cmdCancel_Click(object sender, EventArgs e)
		{
			this.Visible = false;
		}

		private void txtOld_Enter(object sender, EventArgs e)
		{
			txtOld.SelectAll();
		}

		private void txtNew_Enter(object sender, EventArgs e)
		{
			txtNew.SelectAll();
		}

	}
}