package main;

import real.utilities.DumpVisitor;
import real.utilities.EncompassVisitor;
import real.utilities.FocusVisitor;
import real.analyser.StructureVisitor;
import real.analyser.TypeException;
import real.ast.AstNode;
import real.analyser.TypeVisitor;
import real.interpreter.InterpretVisitor;
import real.parser.Parser;
import real.parser.ParserException;
import real.parser.RealParser;

/**
 * @author e
 */
public class Main
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {

        Parser parser = new RealParser();
        
        AstNode ast = null;
        try
        {

            parser.enableParserTrace();
            ast = parser.parse(args[0]);
            
            StructureVisitor structureVisitor = new StructureVisitor();
            ast.applyVisitor(structureVisitor);
            
            TypeVisitor typeVisitor = new TypeVisitor();
            ast.applyVisitor(typeVisitor);

            EncompassVisitor encompassVisitor = new EncompassVisitor();
            ast.applyVisitor(encompassVisitor);
            
            FocusVisitor focusVisitor = new FocusVisitor(1);
            ast.applyVisitor(focusVisitor);
            
            DumpVisitor dumpVisitor = new DumpVisitor();
            ast.applyVisitor(dumpVisitor);

            InterpretVisitor interpreterVisitor = new InterpretVisitor();
            interpreterVisitor.setFocusAstNode(focusVisitor.getFocusAstNode());
            ast.applyVisitor(interpreterVisitor);

            System.out.println("---");
            if(interpreterVisitor.getFocusStack() != null)
                System.out.println(interpreterVisitor.getFocusStack().getResult());
            else
                System.out.println("No focus");
            System.out.println("- -");
            
            for(Object result : interpreterVisitor.getResults())
                if(result == null)
                    System.out.println("ID;");
                else
                    System.out.println(result.toString() + ";");

            System.out.println("---");
            
            dumpVisitor = new DumpVisitor();
            ast.applyVisitor(dumpVisitor);
            
            System.out.println(parser.getParserTrace());

        }
        catch(ParserException e)
        {   System.out.println("Failed to build: " + e.getMessage());
            if(e.getCause() != null)
            {   System.out.println("---------------");
                e.getCause().printStackTrace(System.out);
            }
            if(e.getRootAstNode() != null)
            {   System.out.println("---------------");
                DumpVisitor dumpVisitor = new DumpVisitor();
                e.getRootAstNode().applyVisitor(dumpVisitor);
            }
            System.out.println("---------------");
            System.out.println(parser.getParserTrace());
        }
        catch(TypeException e)
        {   System.out.println("Failed to compile: " + e.getMessage());
            if(e.getCause() != null)
            {   System.out.println("---------------");
                e.getCause().printStackTrace(System.out);
            }
            if(e.getAstNode() != null)
            {   System.out.println("---------------");
                DumpVisitor dumpVisitor = new DumpVisitor(e.getAstNode());
                ast.applyVisitor(dumpVisitor);
            }
        }

    }

}
