package main;

import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import real.ui.GUI;

/**
 * @author e
 */
public class RealApp extends JFrame
{

    public RealApp()
    {   _guiReal = new GUI();
        setLayout(new BorderLayout());
        setSize(640, 480);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        addWindowListener
        (   new WindowAdapter()
            {   @Override
                public void windowOpened(WindowEvent event)
                {   _guiReal.initialise();
                }
            }
        );
        add(_guiReal);
        setVisible(true);
        _guiReal.setSource
        (   "f:int(n:int)={if(n <= 0){1}else{n*f(n-1)}};\n"
         +  "a:int=4;\n"
         +  "b:float=f(a):float;\n"
         +  "f(10);\n"
         +  "\n"
         +  "q:float(a:float, b:float, c:float, d:bool)\n"
         +  "={s:float(v:float)\n"
         +  "  ={if(v<0.0){-1.0}else{if(v>0.0){1.0}}};\n"
         +  "  t:float={-0.5*(b+s(b)*(b^2.0-4.0*a*c)\\2.0)};\n"
         +  "  if(d==true){c/t}else{t/a}\n"
         +  "};\n"
         +  "q(a:float, b, 3.0, true);\n"
         +  "q(a:float, b, 3.0, false);\n"
         +  "\n"
         +  "x:string=\"A piece\";\n"
         +  "x=x+\" of string\";\n"
         +  "x=x-\"piece of \";"
        );
    }

    public static void main(String[] args)
    {   new RealApp();
    }

    private GUI _guiReal;
    
}
