package main;

import java.applet.Applet;
import java.awt.BorderLayout;
import javax.swing.border.EtchedBorder;
import real.ui.GUI;

/**
 * @author e
 */
public class RealApplet extends Applet
{

    @Override
    public void init()
    {   super.init();
        _guiReal = new GUI();
    }
    
    @Override
    public void start()
    {   _guiReal.setBorder(new EtchedBorder());
        setLayout(new BorderLayout());
        add(_guiReal);
        _guiReal.setVisible(true);
        _guiReal.initialise();
        _guiReal.validate();
        _guiReal.setSource(getParameter("source").replaceAll("\\\\n", "\n"));
    }

    private GUI _guiReal;
    
}
