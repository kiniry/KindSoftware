package real.analyser;

import real.ast.AstNode;
import real.parser.ParserSource;
import real.utilities.RealException;

/**
 * @author e
 */
public class StructureException extends RealException
{

    public StructureException(ParserSource parserSource)
    {   super(parserSource);
    }

    public StructureException(AstNode parserSourceAstNode)
    {   super(parserSourceAstNode.getParserSource());
    }

    @Override
    public String toString()
    {   return "Parser error " + getParserSource();
    }
    
}
