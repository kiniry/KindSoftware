package real.analyser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import real.ast.AstNode;
import real.ast.AstNodeAssert;
import real.ast.AstNodeAssignment;
import real.ast.AstNodeBopDivide;
import real.ast.AstNodeBopLog;
import real.ast.AstNodeBopMinus;
import real.ast.AstNodeBopModulus;
import real.ast.AstNodeBopMultiply;
import real.ast.AstNodeBopPlus;
import real.ast.AstNodeBopPower;
import real.ast.AstNodeBopRoot;
import real.ast.AstNodeBracket;
import real.ast.AstNodeConvertType;
import real.ast.AstNodeCopEqual;
import real.ast.AstNodeCopGEqual;
import real.ast.AstNodeCopGreat;
import real.ast.AstNodeCopLEqual;
import real.ast.AstNodeCopLess;
import real.ast.AstNodeCopNotEqual;
import real.ast.AstNodeDeclareFunction;
import real.ast.AstNodeDeclareParam;
import real.ast.AstNodeDeclareParamList;
import real.ast.AstNodeDeclareParamType;
import real.ast.AstNodeDeclareFunctionType;
import real.ast.AstNodeDeclareVariableType;
import real.ast.AstNodeDeclareVariable;
import real.ast.AstNodeDereference;
import real.ast.AstNodeIdentifierFunction;
import real.ast.AstNodeIdentifierNew;
import real.ast.AstNodeIdentifierNewType;
import real.ast.AstNodeIdentifierType;
import real.ast.AstNodeIdentifierVariable;
import real.ast.AstNodeIf;
import real.ast.AstNodeLiteralFalse;
import real.ast.AstNodeLiteralFloat;
import real.ast.AstNodeLiteralID;
import real.ast.AstNodeLiteralInt;
import real.ast.AstNodeLiteralString;
import real.ast.AstNodeLiteralTrue;
import real.ast.AstNodeParam;
import real.ast.AstNodeParamList;
import real.ast.AstNodeProgram;
import real.ast.AstNodeStatementList;
import real.ast.AstNodeUopLevel;
import real.ast.AstNodeUopMinus;
import real.ast.AstNodeUopPlus;
import real.ast.AstNodeWhile;
import real.ast.visitor.AstVisitor;
import real.ast.visitor.AstVisitor.AstAcceptOrderer;
import real.ast.visitor.AstVisitor.InverseInfixAcceptOrderer;

/**
 * Validate the AST structure is correct; every node has the correct children
 *  and number of children
 * @author e
 */
public class StructureVisitor implements AstVisitor
{

    public void beforeVisit() { }
    
    public void afterVisit() { }
    
    public void visit(AstNodeAssert astNode)
    {   validateChildCount(astNode, 1);
        examineChildren(astNode);
    }

    public void visit(AstNodeAssignment astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeBopDivide astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeBopLog astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeBopMinus astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeBopModulus astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeBopMultiply astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeBopPlus astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeBopPower astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeBopRoot astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeBracket astNode)
    {   validateChildCount(astNode, 1);
        examineChildren(astNode);
    }

    public void visit(AstNodeConvertType astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeCopEqual astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeCopGEqual astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeCopGreat astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeCopLEqual astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeCopLess astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeCopNotEqual astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeDeclareFunction astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeDeclareVariableType astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeDeclareParamType astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeDereference astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }
    
    public void visit(AstNodeIf astNode)
    {   if(astNode.getChildCount() != 2
        && astNode.getChildCount() != 3)
            throw new StructureException(astNode);
        examineChildren(astNode);
    }

    public void visit(AstNodeLiteralFalse astNode)
    {   validateChildCount(astNode, 0);
        examineChildren(astNode);
    }

    public void visit(AstNodeLiteralFloat astNode)
    {   validateChildCount(astNode, 0);
        examineChildren(astNode);
    }

    public void visit(AstNodeIdentifierFunction astNode)
    {   validateChildCount(astNode, 1);
        examineChildren(astNode);
    }

    public void visit(AstNodeIdentifierNew astNode)
    {   validateChildCount(astNode, 0);
        examineChildren(astNode);
    }

    public void visit(AstNodeIdentifierNewType astNode)
    {   validateChildCount(astNode, 1);
        examineChildren(astNode);
    }

    public void visit(AstNodeIdentifierType astNode)
    {   validateChildCount(astNode, 0);
        examineChildren(astNode);
    }

    public void visit(AstNodeIdentifierVariable astNode)
    {   validateChildCount(astNode, 0);
        examineChildren(astNode);
    }

    public void visit(AstNodeLiteralID astNode)
    {   validateChildCount(astNode, 0);
        examineChildren(astNode);
    }

    public void visit(AstNodeLiteralInt astNode)
    {   validateChildCount(astNode, 0);
        examineChildren(astNode);
    }

    public void visit(AstNodeLiteralString astNode)
    {   validateChildCount(astNode, 0);
        examineChildren(astNode);
    }

    public void visit(AstNodeLiteralTrue astNode)
    {   validateChildCount(astNode, 0);
        examineChildren(astNode);
    }

    public void visit(AstNodeParam astNode)
    {   validateChildCount(astNode, 1);
        examineChildren(astNode);
    }

    public void visit(AstNodeDeclareParam astNode)
    {   validateChildCount(astNode, 1);
        examineChildren(astNode);
    }

    public void visit(AstNodeDeclareFunctionType astNode)
	{   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeParamList astNode)
    {
        examineChildren(astNode);
    }

    public void visit(AstNodeProgram astNode)
    {
        examineChildren(astNode);
    }

    public void visit(AstNodeDeclareParamList astNode)
    {
        examineChildren(astNode);
    }

    public void visit(AstNodeStatementList astNode)
    {   // Can't be no statements
        if(astNode.getChildCount() == 0)
            throw new StructureException(astNode);
        examineChildren(astNode);
    }

    public void visit(AstNodeUopLevel astNode)
    {   validateChildCount(astNode, 1);
        if(astNode.getChild(0) instanceof AstNodeUopLevel == false
        && astNode.getChild(0) instanceof AstNodeIdentifierFunction == false
        && astNode.getChild(0) instanceof AstNodeIdentifierVariable == false)
            throw new StructureException(astNode);
        examineChildren(astNode);
    }

    public void visit(AstNodeUopMinus astNode)
    {   validateChildCount(astNode, 1);
        examineChildren(astNode);
    }

    public void visit(AstNodeUopPlus astNode)
    {   validateChildCount(astNode, 1);
        examineChildren(astNode);
    }

    public void visit(AstNodeDeclareVariable astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public void visit(AstNodeWhile astNode)
    {   validateChildCount(astNode, 2);
        examineChildren(astNode);
    }

    public AstAcceptOrderer getDefaultOrderer()
    {   return new InverseInfixAcceptOrderer();
    }

    private void validateChildCount(AstNode astNode, int expectedChildCount)
    {   if(astNode.getChildCount() != expectedChildCount)
            throw new StructureException(astNode);
    }

    // Debug - check the structure
    private void examineChildren(AstNode astNode)
    {
    /*
        List<String> astNodes;
        if(usedChildren.containsKey(astNode.getClass().getSimpleName()) == true)
            astNodes = usedChildren.get(astNode.getClass().getSimpleName());
        else
            usedChildren.put
            (   astNode.getClass().getSimpleName(),
                astNodes = new ArrayList<String>()
            );
        
        if(astNode.getChildCount() == 0)
        {   if(astNodes.contains("<NULL>") == false)
                astNodes.add("<NULL>");
        }
        else
            for(int index = 0; index < astNode.getChildCount(); index++)
                if(astNodes.contains(index + "." + astNode.getChild(index).getClass().getSimpleName()) == false)
                    astNodes.add(index + "." + astNode.getChild(index).getClass().getSimpleName());

    */
    }

    //public static HashMap<String, List<String>> usedChildren = new HashMap<String, List<String>>();
    
}
