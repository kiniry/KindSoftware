package real.analyser;

import real.ast.AstNode;
import real.utilities.RealException;

/**
 * @author e
 */
public abstract class TypeException extends RealException
{

    public TypeException(AstNode astNode)
    {   super(astNode.getParserSource());
        _astNode = astNode;
    }

    public AstNode getAstNode()
    {   return _astNode;
    }
    
    /**
     * Location in source where error occurred
     */
    private AstNode _astNode;
    
}
