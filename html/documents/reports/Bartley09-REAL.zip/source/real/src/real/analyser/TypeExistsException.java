package real.analyser;

import real.ast.AstNode;
import real.ast.type.Type;

/**
 * @author e
 */
public class TypeExistsException extends TypeException
{

    public TypeExistsException
    (   String          bindingName,
        Type           existingType,
        AstNode parserSourceAstNode
    ){  super(parserSourceAstNode);
        _bindingName = bindingName;
        _existingType = existingType;
    }

    @Override
    public String getMessage()
    {   return
            "Binding [" + _bindingName
         +  "] already declared as [" + _existingType + "] "
         +  getParserSource();
    }

    private String _bindingName;
    private Type _existingType;
    
}
