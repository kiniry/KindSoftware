package real.analyser;

import real.ast.AstNode;
import real.ast.type.Type;

/**
 * @author e
 */
public class TypeIllegalException extends TypeException
{

    /**
     * Create an incompatible type exception
     * @param receivedType The incompatible type
     */
    TypeIllegalException(Type type, AstNode parserSourceAstNode)
    {   super(parserSourceAstNode);
        _type = type;
    }

    // Helpers
    
    TypeIllegalException(AstNode receivedTypeAstNode, AstNode parserSourceAstNode)
    {   this
        (   receivedTypeAstNode.getType(),
            parserSourceAstNode
        );
    }

    @Override
    public String getMessage()
    {   return
            "Incompatible type: received [" + _type + "] "
         +  getParserSource();
    }

    /**
     * Data-type expected
     */
    private Type _type;
    
}
