package real.analyser;

import real.ast.AstNode;
import real.ast.type.Type;

/**
 * @author e
 */
public class TypeMismatchException extends TypeException
{

    /**
     * Create a type mismatch
     * @param expectedType The type that is correct
     * @param receivedType The type that was used
     */
    TypeMismatchException
    (   Type           expectedType,
        Type           receivedType,
        AstNode parserSourceAstNode
    ){  super(parserSourceAstNode);
        _expectedType = expectedType;
        _receivedType = receivedType;
    }

    // Helpers
    
    TypeMismatchException
    (   Type           expectedType,
        AstNode receivedTypeAstNode
    ){  this
        (   expectedType,
            receivedTypeAstNode.getType(),
            receivedTypeAstNode
        );
    }
    
    TypeMismatchException
    (   AstNode expectedTypeAstNode,
        Type           receivedType,
        AstNode parserSourceAstNode
    ){  this
        (   expectedTypeAstNode.getType(),
            receivedType,
            parserSourceAstNode
        );
    }

    TypeMismatchException
    (   AstNode expectedTypeAstNode,
        AstNode receivedTypeAstNode
    ){  this
        (   expectedTypeAstNode.getType(),
            receivedTypeAstNode.getType(),
            receivedTypeAstNode
        );
    }

    @Override
    public String getMessage()
    {   return
            "Type mismatch: expected ["
         +  (_expectedType != null ? _expectedType : "unknown")
         +  "]; received ["
         +  (_receivedType != null ? _receivedType : "unknown")
         + "]; " + getParserSource();
    }

    /**
     * Data-type expected
     */
    private Type _expectedType;
    /**
     * Data-type supplied
     */
    private Type _receivedType;
    
}
