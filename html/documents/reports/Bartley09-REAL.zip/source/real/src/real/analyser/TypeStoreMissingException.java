package real.analyser;

import real.ast.AstNode;

/**
 * @author e
 */
class TypeStoreMissingException extends TypeException
{

    public TypeStoreMissingException
    (   String            storeName,
        int                   level,
        AstNode parserSourceAstNode
    ){  super(parserSourceAstNode);
        _storeName = storeName;
        _level = level;
    }

    @Override
    public String getMessage()
    {   return
            "Store [" + _storeName
         +  "] could not be found at level [" + _level + "] "
         +  getParserSource();
    }

    private String _storeName;
    private int _level;
}
