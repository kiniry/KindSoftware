package real.analyser;

import real.ast.AstNode;

/**
 * @author e
 */
public class TypeUnknownException extends TypeException
{

    public TypeUnknownException
    (   AstNode parserSourceAstNode
    ){  super(parserSourceAstNode);
    }

    @Override
    public String getMessage()
    {   return "Untyped "
         +  getParserSource();
    }
    
}
