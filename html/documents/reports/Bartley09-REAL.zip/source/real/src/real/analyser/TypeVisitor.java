package real.analyser;

import java.util.ArrayList;
import java.util.List;
import real.ast.AstNode;
import real.ast.AstNodeAssert;
import real.ast.AstNodeAssignment;
import real.ast.AstNodeBopDivide;
import real.ast.AstNodeBopLog;
import real.ast.AstNodeBopMinus;
import real.ast.AstNodeBopModulus;
import real.ast.AstNodeBopMultiply;
import real.ast.AstNodeBopPlus;
import real.ast.AstNodeBopPower;
import real.ast.AstNodeBopRoot;
import real.ast.AstNodeBracket;
import real.ast.AstNodeConvertType;
import real.ast.AstNodeCopEqual;
import real.ast.AstNodeCopGEqual;
import real.ast.AstNodeCopGreat;
import real.ast.AstNodeCopLEqual;
import real.ast.AstNodeCopLess;
import real.ast.AstNodeCopNotEqual;
import real.ast.AstNodeDeclareFunction;
import real.ast.AstNodeDeclareParam;
import real.ast.AstNodeDeclareParamList;
import real.ast.AstNodeDeclareParamType;
import real.ast.AstNodeDeclareFunctionType;
import real.ast.AstNodeDeclareVariableType;
import real.ast.AstNodeDeclareVariable;
import real.ast.AstNodeDereference;
import real.ast.AstNodeExceptionFactory;
import real.ast.AstNodeIdentifier;
import real.ast.AstNodeIdentifierFunction;
import real.ast.AstNodeIdentifierNew;
import real.ast.AstNodeIdentifierNewType;
import real.ast.AstNodeIdentifierType;
import real.ast.AstNodeIdentifierVariable;
import real.ast.AstNodeIf;
import real.ast.AstNodeLiteralFalse;
import real.ast.AstNodeLiteralFloat;
import real.ast.AstNodeLiteralID;
import real.ast.AstNodeLiteralInt;
import real.ast.AstNodeLiteralString;
import real.ast.AstNodeLiteralTrue;
import real.ast.AstNodeParam;
import real.ast.AstNodeParamList;
import real.ast.AstNodeProgram;
import real.ast.AstNodeStatementList;
import real.ast.AstNodeUopLevel;
import real.ast.AstNodeUopMinus;
import real.ast.AstNodeUopPlus;
import real.ast.AstNodeWhile;
import real.ast.AstStoreList;
import real.ast.environment.Environment;
import real.ast.type.CompoundType;
import real.ast.type.Type;
import real.ast.visitor.AstVisitor;
import real.ast.visitor.AstVisitor.AstAcceptOrderer;

/**
 * Validate the AST is type correct
 * @author e
 */
public class TypeVisitor implements AstVisitor, AstNodeExceptionFactory
{

    public void beforeVisit()
    {
    }
    
    public void afterVisit()
    {
    }
    
    /**
     * Assert must always have an argument that is type bool
     * <pre>
     *         Γ |- <>
     * ------------------------
     * Γ |- assert(e:bool):bool
     * </pre>
     */
    public void visit(AstNodeAssert astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode value = astNode.getChild(0);
        if(value.getTypeResolved() == true)
            if(isType(value, Type.TypeBool) == true)
                setTypeResolved(astNode, Type.TypeBool);
            else
                throw new TypeMismatchException(Type.TypeBool, value);
        else
            didntResolve(astNode);
    }

    /**
     * Left and right-hand sides of an assignment must be the same type
     * <pre>
     *  Γ,T0,T1 |- T1=T0
     * -------------------
     * Γ |- (i:T0=e:T1):T0
     * </pre>
     */
    public void visit(AstNodeAssignment astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode lValue = astNode.getChild(0);
        AstNode rValue = astNode.getChild(1);
        if(lValue.getTypeResolved() == true
        && rValue.getTypeResolved() == true)
            if(isType(lValue, rValue) == true)
                setTypeResolved(astNode, lValue.getType());
            else
                throw new TypeMismatchException(lValue, rValue);
        else
            didntResolve(astNode);
    }

    private Type binaryOpTypeGet(AstNode lValue, AstNode rValue)
    {   if(lValue.getType() == Type.TypeID)
            return rValue.getType();
        return lValue.getType();
    }
    
    private void binaryOpTypeCheckAndSet
    (   AstNode astNode,
        AstNode lValue,
        AstNode rValue,
        Type... types
    ){  if(types.length == 0 || isOneOfType(lValue, types) == true)
            if(types.length == 0 || isOneOfType(rValue, types) == true)
                if(isType(lValue, rValue))
                    setTypeResolved(astNode, binaryOpTypeGet(lValue, rValue));
                else
                    throw new TypeMismatchException(lValue, rValue);
            else
                throw new TypeIllegalException(rValue, rValue);
        else
            throw new TypeIllegalException(lValue, lValue);
    }
    
    /**
     * Left and right-hand sides of a binary operator must be the same type, and
     *  the result will be the same type too
     * <pre>
     *   Γ,T0,T1,T2 |- T2=T0=T1
     * -------------------------  (X) = {+}
     * Γ |- (e0:T0 (X) e1:T1):T2
     * </pre>
     */
    private void binaryOp1(AstNode astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode lValue = astNode.getChild(0);
        AstNode rValue = astNode.getChild(1);
        if(lValue.getTypeResolved() == true
        && rValue.getTypeResolved() == true)
            binaryOpTypeCheckAndSet(astNode, lValue, rValue);
        else
            didntResolve(astNode);
    }

    /**
     * Left and right-hand sides of a binary operator must be the same type, and
     *  the result will be the same type too
     * <pre>
     *   Γ,T0,T1,T2 |- T2=T0=T1   (X) = {-}
     * -------------------------  (T0, T1) = {int, float, string}
     * Γ |- (e0:T0 (X) e1:T1):T2
     * </pre>
     */
    private void binaryOp2(AstNode astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode lValue = astNode.getChild(0);
        AstNode rValue = astNode.getChild(1);
        if(lValue.getTypeResolved() == true
        && rValue.getTypeResolved() == true)
            binaryOpTypeCheckAndSet(astNode, lValue, rValue, TypeNotBool);
        else
            didntResolve(astNode);
    }

    /**
     * Left and right-hand sides of a binary operator must be the same type, and
     *  the result will be the same type too
     * <pre>
     *   Γ,T0,T1,T2 |- T2=T0=T1   (X) = {*, ^}
     * -------------------------  (T0, T1) = {bool, int, float}
     * Γ |- (e0:T0 (X) e1:T1):T2
     * </pre>
     */
    private void binaryOp3(AstNode astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode lValue = astNode.getChild(0);
        AstNode rValue = astNode.getChild(1);
        if(lValue.getTypeResolved() == true
        && rValue.getTypeResolved() == true)
            binaryOpTypeCheckAndSet(astNode, lValue, rValue, TypeNotString);
        else
            didntResolve(astNode);
    }

    /**
     * Left and right-hand sides of a binary operator must be the same type, and
     *  the result will be the same type too
     * <pre>
     *   Γ,T0,T1,T2 |- T2=T0=T1   (X) = {/, %, \, |}
     * -------------------------  (T0, T1) != {int, float}
     * Γ |- (e0:T0 (X) e1:T1):T2
     * </pre>
     */
    private void binaryOp4(AstNode astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode lValue = astNode.getChild(0);
        AstNode rValue = astNode.getChild(1);
        if(lValue.getTypeResolved() == true
        && rValue.getTypeResolved() == true)
            binaryOpTypeCheckAndSet(astNode, lValue, rValue, TypeNumber);
        else
            didntResolve(astNode);
    }

    public void visit(AstNodeBopDivide astNode)
    {   binaryOp4(astNode);
    }

    public void visit(AstNodeBopLog astNode)
    {   binaryOp4(astNode);
    }

    public void visit(AstNodeBopMinus astNode)
    {   binaryOp2(astNode);
    }

    public void visit(AstNodeBopModulus astNode)
    {   binaryOp4(astNode);
    }

    public void visit(AstNodeBopMultiply astNode)
    {   binaryOp3(astNode);
    }

    public void visit(AstNodeBopPlus astNode)
    {   binaryOp1(astNode);
    }

    public void visit(AstNodeBopPower astNode)
    {   binaryOp3(astNode);
    }

    public void visit(AstNodeBopRoot astNode)
    {   binaryOp4(astNode);
    }

    /**
     * Brackets have no effect on type
     * <pre>
     *  Γ |- e:T
     * ==========
     * Γ |- (e):T
     * </pre>
     */
    public void visit(AstNodeBracket astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode value = astNode.getChild(0);
        if(value.getTypeResolved() == true)
            setTypeResolved(astNode, value.getType());
        else
            didntResolve(astNode);
    }

    /**
     * Conversion currently only works for basic types. TODO - allow conversion
     *  functions to be constructed and update this to look for the required
     *  conversion function
     * <pre>
     *    Γ |- <>
     * -------------  (T0, T1) = {bool, int, float, string}
     * Γ |- e:T0->T1
     * </pre>
     */
    public void visit(AstNodeConvertType astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode lValue = astNode.getChild(0);
        AstNode rValue = astNode.getChild(1);
        if(lValue.getTypeResolved() == true
        && rValue.getTypeResolved() == true)
            if(isOneOfType(lValue, TypeAll) == true)
                if(isOneOfType(rValue, TypeAll) == true)
                    setTypeResolved(astNode, rValue.getType());
                else
                    throw new TypeIllegalException(rValue, rValue);
            else
                throw new TypeIllegalException(lValue, lValue);
        else
            didntResolve(astNode);
    }

    /**
     * Left and right-hand sides of a compare operator must be the same type,
     *  and the result will always be bool
     * <pre>
     *      Γ,T0,T1 |- T0=T1
     * ---------------------------  (X) = {==, -=}
     * Γ |- (e0:T0 (X) e1:T1):bool
     * </pre>
     */
    private void compareOp1(AstNode astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode lValue = astNode.getChild(0);
        AstNode rValue = astNode.getChild(1);
        if(lValue.getTypeResolved() == true
        && rValue.getTypeResolved() == true)
            if(isType(lValue, rValue) == true)
                setTypeResolved(astNode, Type.TypeBool);
            else
                throw new TypeMismatchException(lValue, rValue);
        else
            didntResolve(astNode);
    }

    /**
     * Left and right-hand sides of a compare operator must be the same type,
     *  and the result will always be bool
     * <pre>
     *      Γ,T0,T1 |- T0=T1        (X) = {<, <=, >=, >}
     * ---------------------------  (T0, T1) != {bool}
     * Γ |- (e0:T0 (X) e1:T1):bool
     * </pre>
     */
    private void compareOp2(AstNode astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode lValue = astNode.getChild(0);
        AstNode rValue = astNode.getChild(1);
        if(lValue.getTypeResolved() == true
        && rValue.getTypeResolved() == true)
            if(isOneOfType(lValue, TypeNotBool) == true)
                if(isOneOfType(rValue, TypeNotBool) == true)
                    if(isType(lValue, rValue) == true)
                        setTypeResolved(astNode, Type.TypeBool);
                    else
                        throw new TypeMismatchException(lValue, rValue);
                else
                    throw new TypeIllegalException(rValue, rValue);
            else
                throw new TypeIllegalException(lValue, lValue);
        else
            didntResolve(astNode);
    }

    public void visit(AstNodeCopEqual astNode)
    {   compareOp1(astNode);
    }

    public void visit(AstNodeCopGEqual astNode)
    {   compareOp2(astNode);
    }

    public void visit(AstNodeCopGreat astNode)
    {   compareOp2(astNode);
    }

    public void visit(AstNodeCopLEqual astNode)
    {   compareOp2(astNode);
    }

    public void visit(AstNodeCopLess astNode)
    {   compareOp2(astNode);
    }

    public void visit(AstNodeCopNotEqual astNode)
    {   compareOp1(astNode);
    }

    /**
     * A function, which is stored as a compound type of its parameters and
     *  return type, is seen in the tree as being of the type of its return-type
     *  only
     * Note: Though out of place, I'm also doing linking here (the type-checker
     *  has all the information I need to link, so rather than scanning the tree
     *  again)
     * <pre>
     *          Γ,F |- <>
     * --------------------------  F = T0->..->TN->R
     * Γ |- f:R(i0:T0,..,iN:TN):R
     * </pre>
     */
    public void visit(AstNodeDeclareFunction astNode)
    {   astNode.getEnvironment().ctorStore(AstStoreList.AST_TYPE);
        // Prepare for linking values
        astNode.getEnvironment().ctorStore(AstStoreList.AST_VALUE);
        // Add a special binding for storing the order of parameters
        if(astNode.getEnvironment().getLocalBindingValue
        (   AstStoreList.AST_VALUE,
            ":"
        ) == null)
            astNode.getEnvironment().ctorBinding
            (   AstStoreList.AST_VALUE,
                ":",
                new ArrayList<String>(),
                this
            );
        visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode head = astNode.getChild(0);
        AstNode body = astNode.getChild(1);
        if(head.getTypeResolved() == true
        && body.getTypeResolved() == true)
        {   Type returnType = head.getType().getSubType(0);
            if(isType(body, returnType) == true)
                setTypeResolved(astNode, returnType);
            else
                throw new TypeMismatchException(returnType, body);
        }
        else
            didntResolve(astNode);
    }

    /**
     * AstNodeDeclareVariableType is the only AST node that adds new types to the store
     *  as it is the node that is closest to the identifier and type in all
     *  declarations (whether variable, function, or parameter). Named type must
     *  not already exist in the current scope and after
     * <pre>
     * Γ,T,i!->loc.i|σ0 |- <>   Γ,i->loc.i|σ1{T/loc.i} |- <>
     * -----------------------------------------------------  Fresh loc.i|σ1
     *           Γ|σ0 |- { [e0; ..; i:T; ..; eN]|σ1 }
     * </pre>
     */
    public void visit(AstNodeDeclareVariableType astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode lValue = astNode.getChild(0);
        AstNode rValue = astNode.getChild(1);
        if(lValue.getTypeResolved() == true
        && rValue.getTypeResolved() == true)
        {   astNode.getEnvironment().ctorBinding
            (   AstStoreList.AST_TYPE,
                ((AstNodeIdentifier)lValue).getName(),
                rValue.getType(),
                this

            );
            // Link in a value binding while we're at it
            astNode.getEnvironment().ctorBinding
            (   AstStoreList.AST_VALUE,
                ((AstNodeIdentifier)lValue).getName(),
                null,
                this
            );
            setTypeResolved(astNode, rValue.getType());
        }
        else
            didntResolve(astNode);
    }

    /**
     * Param is just a container and is the type of what it's containing
     * <pre>
     * Γ |- <>
     * --------
     * Γ |- e:T
     * </pre>
     */
    public void visit(AstNodeDeclareParam astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode value = astNode.getChild(0);
        if(value.getTypeResolved() == true)
            setTypeResolved(astNode, value.getType());
        else
            didntResolve(astNode);
    }

    /**
     * <pre>
     * Γ |- <>
     * --------
     * Γ |- e:T
     * </pre>
     */
    public void visit(AstNodeDeclareFunctionType astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode lValue = astNode.getChild(0);
        AstNode rValue = astNode.getChild(1);
        if(lValue.getTypeResolved() == true
        && rValue.getTypeResolved() == true)
        {   astNode.getEnvironment().ctorBindingIndirect
            (   AstStoreList.AST_TYPE,
                ((AstNodeIdentifier)lValue).getName(),
                rValue.getType(),
                1,
                this
            );
            astNode.getEnvironment().ctorBindingIndirect
            (   AstStoreList.AST_VALUE,
                ((AstNodeIdentifier)lValue).getName(),
                (AstNodeDeclareFunction)astNode.getParent(),
                1,
                this
            );
            setTypeResolved(astNode, rValue.getType());
        }
        else
            didntResolve(astNode);
    }

    /**
     * <pre>
     *         Γ |- <>
     * -----------------------  F = T0->..->TN->R
     * Γ |- (i0:T0,..,iN:TN):F
     * </pre>
     */
    public void visit(AstNodeDeclareParamList astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        int index;
        Type[] types = new Type[astNode.getChildCount()];
        for
        (   index = 0;
            index < astNode.getChildCount();
            index++
        ){  AstNode value = astNode.getChild(index);
            if(value.getTypeResolved() == true)
                types[index] = value.getType();
            else
                break;
        }
        // If all children are resolved, create the new compound type
        if(index == astNode.getChildCount())
            setTypeResolved(astNode, new CompoundType(types));
        else
            didntResolve(astNode);
    }

    /**
     * AstNodeDeclareVariableType is the only AST node that adds new types to the store
     *  as it is the node that is closest to the identifier and type in all
     *  declarations (whether variable, function, or parameter). Named type must
     *  not already exist in the current scope and after
     * Note: declare nodes, unlike all other nodes, will visit child nodes even
     *  if there type is resolved. This is to allow all children declarations
     *  to push their type details onto the stack (Only AstNodeDeclareVariableType nodes
     *  modify the stack and only AstNodeDeclareFunction/AstNodeDeclareParamList
     *  nodes push/pop the stack)
     * <pre>
     * Γ,T,i!->loc.i|σ0 |- <>   Γ,i->loc.i|σ1{T/loc.i} |- <>
     * -----------------------------------------------------  Fresh loc.i|σ1
     *                 Γ|σ0 |- f(i:T)={e|σ1}
     * </pre>
     */
    public void visit(AstNodeDeclareParamType astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode lValue = astNode.getChild(0);
        AstNode rValue = astNode.getChild(1);
        if(lValue.getTypeResolved() == true
        && rValue.getTypeResolved() == true)
        {   astNode.getEnvironment().ctorBinding
            (   AstStoreList.AST_TYPE,
                ((AstNodeIdentifier)lValue).getName(),
                rValue.getType(),
                this
            );
            astNode.getEnvironment().ctorBinding
            (   AstStoreList.AST_VALUE,
                ((AstNodeIdentifier)lValue).getName(),
                null,
                this
            );
            // Keep a list attached to the function definition of all the
            //  parameters it uses in the order it uses them
            // Get the list
            List<String> paramList = (List<String>)astNode
                .getEnvironment()
                .getBindingValue(AstStoreList.AST_VALUE, ":");
            // Add this parameter to the list
            paramList.add(((AstNodeIdentifier)lValue).getName());
            setTypeResolved(astNode, rValue.getType());
        }
        else
            didntResolve(astNode);
    }

    /**
     * <pre>
     * Γ,T0,T1 |- T0=T1
     * ----------------
     *  Γ |- i:T0=e:T1
     * </pre>
     */
    public void visit(AstNodeDeclareVariable astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode lValue = astNode.getChild(0);
        AstNode rValue = astNode.getChild(0);
        if(lValue.getTypeResolved() == true
        && rValue.getTypeResolved() == true)
            if(isType(lValue, rValue) == true)
                setTypeResolved(astNode, lValue.getType());
            else
                throw new TypeMismatchException(lValue, rValue);
        else
            didntResolve(astNode);
    }

    public void visit(AstNodeDereference astNode)
    {   throw new RuntimeException("Not implmented yet!");
    }
    
    /**
     * <pre>
     *   Γ,R,s:R |- if -> R          Γ,R,s:R |- ifel -> R
     * ----------------------  -------------------------------
     * Γ |- if(e:bool){s:R}:R  Γ |- if(e:bool){s:R}else{s:R}:R
     * </pre>
     */
    public void visit(AstNodeIf astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode condition = astNode.getChild(0);
        AstNode trueStatement = astNode.getChild(1);
        AstNode falseStatement = null;
        if(astNode.getChildCount() == 3)
            falseStatement = astNode.getChild(2);
        if(condition.getTypeResolved() == true
        && trueStatement.getTypeResolved() == true
        &&( falseStatement == null
         || falseStatement.getTypeResolved() == true)
        )   if(isType(condition, Type.TypeBool) == true)
                if(falseStatement == null
                || isType(trueStatement, falseStatement) == true)
                    setTypeResolved(astNode, trueStatement.getType());
                else
                    throw new TypeMismatchException(trueStatement, falseStatement);
            else
                throw new TypeMismatchException(Type.TypeBool, condition);
        else
            didntResolve(astNode);
    }

    /**
     * <pre>
     *      Γ |- <>
     * -----------------
     * Γ |- false[:]bool
     * </pre>
     */
    public void visit(AstNodeLiteralFalse astNode)
    {   // AstNodeLiteralFalse.getType() always equal Type.TypeBool
    }

    /**
     * <pre>
     *      Γ |- <>
     * ----------------  N.N = 32bit IEEE float
     * Γ |- N.N[:]float
     * </pre>
     */
    public void visit(AstNodeLiteralFloat astNode)
    {   // AstNodeLiteralFloat.getType() always equal Type.TypeFloat
    }

    /**
     * <pre>
     * Γ,i->loc.i|σ |- σ{loc.i} ~> [T0->..TN->R]  Γ |- T0=t0, .., TN=tN
     * ----------------------------------------------------------------
     *                     Γ|σ |- i(t0, .., tN):R
     * </pre>
     */
    public void visit(AstNodeIdentifierFunction astNode)
    {   int level = _level;
        _level = 0;
        visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        Type type = (Type)astNode.getEnvironment().getBindingValue
        (   AstStoreList.AST_TYPE,
            astNode.getName(),
            level
        );
        if(type != null)
            if(type.getSubTypeCount() >= 2)
                if(isType(astNode.getChild(0), type.getSubType(1)) == true)
                    setTypeResolved(astNode, type.getSubType(0));
                else
                    throw new TypeMismatchException
                    (   type.getSubType(1),
                        astNode.getChild(0)
                    );
            else
                throw new TypeMismatchException
                (   type,
                    astNode.getChild(0)
                );
        else
            didntResolve(astNode);
    }

    /**
     * Untyped, just a name
     * <pre>
     * Γ |- <>
     * -------
     * Γ |- i
     * </pre>
     */
    public void visit(AstNodeIdentifierNew astNode)
    {
    }

    /**
     * <pre>
     *     Γ,i->loc.i|σ |- <>
     * --------------------------
     * Γ,i->loc.i|σ |- σ{loc.i}|σ
     * </pre>
     */
    public void visit(AstNodeIdentifierNewType astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        Type[] type = new Type[2];
        type[0] = (Type)astNode.getEnvironment().getBindingValue
        (   AstStoreList.AST_TYPE,
            astNode.getName()
        );
        type[1] = astNode.getChild(0).getType();
        if(type != null && type[0] != null && type[1] != null)
            setTypeResolved(astNode, new CompoundType(type));
        else
            didntResolve(astNode);
    }


    /**
     * <pre>
     *     Γ,i->loc.i|σ |- <>
     * --------------------------
     * Γ,i->loc.i|σ |- σ{loc.i}|σ
     * </pre>
     */
    public void visit(AstNodeIdentifierType astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        Type type = (Type)astNode.getEnvironment().getBindingValue
        (   AstStoreList.AST_TYPE,
            astNode.getName()
        );
        if(type != null)
            setTypeResolved(astNode, type);
        else
            didntResolve(astNode);
    }

    /**
     * <pre>
     *      Γ,i->loc.i|σ |- <>
     * ----------------------------
     * Γ,i->loc.i|σ |- i:σ{loc.i}|σ
     * </pre>
     */
    public void visit(AstNodeIdentifierVariable astNode)
    {   int level = _level;
        _level = 0;
        visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        Type type = (Type)astNode.getEnvironment().getBindingValue
        (   AstStoreList.AST_TYPE,
            astNode.getName(),
            level
        );
        if(type != null)
            if(type.getSubTypeCount() == 0)
                setTypeResolved(astNode, type);
            else
                throw new TypeMismatchException(type, astNode);
        else
            didntResolve(astNode);
    }

    /**
     * <pre>
     * Γ |- <>
     * -------
     * Γ |- <>
     * </pre>
     */
    public void visit(AstNodeLiteralID astNode)
    {   // AstNodeLiteralID.getType() always null
    }

    /**
     * <pre>
     *    Γ |- <>
     * ------------  N = {(-2^31)..(2^31-1)}
     * Γ |- N[:]int
     * </pre>
     */
    public void visit(AstNodeLiteralInt astNode)
    {   // AstNodeLiteralInt.getType() always equal Type.TypeInt
    }

    /**
     * <pre>
     *      Γ |- <>
     * -----------------  * = {ASCII-{\,"},\\,\"}
     * Γ |- "*"[:]string
     * </pre>
     */
    public void visit(AstNodeLiteralString astNode)
    {   // AstNodeLiteralString.getType() always equal Type.TypeString
    }

    /**
     * <pre>
     *      Γ |- <>
     * ----------------
     * Γ |- true[:]bool
     * </pre>
     */
    public void visit(AstNodeLiteralTrue astNode)
    {   // AstNodeLiteralTrue.getType() always equal Type.TypeBool
    }

    /**
     * <pre>
     * Γ |- <>
     * --------
     * Γ |- e:T
     * </pre>
     */
    public void visit(AstNodeParam astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode value = astNode.getChild(0);
        if(value.getTypeResolved() == true)
            setTypeResolved(astNode, value.getType());
        else
            didntResolve(astNode);
    }

    /**
     * <pre>
     *         Γ |- <>
     * -----------------------  F = T0->..->TN->R
     * Γ |- (i0:T0,..,iN:TN):F
     * </pre>
     */
    public void visit(AstNodeParamList astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        int index;
        Type[] types = new Type[astNode.getChildCount()];
        // Param list is compound type of all its children's types
        for(index = 0; index < astNode.getChildCount(); index++)
        {   AstNode value = astNode.getChild(index);
            if(value.getTypeResolved() == true)
                types[index] = value.getType();
            else
                break;
        }
        // If all children are resolved, create the new compound type
        if(index == astNode.getChildCount())
            setTypeResolved(astNode, new CompoundType(types));
        else
            didntResolve(astNode);
    }

    /**
     * Set up store so that accessing a type by its name will return that type
     * <pre>
     *         Γ|σ |- <>            T = {bool, int, float, string}
     * ---------------------------  Fresh loc.T
     * Γ,T->loc.T|σ{T/loc.T} |- <>
     * </pre>
     */
    public void visit(AstNodeProgram astNode)
    {
        
        if(astNode.getChildCount() == 0)
            return;
        
        // type names and bindings stored together, but type names start with :
        Environment env = astNode.getEnvironment();
        env.ctorStore(AstStoreList.AST_TYPE);
        env.ctorStore(AstStoreList.AST_VALUE);
        env.ctorBinding(AstStoreList.AST_TYPE, ":bool", Type.TypeBool, this);
        env.ctorBinding(AstStoreList.AST_TYPE, ":int", Type.TypeInt, this);
        env.ctorBinding(AstStoreList.AST_TYPE, ":float", Type.TypeFloat, this);
        env.ctorBinding(AstStoreList.AST_TYPE, ":string", Type.TypeString, this);

        didntResolve(astNode);
        _didProgress = true;
        while(_astNodeNotResolved != null && _didProgress == true)
        {   assumeAllResolved();
            visitChildren(astNode);
            if(astNode.getTypeResolved() == true)
                continue;
            AstNode lastChildAstNode = astNode.getChild
            (   astNode.getChildCount() - 1
            );
            if(lastChildAstNode.getTypeResolved() == true)
                setTypeResolved(astNode, lastChildAstNode.getType());
            else
                didntResolve(astNode);

        }

        if(_astNodeNotResolved != null && _didProgress == false)
            throw new TypeUnknownException(_astNodeNotResolved);

    }

    /**
     * <pre>
     *      Γ,T0,..,TN |- <>
     * --------------------------
     * Γ |- [e0:T0; ..; eN:TN]:TN
     * </pre>
     */
    public void visit(AstNodeStatementList astNode)
    {   astNode.getEnvironment().ctorStore(AstStoreList.AST_TYPE);
        astNode.getEnvironment().ctorStore(AstStoreList.AST_VALUE);
        visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode lastChildAstNode = astNode.getChild
        (   astNode.getChildCount() - 1
        );
        if(lastChildAstNode == null)
            throw new TypeUnknownException(astNode);
        if(lastChildAstNode.getTypeResolved() == true)
            setTypeResolved(astNode, lastChildAstNode.getType());
        else
            didntResolve(astNode);
    }

    /**
     * <pre>
     *    Γ,T |- <>
     * ---------------
     * Γ |- (~(e:T)):T
     * </pre>
     */
    public void visit(AstNodeUopLevel astNode)
    {   _level++;
        visitChildren(astNode);
        assert _level == 0;
        if(astNode.getTypeResolved() == true)
            return;
        AstNode value = astNode.getChild(0);
        if(value.getTypeResolved() == true)
            setTypeResolved(astNode, value.getType());
        else
            didntResolve(astNode);
    }

    /**
     * <pre>
     *    Γ,T |- <>
     * ---------------  T != {string}
     * Γ |- (-(e:T)):T
     * </pre>
     */
    public void visit(AstNodeUopMinus astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode value = astNode.getChild(0);
        if(value.getTypeResolved() == true)
            if(isOneOfType(value, TypeNotString) == true)
                setTypeResolved(astNode, value.getType());
            else
                throw new TypeIllegalException(value, value);
        else
            didntResolve(astNode);
    }

    /**
     * <pre>
     *    Γ,T |- <>
     * ---------------  T != {bool, string}
     * Γ |- (+(e:T)):T
     * </pre>
     */
    public void visit(AstNodeUopPlus astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode value = astNode.getChild(0);
        if(value.getTypeResolved() == true)
            if(isOneOfType(value, TypeNumber) == true)
                setTypeResolved(astNode, value.getType());
            else
                throw new TypeIllegalException(value, value);
        else
            didntResolve(astNode);
    }

    /**
     * <pre>
     *   Γ,R,s:R |- while -> R
     * -------------------------
     * Γ |- while:R(e:bool){s:R}
     * </pre>
     */
    public void visit(AstNodeWhile astNode)
    {   visitChildren(astNode);
        if(astNode.getTypeResolved() == true)
            return;
        AstNode condition = astNode.getChild(0);
        AstNode value = astNode.getChild(1);
        if(condition.getTypeResolved() == true
        && value.getTypeResolved() == true)
            if(isType(condition, Type.TypeBool) == true)
                setTypeResolved(astNode, value.getType());
            else
                throw new TypeMismatchException
                (   condition,
                    Type.TypeBool,
                    condition
                );
        else
            didntResolve(astNode);
    }

    public AstAcceptOrderer getDefaultOrderer()
    {   return null;
    }

    private void visitChildren(AstNode astNode)
    {   for(int index = 0; index < astNode.getChildCount(); index++)
            astNode.getChild(index).accept(this);
    }

    public void throwStoreMissingException
    (   String            storeName,
        int                   level,
        AstNode parserSourceAstNode
    ){  throw new TypeStoreMissingException
        (   storeName,
            level,
            parserSourceAstNode
        );
    }

    public void throwBindingExistsException
    (   String          bindingName,
        Object          bindingData,
        AstNode parserSourceAstNode
    ){  Type existingType = (Type)bindingData;
        throw new TypeExistsException
        (   bindingName,
            existingType,
            parserSourceAstNode
        );
    }

    private static Type[] TypeAll = new Type[]
    {   Type.TypeBool,
        Type.TypeInt,
        Type.TypeFloat,
        Type.TypeString
    };
    
    private static Type[] TypeNotBool = new Type[]
    {   Type.TypeInt,
        Type.TypeFloat,
        Type.TypeString
    };
    
    private static Type[] TypeNotString = new Type[]
    {   Type.TypeBool,
        Type.TypeInt,
        Type.TypeFloat
    };
    
    private static Type[] TypeNumber = new Type[]
    {   Type.TypeInt,
        Type.TypeFloat
    };
    
    private boolean isOneOfType(Type type, Type... versusTypes)
    {   for(Type versusType : versusTypes)
            if(type.equals(versusType) == true)
                return true;
        return false;
    }
    
    private boolean isOneOfType(AstNode node, Type... versusTypes)
    {   return isOneOfType(node.getType(), versusTypes);
    }
    
    private boolean isType(AstNode node, Type versusType)
    {   return isOneOfType(node.getType(), versusType);
    }
    
    private boolean isType(AstNode node, AstNode versusNode)
    {   return isOneOfType(node.getType(), versusNode.getType());
    }
    
    /**
     * Before visiting, assume all are resolved
     */
    private void assumeAllResolved()
    {   _astNodeNotResolved = null;
        _didProgress = false;
    }

    private void didntResolve(AstNode astNode)
    {   if(_astNodeNotResolved == null)
            _astNodeNotResolved = astNode;
    }
    
    /**
     * Helper that not only sets a node's intermediate type, but updates
     *  didProgress to true and allResolved to false
     * @param astNode The node whose type is to be set
     * @param type The type to set
     */
    private void setType(AstNode astNode, Type type)
    {   astNode.setType(type);
        _astNodeNotResolved = astNode;
        _didProgress = true;
    }

    /**
     * Helper that not only sets a node's type, but updates didProgress to true
     * @param astNode The node whose type is to be set
     * @param type The type to set
     */
    private void setTypeResolved(AstNode astNode, Type type)
    {   astNode.setTypeResolved(type);
        _didProgress = true;
    }

    /**
     * Assume all types are resolved. When one is found that's not, this
     *  goes to false and the whole tree must be re-visited
     */
    private AstNode _astNodeNotResolved = null;

    /**
     * Assume no progress is being made. When a node's type is updated this goes
     *  to true. This allows it to detects if its reached a stage where there
     *  are types that will never be resolved (such as undeclared identifiers)
     */
    private boolean _didProgress = false;
    /**
     * When accessing the next identifier, search for it at this level (above
     *  the current level (change of scope))
     */
    private int _level = 0;

}
