package real.ast;

import java.util.ArrayList;
import java.util.List;
import real.ast.environment.Environment;
import real.ast.type.Type;
import real.ast.visitor.AstVisitor;
import real.ast.visitor.AstVisitor.AstAcceptOrderer;
import real.parser.ParserSource;

/**
 * @author e
 */
public abstract class AstNode
{

    //--------------------------------------------------------------------------
    // Relative nodes

    /**
     * Get the parent of this node
     * @return the parent of this node
     */
    public AstNode getParent()
    {   return _parent;
    }
    
    /**
     * Add an AST node as a child of this one. The AST node cannot be a child
     *  of another parent when this is called (call removeChild to remove a
     *  a child from its parent)
     * @param node The AST node to add
     */
    public void appendChild(AstNode astNode)
    {   assert(astNode.getParent() == null);
        if(_children == null)
            _children = new ArrayList<AstNode>();
        _children.add(astNode);
        astNode.setParent(this);
    }
    
    /**
     * Add an AST node as a child of this one, replacing a specified child. The
     *  replaced child then becomes a child of the added node, e.g., if 'B' is a
     *  child of 'A' and 'C' is inserted in 'A' on top of 'B', 'B' will become a
     *  child of 'C', and 'C' will be a child of 'A' in the index position where
     *  'B' used to be
     * @param astNode The AST node to add in position of the child
     * @param index The child to moved into a child of the <var>astNode</var>
     *  and the position the <var>astNode</var> is to be inserted
     * @return
     */
    public void insertChild(AstNode astNode, AstNode childAstNode)
    {   assert(astNode.getParent() == null);
        assert(childAstNode.getParent() == this);
        _children.set(_children.indexOf(childAstNode), astNode);
        astNode.setParent(this);
        childAstNode.setParent(null);
        astNode.appendChild(childAstNode);
    }
    
    public void replaceChild(AstNode astNode, AstNode childAstNode)
    {   assert(astNode.getParent() == null);
        assert(childAstNode.getParent() == this);
        _children.set(_children.indexOf(childAstNode), astNode);
        astNode.setParent(this);
        childAstNode.setParent(null);
        while(childAstNode.getChildCount() > 0)
            astNode.appendChild(childAstNode.removeChild(0));
    }

    /**
     * Remove as AST node from this one. Once removed, it will no longer have a
     *  parent or be contained in this node's children list
     * @param index The index of the child to remove
     * @return The removed child
     */
    public AstNode removeChild(int index)
    {   AstNode child = _children.remove(index);
        child.setParent(null);
        return child;
    }
    
    /**
     * Get how many children AST nodes are directly below this one
     * @return how many children AST nodes are directly below this one
     */
    public int getChildCount()
    {   if(_children == null)
            return 0;
        return _children.size();
    }
    
    /**
     * Get the indexed AstNode. <var>index</var> must be in the range
     *  0..getChildCount()-1
     * @param index The index of the AST node to retrieve
     * @return the indexed AstNode
     */
    public AstNode getChild(int index)
    {   if(_children == null)
            return null;
        if(index < 0 || index >= getChildCount())
            return null;
        return _children.get(index);
    }
    
    /**
     * Sets a node as being the parent of this node. This is handled internally,
     *  called by the parent when this node is set to a child of that parent
     * @param parent
     */
    private void setParent(AstNode parent)
    {   _parent = parent;
    }
    
    //--------------------------------------------------------------------------
    // Node type

    /**
     * Update the best known type for this node. The type will remain unresolved
     * @param type the type of this node
     */
    public void setType(Type type)
    {   assert _typeResolved == false;
        _type = type;
    }
    /**
     * Fix the type for this node. The type cannot be modified afterwards
     * @param type the type of this node
     */
    public void setTypeResolved(Type type)
    {   assert _typeResolved == false;
        _type = type;
        _typeResolved = true;
        // Don't call this assert before _typeResolved is set to true as the
        //  first thing it does is to check that <var>this</var> is resolved
        //assert assertTypeResolved();
    }
    /**
     * Get the current best known type for this node
     * @return the current best known type for this node
     */
    public Type getType()
    {   return _type;
    }
    /**
     * Get whether this node's type is fixed. The type cannot be modified if
     *  this is true
     * @return whether this node's type is fixed
     */
    public boolean getTypeResolved()
    {   return _typeResolved;
    }

    /**
     * Get this node's layered position in the AST
     */
    public abstract int getPrecedence();

    //--------------------------------------------------------------------------
    // Data store

    public Environment getEnvironment()
    {   if(_environment == null)
            _environment = new Environment(this);
        return _environment;
    }
    
    //--------------------------------------------------------------------------
    // Error reporting - information about the node/code relation

    public ParserSource getParserSource()
    {   if(_parserSource == null)
            _parserSource = new ParserSource();
        return _parserSource;
    }

    //--------------------------------------------------------------------------
    // Visitor

    /**
     * Start visiting this and all children nodes using the visitors default
     *  orderer
     * @param astVisitor The visitor to visit the nodes
     */
    public void applyVisitor(AstVisitor astVisitor)
    {   applyVisitor(astVisitor, astVisitor.getDefaultOrderer());
    }
    
    /**
     * Start visiting this and all children nodes using a custom accept orderer
     *  allowing the nodes to be visited in a different order. If no order is
     *  specified (null), no automatic ordering is done and it is up to the
     *  visitor to accept all its children (and this only accepts the root)
     * @param astVisitor The visitor to visit the nodes
     * @param astAcceptOrderer Orderer that controls how nodes are visited
     */
    public void applyVisitor
    (   AstVisitor astVisitor,
        AstAcceptOrderer astAcceptOrderer
    ){  astVisitor.beforeVisit();
        if(astAcceptOrderer == null)
            accept(astVisitor);
        else
            astAcceptOrderer.order(this, astVisitor);
        astVisitor.afterVisit();
    }
    
    /**
     * Called by accept orderer when it wants this node to be visited by the
     *  specified visitor
     * @param astVisitor The visitor that is visiting the nodes
     */
    public abstract void accept(AstVisitor astVisitor);
    
    //--------------------------------------------------------------------------
    // Helpers

    /**
     * Get whether all children's (recursively) types are fixed. Returns false
     *  if any child's getTypeResolved() is false, and true if all children's
     *  getTypeResolved() are true. Note: this is only an assertion helper
     *  to check that setTypeResolved is set true iff all it's children are
     *  true, and as such requires that the calling node's type is resolved
     *  as the first thing it does is test itself
     * @return whether all children's (recursively) types are fixed
     */
    private boolean assertTypeResolved()
    {   if(getTypeResolved() == false)
            return false;
        else
            for(int i = 0; i < getChildCount(); i++)
                if(getChild(i).assertTypeResolved() == false)
                    return false;
        return true;
    }

    @Override
    public String toString()
    {   return
            getClass().getSimpleName()
         +  "; pr:" + getPrecedence()
         +  "; ty:" + getType() + (getTypeResolved() == true ? " (+)" : " (-)")
         +  "; cc:" + getChildCount()
         +  "; ps:" + getParserSource().toString()
         +  "; st:" + getEnvironment().toString();
    }

    //--------------------------------------------------------------------------
    // Data

    // Relatives  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    /**
     * The parent of this node
     */
    private AstNode _parent = null;
    /**
     * Keep a list of children below this node
     */
    private List<AstNode> _children = null;
    // Types  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    /**
     * Cache the type that this node resolves to
     */
    private Type _type = null;
    /**
     * During static type checking, types that cannot yet be resolved will
     *  keep this false. Loop will continue until all nodes'
     *  <var>_typeResolved</var> is are true.
     * Note: this._typeResolved => for_all this.getChild()._typeResolved 
     */
    private boolean _typeResolved = false;
    /**
     * Store details about where this node came from in the source code
     */
    private ParserSource _parserSource;
    /**
     * Associate some named data with the node in a named store
     */
    private Environment _environment;
    
}
