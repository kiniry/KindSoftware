package real.ast;

import real.ast.visitor.AstVisitor;

/**
 * Assign r-value to l-value :  a = b;
 *  Where 'a' is a the declaration of a type, variable, or function; or 'a' is
 *  an instance of a variable; and where 'b' is any expression that does not
 *  contain an Assign
 *  
 * @author e
 */
public class AstNodeDeclareVariableType extends AstNode
{

    @Override
    public void accept(AstVisitor astVisitor)
    {   astVisitor.visit(this);
    }

    @Override
    public int getPrecedence()
    {   return AstPrecedenceList.AST_TYPE;
    }

}
