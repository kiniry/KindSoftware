package real.ast;

/**
 * @author e
 */
public interface AstNodeExceptionFactory
{

    public void throwStoreMissingException
    (   String            storeName,
        int                   level,
        AstNode parserSourceAstNode
    );
    public void throwBindingExistsException
    (   String          bindingName,
        Object         existingType,
        AstNode parserSourceAstNode
    );

}
