package real.ast;

/**
 * @author e
 */
public abstract class AstNodeIdentifier extends AstNode
{

    public AstNodeIdentifier(String name)
    {   //assert name.length() != 0;
        _name = name;
    }
    
    public String getName()
    {   return _name;
    }

    public int getLevel()
    {   return 0;
    }
    
    @Override
    public int getPrecedence()
    {   return AstPrecedenceList.AST_IDENTIFIER;
    }

    @Override
    public String toString()
    {   return super.toString() + "; n:" + getName();
    }

    private String _name;
    
}
