package real.ast;

import real.ast.visitor.AstVisitor;

/**
 * Constant boolean : true|false
 * @author e
 */
public class AstNodeIdentifierFunction extends AstNodeIdentifier
{

    public AstNodeIdentifierFunction(String name)
    {   super(name);
    }
    
    //--------------------------------------------------------------------------
    // Visitor

    @Override
    public void accept(AstVisitor astVisitor)
    {   astVisitor.visit(this);
    }

}
