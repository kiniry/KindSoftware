package real.ast;

import real.ast.type.Type;
import real.ast.visitor.AstVisitor;

/**
 * An identifier for a new type; where it itself does not yet have a type.
 * a:int=0; -- Creates 'a' of type 'int', but 'a' alone here is not typed yet
 * @author e
 */
public class AstNodeIdentifierNew extends AstNodeIdentifier
{

    public AstNodeIdentifierNew(String name)
    {   super(name);
    }
    
    @Override
    public void setType(Type type)
    {   throw new RuntimeException("AstNodeIdentifierNew can not have Type");
    }

    @Override
    public void setTypeResolved(Type type)
    {   throw new RuntimeException("AstNodeIdentifierNew can not have Type");
    }

    @Override
    public Type getType()
    {   return null;
    }

    @Override
    public boolean getTypeResolved()
    {   return true;
    }

    @Override
    public void accept(AstVisitor astVisitor)
    {   astVisitor.visit(this);
    }

}
