package real.ast;

import real.ast.visitor.AstVisitor;

/**
 * Constant boolean : true|false
 * @author e
 */
public class AstNodeIdentifierVariable extends AstNodeIdentifier
{

    public AstNodeIdentifierVariable(String name)
    {   super(name);
    }
    
    @Override
    public void accept(AstVisitor astVisitor)
    {   astVisitor.visit(this);
    }

}
