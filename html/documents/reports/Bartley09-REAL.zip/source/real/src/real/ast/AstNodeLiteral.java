package real.ast;

import real.ast.type.Type;

/**
 * @author e
 */
public abstract class AstNodeLiteral extends AstNode
{

    public abstract String getValue();
    
    //--------------------------------------------------------------------------
    // Node type

    /**
     * Cannot change the type of a constant int
     * @param type Ignored
     */
    @Override
    public void setType(Type type)
    {   assert false;
    }
    /**
     * Cannot change the type of a constant int
     * @param type Ignored
     */
    @Override
    public void setTypeResolved(Type type)
    {   assert false;
    }
    /**
     * Returns Int always
     * @return Int
     */
    @Override
    public abstract Type getType();
    /**
     * Returns true always. Type is fixed at Int
     * @return true
     */
    @Override
    public boolean getTypeResolved()
    {   return true;
    }    

    @Override
    public int getPrecedence()
    {   return AstPrecedenceList.AST_LITERAL;
    }

    @Override
    public String toString()
    {   return
            super.toString()
         +  "; n:" + getValue();
    }

}
