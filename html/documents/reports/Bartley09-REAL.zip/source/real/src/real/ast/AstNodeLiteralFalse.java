package real.ast;

import real.ast.type.Type;
import real.ast.visitor.AstVisitor;

/**
 * Constant boolean : true|false
 * @author e
 */
public class AstNodeLiteralFalse extends AstNodeLiteral
{

    public boolean getJavaValue()
    {   return false;
    }
    
    public String getValue()
    {   return "false";
    }

    /**
     * Returns Int always
     * @return Int
     */
    @Override
    public Type getType()
    {   return Type.TypeBool;
    }

    //--------------------------------------------------------------------------
    // Visitor

    @Override
    public void accept(AstVisitor astVisitor)
    {   astVisitor.visit(this);
    }

}
