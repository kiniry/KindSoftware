package real.ast;

import real.ast.type.Type;
import real.ast.visitor.AstVisitor;

/**
 * Constant float : N*.N+
 * @author e
 */
public class AstNodeLiteralFloat extends AstNodeLiteral
{

    public AstNodeLiteralFloat(String value)
    {   _value = Float.parseFloat(value);
    }

    public float getJavaValue()
    {   return _value;
    }
    
    public String getValue()
    {   return String.valueOf(_value);
    }
    
    /**
     * Returns Int always
     * @return Int
     */
    @Override
    public Type getType()
    {   return Type.TypeFloat;
    }

    //--------------------------------------------------------------------------
    // Visitor

    @Override
    public void accept(AstVisitor astVisitor)
    {   astVisitor.visit(this);
    }

    private float _value;
    
}
