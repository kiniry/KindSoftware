package real.ast;

import real.ast.type.Type;
import real.ast.visitor.AstVisitor;

/**
 * Constant ID
 * @author e
 */
public class AstNodeLiteralID extends AstNodeLiteral
{

    public String getValue()
    {   return null;
    }
    
    /**
     * Returns ID always
     * @return ID
     */
    @Override
    public Type getType()
    {   return Type.TypeID;
    }

    //--------------------------------------------------------------------------
    // Visitor

    @Override
    public void accept(AstVisitor astVisitor)
    {   astVisitor.visit(this);
    }

}
