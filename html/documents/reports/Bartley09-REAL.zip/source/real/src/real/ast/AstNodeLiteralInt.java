package real.ast;

import real.ast.type.Type;
import real.ast.visitor.AstVisitor;

/**
 * Constant int : N+
 * @author e
 */
public class AstNodeLiteralInt extends AstNodeLiteral
{

    public AstNodeLiteralInt(String value)
    {   _value = Integer.parseInt(value);
    }

    public int getJavaValue()
    {   return _value;
    }
    
    public String getValue()
    {   return String.valueOf(_value);
    }
    
    /**
     * Returns Int always
     * @return Int
     */
    @Override
    public Type getType()
    {   return Type.TypeInt;
    }

    //--------------------------------------------------------------------------
    // Visitor

    @Override
    public void accept(AstVisitor astVisitor)
    {   astVisitor.visit(this);
    }

    private int _value;
    
}
