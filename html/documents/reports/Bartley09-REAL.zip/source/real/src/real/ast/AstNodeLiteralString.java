package real.ast;

import real.ast.type.Type;
import real.ast.visitor.AstVisitor;

/**
 * Constant string : "*"
 * @author e
 */
public class AstNodeLiteralString extends AstNodeLiteral
{

    public AstNodeLiteralString(String value)
    {   _value = value;
    }

    public String getJavaValue()
    {   return _value;
    }
    
    public String getValue()
    {   return _value;
    }
    
    /**
     * Returns Int always
     * @return Int
     */
    @Override
    public Type getType()
    {   return Type.TypeString;
    }

    //--------------------------------------------------------------------------
    // Visitor

    @Override
    public void accept(AstVisitor astVisitor)
    {   astVisitor.visit(this);
    }

    private String _value;
    
}
