package real.ast;

import real.ast.type.Type;
import real.ast.visitor.AstVisitor;

/**
 * Constant boolean : true|false
 * @author e
 */
public class AstNodeLiteralTrue extends AstNodeLiteral
{

    public boolean getJavaValue()
    {   return true;
    }
    
    public String getValue()
    {   return "true";
    }
    
    /**
     * Returns Int always
     * @return Int
     */
    @Override
    public Type getType()
    {   return Type.TypeBool;
    }

    //--------------------------------------------------------------------------
    // Visitor

    @Override
    public void accept(AstVisitor astVisitor)
    {   astVisitor.visit(this);
    }

}
