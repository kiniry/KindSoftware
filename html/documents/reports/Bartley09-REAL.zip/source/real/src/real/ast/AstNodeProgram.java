package real.ast;

import real.ast.visitor.AstVisitor;

/**
 * @author e
 */
public class AstNodeProgram extends AstNodeStatementList
{

    @Override
    public void accept(AstVisitor astVisitor)
    {   astVisitor.visit(this);
    }

}
