package real.ast;

import real.ast.visitor.AstVisitor;

/**
 * @author e
 */
public class AstNodeStatementList extends AstNode
{

    //--------------------------------------------------------------------------
    // Visitor

    @Override
    public void accept(AstVisitor astVisitor)
    {   astVisitor.visit(this);
    }

    @Override
    public int getPrecedence()
    {   return AstPrecedenceList.AST_BLOCK;
    }

}
