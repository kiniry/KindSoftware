package real.ast;

import real.ast.visitor.AstVisitor;

/**
 * @author e
 */
public class AstNodeUopLevel extends AstNodeIdentifier
{

    public AstNodeUopLevel()
    {   super(null);
    }

    @Override
    public String getName()
    {   return ((AstNodeIdentifier)getChild(0)).getName();
    }

    @Override
    public int getLevel()
    {   return ((AstNodeIdentifier)getChild(0)).getLevel() + 1;
    }
    
    @Override
    public void accept(AstVisitor astVisitor)
    {   astVisitor.visit(this);
    }

    @Override
    public int getPrecedence()
    {   return AstPrecedenceList.AST_LEVEL;
    }

    @Override
    public String toString()
    {   return super.toString() + "; l:" + getLevel();
    }

}
