package real.ast;

import real.ast.visitor.AstVisitor;

/**
 * @author e
 */
public class AstNodeUopPlus extends AstNode
{

    @Override
    public void accept(AstVisitor astVisitor)
    {   astVisitor.visit(this);
    }

    @Override
    public int getPrecedence()
    {   return AstPrecedenceList.AST_UOP;
    }

}
