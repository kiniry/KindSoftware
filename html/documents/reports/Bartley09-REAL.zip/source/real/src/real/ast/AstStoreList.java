package real.ast;

/*
 * @author e
 */
public class AstStoreList
{   public static final String AST_TYPE = "type";
    public static final String AST_VALUE = "value";
}
