package real.ast.environment;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

/**
 * @author e
 */
public class Bindings implements Iterable<Entry<String, Object>>
{

    public Bindings() { }

    public Bindings(Bindings cloneBindings)
    {   for(Entry<String, Object> bindingEntry : cloneBindings)
            _bindings.put(bindingEntry.getKey(), bindingEntry.getValue());
    }

    public boolean containsKey(String key)
    {   return _bindings.containsKey(key);
    }
    
    public void put(String key, Object value)
    {   _bindings.put(key, value);
    }
    
    public Object get(String key)
    {   return _bindings.get(key);
    }
    
    public Iterator<Entry<String, Object>> iterator()
    {   return _bindings.entrySet().iterator();
    }

    private HashMap<String, Object> _bindings = new HashMap<String, Object>();

}
