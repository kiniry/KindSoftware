package real.ast.environment;

import java.util.Map.Entry;
import real.ast.AstNode;
import real.ast.AstNodeExceptionFactory;

/**
 * @author e
 */
public class Environment
{

    public Environment(AstNode astNode)
    {   _astNode = astNode;
    }
    
    /**
     * Construct a store for this node. If a store has already been constructed
     *  this does nothing. To create a new store, the old one must be
     *  destructed with dtorStore() first
     */
    public void ctorStore(String storeName)
    {   if(_store == null)
            _store = new Store();
        if(_store.containsKey(storeName) == false)
            _store.put(storeName, new Stack());
    }
    
    /**
     * Destruct a store
     */
    public void dtorStore(String storeName)
    {   if(_store != null && _store.containsKey(storeName) == true)
            _store.remove(storeName);
    }

    /**
     * Add a named binding to the store. If no store exists for this node, the
     *  parent nodes are searched until the a store is found
     * @param storeName The name of the store to place the binding
     * @param bindingName The name to bind to
     * @param value The value bound
     */
    public void ctorBinding
    (   String                         storeName,
        String                       bindingName,
        Object                             value,
        AstNodeExceptionFactory exceptionFactory
    ){  ctorBindingIndirect
        (   storeName,
            bindingName,
            value,
            0,
            exceptionFactory
        );
    }

    /**
     * Add a named binding to the store. If no store exists for this node, the
     *  parent nodes are searched until the a <var>level</var>'th store is found
     * @param storeName The name of the store to place the binding
     * @param bindingName The name to bind to
     * @param value The value bound
     * @param level The number of stores to search before storing
     */
    public void ctorBindingIndirect
    (   String                         storeName,
        String                       bindingName,
        Object                             value,
        int                                level,
        AstNodeExceptionFactory exceptionFactory
    ){  Bindings bindings = getStoreBindings(storeName);
        Environment parent = getParentEnvironment();
        if(bindings == null)
            if(parent == null)
                exceptionFactory.throwStoreMissingException
                (   storeName,
                    level,
                    _astNode
                );
            else
                parent.ctorBindingIndirect
                (   storeName,
                    bindingName,
                    value,
                    level,
                    exceptionFactory
                );
        else
        if(level > 0)
            parent.ctorBindingIndirect
            (   storeName,
                bindingName,
                value,
                level - 1,
                exceptionFactory
            );
        else
        if(bindings.containsKey(bindingName) == false)
            bindings.put(bindingName, value);
        else
            exceptionFactory.throwBindingExistsException
            (   bindingName,
                bindings.get(bindingName),
                _astNode
            );
    }

    public void pushBinding(String storeName)
    {   _store.get(storeName).push();
    }
    
    public void popBinding(String storeName)
    {   _store.get(storeName).pop();
    }
    
    public Object getBindingValue(String storeName, String bindingName)
    {   return getBindingValue(storeName, bindingName, 0);
    }
    
    /**
     * Get the value of a named binding. The first store found (from current to
     *  root nodes) that has the named binding is returned
     * @param storeName The name of the store to get the binding
     * @param bindingName The name of the binding
     * @return The value contained in the nearest store with the named binding
     */
    public Object getBindingValue
    (   String storeName,
        String bindingName,
        int level
    ){  Bindings binding = getStoreBindings(storeName);
        Environment parent = getParentEnvironment();
        if(level > 0
        || binding == null
        || binding.containsKey(bindingName) == false)
            if(parent == null)
                return null;
            else
                return parent.getBindingValue
                (   storeName,
                    bindingName,
                    binding == null ? level : level - 1
                );
        else
            return binding.get(bindingName);
    }
    
    public Object getLocalBindingValue
    (   String storeName,
        String bindingName
    ){  Bindings binding = getStoreBindings(storeName);
        if(binding == null
        || binding.containsKey(bindingName) == false)
            return null;
        return binding.get(bindingName);
    }
    
    public void setBindingValue
    (   String   storeName,
        String bindingName,
        Object       value
    ){  setBindingValue(storeName, bindingName, value, 0);
    }
    
    public void setBindingValue
    (   String   storeName,
        String bindingName,
        Object       value,
        int          level
    ){  Bindings binding = getStoreBindings(storeName);
        Environment parent = getParentEnvironment();
        if(level > 0
        || binding == null
        || binding.containsKey(bindingName) == false)
            if(parent == null)
                return;
            else
                parent.setBindingValue
                (   storeName,
                    bindingName,
                    value,
                    binding == null ? level : level - 1
                );
        else
            binding.put(bindingName, value);
    }

    public SimpleEnvironment getSimpleEnvironment(String storeName)
    {   SimpleEnvironment simpleEnvironment = new SimpleEnvironment();
        getSimpleEnvironment(storeName, simpleEnvironment);
        return simpleEnvironment;
    }

    private void getSimpleEnvironment
    (   String                    storeName,
        SimpleEnvironment simpleEnvironment
    ){  Bindings bindings = getStoreBindings(storeName);
        Environment parent = getParentEnvironment();
        if(bindings != null)
        {   SimpleBindings simpleBindings = new SimpleBindings();
            simpleEnvironment.add(simpleBindings);
            for(Entry<String, Object> bindingEntry : bindings)
                simpleBindings.add
                (   new SimpleBinding
                    (   bindingEntry.getKey(),
                        bindingEntry.getValue()
                    )
                );
        }
        if(parent != null)
            parent.getSimpleEnvironment(storeName, simpleEnvironment);
    }
    
    private Bindings getStoreBindings(String storeName)
    {   if(_store == null || _store.containsKey(storeName) == false)
            return null;
        return _store.get(storeName).peek();
    }

    private Environment getParentEnvironment()
    {   if(_astNode.getParent() == null)
            return null;
        return _astNode.getParent().getEnvironment();
    }

    @Override
    public String toString()
    {   StringBuilder builder = new StringBuilder();
        boolean storeFirst = true;
        if(_store != null)
        {   boolean bindingFirst = true;
            for(Entry<String, Stack> storeEntry : _store)
            {   builder.append(storeFirst == true ? '(' : ", (");
                builder.append(storeEntry.getKey());
                builder.append(", (");
                for
                (   Entry<String, Object> bindingEntry
                 :  storeEntry.getValue().peek()
                ){  builder.append(bindingFirst == true ? '(' : ", (");
                    builder.append(bindingEntry.getKey());
                    builder.append(", ");
                    builder.append(bindingEntry.getValue());
                    builder.append(")");
                    bindingFirst = false;
                }
                builder.append("))");
                storeFirst = false;
            }
        }
        else
            builder.append("none");
        return builder.toString();
    }

    /**
     * Associate some named data with the node in a named store
     */
    private Store _store;
    /**
     * The AST node this environment belongs to
     */
    private AstNode _astNode;
    
}
