package real.ast.environment;

import real.ast.AstNode;

/**
 * @author e
 */
public class SimpleBinding
{

    SimpleBinding(String name, Object value)
    {   _name = name;
        if(value instanceof AstNode)
            _value = "FN:" + ((AstNode)value).getType();
        else
            _value = value;
    }
    
    public String getName()
    {   return _name;
    }
    
    public Object getValue()
    {   return _value;
    }

    @Override
    public String toString()
    {   return _name + "=" + _value;
    }
    
    private String _name;
    private Object _value;

}
