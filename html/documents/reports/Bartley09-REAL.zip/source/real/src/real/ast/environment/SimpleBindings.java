package real.ast.environment;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author e
 */
public class SimpleBindings implements Iterable<SimpleBinding>
{

    void add(SimpleBinding binding)
    {   _bindings.add(binding);
    }
    
    public Iterator<SimpleBinding> iterator()
    {   return _bindings.iterator();
    }

    @Override
    public String toString()
    {   StringBuilder builder = new StringBuilder();
        for(SimpleBinding binding : _bindings)
        {   if(builder.length() != 0)
                builder.append(", ");
            builder.append(binding);
        }
        return builder.toString();
    }
    
    private List<SimpleBinding> _bindings = new ArrayList<SimpleBinding>();

}
