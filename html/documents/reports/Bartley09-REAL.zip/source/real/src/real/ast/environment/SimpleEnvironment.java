package real.ast.environment;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author e
 */
public class SimpleEnvironment implements Iterable<SimpleBindings>
{

    void add(SimpleBindings bindings)
    {   _bindings.add(bindings);
    }
    
    public Iterator<SimpleBindings> iterator()
    {   return _bindings.iterator();
    }

    @Override
    public String toString()
    {   StringBuilder builder = new StringBuilder();
        for(SimpleBindings bindings : _bindings)
        {   builder.append(bindings);
            builder.append('\n');
        }
        return builder.toString();
    }

    private List<SimpleBindings> _bindings = new ArrayList<SimpleBindings>();

}
