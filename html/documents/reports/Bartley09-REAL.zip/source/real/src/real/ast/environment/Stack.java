package real.ast.environment;

/**
 * @author e
 */
public class Stack
{
    public Stack()
    {   _stack.push(new Bindings());
    }

    public void push()
    {   Bindings bindings = _stack.peek();
        _stack.push(new Bindings(bindings));
    }

    public Bindings pop()
    {   return _stack.pop();
    }
    
    public Bindings peek()
    {   return _stack.peek();
    }
    
    private java.util.Stack<Bindings> _stack = new java.util.Stack<Bindings>();
    
}
