package real.ast.environment;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

/**
 * @author e
 */
public class Store implements Iterable<Entry<String, Stack>>
{
    
    public boolean containsKey(String key)
    {   return _store.containsKey(key);
    }
    
    public void put(String key, Stack stack)
    {   _store.put(key, stack);
    }
    
    public Stack get(String key)
    {   return _store.get(key);
    }
    
    public void remove(String key)
    {   _store.remove(key);
    }
    
    public Iterator<Entry<String, Stack>> iterator()
    {   return _store.entrySet().iterator();
    }
    
    private HashMap<String, Stack> _store = new HashMap<String, Stack>();

}