package real.ast.type;

/**
 * @author e
 */
public enum BasicTypes
{    /** Untyped, waiting to be resolved */
    NONE,
    /** Special type for IDx literals (which implicitly become any type) */
    ID,
    /** Type with two values (true or fales) */
    BOOL,
    /** Type with signed 32bit integer values */
    INT,
    /** Type with IEEE 64bit float values */
    FLOAT,
    /** Array of 8bit ASCII characters */
    STRING,
    /** A type made up of several other types */
    COMPOUND,
}
