package real.ast.type;

/**
 * Everything must have a simple type, a single type it can be 
 * @author e
 */
public class CompoundType extends Type
{

    /**
     * Construct this type as a collection of an arbitrary number of sub-types
     * @param types all the types that make up this compound type
     */
    public CompoundType(Type... types)
    {   _types = types;
    }

    /**
     * Always COMPOUND
     * @return COMPOUND
     */
    @Override
    public BasicTypes getBasicType()
    {   return BasicTypes.COMPOUND;
    }

    /**
     * Equal if both have the same basic type, and the same number of sub-types
     *  and all sub-types are in the same order; repeat recursively for each
     *  sub-type
     */
    @Override
    public boolean equals(Type versusType)
    {   if(getBasicType() != versusType.getBasicType())
            return false;
        if(getSubTypeCount() != versusType.getSubTypeCount())
            return false;
        for(int index = 0; index < getSubTypeCount(); index++)
            if(getSubType(index).equals
            (   versusType.getSubType(index)
            ) == false)
                return false;
        return true;
    }

    /**
     * Number of sub-types
     * @return
     */
    @Override
    public int getSubTypeCount()
    {   return _types.length;
    }

    @Override
    public Type getSubType(int index)
    {   if(index >= 0 && index < getSubTypeCount())
            return _types[index];
        return null;
    }

    /**
     * @return "(T0, .., Tn)" -- T output recursively
     */
    @Override
    public String toString()
    {   StringBuilder builder = new StringBuilder();
        builder.append('(');
        for(Type type : _types)
        {   if(builder.length() != 1)
                builder.append(", ");
            builder.append(type.toString());
        }
        builder.append(')');
        return builder.toString();
    }

    private Type[] _types;

}
