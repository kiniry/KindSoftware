package real.ast.type;

/**
 * @author e
 */
public class SimpleType extends Type
{

    /**
     * Set the simple type. Must be ID, BOOL, INT, FLOAT, or STRING
     * @param type The simple type
     */
    public SimpleType(BasicTypes type)
    {   assert
            type == BasicTypes.ID
         || type == BasicTypes.BOOL
         || type == BasicTypes.INT
         || type == BasicTypes.FLOAT
         || type == BasicTypes.STRING;
        _type = type;
    }

    /**
     * Simple types can only be basic types, so just return that
     * @return
     */
    @Override
    public BasicTypes getBasicType()
    {   return _type;
    }

    /**
     * If both have the same simple type, they're the same. If the versusType
     *  is a compound type, it's basic type will be COMPOUND, so will never
     *  match this type (even if it's a compound of only a single simple type
     *  that matches (I wonder, is this correct?))
     * @param versusType
     * @return
     */
    @Override
    public boolean equals(Type versusType)
    {   // IDx types are always equal. This only applies to literal IDx values
        if(getBasicType() == BasicTypes.ID
        || versusType.getBasicType() == BasicTypes.ID)
            return true;
        return getBasicType() == versusType.getBasicType();
    }

    /**
     * 0 - no sub types
     * @return
     */
    @Override
    public int getSubTypeCount()
    {   return 0;
    }

    /**
     * null - no sub types
     * @param index
     * @return
     */
    @Override
    public Type getSubType(int index)
    {   return null;
    }

    @Override
    public String toString()
    {   return _type.name();
    }

    private BasicTypes _type;

}
