package real.ast.type;

/**
 * @author e
 */
public abstract class Type
{

    // Turn all basic types into SimpleTypes
    public static final Type TypeID = new SimpleType(BasicTypes.ID);
    public static final Type TypeBool = new SimpleType(BasicTypes.BOOL);
    public static final Type TypeInt = new SimpleType(BasicTypes.INT);
    public static final Type TypeFloat = new SimpleType(BasicTypes.FLOAT);
    public static final Type TypeString = new SimpleType(BasicTypes.STRING);
    
    /**
     * Get the basic type of this type; either one of the core basic types or
     *  compound
     * @return the basic type of this type
     */
    public abstract BasicTypes getBasicType();
    /**
     * Test if this type is equal to another
     * @param type the type to compare against
     * @return true if both types are made up of the same stuff
     */
    public abstract boolean equals(Type type);
    /**
     * Get the number of sub-types that make up this compound type (or 0 if this
     *  is not a compound type)
     * @return how many sub-types make up this type
     */
    public abstract int getSubTypeCount();
    /**
     * Get the indexed sub-type that makes up this type
     * @param index Index of sub-type in range from 0..getSubTypeCount()-1
     * @return The indexed sub type or null if index is out of range
     */
    public abstract Type getSubType(int index);

}
