package real.ast.visitor;

import real.ast.AstNode;
import real.ast.AstNodeAssert;
import real.ast.AstNodeAssignment;
import real.ast.AstNodeBopDivide;
import real.ast.AstNodeBopLog;
import real.ast.AstNodeBopMinus;
import real.ast.AstNodeBopModulus;
import real.ast.AstNodeBopMultiply;
import real.ast.AstNodeBopPlus;
import real.ast.AstNodeBopPower;
import real.ast.AstNodeBopRoot;
import real.ast.AstNodeBracket;
import real.ast.AstNodeConvertType;
import real.ast.AstNodeCopEqual;
import real.ast.AstNodeCopGEqual;
import real.ast.AstNodeCopGreat;
import real.ast.AstNodeCopLEqual;
import real.ast.AstNodeCopLess;
import real.ast.AstNodeCopNotEqual;
import real.ast.AstNodeDeclareFunction;
import real.ast.AstNodeDeclareParam;
import real.ast.AstNodeDeclareParamList;
import real.ast.AstNodeDeclareParamType;
import real.ast.AstNodeDeclareFunctionType;
import real.ast.AstNodeDeclareVariableType;
import real.ast.AstNodeDeclareVariable;
import real.ast.AstNodeDereference;
import real.ast.AstNodeIdentifierFunction;
import real.ast.AstNodeIdentifierNew;
import real.ast.AstNodeIdentifierNewType;
import real.ast.AstNodeIdentifierType;
import real.ast.AstNodeIdentifierVariable;
import real.ast.AstNodeIf;
import real.ast.AstNodeLiteralFalse;
import real.ast.AstNodeLiteralFloat;
import real.ast.AstNodeLiteralID;
import real.ast.AstNodeLiteralInt;
import real.ast.AstNodeLiteralString;
import real.ast.AstNodeLiteralTrue;
import real.ast.AstNodeParam;
import real.ast.AstNodeParamList;
import real.ast.AstNodeProgram;
import real.ast.AstNodeStatementList;
import real.ast.AstNodeUopLevel;
import real.ast.AstNodeUopMinus;
import real.ast.AstNodeUopPlus;
import real.ast.AstNodeWhile;

/**
 * Visit an AstNode
 */
public interface AstVisitor
{
    
    public void beforeVisit();
    public void afterVisit();
    public void visit(AstNodeAssert astNodeAssert);
    public void visit(AstNodeAssignment astNodeAssignment);
    public void visit(AstNodeBopDivide astNodeBopDivide);
    public void visit(AstNodeBopLog astNodeBopLog);
    public void visit(AstNodeBopMinus astNodeBopMinus);
    public void visit(AstNodeBopModulus astNodeBopModulus);
    public void visit(AstNodeBopMultiply astNodeBopMultiply);
    public void visit(AstNodeBopPlus astNodeBopPlus);
    public void visit(AstNodeBopPower astNodeBopPower);
    public void visit(AstNodeBopRoot astNodeBopRoot);
    public void visit(AstNodeBracket astNodeBracket);
    public void visit(AstNodeConvertType astNodeConvertType);
    public void visit(AstNodeCopEqual astNodeCopEqual);
    public void visit(AstNodeCopGEqual astNodeCopGEqual);
    public void visit(AstNodeCopGreat astNodeCopGreat);
    public void visit(AstNodeCopLEqual astNodeCopLEqual);
    public void visit(AstNodeCopLess astNodeCopLess);
    public void visit(AstNodeCopNotEqual astNodeCopNotEqual);
    public void visit(AstNodeDeclareFunction astNodeDeclareFunction);
    public void visit(AstNodeDeclareParamList astNodeDeclareParamList);
    public void visit(AstNodeDeclareParamType astNodeDeclareParamType);
    public void visit(AstNodeDeclareParam astNodeDeclareParam);
    public void visit(AstNodeDeclareFunctionType astNodeDeclareFunctionType);
    public void visit(AstNodeDeclareVariableType astNodeDeclareType);
    public void visit(AstNodeDeclareVariable astNodeDeclareVariable);
    public void visit(AstNodeDereference astNodeDereference);
    public void visit(AstNodeIdentifierFunction astNodeIdentifierFunction);
    public void visit(AstNodeIdentifierNew astNodeIdentifierNew);
    public void visit(AstNodeIdentifierNewType astNodeIdentifierNewType);
    public void visit(AstNodeIdentifierType astNodeIdentifierType);
    public void visit(AstNodeIdentifierVariable astNodeIdentifierVariable);
    public void visit(AstNodeIf astNodeIf);
    public void visit(AstNodeLiteralFalse astNodeLiteralFalse);
    public void visit(AstNodeLiteralFloat astNodeLiteralFloat);
    public void visit(AstNodeLiteralID astNodeLiteralID);
    public void visit(AstNodeLiteralInt astNodeLiteralInt);
    public void visit(AstNodeLiteralString astNodeLiteralString);
    public void visit(AstNodeLiteralTrue astNodeLiteralTrue);
    public void visit(AstNodeParam astNodeParam);
    public void visit(AstNodeParamList astNodeParamList);
    public void visit(AstNodeProgram astNodeProgram);
    public void visit(AstNodeStatementList astNodeStatementList);
    public void visit(AstNodeUopLevel astNodeUopLevel);
    public void visit(AstNodeUopMinus astNodeUopMinus);
    public void visit(AstNodeUopPlus astNodeUopPlus);
    public void visit(AstNodeWhile astNodeWhile);
    public AstAcceptOrderer getDefaultOrderer();
    
    /**
     * Allow customised accept orderings to be created
     */
    public interface AstAcceptOrderer
    {   void order(AstNode astNode, AstVisitor astVisitor);
    }
    
    /**
     * Default accept orderer; infix iteration, e.g.,
     *     1
     *    / \
     *   2   5
     *  / \ / \
     *  3 4 6 7
     */
    public class InfixAcceptOrderer implements AstAcceptOrderer
    {   public void order(AstNode astNode, AstVisitor astVisitor)
        {   astNode.accept(astVisitor);
            for(int index = 0; index < astNode.getChildCount(); index++)
                order(astNode.getChild(index), astVisitor);
        }
    }
    
    /**
     * Reverse of infix iteration, e.g.,
     *     7
     *    / \
     *   3   6
     *  / \ / \
     *  1 2 4 5
     */
    public class InverseInfixAcceptOrderer implements AstAcceptOrderer
    {   public void order(AstNode astNode, AstVisitor astVisitor)
        {   for(int index = 0; index < astNode.getChildCount(); index++)
                order(astNode.getChild(index), astVisitor);
            astNode.accept(astVisitor);
        }
    }

}
