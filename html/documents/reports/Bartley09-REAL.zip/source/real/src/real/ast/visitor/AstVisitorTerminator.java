package real.ast.visitor;

/**
 * @author e
 */
public interface AstVisitorTerminator
{

    public void terminate();

}
