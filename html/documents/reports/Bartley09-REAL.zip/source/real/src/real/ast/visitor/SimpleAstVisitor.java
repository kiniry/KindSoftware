package real.ast.visitor;

import real.ast.AstNode;
import real.ast.AstNodeAssert;
import real.ast.AstNodeAssignment;
import real.ast.AstNodeBopDivide;
import real.ast.AstNodeBopLog;
import real.ast.AstNodeBopMinus;
import real.ast.AstNodeBopModulus;
import real.ast.AstNodeBopMultiply;
import real.ast.AstNodeBopPlus;
import real.ast.AstNodeBopPower;
import real.ast.AstNodeBopRoot;
import real.ast.AstNodeBracket;
import real.ast.AstNodeConvertType;
import real.ast.AstNodeCopEqual;
import real.ast.AstNodeCopGEqual;
import real.ast.AstNodeCopGreat;
import real.ast.AstNodeCopLEqual;
import real.ast.AstNodeCopLess;
import real.ast.AstNodeCopNotEqual;
import real.ast.AstNodeDeclareFunction;
import real.ast.AstNodeDeclareFunctionType;
import real.ast.AstNodeDeclareParam;
import real.ast.AstNodeDeclareParamList;
import real.ast.AstNodeDeclareParamType;
import real.ast.AstNodeDeclareVariableType;
import real.ast.AstNodeDeclareVariable;
import real.ast.AstNodeDereference;
import real.ast.AstNodeIdentifierFunction;
import real.ast.AstNodeIdentifierNew;
import real.ast.AstNodeIdentifierNewType;
import real.ast.AstNodeIdentifierType;
import real.ast.AstNodeIdentifierVariable;
import real.ast.AstNodeIf;
import real.ast.AstNodeLiteralFalse;
import real.ast.AstNodeLiteralFloat;
import real.ast.AstNodeLiteralID;
import real.ast.AstNodeLiteralInt;
import real.ast.AstNodeLiteralString;
import real.ast.AstNodeLiteralTrue;
import real.ast.AstNodeParam;
import real.ast.AstNodeParamList;
import real.ast.AstNodeProgram;
import real.ast.AstNodeStatementList;
import real.ast.AstNodeUopLevel;
import real.ast.AstNodeUopMinus;
import real.ast.AstNodeUopPlus;
import real.ast.AstNodeWhile;

/**
 * @author e
 */
public abstract class SimpleAstVisitor implements AstVisitor
{

    protected abstract void defaultVisit(AstNode astNode);
 
    public void beforeVisit()
    {
    }
    
    public void afterVisit()
    {
    }
    
    public void visit(AstNodeAssert astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeAssignment astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeBopDivide astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeBopLog astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeBopMinus astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeBopModulus astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeBopMultiply astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeBopPlus astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeBopPower astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeBopRoot astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeBracket astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeConvertType astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeCopEqual astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeCopGEqual astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeCopGreat astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeCopLEqual astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeCopLess astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeCopNotEqual astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeDeclareFunction astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeDeclareParamList astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeDeclareParamType astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeDeclareParam astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeDeclareFunctionType astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeDeclareVariableType astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeDeclareVariable astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeDereference astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeIdentifierFunction astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeIdentifierNew astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeIdentifierNewType astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeIdentifierType astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeIdentifierVariable astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeIf astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeLiteralFalse astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeLiteralFloat astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeLiteralID astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeLiteralInt astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeLiteralString astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeLiteralTrue astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeParam astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeParamList astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeProgram astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeStatementList astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeUopLevel astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeUopMinus astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeUopPlus astNode)
    {   defaultVisit(astNode);
    }

    public void visit(AstNodeWhile astNode)
    {   defaultVisit(astNode);
    }

    public AstAcceptOrderer getDefaultOrderer()
    {   return new InfixAcceptOrderer();
    }

}