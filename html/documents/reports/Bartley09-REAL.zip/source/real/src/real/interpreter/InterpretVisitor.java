package real.interpreter;

import java.util.ArrayList;
import java.util.List;
import real.ast.AstNode;
import real.ast.AstNodeAssert;
import real.ast.AstNodeAssignment;
import real.ast.AstNodeBopDivide;
import real.ast.AstNodeBopLog;
import real.ast.AstNodeBopMinus;
import real.ast.AstNodeBopModulus;
import real.ast.AstNodeBopMultiply;
import real.ast.AstNodeBopPlus;
import real.ast.AstNodeBopPower;
import real.ast.AstNodeBopRoot;
import real.ast.AstNodeBracket;
import real.ast.AstNodeConvertType;
import real.ast.AstNodeCopEqual;
import real.ast.AstNodeCopGEqual;
import real.ast.AstNodeCopGreat;
import real.ast.AstNodeCopLEqual;
import real.ast.AstNodeCopLess;
import real.ast.AstNodeCopNotEqual;
import real.ast.AstNodeDeclareFunction;
import real.ast.AstNodeDeclareParam;
import real.ast.AstNodeDeclareParamList;
import real.ast.AstNodeDeclareParamType;
import real.ast.AstNodeDeclareFunctionType;
import real.ast.AstNodeDeclareVariableType;
import real.ast.AstNodeDeclareVariable;
import real.ast.AstNodeDereference;
import real.ast.AstNodeIdentifier;
import real.ast.AstNodeIdentifierFunction;
import real.ast.AstNodeIdentifierNew;
import real.ast.AstNodeIdentifierNewType;
import real.ast.AstNodeIdentifierType;
import real.ast.AstNodeIdentifierVariable;
import real.ast.AstNodeIf;
import real.ast.AstNodeLiteralFalse;
import real.ast.AstNodeLiteralFloat;
import real.ast.AstNodeLiteralID;
import real.ast.AstNodeLiteralInt;
import real.ast.AstNodeLiteralString;
import real.ast.AstNodeLiteralTrue;
import real.ast.AstNodeParam;
import real.ast.AstNodeParamList;
import real.ast.AstNodeProgram;
import real.ast.AstNodeStatementList;
import real.ast.AstNodeUopLevel;
import real.ast.AstNodeUopMinus;
import real.ast.AstNodeUopPlus;
import real.ast.AstNodeWhile;
import real.ast.AstStoreList;
import real.ast.environment.SimpleEnvironment;
import real.ast.type.Type;
import real.ast.visitor.AstVisitor;
import real.ast.visitor.AstVisitor.AstAcceptOrderer;
import real.ast.visitor.AstVisitorTerminator;

/**
 * SOS shorthand - Γ:environment, σ:store, s:statement, e:expression, v:value,
 *                 i:identifier, T:type
 * @author e
 */
public class InterpretVisitor implements AstVisitor, AstVisitorTerminator
{

    public void beforeVisit() { }
    
    public void afterVisit() { }
    
    /**
     * <pre>
     *     Γ |- e ~> ID
     * --------------------
     * Γ |- assert(e) ~> ID
     *
     *     Γ |- e ~> true
     * ----------------------
     * Γ |- assert(e) ~> true
     * 
     *    Γ |- e ~> false
     * ----------------------
     * Γ |- assert(e) ~> Stop
     * </pre>
     */
    public void visit(AstNodeAssert astNode)
    {   preVisit(astNode);
        Boolean predicate = reduceToBool(astNode.getChild(0));
        // _result will continue to hold 
        if(predicate == null)
            _result = null;
        else
        if(predicate == false)
            throw new InterpreterException("Assert failure", astNode);
        //else
            //skip; // result will still have the true value
        postVisit(astNode);
    }

    /**
     * <pre>
     *  Γ,i->loc.i|σ |- e ~> v|σ
     * --------------------------
     * Γ|σ |- i=e ~> v|σ{v/loc.i}
     * </pre>
     */
    public void visit(AstNodeAssignment astNode)
    {   preVisit(astNode);
        astNode.getEnvironment().setBindingValue
        (   AstStoreList.AST_VALUE,
            ((AstNodeIdentifier)astNode.getChild(0)).getName(),
            reduceTo(astNode.getChild(1)),
            ((AstNodeIdentifier)astNode.getChild(0)).getLevel()
        );
        postVisit(astNode);
    }

    
    
    /**
     * <pre>
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {int, float}
     *      Γ |- e0/e1 ~> v0 Div v1
     * </pre>
     *
     * Bop id rules
     * <pre>
     * Γ |- e0 ~> ID   Γ |- e1 ~> v1:T
     * -------------------------------
     *      Γ |- e0 (X) e1 ~> v1
     *
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> ID
     * -------------------------------
     *      Γ |- e0 (X) e1 ~> v0
     *
     * Γ |- e0 ~> ID   Γ |- e1 ~> ID
     * -----------------------------
     *     Γ |- e0 (X) e1 ~> ID
     * </pre>
     */
    public void visit(AstNodeBopDivide astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        Object rSide = reduceTo(astNode.getChild(1));
        if(identityBopResult(lSide, rSide) == false)
            if(astNode.getType().equals(Type.TypeInt) == true)
                _result = (Integer)lSide / (Integer)rSide;
            else
            if(astNode.getType().equals(Type.TypeFloat) == true)
                _result = (Float)lSide / (Float)rSide;
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {int, float}
     * Γ |- e0|e1 ~> Log(v0) Div Log(v1)
     * </pre>
     * + Id bop rules
     * @see #visit(AstNodeBopDivide)
     */
    public void visit(AstNodeBopLog astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        Object rSide = reduceTo(astNode.getChild(1));
        if(identityBopResult(lSide, rSide) == false)
            if(astNode.getType().equals(Type.TypeInt) == true)
                _result = (int)
                (   Math.log((Integer)lSide)
                 /  Math.log((Integer)rSide)
                );
            else
            if(astNode.getType().equals(Type.TypeFloat) == true)
                _result = (float)
                (   Math.log((Float)lSide)
                 /  Math.log((Float)rSide)
                );
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {int, float, string}
     *      Γ |- e0-e1 ~> v0 Sub v1
     * </pre>
     * + Id bop rules
     * @see #visit(AstNodeBopDivide)
     */
    public void visit(AstNodeBopMinus astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        Object rSide = reduceTo(astNode.getChild(1));
        if(identityBopResult(lSide, rSide) == false)
            if(astNode.getType().equals(Type.TypeInt) == true)
                _result = (Integer)lSide - (Integer)rSide;
            else
            if(astNode.getType().equals(Type.TypeFloat) == true)
                _result = (Float)lSide - (Float)rSide;
            else
            if(astNode.getType().equals(Type.TypeString) == true)
            {   String lValue = lSide.toString();
                String rValue = rSide.toString();
                int index = lValue.lastIndexOf(rValue);
                if(index != -1)
                    _result
                     =  lValue.substring(0, index)
                     +  lValue.substring(index + rValue.length());
                else
                    _result = lValue;
            }
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {int, float}
     *      Γ |- e0%e1 ~> v0 Mod v1
     * </pre>
     * + Id rules @see #visit(AstNodeBopDivide)
     */
    public void visit(AstNodeBopModulus astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        Object rSide = reduceTo(astNode.getChild(1));
        if(identityBopResult(lSide, rSide) == false)
            if(astNode.getType().equals(Type.TypeInt) == true)
                _result = (Integer)lSide % (Integer)rSide;
            else
            if(astNode.getType().equals(Type.TypeFloat) == true)
                _result = (Float)lSide % (Float)rSide;
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {bool}
     *      Γ |- e0*e1 ~> v0 And v1
     *
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {int, float}
     *      Γ |- e0*e1 ~> v0 Mul v1
     * </pre>
     * + Id bop rules
     * @see #visit(AstNodeBopDivide)
     */
    public void visit(AstNodeBopMultiply astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        Object rSide = reduceTo(astNode.getChild(1));
        if(identityBopResult(lSide, rSide) == false)
            if(astNode.getType().equals(Type.TypeBool) == true)
                _result = (Boolean)lSide && (Boolean)rSide;
            else
            if(astNode.getType().equals(Type.TypeInt) == true)
                _result = (Integer)lSide * (Integer)rSide;
            else
            if(astNode.getType().equals(Type.TypeFloat) == true)
                _result = (Float)lSide * (Float)rSide;
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {bool}
     *      Γ |- e0+e1 ~> v0 Or v1
     *
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {int, float}
     *      Γ |- e0+e1 ~> v0 Add v1
     *
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {string}
     *      Γ |- e0+e1 ~> v0 Cat v1
     * </pre>
     * + Id bop rules
     * @see #visit(AstNodeBopDivide)
     */
    public void visit(AstNodeBopPlus astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        Object rSide = reduceTo(astNode.getChild(1));
        if(identityBopResult(lSide, rSide) == false)
            if(astNode.getType().equals(Type.TypeBool) == true)
                _result = (Boolean)lSide || (Boolean)rSide;
            else
            if(astNode.getType().equals(Type.TypeInt) == true)
                _result = (Integer)lSide + (Integer)rSide;
            else
            if(astNode.getType().equals(Type.TypeFloat) == true)
                _result = (Float)lSide + (Float)rSide;
            else
            if(astNode.getType().equals(Type.TypeString) == true)
                _result = (String)lSide + (String)rSide;
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {bool}
     *      Γ |- e0^e1 ~> v0 XOr v1
     *
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {int, float}
     *      Γ |- e0^e1 ~> v0 Pow v1
     * </pre>
     * + Id bop rules
     * @see #visit(AstNodeBopDivide)
     */
    public void visit(AstNodeBopPower astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        Object rSide = reduceTo(astNode.getChild(1));
        if(identityBopResult(lSide, rSide) == false)
            if(astNode.getType().equals(Type.TypeBool) == true)
                _result = (Boolean)lSide ^ (Boolean)rSide;
            else
            if(astNode.getType().equals(Type.TypeInt) == true)
                _result = (int)Math.pow((Integer)lSide, (Integer)rSide);
            else
            if(astNode.getType().equals(Type.TypeFloat) == true)
                _result = (float)Math.pow((Float)lSide, (Float)rSide);
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {int, float}
     *  Γ |- e0\e1 ~> v0 Pow (1 Div v1)
     * </pre>
     * + Id bop rules
     * @see #visit(AstNodeBopDivide)
     */
    public void visit(AstNodeBopRoot astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        Object rSide = reduceTo(astNode.getChild(1));
        if(identityBopResult(lSide, rSide) == false)
            if(astNode.getType().equals(Type.TypeInt) == true)
                _result = (int)Math.pow((Integer)lSide, 1 / (Integer)rSide);
            else
            if(astNode.getType().equals(Type.TypeFloat) == true)
                _result = (float)Math.pow((Float)lSide, 1 / (Float)rSide);
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     *  Γ |- e ~> v
     * -------------
     * Γ |- (e) ~> v
     * </pre>
     */
    public void visit(AstNodeBracket astNode)
    {   preVisit(astNode);
        visitChildren(astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     *  Γ |- e ~> v
     * -------------
     * Γ |- e:T ~> v
     * </pre>
     */
    public void visit(AstNodeConvertType astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        try
        {   if(astNode.getType().equals(Type.TypeBool) == true)
                _result = toBool(lSide);
            else
            if(astNode.getType().equals(Type.TypeInt) == true)
                _result = toInt(lSide);
            else
            if(astNode.getType().equals(Type.TypeFloat) == true)
                _result = toFloat(lSide);
            else
            if(astNode.getType().equals(Type.TypeString) == true)
                _result = toString(lSide);
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        }
        catch(NumberFormatException e)
        {   // Identity value
            _result = null;
        }
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {bool, int, float, string}
     *     Γ |- e0==e1 ~> v0 equ v1
     * </pre>
     *
     * Cop id rules
     * <pre>
     * Γ |- e0 ~> ID or e1 ~> ID
     * -------------------------
     *   Γ |- e0 (X) e1 ~> ID
     * </pre>
     */
    public void visit(AstNodeCopEqual astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        Object rSide = reduceTo(astNode.getChild(1));
        Type type = astNode.getChild(0).getType();
        if(identityCopResult(lSide, rSide) == false)
            if(type.equals(Type.TypeBool) == true)
                _result = ((Boolean)lSide).equals((Boolean)rSide);
            else
            if(type.equals(Type.TypeInt) == true)
                _result = ((Integer)lSide).equals((Integer)rSide);
            else
            if(type.equals(Type.TypeFloat) == true)
                _result = ((Float)lSide).equals((Float)rSide);
            else
            if(type.equals(Type.TypeString) == true)
                _result = ((String)lSide).equals((String)rSide);
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {int, float, string}
     *     Γ |- e0>=e1 ~> v0 geq v1
     * </pre>
     * + Id cop rule
     * @see #visit(AstNodeCopEqual)
     */
    public void visit(AstNodeCopGEqual astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        Object rSide = reduceTo(astNode.getChild(1));
        Type type = astNode.getChild(0).getType();
        if(identityCopResult(lSide, rSide) == false)
            if(type.equals(Type.TypeInt) == true)
                _result = ((Integer)lSide).compareTo((Integer)rSide) >= 0;
            else
            if(type.equals(Type.TypeFloat) == true)
                _result = ((Float)lSide).compareTo((Float)rSide) >= 0;
            else
            if(type.equals(Type.TypeString) == true)
                _result = ((String)lSide).compareTo((String)rSide) >= 0;
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {int, float, string}
     *      Γ |- e0>e1 ~> v0 gr v1
     * </pre>
     * + Id cop rule
     * @see #visit(AstNodeCopEqual)
     */
    public void visit(AstNodeCopGreat astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        Object rSide = reduceTo(astNode.getChild(1));
        Type type = astNode.getChild(0).getType();
        if(identityCopResult(lSide, rSide) == false)
            if(type.equals(Type.TypeInt) == true)
                _result = ((Integer)lSide).compareTo((Integer)rSide) > 0;
            else
            if(type.equals(Type.TypeFloat) == true)
                _result = ((Float)lSide).compareTo((Float)rSide) > 0;
            else
            if(type.equals(Type.TypeString) == true)
                _result = ((String)lSide).compareTo((String)rSide) > 0;
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {int, float, string}
     *     Γ |- e0&lt;=e1 ~> v0 leq v1
     * </pre>
     * + Id cop rule
     * @see #visit(AstNodeCopEqual)
     */
    public void visit(AstNodeCopLEqual astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        Object rSide = reduceTo(astNode.getChild(1));
        Type type = astNode.getChild(0).getType();
        if(identityCopResult(lSide, rSide) == false)
            if(type.equals(Type.TypeInt) == true)
                _result = ((Integer)lSide).compareTo((Integer)rSide) <= 0;
            else
            if(type.equals(Type.TypeFloat) == true)
                _result = ((Float)lSide).compareTo((Float)rSide) <= 0;
            else
            if(type.equals(Type.TypeString) == true)
                _result = ((String)lSide).compareTo((String)rSide) <= 0;
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {int, float, string}
     *      Γ |- e0%lt;e1 ~> v0 le v1
     * </pre>
     * + Id cop rule
     * @see #visit(AstNodeCopEqual)
     */
    public void visit(AstNodeCopLess astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        Object rSide = reduceTo(astNode.getChild(1));
        Type type = astNode.getChild(0).getType();
        if(identityCopResult(lSide, rSide) == false)
            if(type.equals(Type.TypeInt) == true)
                _result = ((Integer)lSide).compareTo((Integer)rSide) < 0;
            else
            if(type.equals(Type.TypeFloat) == true)
                _result = ((Float)lSide).compareTo((Float)rSide) < 0;
            else
            if(type.equals(Type.TypeString) == true)
                _result = ((String)lSide).compareTo((String)rSide) < 0;
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- e0 ~> v0:T   Γ |- e1 ~> v1:T
     * ---------------------------------  T = {bool, int, float, string}
     *     Γ |- e0-=e1 ~> v0 neq v1
     * </pre>
     * + Id cop rule
     * @see #visit(AstNodeCopEqual)
     */
    public void visit(AstNodeCopNotEqual astNode)
    {   preVisit(astNode);
        Object lSide = reduceTo(astNode.getChild(0));
        Object rSide = reduceTo(astNode.getChild(1));
        Type type = astNode.getChild(0).getType();
        if(identityCopResult(lSide, rSide) == false)
            if(type.equals(Type.TypeBool) == true)
                _result = !((Boolean)lSide).equals((Boolean)rSide);
            else
            if(type.equals(Type.TypeInt) == true)
                _result = !((Integer)lSide).equals((Integer)rSide);
            else
            if(type.equals(Type.TypeFloat) == true)
                _result = !((Float)lSide).equals((Float)rSide);
            else
            if(type.equals(Type.TypeString) == true)
                _result = !((String)lSide).equals((String)rSide);
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     *   Γ |- <>
     * -----------
     * Γ |- i ~> i
     * </pre>
     */
    public void visit(AstNodeDeclareParamType astNode)
    {   preVisit(astNode);
        _result = reduceToString(astNode.getChild(0));
        postVisit(astNode);
    }

    /**
     * Note: no operational semantics; linker does work and not interpreter
     * <pre>
     *      Γ |- <>
     * ------------------
     * Γ |- i()={e} ~> ID
     * </pre>
     */
    public void visit(AstNodeDeclareFunction astNode)
    {   preVisit(astNode);
        _result = null;
        postVisit(astNode);
    }

    /**
     * <pre>
     *   Γ |- <>
     * -----------
     * Γ |- T ~> T
     * </pre>
     */
    public void visit(AstNodeDeclareVariableType astNode)
    {   preVisit(astNode);
        _result = reduceToString(astNode.getChild(0));
        postVisit(astNode);
    }

    /**
     * <pre>
     *   Γ |- <>
     * ------------
     * Γ |- T ~> ID
     * </pre>
     */
    public void visit(AstNodeDeclareFunctionType astNode)
    {   preVisit(astNode);
        _result = null;
    }

    public void visit(AstNodeDereference astNode)
    {   throw new RuntimeException("Not implemented yet!");
    }
    
    /**
     * <pre>
     * Γ |- e ~> true   Γ |- s0 ~> v0
     * ------------------------------
     *  Γ |- if(e){s0}else{s1} ~> v0
     *
     * Γ |- e ~> false   Γ |- s1 ~> v1
     * -------------------------------
     *  Γ |- if(e){s0}else{s1} ~> v1
     *
     *   Γ |- e ~> false
     * --------------------
     * Γ |- if(e){s0} ~> ID
     *
     *   Γ |- e ~> ID
     * ----------------
     * Γ |- if(e) ~> ID
     * </pre>
     */
    public void visit(AstNodeIf astNode)
    {   preVisit(astNode);
        Boolean predicate = reduceToBool(astNode.getChild(0));
        if(predicate == null)
            _result = null;
        else
        if(predicate == true)
            _result = reduceTo(astNode.getChild(1));
        else
        if(astNode.getChildCount() > 2)
            _result = reduceTo(astNode.getChild(2));
        else
            _result = null;
        postVisit(astNode);
    }

    /**
     * <pre>
     *  Γ |- <>
     * ----------
     * Γ |- false
     * </pre>
     */
    public void visit(AstNodeLiteralFalse astNode)
    {   preVisit(astNode);
        _result = astNode.getJavaValue();
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- <>
     * --------
     * Γ |- N.N
     * </pre>
     */
    public void visit(AstNodeLiteralFloat astNode)
    {   preVisit(astNode);
        _result = astNode.getJavaValue();
        postVisit(astNode);
    }

    /**
     * <pre>
     *    Γ,i->loc.i|σ |- <>
     * ------------------------
     * Γ|σ |- i() ~> σ{loc.i}|σ
     * </pre>
     */
    public void visit(AstNodeIdentifierFunction astNode)
    {   preVisit(astNode);
        Object[] result;
        List<String> paramList;
        int level = _level;
        _level = 0;
        // Reduce parameters to a list of values
        result = (Object[])reduceTo(astNode.getChild(0));
        // Get the node that is the function definition by looking up the store
        //  using the function name (the value stored there is a function node)
        AstNodeDeclareFunction functionAstNode;
        functionAstNode = (AstNodeDeclareFunction)astNode
            .getEnvironment()
            .getBindingValue(AstStoreList.AST_VALUE, astNode.getName(), level);
        // From that functions local store, look up a special value that holds
        //  the parameter list names, so that each named item can be set to the
        //  parameter's value
        paramList = (List<String>)functionAstNode
            .getEnvironment()
            .getBindingValue(AstStoreList.AST_VALUE, ":");
        functionAstNode.getEnvironment().pushBinding(AstStoreList.AST_VALUE);
        // Type-checker should ensure this never happens
        //assert result.length == paramList.size();
        // Set the parameter values
        for(int index = 0; index < result.length; index++)
            functionAstNode.getEnvironment().setBindingValue
            (   AstStoreList.AST_VALUE,
                paramList.get(index),
                result[index]
            );
        // Reduce the function
        _result = reduceTo(functionAstNode.getChild(1));
        functionAstNode.getEnvironment().popBinding(AstStoreList.AST_VALUE);
        postVisit(astNode);
    }

    /**
     * <pre>
     *   Γ |- <>
     * -----------
     * Γ |- i ~> i
     * </pre>
     */
    public void visit(AstNodeIdentifierNew astNode)
    {   preVisit(astNode);
        _result = astNode.getName();   
        postVisit(astNode);
    }

    /**
     * <pre>
     *   Γ |- <>
     * ------------
     * Γ |- T ~> ID
     * </pre>
     */
    public void visit(AstNodeIdentifierNewType astNode)
    {   preVisit(astNode);
        _result = null;
        postVisit(astNode);
    }

    /**
     * <pre>
     *   Γ |- <>
     * ------------
     * Γ |- T ~> ID
     * </pre>
     */
    public void visit(AstNodeIdentifierType astNode)
    {   preVisit(astNode);
        _result = null;
        postVisit(astNode);
    }

    /**
     * <pre>
     *   Γ,i->loc.i|σ |- <>
     * ----------------------
     * Γ|σ |- i ~> σ{loc.i}|σ
     * </pre>
     */
    public void visit(AstNodeIdentifierVariable astNode)
    {   preVisit(astNode);
        int level = _level;
        _level = 0;
        _result = astNode.getEnvironment().getBindingValue
        (   AstStoreList.AST_VALUE,
            astNode.getName(),
            level
        );
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- <>
     * -------
     * Γ |- ID
     * </pre>
     */
    public void visit(AstNodeLiteralID astNode)
    {   preVisit(astNode);
        _result = null;
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- <>
     * -------
     * Γ |- N
     * </pre>
     */
    public void visit(AstNodeLiteralInt astNode)
    {   preVisit(astNode);
        _result = astNode.getJavaValue();
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- <>
     * -------
     * Γ |- ""
     * </pre>
     */
    public void visit(AstNodeLiteralString astNode)
    {   preVisit(astNode);
        _result = astNode.getJavaValue();
        postVisit(astNode);
    }

    /**
     * <pre>
     *  Γ |- <>
     * ---------
     * Γ |- true
     * </pre>
     */
    public void visit(AstNodeLiteralTrue astNode)
    {   preVisit(astNode);
        _result = astNode.getJavaValue();
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- e ~> v
     * -----------
     * Γ |- e ~> v
     * </pre>
     */
    public void visit(AstNodeParam astNode)
    {   preVisit(astNode);
        _result = reduceTo(astNode.getChild(0));
        postVisit(astNode);
    }

    /**
     * <pre>
     *   Γ |- <>
     * ------------
     * Γ |- i ~> ID
     * </pre>
     */
    public void visit(AstNodeDeclareParam astNode)
    {   preVisit(astNode);
        _result = null;
        postVisit(astNode);
    }

    /**
     * <pre>
     *  Γ |- e0 ~> v0 .. Γ |- eN ~> vN
     * ---------------------------------
     * Γ |- (e0, .., eN) ~> [v0, .., vN]
     * </pre>
     */
    public void visit(AstNodeParamList astNode)
    {   preVisit(astNode);
        Object[] results = new Object[astNode.getChildCount()];
        for(int index = 0; index < astNode.getChildCount(); index++)
            results[index] = reduceTo(astNode.getChild(index));
        _result = results;
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- <>
     * -------
     * Γ |- <>
     * </pre>
     */
    public void visit(AstNodeDeclareParamList astNode)
    {   preVisit(astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ |- s0 ~> v0 .. Γ |- sN ~> vN
     * ------------------------------
     *     Γ |- [s0; ..; sN] ~> vN
     * </pre>
     */
    public void visit(AstNodeProgram astNode)
    {   preVisit(astNode);
        _results = new ArrayList<InterpreterResult>();
        for(int index = 0; index < astNode.getChildCount(); index++)
        {   astNode.getChild(index).accept(this);
            _results.add
            (   new InterpreterResult
                (   _result,
                    astNode.getChild(index)
                )
            );
        }
        // The last statement executed will still be in the result binding,
        //  so just leave it as is - no extra work here
        postVisit(astNode);
    }
    
    /**
     * <pre>
     * Γ |- s0 ~> v0 .. Γ |- sN ~> vN
     * ------------------------------
     *     Γ |- {s0; ..; sN} ~> vN
     * </pre>
     */
    public void visit(AstNodeStatementList astNode)
    {   preVisit(astNode);
        visitChildren(astNode);
        // Return value will be set by last child, so when then returns, that
        //  return value will still be there
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ,i->loc.i|σ(n-1) |- <>
     * ------------------------
     * Γ|σn |- (~i) ~> i|σ(n-1)
     */
    public void visit(AstNodeUopLevel astNode)
    {   preVisit(astNode);
        _level++;
        visitChildren(astNode);
        assert _level == 0;
        postVisit(astNode);
    }
    
    /**
     * <pre>
     *   Γ |- e ~> v:T
     * -----------------  T = {bool}
     * Γ |- -e ~> not(v)
     *
     * Γ |- e ~> v:T
     * -------------  T = {int, float}
     * Γ |- -e ~> -v
     *
     * Γ |- e ~> ID
     * -------------
     * Γ |- -e ~> ID
     * </pre>
     */
    public void visit(AstNodeUopMinus astNode)
    {   preVisit(astNode);
        Object value = reduceTo(astNode.getChild(0));
        if(value == null)
            _result = null;
        else
            if(astNode.getType().equals(Type.TypeBool) == true)
                _result = !((Boolean)value);
            else
            if(astNode.getType().equals(Type.TypeInt) == true)
                _result = -((Integer)value);
            else
            if(astNode.getType().equals(Type.TypeFloat) == true)
                _result = -((Float)value);
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     *   Γ |- e ~> v:T
     * -----------------  T = {int, float}
     * Γ |- +e ~> abs(v)
     *
     * Γ |- e ~> ID
     * -------------
     * Γ |- +e ~> ID
     * </pre>
     */
    public void visit(AstNodeUopPlus astNode)
    {   preVisit(astNode);
        Object value = reduceTo(astNode.getChild(0));
        if(value == null)
            _result = null;
        else
            if(astNode.getType().equals(Type.TypeInt) == true)
                _result = Math.abs((Integer)value);
            else
            if(astNode.getType().equals(Type.TypeFloat) == true)
                _result = Math.abs((Float)value);
            else
                // This error should never occur; type-checker should have
                //  caught it
                throw new InterpreterException("Internal error!", astNode);
        postVisit(astNode);
    }

    /**
     * <pre>
     * Γ,i!->loc.i|σ0 |- e ~> v   Γ,i->loc.i|σ1{v/loc.i} |- <>
     * -------------------------------------------------------  Fresh loc.i
     *            Γ|σ0 |- { i=e; [e0; ..; eN]|σ1 }
     * </pre>
     */
    public void visit(AstNodeDeclareVariable astNode)
    {   preVisit(astNode);
        String name = reduceToString(astNode.getChild(0));
        Object value;
        if(astNode.getType().equals(Type.TypeBool) == true)
            value = reduceToBool(astNode.getChild(1));
        else
        if(astNode.getType().equals(Type.TypeInt) == true)
            value = reduceToInt(astNode.getChild(1));
        else
        if(astNode.getType().equals(Type.TypeFloat) == true)
            value = reduceToFloat(astNode.getChild(1));
        else
        if(astNode.getType().equals(Type.TypeString) == true)
            value = reduceToString(astNode.getChild(1));
        else
            throw new InterpreterException("Internal error!", astNode);
        astNode.getEnvironment().setBindingValue
        (   AstStoreList.AST_VALUE,
            name,
            value
        );
        _result = value;
        postVisit(astNode);
    }

    /**
     * <pre>
     *          Γ |- e0 ~> true
     * ---------------------------------
     * Γ |- while(e0){s} ~> while(e1){s}
     *
     *    Γ |- e0 ~> false
     * -----------------------
     * Γ |- while(e0){s} ~> ID
     *
     * Γ |- e1 ~> false   s ~> v
     * -------------------------
     *  Γ |- while(e1){s} ~> v
     * </pre>
     */
    public void visit(AstNodeWhile astNode)
    {   preVisit(astNode);
        Object result = null;
        Boolean predicate = true;
        while(predicate != null && predicate == true)
        {   predicate = reduceToBool(astNode.getChild(0));
            if(predicate != null && predicate == true)
                result = reduceTo(astNode.getChild(1));
        }
        _result = result;
        postVisit(astNode);
    }

    /**
     * No default orderer, each node handles visiting its children
     * @return
     */
    public AstAcceptOrderer getDefaultOrderer()
    {   return null;
    }

    /**
     * Cause the interpreter to stop visiting
     */
    public void terminate()
    {   _running = false;
    }

    /**
     * Do before visiting
     */
    private void preVisit(AstNode astNode)
    {   checkAndTerminate();
    }

    /**
     * Do after visiting
     */
    private void postVisit(AstNode astNode)
    {   populateBestFocus(astNode);
    }
    
    /**
     * Do the actual termination by throwing a afterVisit exception
     */
    private void checkAndTerminate()
    {   if(_running == false)
            throw new InterpreterException("Terminated", null);
    }

    /**
     * Get the final result of the program
     * @return
     */
    public InterpreterResult getResult()
    {   return _results.get(_results.size() - 1);
    }

    public List<InterpreterResult> getResults()
    {   return _results;
    }
    
    //--------------------------------------------------------------------------
    // Helpers
    
    /**
     * Safely convert from string to bool. "true"~>true, anything else~>false
     */
    private Boolean stringToBool(String value)
    {   return Boolean.parseBoolean(value);
    }

    /**
     * Safely convert from string to integer by parsing. If it can't be parsed,
     *  attempt to parse it as a float (and cast that to int). Note. if float
     *  can't be parsed, it attempts to parse as bool, and return 1 for true,
     *  else 0
     */
    private Integer stringToInt(String value)
    {   try
        {   return Integer.parseInt(value);
        }
        catch(NumberFormatException e)
        {   return (int)(float)stringToFloat(value);
        }
    }
    
    /**
     * Safely convert from string to float by parsing. If it can't be parsed,
     *  attempt to parse it as a bool and return 1.0 if true, and 0.0 if false
     */
    private Float stringToFloat(String value)
    {   try
        {   return Float.parseFloat(value);
        }
        catch(NumberFormatException e)
        {   return stringToBool(value) == true ? 1.0f : 0.0f;
        }
    }

    /**
     * Safely convert object to boolean
     */
    private Boolean toBool(Object value)
    {   if(value == null)
            return null;
        try
        {   return (Boolean)value;
        }
        catch(ClassCastException e)
        {   if(value instanceof Integer)
                return (Integer)value != 0;
            else
            if(value instanceof Float)
                return (Float)value != 0;
            else
            if(value instanceof String)
                return stringToBool((String)value);
            else
                throw new RuntimeException();
        }
    }
    
    /**
     * Safely convert object to integer
     */
    private Integer toInt(Object value)
    {   if(value == null)
            return null;
        try
        {   return (Integer)value;
        }
        catch(ClassCastException e)
        {   if(value instanceof Boolean)
                return (Boolean)value == true ? 1 : 0;
            else
            if(value instanceof Float)
                return (int)(float)(Float)value;
            else
            if(value instanceof String)
                return stringToInt((String)value);
            else
                throw new RuntimeException();
        }
    }
    
    /**
     * Safely convert object to float
     */
    private Float toFloat(Object value)
    {   if(value == null)
            return null;
        try
        {   return (Float)value;
        }
        catch(ClassCastException e)
        {   if(value instanceof Boolean)
                return (Boolean)value == true ? 1.0f : 0.0f;
            else
            if(value instanceof Integer)
                return (float)(Integer)value;
            else
            if(value instanceof String)
                return stringToFloat((String)value);
            else
                throw new RuntimeException();
        }
    }
    
    /**
     * Safely convert object to string
     */
    private String toString(Object value)
    {   if(value == null)
            return null;
        return value.toString();
    }
    
    /**
     * Accept a node and return its result as a boolean
     */
    private Boolean reduceToBool(AstNode astNode)
    {   astNode.accept(this);
        return toBool(_result);
    }
    
    /**
     * Accept a node and return its result as an integer
     */
    private Integer reduceToInt(AstNode astNode)
    {   astNode.accept(this);
        return toInt(_result);
    }
    
    /**
     * Accept a node and return its result as a float
     */
    private Float reduceToFloat(AstNode astNode)
    {   astNode.accept(this);
        return toFloat(_result);
    }
    
    /**
     * Accept a node and return its result as a string
     */
    private String reduceToString(AstNode astNode)
    {   astNode.accept(this);
        return toString(_result);
    }

    /**
     * Accept a node and return its result as whatever
     */
    private Object reduceTo(AstNode astNode)
    {   astNode.accept(this);
        return _result;
    }
    
    /**
     * Handle identity values given to binary arithmetic operations. If lSide
     *  is ID, result if rSide and visa-versa. If both lSide and rSide are ID,
     *  result is ID. If neither are ID, return false (result needs to be
     *  calculated)
     * @return true if identity result, false if must calculate result
     */
    private boolean identityBopResult(Object lSide, Object rSide)
    {   if(lSide == null && rSide == null)
            _result = null;
        else
        if(lSide == null)
            _result = rSide;
        else
        if(rSide == null)
            _result = lSide;
        else
            return false;
        return true;
    }
    
    /**
     * Handle identity values given to binary comparison operations. If lSide
     *  or rSide is ID, result is ID, else return false (result needs to be
     *  calculated)
     * @return true if identity result, false if must calculate result
     */
    private boolean identityCopResult(Object lSide, Object rSide)
    {   if(lSide != null && rSide != null)
            return false;
        _result = null;
        return true;
    }

    /**
     * Visit all children of <var>astNode</var> in order
     */
    private void visitChildren(AstNode astNode)
    {   for(int index = 0; index < astNode.getChildCount(); index++)
            astNode.getChild(index).accept(this);
    }

    public void setFocusAstNode(AstNode focusAstNode)
    {   _focusAstNode = focusAstNode;
    }
    
    private void populateBestFocus(AstNode astNode)
    {   if(astNode == _focusAstNode)
            _focusStack = new Focus(_result, astNode);        
    }
    
    public Focus getFocusStack()
    {   return _focusStack;
    }
    
    //------------------------------------------------------------------------\\
    // Data
    
    /**
     * Scope the AstNode that has the best focus
     */
    private AstNode _focusAstNode = null;
    /**
     * Information generated from focus index
     */
    private Focus _focusStack = null;
    /**
     * Scope the result of the last node evaluated. This is used as a temporary
     *  return value for each node visited
     */
    private Object _result = null;
    /**
     * Scope all top-level results
     */
    private List<InterpreterResult> _results = null;
    /**
     * When accessing the next identifier, search for it at this level (above
     *  the current level (change of scope))
     */
    private int _level = 0;
    /**
     * Set to false if interpreter is terminated
     */
    private volatile boolean _running = true;

    /**
     * Store details about the focal point
     */
    public class Focus
    {
        
        Focus(Object result, AstNode astNode)
        {   _result = new InterpreterResult(result, astNode);
            _astNode = astNode;
            _environment = astNode
                .getEnvironment()
                .getSimpleEnvironment(AstStoreList.AST_VALUE);
        }
        
        /**
         * Get the result of the node at the focal point
         * @return
         */
        public InterpreterResult getResult()
        {   return _result;
        }

        public AstNode getAstNode()
        {   return _astNode;
        }
        
        public SimpleEnvironment getEnvironment()
        {   return _environment;
        }

        @Override
        public String toString()
        {   return _result.toString() + "\n" + _environment.toString();
        }
        
        private InterpreterResult _result;
        private AstNode _astNode;
        private SimpleEnvironment _environment;
        
    }
    
}
