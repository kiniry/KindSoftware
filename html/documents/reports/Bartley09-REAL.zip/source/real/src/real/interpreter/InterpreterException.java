package real.interpreter;

import real.ast.AstNode;
import real.utilities.RealException;

/**
 * @author e
 */
public class InterpreterException extends RealException
{

    public InterpreterException(String message, AstNode astNode)
    {   super(astNode != null ? astNode.getParserSource() : null);
        _message = message;
        _astNode = astNode;
    }

    @Override
    public String getMessage()
    {   if(_astNode == null)
            return _message;
        else
            return
                _message + " "
             +  getParserSource();
    }

    public AstNode getAstNode()
    {   return _astNode;
    }
    
    private String _message;
    /**
     * Location in source where error occurred
     */
    private AstNode _astNode;

}
