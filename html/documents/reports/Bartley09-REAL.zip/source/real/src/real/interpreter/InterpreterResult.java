package real.interpreter;

import real.ast.AstNode;
import real.ast.type.Type;

/**
 * @author e
 */
public class InterpreterResult
{

    InterpreterResult(Object value, AstNode astNode)
    {   _astNode = astNode;
        _value = value;
    }

    public boolean isId()
    {   return _value == null;
    }
    
    public AstNode getAstNode()
    {   return _astNode;
    }
    
    public Object getValue()
    {   return _value;
    }
    
    public Type getType()
    {   return _astNode.getType();
    }

    @Override
    public String toString()
    {   if(isId() == true)
            return "ID" + ":" + getType();
        return getValue() + ":" + getType();
    }

    private AstNode _astNode;
    private Object _value;

}
