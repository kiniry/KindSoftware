package real.parser;

import java.util.Stack;
import real.ast.AstNode;
import real.ast.AstNodeProgram;
import real.ast.AstPrecedenceList;

/**
 * Abstract parser, inherit to specify specifics of parsing
 * @author e
 */
public abstract class Parser
{

    //--------------------------------------------------------------------------
    // Work to do

    /**
     * Create an AST node from which all others will be nested
     * @return the AST node from which all others will be nested
     */
    protected AstNode createRootAstNode()
    {   return new AstNodeProgram();
    }
    /**
     * Inheriting class specifies the start state
     * @return the start state
     */
    protected abstract ParseStateList getStartState();
    /**
     * Inheriting class parses each symbol
     */
    protected abstract void parseSymbol() throws ParserException;
    
    //--------------------------------------------------------------------------
    // Parser logics

    /**
     * Override to perform custom initialisation
     */
    protected void beforeParse()
    {   // Empty; inheriting can override to do custom initialisation
    }

    /**
     * Override to perform custom termination
     */
    protected void afterParse()
    {   // Empty; inheriting can override to do custom termination
    }

    /**
     * Must be initialised before parsing. Private so inheriting classes cannot
     *  mess with it, but instead override beforeParse to do its initialisation
     */
    private AstNode privateBeforeParse()
    {   AstNode rootAstNode = createRootAstNode();
        _doExtract = false;
        _index = -1;
        _lineIndex = 0;
        _charIndex = -1;
        _newlineSymbol = 0;
        _doConsume = true;
        _doConsumeWhitespace = false;
        setActiveAstNode(rootAstNode);
        _activeAstNodeStack = new Stack<AstNode>();
        pushActiveAstNode();
        _appendAstNodeMode = AppendAstNodeMode.APPEND;
        setParseState(getStartState());
        _parseStateStack = new Stack<ParseStateList>();
        beforeParse();
        return rootAstNode;
    }

    /**
     * Clean up--null all global references
     */
    private void privateAfterParse()
    {   afterParse();
        _extract = null;
        setActiveAstNode(null);
        _activeAstNodeStack = null;
        _parseStateStack = null;
    }
    
    /**
     * Parse the specified source to an AST
     * @param source The source to parse
     * @return an AST of the source, rooted in an AstNodeStatementList
     */
    public final AstNode parse(String source) throws ParserException
    {   AstNode astNode = null;

        try
        {
        
            // Initialise for parsing. Inheriting class should override
            //  beforeParse if it needs to do initialisation
            astNode = privateBeforeParse();
        
            // nextSymbol will get the next symbol to parse or return false if
            //  the end of the input has been reached. Note that _index starts
            //  at -1 (set in privateBeforeParse), and nextSymbol increments
            //  _index as its first action, then reads or fails. When the end
            //  is reached, one additional symbol is returned, SpecialSymbol.EOF
            //  so nextSymbol will run for N+1 symbols before returning false
            while(nextSymbol(source) == true)
            {

                // Ignore whitespace if they're not to be consumed
                if(_doConsumeWhitespace == false && _symbol <= ' ')
                    continue;

                if(_startIndex == -1)
                    setStartIndex();
                
                // Call on the inheriting class to do the work
                parseSymbol();

                // Copy symbol into buffer. Happens after parsing the symbol,
                //  that way when the parser starts extracting, it will be on
                //  the first symbol it wants to extract, and when it stops
                //  extracting, it will be on the symbol following the last
                //  symbol it wants to extract
                if(_doExtract == true && _doConsume == true)
                    _extract.append(_symbol);

            }

        }
        catch(Exception e)
        {   // Repackage exceptions to look like parsing exceptions
            throwParserException(e);
        }

        privateAfterParse();

        return astNode;

    }

    private boolean nextSymbol(String source)
    {
        
        if(_doConsume == true)
        {   // Index starts at -1, so increment before reading. This keeps the
            //  index and symbol in sync during the parsing while allowing all
            //  to happen together
            _index++;
            _charIndex++;
            // Index>length returns false, as index==length returns a special
            //  EOF symbol
            if(_index > source.length())
                return false;
            else
            // When the end is reached, continue parsing, but on a special EOF
            //  symbol
            if(_index == source.length())
                _symbol = SpecialSymbol.EOF;
            else
                _symbol = source.charAt(_index);
            
            // Track new-lines (for debugging line/column output) by finding the
            //  first symbol used for new-line (\n or \r). This symbol then
            //  represents new-lines and the other (\r or \n) is ignored
            if(_symbol == '\n' || _symbol == '\r')
            {   _charIndex = -1;
                if(_newlineSymbol == 0)
                    _newlineSymbol = _symbol;
                if(_newlineSymbol == _symbol)
                    _lineIndex++;
            }
        }
        else
            // Don't need to specify that consuming resume. Saying don't consume
            //  only applies for one round
            _doConsume = true;
        
        // Returns false (above) when the end is reached
        return true;
        
    }

    //--------------------------------------------------------------------------
    // Queries

    /**
     * Get the current symbol read from the input
     * @return the current symbol read from the input
     */
    protected char getSymbol()
    {   return _symbol;
    }
    
    /**
     * Get the value that was extracted between startExtract() and stopExtract()
     * @returnthe value that was extracted
     */
    protected String getExtract()
    {   return _extract.toString();
    }

    /**
     * Get the index of the current symbol read from the input
     * @return the index of the current symbol read from the input
     */
    protected int getIndex()
    {   return _index;
    }

    /**
     * Get the current line number in the source
     * @return the current line number in the source
     */
    protected int getLineIndex()
    {   return _lineIndex;
    }

    /**
     * Get the current line character number in the source
     * @return the current line character number in the source
     */
    protected int getCharIndex()
    {   return _charIndex;
    }

    /**
     * Get the currently active node; all added nodes are in relation to the
     *  active node.
     * @return the currently active node
     */
    protected AstNode getActiveAstNode()
    {   return _activeAstNode;
    }

    /**
     * Get the current parse state
     * @return the current parse state
     */
    protected ParseStateList getParseState()
    {   return _parseState;
    }

    //--------------------------------------------------------------------------
    // Commands
    
    private boolean testPrecedence
    (   AstNode activeAstNode,
        AstNode newAstNode,
        AddAstNodeMode mode
    ){  if(activeAstNode.getPrecedence() != AstPrecedenceList.AST_NONE)
            if(mode != AddAstNodeMode.INSERT)
                return activeAstNode.getPrecedence() > newAstNode.getPrecedence();
            else
                return activeAstNode.getPrecedence() >= newAstNode.getPrecedence();
        else
            return false;
    }
    
    /**
     * Append the specified node on to the active node. If the active node is
     *  higher precedence, the new node is appended to the first parent of the
     *  active node with a lower, equal, or bracketed precedence. If the new
     *  node is a bracketed node, it is appended to the active node without
     *  checking the precedence. After this call, the active node will become
     *  the <var>astNode</var>
     * @param astNode the new node to append to the active node
     * @param mode the mode of adding (append or insert)
     */
    private void addAstNode(AstNode astNode, AddAstNodeMode mode)
    {   AstNode activeAstNode = getActiveAstNode();
        AstNode childAstNode = null;
        
        // If adding a node that has a precedence order, first find the position
        //  in the AST where this node should go. This means search up the tree
        //  (towards root) until a node is found with a higher or equal
        //  precedence (lower precedence are done first using depth-first
        //  evaluation), the node is inserted as a child of it, or until a node
        //  is found with no precedence
        if(astNode.getPrecedence() != AstPrecedenceList.AST_NONE)
            while(testPrecedence(activeAstNode, astNode, mode) == true)
            {  // Remember which child the parent was reached from
                childAstNode = activeAstNode;
                // Make the parent the new active node
                activeAstNode = activeAstNode.getParent();
            }

        // If a previous action was a pop, it means the active node has become
        //  active by being popped off a stack, so this node should be inserted
        //  in place of the active node (e.g., a bracket will be popped when it
        //  has passed, so the next node should not be inside the bracket
        //  section.. (a-b)+c, the + should be a parent of (a-b) and c, so
        //  popping after the ) means the + is going to be inserted (parent)
        //  rather than appended (child)
        // append produces
        //   (   )
        //     -  +
        //    a b  c
        // insert produces
        //        +
        //   (   ) c
        //     -
        //    a b
        if(_appendAstNodeMode == AppendAstNodeMode.INSERT)
        {

            // Only do an INSERT once when asked, not everytime after
            _appendAstNodeMode = AppendAstNodeMode.APPEND;

            // Make the parent the active node (the append is going to be
            //  on the parent, and the child is going to be moved as a child
            //  of the new node)
            childAstNode = activeAstNode;
            activeAstNode = activeAstNode.getParent();

            // Because this is in response to a pop, the precedence will have
            //  been ignored (pop may be to a node that has no precedence
            //  level), so now that it's gone to the parent, search for correct
            //  position in precedence
            if(astNode.getPrecedence() != AstPrecedenceList.AST_NONE)
                while(testPrecedence(activeAstNode, astNode, mode) == true)
                {  // Remember which child the parent was reached from
                    childAstNode = activeAstNode;
                    // Make the parent the new active node
                    activeAstNode = activeAstNode.getParent();
                }
            else
                // If the node being inserted is one that has no precedence,
                //  skip doing an insert, just append (as having no precedence
                //  gives it no relation to the popped node, so it won't become
                //  its parent, it will become a sibling
                childAstNode = null;
            
        }

        // If mode is insert, but no child is set, then an insert can't be done
        //  so change it to an append
        if(mode == AddAstNodeMode.INSERT && childAstNode == null)
            mode = AddAstNodeMode.APPEND;
        else
        // If mode is append, but a child is set, that child must become a child
        //  of the added node, so it's an insert
        if(mode == AddAstNodeMode.APPEND && childAstNode != null)
            mode = AddAstNodeMode.INSERT;
        
        // Finally do what this method says it does
        switch(mode)
        {   case APPEND:
                parserTrace("APPEND ");
                activeAstNode.appendChild(astNode);
                break;
            case INSERT:
                parserTrace("INSERT ");
                activeAstNode.insertChild(astNode, childAstNode);
                break;
            case REPLACE:
                childAstNode = activeAstNode;
                activeAstNode = activeAstNode.getParent();
                parserTrace("REPLACE [" + childAstNode + "] with [" + astNode+ "]");
                activeAstNode.replaceChild(astNode, childAstNode);
                astNode.getParserSource().set(childAstNode.getParserSource());
                break;
        }
        
        // The node added always becomes the active node
        setActiveAstNode(astNode);
        
        astNode.getParserSource().set
        (   _startIndex, _startLineIndex, _startCharIndex,
            getIndex(), getLineIndex(), getCharIndex()
        );
        
        _startIndex = -1;

    }

    /**
     * Append a node (that is, add the new node as a child of the active node).
     * Where P=parent, A=active, C=child, N=new; N is the position this new node
     *  is placed from the active node A
     * P
     * |_A
     *   |_C
     *   |_N
     */
    protected void appendAstNode(AstNode astNode)
    {   parserTrace("append ");
        addAstNode(astNode, AddAstNodeMode.APPEND);
    }

    /**
     * Insert a new (that is, add the new node in place of the active node and
     *  make the active a child of the new
     * Where P=parent, A=active, C=child, N=new; N is the position this new node
     *  is placed from the active node A
     * P
     * |_N
     *   |_A
     *     |_C
     */
    protected void insertAstNode(AstNode astNode)
    {   parserTrace("insert ");
        addAstNode(astNode, AddAstNodeMode.INSERT);
    }
    
    /**
     * Insert a new (that is, add the new node in place of the active node and
     *  make the active a child of the new
     * Where P=parent, A=active, C=child, N=new; N is the position this new node
     *  is placed from the active node A (which has been overwritten below by N)
     * P
     * |_N   (was A, replaced by N)
     *   |_C
     */
    protected void replaceAstNode(AstNode astNode)
    {   parserTrace("replace ");
        addAstNode(astNode, AddAstNodeMode.REPLACE);
    }
    
    /**
     * Begin extracting from the current symbol. Actual extraction is done in
     *  parse
     */
    protected void startExtract()
    {   parserTrace("start ");
        _extract = new StringBuilder();
        _doExtract = true;
        setStartIndex();
    }
    
    /**
     * Stop extracting, the current symbol will not be extracted
     */
    protected void stopExtract()
    {   parserTrace("stop ");
        _doExtract = false;
    }
    
    /**
     * Disable consumption of the current symbol. Call when the current symbol
     *  shouldn't be consumed; it will remain for the next state. Consume will
     *  be automatically re-enabled after each loop
     */
    protected void dontConsume()
    {   parserTrace("dontConsume ");
        _doConsume = false;
    }

    /**
     * Enable consumption of white-space. This will remain in effect until
     *  dontConsumeWhitespace is called
     */
    protected void consumeWhitespace()
    {   parserTrace("consumeWS ");
        _doConsumeWhitespace = true;
    }

    /**
     * Disable consumption of white-space. This will remain in effect until
     *  consumeWhitespace is called. Note. after this call, the parser will
     *  completely ignore white-space so parsing " a  bc " is equivalent to
     *  parsing "abc"
     */
    protected void dontConsumeWhitespace()
    {   parserTrace("dontConsumeWS ");
        _doConsumeWhitespace = false;
    }

    /**
     * Set the currently active AST node; the node from which the next node
     *  will be relatively placed
     * @param activeAstNode the current active AST node
     */
    private void setActiveAstNode(AstNode activeAstNode)
    {   if(activeAstNode == null)
            activeAstNode = null;
        _activeAstNode = activeAstNode;
    }

    /**
     * Push the currently active AST node on to the stack. This node can be
     *  later restored as the active AST node by calling popActiveAstNode() or
     *  topActiveAstNode()
     * @param activeAstNode the current active AST node
     */
    protected void pushActiveAstNode()
    {   parserTrace("push(" + getActiveAstNode() + ") ");
        _activeAstNodeStack.push(getActiveAstNode());
    }

    /**
     * Set the currently active AST node to be the previously pushed node and
     *  then remove that node from the stack
     */
    protected void popActiveAstNode()
    {   setActiveAstNode(_activeAstNodeStack.pop());
        parserTrace("pop(" + getActiveAstNode() + ") ");
        _appendAstNodeMode = AppendAstNodeMode.INSERT;
    }

    /**
     * Set the currently active AST node to be the previously pushed node but
     *  keep that node on the stack; the next popActiveAstNode() or
     *  topActiveAstNode() will refer to this node again
     */
    protected void topActiveAstNode()
    {   setActiveAstNode(_activeAstNodeStack.peek());
        parserTrace("top(" + getActiveAstNode() + ") ");
        _appendAstNodeMode = AppendAstNodeMode.APPEND;
    }

    /**
     * Navigate through the AST by means of a relative reference. (related node
     *  becomes the active node)
     * @param navigateAstNodeMode relative reference, PARENT, CHILD (first),
     *  PREV (sibling), NEXT (sibling)
     */
    protected void navigateActiveAstNode(NavigateAstNodeMode navigateAstNodeMode)
    {   parserTrace("navigate(" + navigateAstNodeMode + ") ");
        switch(navigateAstNodeMode)
        {   case PARENT:
                setActiveAstNode(getActiveAstNode().getParent());
                break;
            case CHILD:
                setActiveAstNode(getActiveAstNode().getChild(0));
                break;
            case PREV:
                throw new UnsupportedOperationException("Not supported yet.");
            case NEXT:
                throw new UnsupportedOperationException("Not supported yet.");
        }
    }

    /**
     * Navigate through the AST to an indexed child of the active node and make
     *  it the active node. If the index is negative, the index is from the last
     *  child. Run first to last either (-N..-1) or (0..N-1)
     * @param childIndex First-to-last (0..N-1) or last-to-first (-1..-N)
     */
    protected void navigateActiveAstNode(int childIndex)
    {   parserTrace("navigate(" + childIndex + ") ");
        if(childIndex < 0)
            childIndex = getActiveAstNode().getChildCount() - childIndex;
        setActiveAstNode(getActiveAstNode().getChild(childIndex));
    }
    
    /**
     * Update the current parse state
     * @param parseState new state to switch to
     */
    protected void setParseState(ParseStateList parseState)
    {   _parseState = parseState;
    }

    /**
     * Update the current parse state and push a given state onto the stack,
     *  this state will become the set parse state when popAndSetParseState() is
     *  called
     * @param parseState new state to switch to
     * @param pushState The state to push on the stack
     */
    protected void setParseStateAndPush
    (   ParseStateList parseState,
        ParseStateList  pushState
    ){  parserTrace("pushState(" + pushState + ") ");
        setParseState(parseState);
        _parseStateStack.push(pushState);
    }

    /**
     * Remove the last pushed state from the stack and set it as the current
     *  state
     */
    protected void popAndSetParseState()
    {   setParseState(_parseStateStack.pop());
        parserTrace("pushState(" + getParseState() + ") ");
    }

    private void setStartIndex()
    {   _startIndex = getIndex();
        _startLineIndex = getLineIndex();
        _startCharIndex = getCharIndex();
    }
    
    /**
     * Enable a trace of the parser. This trace is returned from getParserTrace
     */
    public void enableParserTrace()
    {   _parserTrace = new StringBuilder();
    }

    /**
     * Disable parser tracing. getParserTrace will return a disabled message
     *  after this is called
     */
    public void disableParserTrace()
    {   _parserTrace = null;
    }

    /**
     * Get the trace generated while parsing if enableParserTrace has been
     *  called
     * @return
     */
    public String getParserTrace()
    {   if(_parserTrace == null)
            return
                "Trace not enabled. Call enableParserTrace()."
             +  System.getProperty("line.separator");
        return _parserTrace.toString();
    }
    
    /**
     * Add a message to the parser trace
     */
    protected void parserTrace(String message)
    {   if(_parserTrace != null)
            _parserTrace.append(message);
    }
    
    /**
     * Add a message and a new-line to the parser trace
     */
    protected void parserTraceln(String message)
    {   if(_parserTrace != null)
        {   _parserTrace.append(message);
            _parserTrace.append(System.getProperty("line.separator"));
        }       
    }
    
    /**
     * If an error occurs, throw the details
     * @param message An internal message about the error
     */
    protected void throwParserException(String message) throws ParserException
    {   throwParserException(message, null);
    }
    
    /**
     * If an error occurs, throw the details
     * @param exception Some external details about the error
     */
    protected void throwParserException
    (   Throwable exception
    )   throws ParserException
    {   throwParserException(exception.getMessage(), exception);
    }
    
    /**
     * If an error occurs, throw the details
     * @param message An internal message about the error
     * @param exception Some external details about the error
     */
    protected void throwParserException
    (   String      message,
        Throwable exception
    )   throws ParserException
    {   throw new ParserException
        (   message,
            exception,
            new ParserSource(getIndex(), getLineIndex(), getCharIndex())
        );
    }
    
    //--------------------------------------------------------------------------
    // Data

    /**
     * The current character in the source
     */
    private char _symbol;
    /**
     * While reading symbols that may be used later, extract them into this
     *  while parsing so they won't have to be picked up later if it's
     *  determined that they are needed
     */
    private StringBuilder _extract;
    /**
     * Should extraction be done. When true, the current symbol is appended to
     *  _extract
     */
    private boolean _doExtract;
    /**
     * The index of the current character in the source
     */
    private int _index;
    /**
     * Store the current line number in the source; for error reporting
     */
    private int _lineIndex;
    /**
     * Store the current line character in the source; for error reporting
     */
    private int _charIndex;
    private int _startIndex;
    private int _startLineIndex;
    private int _startCharIndex;
    /**
     * Store the first found new-line symbol '\n' or '\r', after that, only
     *  match that symbol as a new line and if the other occurs, ignore it
     */
    private char _newlineSymbol;
    /**
     * If true, index is incremented (to get the next symbol next loop). Some
     *  states don't consume the symbol, just react to it, and want to leave it
     *  for another state to consume it
     */
    private boolean _doConsume;
    /**
     * If true, white-space will be read and parsed. If false, white-space will
     *  be skipped without notifying the parser (the parser will see the input
     *  as a stream of characters without white-spaces)
     */
    private boolean _doConsumeWhitespace;
    /**
     * The current ast node that is active, new nodes are added in relation to
     *  this
     */
    private AstNode _activeAstNode;
    /**
     * Allow AST nodes to be pushed onto a stack so a relative top-level node
     *  can be reactivated as needed
     */
    private Stack<AstNode> _activeAstNodeStack;
    /**
     * After a pop, the action of adding nodes when appending changes to INSERT
     *  the node. This tracks when this should be done
     */
    private AppendAstNodeMode _appendAstNodeMode;
    /**
     * The current state the parser is in (decides what symbols are allowed next)
     */
    private ParseStateList _parseState;
    /**
     * Allow states to be pushed onto a stack so return states will take from
     *  the stack, rather than use a specific state
     */
    private Stack<ParseStateList> _parseStateStack;
    /**
     * Trace the execution of the parser
     */
    private StringBuilder _parserTrace;

    /**
     * When a node is appended, should it be added to the active node, or
     *  inserted (take the current nodes place and make the current node a
     *  child). This is only used in cases where the active node has a
     *  precedence of -1 (no precedence). Any node that has a precedence will
     *  cause the node to be added or inserted based on the precedence order
     */
    private enum AppendAstNodeMode
    {   /**
         * The next node appended will be a child of the active node. This is
         *  the default action and the mode is restored to this as soon as a
         *  node has been added while in INSERT mode
         */
        APPEND,
        /**
         * The next node appended will take the place of the active node after
         *  making the active node a child
         */
        INSERT
    }

    private enum AddAstNodeMode
    {   APPEND,
        INSERT,
        REPLACE
    }

    protected enum NavigateAstNodeMode
    {   PARENT,
        CHILD,
        PREV,
        NEXT
    }
    
    protected static class SpecialSymbol
    {   public static final char EOF = (char)-1;
    }
    
}
