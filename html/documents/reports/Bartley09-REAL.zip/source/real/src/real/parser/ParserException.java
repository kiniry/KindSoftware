package real.parser;

import real.ast.AstNode;
import real.utilities.RealException;

/**
 * @author e
 */
public class ParserException extends RealException
{

    public ParserException
    (   String            message,
        Throwable       exception,
        AstNode       rootAstNode,
        ParserSource parserSource
    ){  super(message, exception, parserSource);
        _rootAstNode = rootAstNode;
    }

    public ParserException
    (   String            message,
        Throwable       exception,
        ParserSource parserSource
    ){  this(message, exception, null, parserSource);
    }

    @Override
    public String getMessage()
    {   return
            super.getMessage()
         +  getParserSource();
    }

    public AstNode getRootAstNode()
    {   return _rootAstNode;
    }

    public void setRootAstNode(AstNode astNode)
    {   _rootAstNode = astNode;
    }
    
    private AstNode _rootAstNode;
    
}
