package real.parser;

/**
 * @author e
 */
public class ParserSource
{

    public ParserSource()
    {
    }

    public ParserSource
    (   int     start,
        int startLine,
        int startChar,
        int       end,
        int   endLine,
        int   endChar
    ){  set(start, startLine, startChar, end, endLine, endChar);
    }

    public ParserSource
    (   int     offset,
        int offsetLine,
        int offsetChar
    ){  setEnd(offset, offsetLine, offsetChar);
    }

    public void set
    (   int     start,
        int startLine,
        int startChar,
        int       end,
        int   endLine,
        int   endChar
    ){  setStart(start, startLine, startChar);
        setEnd(end, endLine, endChar);
    }
    
    public void set(ParserSource parserSource)
    {   _start = parserSource._start;
        _startLine = parserSource._startLine;
        _startChar = parserSource._startChar;
        _end = parserSource._end;
        _endLine = parserSource._endLine;
        _endChar = parserSource._endChar;
    }
    
    public void setStart(int start, int startLine, int startChar)
    {   if(_start == -1)
        {   _start = start;
            _startLine = startLine;
            _startChar = startChar;
        }
    }
    public void setEnd(int end, int endLine, int endChar)
    {   setStart(end, endLine, endChar);  // Only sets if not previously set
        if(_end == -1)
        {   _end = end;
            _endLine = endLine;
            _endChar = endChar;
        }
    }

    public void setEncompass(ParserSource parserSource)
    {
        
        if(parserSource._start < _start)
        {   _start = parserSource._start;
            _startLine = parserSource._startLine;
            _startChar = parserSource._startChar;
        }
        
        if(parserSource._end > _end)
        {   _end = parserSource._end;
            _endLine = parserSource._endLine;
            _endChar = parserSource._endChar;
        }

    }
    
    public int getStart()
    {   return _start;
    }
    public int getStartLine()
    {   return _startLine;
    }
    public int getStartChar()
    {   return _startChar;
    }
    public int getEnd()
    {   return _end;
    }
    public int getEndLine()
    {   return _endLine;
    }
    public int getEndChar()
    {   return _endChar;
    }

    @Override
    public String toString()
    {   StringBuilder builder = new StringBuilder();
        builder.append("((");
        builder.append(getStart());
        builder.append("; ");
        builder.append(getStartLine());
        builder.append(", ");
        builder.append(getStartChar());
        builder.append("), (");
        builder.append(getEnd());
        builder.append("; ");
        builder.append(getEndLine());
        builder.append(", ");
        builder.append(getEndChar());
        builder.append("))");
        return builder.toString();
    }
    
    /**
     * Absolute character start (from start of file)
     */
    private int _start = -1;
    /**
     * The line of code where this node began
     */
    private int _startLine;
    /**
     * The character on the line of code where this node began
     */
    private int _startChar;
    /**
     * Absolute character end (from start of file)
     */
    private int _end = -1;
    /**
     * The line of code where this node ended
     */
    private int _endLine;
    /**
     * The character on the line of code where this node ended
     */
    private int _endChar;

}
