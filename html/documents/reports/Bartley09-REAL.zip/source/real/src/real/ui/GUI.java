package real.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextPane;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Element;
import javax.swing.text.Highlighter;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import real.analyser.StructureVisitor;
import real.analyser.TypeException;
import real.analyser.TypeVisitor;
import real.ast.AstNode;
import real.ast.visitor.AstVisitorTerminator;
import real.interpreter.InterpretVisitor;
import real.interpreter.InterpreterException;
import real.interpreter.InterpreterResult;
import real.parser.ParserException;
import real.parser.ParserSource;
import real.parser.RealParser;
import real.utilities.EncompassVisitor;
import real.utilities.FocusVisitor;
import real.utilities.RealException;

/**
 * @author e
 */
public class GUI extends JPanel
{

    public GUI()
    {   super(new BorderLayout());

        Font font = new Font(Font.MONOSPACED, Font.PLAIN, 12);

        _guiAST = new JTree();
        _guiAST.addTreeSelectionListener(new TreeSelectionListener()
        {   public void valueChanged(TreeSelectionEvent arg0)
            {   realASTSelect();
            }
        });
        _guiAST.setModel
        (   new DefaultTreeModel
            (   new DefaultMutableTreeNode("REAL")
            )
        );
        
        _guiSource = new NoWrapTextPane();
        _guiSource.setFont(font);
        _guiSource.addKeyListener
        (   new KeyAdapter()
            {   @Override
                public void keyPressed(KeyEvent arg0)
                {   realWatch();
                }
                @Override
                public void keyReleased(KeyEvent arg0)
                {   realWatch();
                }
            }
        );
        _guiSource.addMouseListener
        (   new MouseAdapter()
            {   @Override
                public void mousePressed(MouseEvent arg0)
                {   realWatch();
                }
                @Override
                public void mouseReleased(MouseEvent arg0)
                {   realWatch();
                }
            }
        );

        _guiOutput = new NoWrapTextPane();
        _guiOutput.setFont(font);

        _guiFocus = new NoWrapTextPane();
        _guiFocus.setFont(font);

        _guiStatus = new StatusPane();
        
        _guiSplit[2] = new JSplitPane
        (   JSplitPane.HORIZONTAL_SPLIT,
            _guiSourceScroll = new JScrollPane(_guiSource),
            _guiOutputScroll = new JScrollPane(_guiOutput)
        );

        _guiSourceScroll.getVerticalScrollBar().addAdjustmentListener
        (   new AdjustmentListener()
            {   public void adjustmentValueChanged(AdjustmentEvent event)
                {   _guiOutputScroll
                        .getVerticalScrollBar()
                        .setValue(event.getValue());
                }
            }
        );
        _guiOutputScroll.setVerticalScrollBarPolicy
        (   JScrollPane.VERTICAL_SCROLLBAR_NEVER
        );
        
        _guiSplit[1] = new JSplitPane
        (   JSplitPane.VERTICAL_SPLIT,
            _guiSplit[2],
            new JScrollPane(_guiFocus)
        );
        
        _guiSplit[0] = new JSplitPane
        (   JSplitPane.HORIZONTAL_SPLIT,
            new JScrollPane(_guiAST),
            _guiSplit[1]
        );
        _guiSplit[0].setOneTouchExpandable(true);
        
        add(_guiSplit[0]);
        add(_guiStatus, BorderLayout.SOUTH);

    }

    public String getSource()
    {   return _guiSource.getText();
    }
    
    public void setSource(String source)
    {   _guiSource.setText(source);
        realWatch();
    }
    
    private void realWatch()
    {
        
        if(realKill() == false)
            return;
        
        new Thread(new Runnable()
        {   public void run()
            {   try
                {
                    _guiStatus.setStatus("Running..");
                    _guiStatus.setPosition
                    (   _guiSource.getCaretLine(),
                        _guiSource.getCaretColumn()
                    );
                    if(realTime() == true)
                        _guiStatus.setStatus("Ready");
                }
                catch(Throwable e)
                {   System.out.println("BOOM!");
                    e.printStackTrace();
                }
                synchronized(_sync)
                {   _terminator = null;
                }
            }
        }).start();
    }

    private boolean realTime()
    {   String source;
        RealParser realParser;
        AstNode astNode;
        StructureVisitor structureVisitor;
        TypeVisitor typeVisitor;
        EncompassVisitor encompassVisitor;
        FocusVisitor focusVisitor;
        InterpretVisitor interpreterVisitor;
        boolean success = true;

        source = _guiSource.getText().replaceAll("\n\r", "\n");
        realParser = new RealParser();
        structureVisitor = new StructureVisitor();
        typeVisitor = new TypeVisitor();
        encompassVisitor = new EncompassVisitor();
        focusVisitor = new FocusVisitor(_guiSource.getCaretPosition());
        interpreterVisitor = new InterpretVisitor();
        _terminator = interpreterVisitor;

        realHighlightRemoveAll();
        
        try
        {

            astNode = realParser.parse(source);
            astNode.applyVisitor(structureVisitor);
            astNode.applyVisitor(typeVisitor);
            astNode.applyVisitor(focusVisitor);
            astNode.applyVisitor(encompassVisitor);

            interpreterVisitor.setFocusAstNode(focusVisitor.getFocusAstNode());
            astNode.applyVisitor(interpreterVisitor);

            realFocus(interpreterVisitor.getFocusStack());

            List<InterpreterResult> results = interpreterVisitor.getResults();
            StringBuilder builder = new StringBuilder();
            int currentLine = 0;
            for(InterpreterResult result : results)
            {   int endLine = result.getAstNode().getParserSource().getEndLine();
                while(currentLine < endLine)
                {   builder.append('\n');
                    currentLine++;
                }
                builder.append(result.toString() + "; ");
            }

            _guiOutput.setText(builder.toString());

            DefaultMutableTreeNode rootTreeNode = new DefaultMutableTreeNode("REAL");
            realASTBuild(astNode, rootTreeNode);
            _guiAST.setModel(new DefaultTreeModel(rootTreeNode));

        }
        catch(ParserException e)
        {   success = realError("Parse error: " + e.getMessage(), e);
        }
        catch(TypeException e)
        {   success = realError("Type error: " + e.getMessage(), e);
        }
        catch(InterpreterException e)
        {   success = realError("Interpreter error: " + e.getMessage(), e);
        }
        catch(Exception e)
        {   success = realError
            (   "Error: " + e.getMessage()
             +  " " + e.getStackTrace()[0].toString()
            );
        }
        catch(Error e)
        {   success = realError
            (   "Error: " + e.getClass().getSimpleName()
             +  " " + e.getStackTrace()[0].toString()
            );
        }
        catch(Throwable e)
        {   success = realError
            (   "Error: " + e.getClass().getSimpleName()
             +  " " + e.getStackTrace()[0].toString()
            );
        }

        return success;
        
    }
    
    private boolean realError(String error)
    {   return realError(error, null);
    }

    private boolean realError(String error, RealException exception)
    {   _guiStatus.setStatus(error);
        _guiOutput.setText("");
        _guiFocus.setText("");
        if(exception != null)
            try { realHighlight(exception.getParserSource(), _paintError); }
            catch(BadLocationException e) { }
        return false;
    }

    private void realASTBuild
    (   AstNode                       astNode
    ,   DefaultMutableTreeNode parentTreeNode
    ){  DefaultMutableTreeNode       treeNode;

        treeNode = new DefaultMutableTreeNode(astNode);
        parentTreeNode.add(treeNode);

        for(int i = 0; i < astNode.getChildCount(); i++)
            realASTBuild(astNode.getChild(i), treeNode);

    }
    
    private void realASTSelect()
    {
        
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)_guiAST
            .getLastSelectedPathComponent();

        if(node == null)
            return;

        if(node.getUserObject() instanceof AstNode == false)
            return;

        AstNode astNode = (AstNode)node.getUserObject();

        ParserSource parserSource = astNode.getParserSource();

        _guiSource.setSelectionStart(parserSource.getStart());
        _guiSource.setSelectionEnd(parserSource.getEnd());
        _guiSource.getCaret().setSelectionVisible(true);

    }
    
    private void realFocus(InterpretVisitor.Focus focus)
    throws BadLocationException
    {

        if(focus != null)
        {   realHighlight(focus.getAstNode(), _paintScope);
            if(focus.getResult() == null)
                _guiFocus.setText("ID");
            else
                _guiFocus.setText(focus.toString());
        }
        else
        {   //realHighlightRemove(_paintScope);
            _guiFocus.setText("No focus");
        }

    }
    
    private void realHighlight
    (   ParserSource   parserSource
    ,   Paint                 paint
    )   throws BadLocationException
    {   Highlighter highlighter;
        Object paintTag;
        
        if(parserSource == null)
            return;
        
        if((highlighter = _guiSource.getHighlighter()) == null)
        {   highlighter = new DefaultHighlighter();
            _guiSource.setHighlighter(highlighter);
        }
        
        paintTag = highlighter.addHighlight
        (   parserSource.getStart(),
            parserSource.getEnd() + 1,
            paint
        );

        _paintTag.put(paint, paintTag);
        
    }
    
    private void realHighlight
    (   AstNode             astNode
    ,   Paint                 paint
    )   throws BadLocationException
    {   realHighlight(astNode.getParserSource(), paint);
    }
    
    private void realHighlightRemove(Paint paint)
    {   Highlighter highlighter;

        if((highlighter = _guiSource.getHighlighter()) == null)
        {   highlighter = new DefaultHighlighter();
            _guiSource.setHighlighter(highlighter);
        }

        if(_paintTag.containsKey(paint) == true)
        {   highlighter.removeHighlight(_paintTag.get(paint));
            _paintTag.remove(paint);
        }
        
    }
    
    private void realHighlightRemoveAll()
    {/*   Highlighter highlighter;

        if((highlighter = _guiSource.getHighlighter()) == null)
        {   highlighter = new DefaultHighlighter();
            _guiSource.setHighlighter(highlighter);
        }

        highlighter.removeAllHighlights();*/
        
        for(Paint paint : _paintTag.keySet())
            realHighlightRemove(paint);
        
    }
    
    private boolean realKill()
    {   int wait = 20;
        
        // If REAL is currently running, ask it to shut-down
        synchronized(_sync)
        {   if(_terminator != null)
                _terminator.terminate();
        }

        // Having given REAL the command to shut-down, wait for it to do so
        while(_terminator != null && wait > 0)
        {   try { Thread.sleep(25); }
            catch(InterruptedException e) { }
            wait--;
        }

        // If it didn't shut-down, write an error
        if(_terminator != null)
        {   synchronized(_sync)
            {   realError("Failed to release");
            }
            return false;
        }
        
        return true;

    }
    
    public void initialise()
    {   _guiSplit[1].setDividerLocation(0.8);
        _guiSplit[0].setDividerLocation(0.0);
        _guiSplit[2].setDividerLocation(0.6);
        _guiSplit[1].setResizeWeight(0.8);
        _guiSplit[0].setResizeWeight(0.0);
        _guiSplit[2].setResizeWeight(0.6);
    }

    private JSplitPane[] _guiSplit = new JSplitPane[3];
    private JScrollPane _guiSourceScroll;
    private NoWrapTextPane _guiSource;
    private JScrollPane _guiOutputScroll;
    private NoWrapTextPane _guiOutput;
    private NoWrapTextPane _guiFocus;
    private JTree _guiAST;
    private StatusPane _guiStatus;
    private AstVisitorTerminator _terminator;
    private Paint _paintScope = new Paint(Color.YELLOW);
    private Paint _paintError = new Paint(Color.RED);
    private Paint _paintSelect = new Paint(Color.BLUE);
    private HashMap<Paint, Object> _paintTag = new HashMap<Paint, Object>();
    private Object _sync = new Object();

    private class Paint extends DefaultHighlighter.DefaultHighlightPainter
    {   public Paint(Color colour) { super(colour); } }
    
    private class NoWrapTextPane extends JTextPane
    {
        
        @Override
        public void setSize(Dimension dimension)
        {   if(dimension.width < getParent().getSize().width)
                dimension.width = getParent().getSize().width;
            super.setSize(dimension);
        }

        @Override
        public boolean getScrollableTracksViewportWidth()
        {   return false;
        }

        public int getCaretLine()
        {   return getDocument()
                .getDefaultRootElement()
                .getElementIndex(getCaretPosition());
        }
        
        public int getCaretColumn()
        {   int offset = getCaretPosition();
            Element root = getDocument().getDefaultRootElement();
            return offset - root
                .getElement(root.getElementIndex(offset))
                .getStartOffset() + 1;
        }
        
    }
    
    private class StatusPane extends JPanel
    {

        public StatusPane()
        {   super();
            setLayout(new BorderLayout());
            _guiStatus = new JLabel("Ready");
            _guiPosition = new JLabel();
            add(_guiStatus);
            add(_guiPosition, BorderLayout.EAST);
        }

        public void setStatus(String status)
        {   _guiStatus.setText(status);
        }
        
        public void setPosition(int line, int column)
        {   _guiPosition.setText("L:" + line + ";C:" + column);
        }
        
        private JLabel _guiStatus;
        private JLabel _guiPosition;
        
    }
    
}
