package real.utilities;

import java.io.PrintStream;
import real.ast.AstNode;
import real.ast.visitor.SimpleAstVisitor;

/**
 * Validate the AST is type correct
 * @author e
 */
public class DumpVisitor extends SimpleAstVisitor
{

    public DumpVisitor(PrintStream out, AstNode activeAstNode)
    {   _out = out;
        _activeAstNode = activeAstNode;
    }

    public DumpVisitor(AstNode activeAstNode)
    {   this(System.out, activeAstNode);
    }

    public DumpVisitor(PrintStream out)
    {   this(out, null);
    }
    
    public DumpVisitor()
    {   this(System.out, null);
    }
    
    @Override
    protected void defaultVisit(AstNode astNode)
    {   _out.println(getIndent(astNode) + astNode);
    }
    
    private String getIndent(AstNode astNode)
    {   StringBuilder builder = new StringBuilder();
        if(_activeAstNode != null)
            if(astNode == _activeAstNode)
                builder.append("->");
            else
                builder.append(" .");
        for(astNode = astNode.getParent(); astNode != null; astNode = astNode.getParent())
            builder.append("    ");
        return builder.toString();
    }
    
    private PrintStream _out;
    /**
     * Highlight the active ast node if this is set
     */
    private AstNode _activeAstNode;
    
}
