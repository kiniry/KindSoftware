package real.utilities;

import real.ast.AstNode;
import real.ast.visitor.AstVisitor;
import real.ast.visitor.AstVisitor.AstAcceptOrderer;
import real.ast.visitor.SimpleAstVisitor;
import real.parser.ParserSource;

/**
 * @author e
 */
public class EncompassVisitor extends SimpleAstVisitor
{

    @Override
    protected void defaultVisit(AstNode astNode)
    {   ParserSource parserSource = astNode.getParserSource();
        for(int index = 0; index < astNode.getChildCount(); index++)
            parserSource.setEncompass(astNode.getChild(index).getParserSource());
    }

    @Override
    public AstAcceptOrderer getDefaultOrderer()
    {   return new AstVisitor.InverseInfixAcceptOrderer();
    }

}
