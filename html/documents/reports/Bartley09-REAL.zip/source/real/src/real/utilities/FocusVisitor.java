package real.utilities;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import real.ast.AstNode;
import real.ast.visitor.AstVisitor;
import real.ast.visitor.SimpleAstVisitor;
import real.parser.ParserSource;

/**
 * @author e
 */
public class FocusVisitor extends SimpleAstVisitor
{

    public FocusVisitor(int focusIndex)
    {   _focusIndex = focusIndex;
    }

    @Override
    public void afterVisit()
    {
        AstNode astNode = null;
        boolean allMatch = true;

        if(_foci.size() == 0)
            return;
        
        while(allMatch == true)
        {
        
            astNode = null;
            for(Focus focus : _foci)
                if(astNode == null)
                    astNode = focus.popAstNodeParent();
                else
                    if(astNode != focus.popAstNodeParent())
                    {   allMatch = false;
                        break;
                    }

            if(allMatch == true)
                if(astNode != null)
                    _focusAstNode = astNode;
                else
                    allMatch = false;
            
        }
        
    }
    
    @Override
    protected void defaultVisit(AstNode astNode)
    {   if(isAddedParent(astNode) == false)
        {   ParserSource parserSource = astNode.getParserSource();
            if(_focusIndex >= parserSource.getStart()
            && _focusIndex <= parserSource.getEnd())
                _foci.add(new Focus(astNode));
        }
    }

    @Override
    public AstAcceptOrderer getDefaultOrderer()
    {   return new AstVisitor.InverseInfixAcceptOrderer();
    }

    public AstNode getFocusAstNode()
    {   return _focusAstNode;
    }

    private boolean isAddedParent(AstNode parentAstNode)
    {   for(Focus focus : _foci)
            for
            (   AstNode astNode = focus.getAstNode().getParent();
                astNode != null;
                astNode = astNode.getParent()
            )   if(astNode == parentAstNode)
                    return true;
        return false;
    }
    
    /**
     * Scope the text position of focus. The node closest to this focus will
     *  populate extra details about the execution
     */
    private int _focusIndex;
    /**
     * Scope the AstNode that has the best focus
     */
    private AstNode _focusAstNode;
    /**
     * Work buffer
     */
    private List<Focus> _foci = new ArrayList<Focus>();

    private class Focus
    {
        
        public Focus(AstNode astNode)
        {   _astNode = astNode;
            for
            (   astNode = astNode.getParent();
                astNode != null;
                astNode = astNode.getParent()
            )   parentAstNodes.push(astNode);
        }

        public AstNode getAstNode()
        {   return _astNode;
        }
        
        public AstNode popAstNodeParent()
        {   if(parentAstNodes.size() == 0)
                return null;
            return parentAstNodes.pop();
        }
        
        private AstNode _astNode;
        private Stack<AstNode> parentAstNodes = new Stack<AstNode>();
    }
    
}
