package real.utilities;

import real.parser.ParserSource;

/**
 * @author e
 */
public class RealException extends RuntimeException
{

    public RealException(ParserSource parserSource)
    {   _parserSource = parserSource;
    }

    public RealException
    (   String            message,
        Throwable       exception,
        ParserSource parserSource
    ){  super(message, exception);
        _parserSource = parserSource;
    }

    public ParserSource getParserSource()
    {   return _parserSource;
    }

    private ParserSource _parserSource;
    
}
