import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.List;
import junit.framework.TestCase;
import real.utilities.DumpVisitor;
import real.analyser.StructureVisitor;
import real.analyser.TypeExistsException;
import real.analyser.TypeIllegalException;
import real.analyser.TypeMismatchException;
import real.analyser.TypeUnknownException;
import real.analyser.TypeVisitor;
import real.ast.AstNode;
import real.ast.type.Type;
import real.ast.visitor.AstVisitorTerminator;
import real.interpreter.InterpreterException;
import real.interpreter.InterpreterResult;
import real.interpreter.InterpretVisitor;
import real.parser.RealParser;

/**
 * @author e
 */
public class Test extends TestCase
{

    /**
     * @param args the command line arguments
     */
    public void testBasic()
    {

        runTest("true", true, Type.TypeBool);
        runTest("-true", false, Type.TypeBool);
        runTest("false", false, Type.TypeBool);
        runTest("-false", true, Type.TypeBool);
        runTest("+true", TypeIllegalException.class, null);
        runTest("+-true", TypeIllegalException.class, null);
        runTest("+false", TypeIllegalException.class, null);
        runTest("+-false", TypeIllegalException.class, null);
        
        runTest("10", 10, Type.TypeInt);
        runTest("0", 0, Type.TypeInt);
        runTest("-10", -10, Type.TypeInt);
        runTest("+10", 10, Type.TypeInt);
        runTest("+0", 0, Type.TypeInt);
        runTest("+-10", 10, Type.TypeInt);
        
        runTest("10.0", 10.0f, Type.TypeFloat);
        runTest("0.0", 0.0f, Type.TypeFloat);
        runTest("-10.0", -10.0f, Type.TypeFloat);
        runTest("+10.0", 10.0f, Type.TypeFloat);
        runTest("+0.0", 0.0f, Type.TypeFloat);
        runTest("+-10.0", 10.0f, Type.TypeFloat);
        
        runTest("\"a\\\"b\\\\c\"", "a\\\"b\\\\c", Type.TypeString);
        runTest("+\"a\\\"b\\\\c\"", TypeIllegalException.class, null);
        runTest("-\"a\\\"b\\\\c\"", TypeIllegalException.class, null);

        runTest("ID", null, Type.TypeID);
        runTest("+ID", null, Type.TypeID);
        runTest("-ID", null, Type.TypeID);
        runTest("+-ID", null, Type.TypeID);
        
    }
    
    public void testConversion()
    {
        
        runTest("true:bool", true, Type.TypeBool);
        runTest("true:int", 1, Type.TypeInt);
        runTest("true:float", 1.0f, Type.TypeFloat);
        runTest("true:string", "true", Type.TypeString);

        runTest("false:bool", false, Type.TypeBool);
        runTest("false:int", 0, Type.TypeInt);
        runTest("false:float", 0.0f, Type.TypeFloat);
        runTest("false:string", "false", Type.TypeString);

        runTest("10:bool", true, Type.TypeBool);
        runTest("10:int", 10, Type.TypeInt);
        runTest("10:float", 10.0f, Type.TypeFloat);
        runTest("10:string", "10", Type.TypeString);

        runTest("0:bool", false, Type.TypeBool);
        runTest("0:int", 0, Type.TypeInt);
        runTest("0:float", 0.0f, Type.TypeFloat);
        runTest("0:string", "0", Type.TypeString);

        runTest("10.0:bool", true, Type.TypeBool);
        runTest("10.0:int", 10, Type.TypeInt);
        runTest("10.0:float", 10.0f, Type.TypeFloat);
        runTest("10.0:string", "10.0", Type.TypeString);

        runTest("0.0:bool", false, Type.TypeBool);
        runTest("0.0:int", 0, Type.TypeInt);
        runTest("0.0:float", 0.0f, Type.TypeFloat);
        runTest("0.0:string", "0.0", Type.TypeString);

        runTest("\"10.0\":bool", false, Type.TypeBool);
        runTest("\"10.0\":int", 10, Type.TypeInt);
        runTest("\"10.0\":float", 10.0f, Type.TypeFloat);
        runTest("\"10.0\":string", "10.0", Type.TypeString);

        runTest("\"0.0\":bool", false, Type.TypeBool);
        runTest("\"0.0\":int", 0, Type.TypeInt);
        runTest("\"0.0\":float", 0.0f, Type.TypeFloat);
        runTest("\"0.0\":string", "0.0", Type.TypeString);

        runTest("\"true\":bool", true, Type.TypeBool);
        runTest("\"true\":int", 1, Type.TypeInt);
        runTest("\"true\":float", 1.0f, Type.TypeFloat);
        runTest("\"true\":string", "true", Type.TypeString);

        runTest("\"false\":bool", false, Type.TypeBool);
        runTest("\"false\":int", 0, Type.TypeInt);
        runTest("\"false\":float", 0.0f, Type.TypeFloat);
        runTest("\"false\":string", "false", Type.TypeString);

        runTest("true:ID", TypeUnknownException.class, null);
        runTest("true:true", TypeUnknownException.class, null);
        runTest("true:test", TypeUnknownException.class, null);
        runTest("true:false", TypeUnknownException.class, null);
        runTest("true:assert", TypeUnknownException.class, null);
        runTest("true:while", TypeUnknownException.class, null);
        runTest("true:if", TypeUnknownException.class, null);
        
    }
    
    public void testIf()
    {
        
        runTest("if(true){1}else{2}", 1, Type.TypeInt);
        runTest("if(false){1}else{2}", 2, Type.TypeInt);
        runTest("if(ID){1}else{2}", null, Type.TypeInt);
        runTest("if(true){1}", 1, Type.TypeInt);
        runTest("if(false){1}", null, Type.TypeInt);
        runTest("if(ID){1}", null, Type.TypeInt);
        runTest("if(1){1}", TypeMismatchException.class, null);
        runTest("if(1.0){1}", TypeMismatchException.class, null);
        runTest("if(\"1\"){1}", TypeMismatchException.class, null);
        runTest("if(true){true}else{2}", TypeMismatchException.class, null);
        runTest("if(true){true}else{2.0}", TypeMismatchException.class, null);
        runTest("if(true){true}else{\"2\"}", TypeMismatchException.class, null);
        runTest("if(true){1}else{false}", TypeMismatchException.class, null);
        runTest("if(true){1}else{2.0}", TypeMismatchException.class, null);
        runTest("if(true){1}else{\"2\"}", TypeMismatchException.class, null);
        runTest("if(true){1.0}else{false}", TypeMismatchException.class, null);
        runTest("if(true){1.0}else{2}", TypeMismatchException.class, null);
        runTest("if(true){1.0}else{\"2\"}", TypeMismatchException.class, null);
        runTest("if(true){\"1\"}else{false}", TypeMismatchException.class, null);
        runTest("if(true){\"1\"}else{2}", TypeMismatchException.class, null);
        runTest("if(true){\"1\"}else{2.0}", TypeMismatchException.class, null);
        runTest("if(true){ID}else{false}", null, Type.TypeBool);
        runTest("if(true){ID}else{2}", null, Type.TypeInt);
        runTest("if(true){ID}else{2.0}", null, Type.TypeFloat);
        runTest("if(true){ID}else{\"2\"}", null, Type.TypeString);
        runTest("if(true){true}else{ID}", true, Type.TypeBool);
        runTest("if(true){1}else{ID}", 1, Type.TypeInt);
        runTest("if(true){1.0}else{ID}", 1.0f, Type.TypeFloat);
        runTest("if(true){\"1\"}else{ID}", "1", Type.TypeString);
        
    }
    
    public void testWhile()
    {
        
        runTest("while(false){true}", null, Type.TypeBool);
        runTest("while(false){0}", null, Type.TypeInt);
        runTest("while(false){0.0}", null, Type.TypeFloat);
        runTest("while(false){\"0\"}", null, Type.TypeString);
        runTest("while(true){0}", InterpreterException.class, null);
        runTest("while(ID){1}", null, Type.TypeInt);
        runTest("while(1){1}", TypeMismatchException.class, null);
        runTest("while(1.0){1}", TypeMismatchException.class, null);
        runTest("while(\"1\"){1}", TypeMismatchException.class, null);

    }
    
    public void testAssert()
    {
        
        runTest("assert(true)", true, Type.TypeBool);
        runTest("assert(false)", InterpreterException.class, null);
        runTest("assert(1)", TypeMismatchException.class, null);
        runTest("assert(1.0)", TypeMismatchException.class, null);
        runTest("assert(\"1\")", TypeMismatchException.class, null);

    }
    
    public void testBopBool()
    {
        
        runTest("true+true", true, Type.TypeBool);
        runTest("true+false", true, Type.TypeBool);
        runTest("false+true", true, Type.TypeBool);
        runTest("false+false", false, Type.TypeBool);
        runTest("true-true", TypeIllegalException.class, null);
        runTest("true-false", TypeIllegalException.class, null);
        runTest("false-true", TypeIllegalException.class, null);
        runTest("false-false", TypeIllegalException.class, null);
        runTest("true*true", true, Type.TypeBool);
        runTest("true*false", false, Type.TypeBool);
        runTest("false*true", false, Type.TypeBool);
        runTest("false*false", false, Type.TypeBool);
        runTest("true/true", TypeIllegalException.class, null);
        runTest("true/false", TypeIllegalException.class, null);
        runTest("false/true", TypeIllegalException.class, null);
        runTest("false/false", TypeIllegalException.class, null);
        runTest("true%true", TypeIllegalException.class, null);
        runTest("true%false", TypeIllegalException.class, null);
        runTest("false%true", TypeIllegalException.class, null);
        runTest("false%false", TypeIllegalException.class, null);
        runTest("true^true", false, Type.TypeBool);
        runTest("true^false", true, Type.TypeBool);
        runTest("false^true", true, Type.TypeBool);
        runTest("false^false", false, Type.TypeBool);
        runTest("true\\true", TypeIllegalException.class, null);
        runTest("true\\false", TypeIllegalException.class, null);
        runTest("false\\true", TypeIllegalException.class, null);
        runTest("false\\false", TypeIllegalException.class, null);
        runTest("true|true", TypeIllegalException.class, null);
        runTest("true|false", TypeIllegalException.class, null);
        runTest("false|true", TypeIllegalException.class, null);
        runTest("false|false", TypeIllegalException.class, null);
        
        runTest("true+ID", true, Type.TypeBool);
        runTest("ID+true", true, Type.TypeBool);
        runTest("false+ID", false, Type.TypeBool);
        runTest("ID+false", false, Type.TypeBool);
        runTest("true-ID", TypeIllegalException.class, null);
        runTest("ID-true", TypeIllegalException.class, null);
        runTest("false-ID", TypeIllegalException.class, null);
        runTest("ID-false", TypeIllegalException.class, null);
        runTest("true*ID", true, Type.TypeBool);
        runTest("ID*true", true, Type.TypeBool);
        runTest("false*ID", false, Type.TypeBool);
        runTest("ID*false", false, Type.TypeBool);
        runTest("true/ID", TypeIllegalException.class, null);
        runTest("ID/true", TypeIllegalException.class, null);
        runTest("false/ID", TypeIllegalException.class, null);
        runTest("ID/false", TypeIllegalException.class, null);
        runTest("true%ID", TypeIllegalException.class, null);
        runTest("ID%true", TypeIllegalException.class, null);
        runTest("false%ID", TypeIllegalException.class, null);
        runTest("ID%false", TypeIllegalException.class, null);
        runTest("true^ID", true, Type.TypeBool);
        runTest("ID^true", true, Type.TypeBool);
        runTest("false^ID", false, Type.TypeBool);
        runTest("ID^false", false, Type.TypeBool);
        runTest("true\\ID", TypeIllegalException.class, null);
        runTest("ID\\true", TypeIllegalException.class, null);
        runTest("false\\ID", TypeIllegalException.class, null);
        runTest("ID\\false", TypeIllegalException.class, null);
        runTest("true|ID", TypeIllegalException.class, null);
        runTest("ID|true", TypeIllegalException.class, null);
        runTest("false|ID", TypeIllegalException.class, null);
        runTest("ID|false", TypeIllegalException.class, null);

    }
    
    public void testBopInt()
    {
        
        runTest("50+50", 100, Type.TypeInt);
        runTest("50+10", 60, Type.TypeInt);
        runTest("10+50", 60, Type.TypeInt);
        runTest("10+10", 20, Type.TypeInt);
        runTest("50-50", 0, Type.TypeInt);
        runTest("50-10", 40, Type.TypeInt);
        runTest("10-50", -40, Type.TypeInt);
        runTest("10-10", 0, Type.TypeInt);
        runTest("50*50", 2500, Type.TypeInt);
        runTest("50*10", 500, Type.TypeInt);
        runTest("10*50", 500, Type.TypeInt);
        runTest("10*10", 100, Type.TypeInt);
        runTest("50/50", 1, Type.TypeInt);
        runTest("50/10", 5, Type.TypeInt);
        runTest("10/50", 0, Type.TypeInt);
        runTest("10/10", 1, Type.TypeInt);
        runTest("10/0", ArithmeticException.class, null);
        runTest("50%50", 0, Type.TypeInt);
        runTest("50%10", 0, Type.TypeInt);
        runTest("50%11", 6, Type.TypeInt);
        runTest("10%50", 10, Type.TypeInt);
        runTest("10%10", 0, Type.TypeInt);
        runTest("50^5", 312500000, Type.TypeInt);
        runTest("50^1", 50, Type.TypeInt);
        runTest("50^0", 1, Type.TypeInt);
        runTest("10^5", 100000, Type.TypeInt);
        runTest("10^1", 10, Type.TypeInt);
        runTest("1^10", 1, Type.TypeInt);
        runTest("0^10", 0, Type.TypeInt);
        runTest("0^0", 1, Type.TypeInt);
        runTest("50\\50", 1, Type.TypeInt);
        runTest("50\\10", 1, Type.TypeInt);
        runTest("10\\50", 1, Type.TypeInt);
        runTest("10\\10", 1, Type.TypeInt);
        runTest("50|50", 1, Type.TypeInt);
        runTest("50|10", 1, Type.TypeInt);
        runTest("10|50", 0, Type.TypeInt);
        runTest("10|10", 1, Type.TypeInt);

        runTest("10+ID", 10, Type.TypeInt);
        runTest("ID+10", 10, Type.TypeInt);
        runTest("10-ID", 10, Type.TypeInt);
        runTest("ID-10", 10, Type.TypeInt);
        runTest("10*ID", 10, Type.TypeInt);
        runTest("ID*10", 10, Type.TypeInt);
        runTest("10/ID", 10, Type.TypeInt);
        runTest("ID/10", 10, Type.TypeInt);
        runTest("ID/0", 0, Type.TypeInt);
        runTest("10%ID", 10, Type.TypeInt);
        runTest("ID%10", 10, Type.TypeInt);
        runTest("10^ID", 10, Type.TypeInt);
        runTest("ID^10", 10, Type.TypeInt);
        runTest("10\\ID", 10, Type.TypeInt);
        runTest("ID\\10", 10, Type.TypeInt);
        runTest("10|ID", 10, Type.TypeInt);
        runTest("ID|10", 10, Type.TypeInt);

    }
    
    public void testBopFloat()
    {
        
        runTest("3.141+3.141", 6.282f, Type.TypeFloat);
        runTest("3.141+2.718", 5.859f, Type.TypeFloat);
        runTest("2.718+3.141", 5.859f, Type.TypeFloat);
        runTest("2.718+2.718", 5.436f, Type.TypeFloat);
        runTest("3.141-3.141", 0.0f, Type.TypeFloat);
        runTest("3.141-2.718", 0.423f, Type.TypeFloat);
        runTest("2.718-3.141",-0.423f, Type.TypeFloat);
        runTest("2.718-2.718", 0.0f, Type.TypeFloat);
        runTest("3.141*3.141", 9.865881f, Type.TypeFloat);
        runTest("3.141*2.718", 8.537238f, Type.TypeFloat);
        runTest("2.718*3.141", 8.537238f, Type.TypeFloat);
        runTest("2.718*2.718", 7.387524f, Type.TypeFloat);
        runTest("3.141/3.141", 1.0f, Type.TypeFloat);
        runTest("3.141/2.718", 1.155629f, Type.TypeFloat);
        runTest("2.718/3.141", 0.865329f, Type.TypeFloat);
        runTest("2.718/2.718", 1.0f, Type.TypeFloat);
        runTest("2.718/0.0", Float.POSITIVE_INFINITY, Type.TypeFloat);
        runTest("-2.718/0.0", Float.NEGATIVE_INFINITY, Type.TypeFloat);
        runTest("2.718/-0.0", Float.NEGATIVE_INFINITY, Type.TypeFloat);
        runTest("-2.718/-0.0", Float.POSITIVE_INFINITY, Type.TypeFloat);
        runTest("3.141%3.141", 0.0f, Type.TypeFloat);
        runTest("3.141%2.718", 0.423f, Type.TypeFloat);
        runTest("3.141%11.0", 3.141f, Type.TypeFloat);
        runTest("2.718%3.141", 2.718f, Type.TypeFloat);
        runTest("2.718%-3.141", 2.718f, Type.TypeFloat);
        runTest("-2.718%3.141", -2.718f, Type.TypeFloat);
        runTest("-2.718%-3.141", -2.718f, Type.TypeFloat);
        runTest("2.718%2.718", 0.0f, Type.TypeFloat);
        runTest("3.141^3.141", 36.415844f, Type.TypeFloat);
        runTest("3.141^2.718", 22.440402f, Type.TypeFloat);
        runTest("3.141^0.0", 1.0f, Type.TypeFloat);
        runTest("2.718^3.141", 23.119451f, Type.TypeFloat);
        runTest("2.718^2.718", 15.145723f, Type.TypeFloat);
        runTest("2.718^1.0", 2.718f, Type.TypeFloat);
        runTest("1.0^2.718", 1.0f, Type.TypeFloat);
        runTest("0.0^2.718", 0.0f, Type.TypeFloat);
        runTest("0.0^0.0", 1.0f, Type.TypeFloat);
        runTest("3.141\\3.141", 1.439632f, Type.TypeFloat);
        runTest("3.141\\2.718", 1.523631f, Type.TypeFloat);
        runTest("2.718\\3.141", 1.374839f, Type.TypeFloat);
        runTest("2.718\\2.718", 1.444667f, Type.TypeFloat);
        runTest("3.141|3.141", 1.0f, Type.TypeFloat);
        runTest("3.141|2.718", 1.144659f, Type.TypeFloat);
        runTest("2.718|3.141", 0.873621f, Type.TypeFloat);
        runTest("2.718|2.718", 1.0f, Type.TypeFloat);

        runTest("10.0+ID", 10.0f, Type.TypeFloat);
        runTest("ID+10.0", 10.0f, Type.TypeFloat);
        runTest("10.0-ID", 10.0f, Type.TypeFloat);
        runTest("ID-10.0", 10.0f, Type.TypeFloat);
        runTest("10.0*ID", 10.0f, Type.TypeFloat);
        runTest("ID*10.0", 10.0f, Type.TypeFloat);
        runTest("10.0/ID", 10.0f, Type.TypeFloat);
        runTest("ID/10.0", 10.0f, Type.TypeFloat);
        runTest("10.0%ID", 10.0f, Type.TypeFloat);
        runTest("ID%10.0", 10.0f, Type.TypeFloat);
        runTest("10.0^ID", 10.0f, Type.TypeFloat);
        runTest("ID^10.0", 10.0f, Type.TypeFloat);
        runTest("10.0\\ID", 10.0f, Type.TypeFloat);
        runTest("ID\\10.0", 10.0f, Type.TypeFloat);
        runTest("10.0|ID", 10.0f, Type.TypeFloat);
        runTest("ID|10.0", 10.0f, Type.TypeFloat);

    }
    
    public void testBopString()
    {
        
        runTest("\"abc\"+\"def\"", "abcdef", Type.TypeString);
        runTest("\"\"+\"def\"", "def", Type.TypeString);
        runTest("\"abc\"+\"\"", "abc", Type.TypeString);
        runTest("\"\"+\"\"", "", Type.TypeString);
        runTest("\"abcb\"-\"b\"", "abc", Type.TypeString);
        runTest("\"abcb\"-\"abcb\"", "", Type.TypeString);
        runTest("\"abc\"-\"x\"", "abc", Type.TypeString);
        runTest("\"abcd\"-\"bc\"", "ad", Type.TypeString);
        runTest("\"abc\"*\"def\"", TypeIllegalException.class, null);
        runTest("\"abc\"/\"def\"", TypeIllegalException.class, null);
        runTest("\"abc\"%\"def\"", TypeIllegalException.class, null);
        runTest("\"abc\"^\"def\"", TypeIllegalException.class, null);
        runTest("\"abc\"\\\"def\"", TypeIllegalException.class, null);
        runTest("\"abc\"|\"def\"", TypeIllegalException.class, null);

        runTest("\"abc\"+ID", "abc", Type.TypeString);
        runTest("ID+\"abc\"", "abc", Type.TypeString);
        runTest("\"abc\"-ID", "abc", Type.TypeString);
        runTest("ID-\"abc\"", "abc", Type.TypeString);
        runTest("\"abc\"*ID", TypeIllegalException.class, null);
        runTest("ID*\"abc\"", TypeIllegalException.class, null);
        runTest("\"abc\"/ID", TypeIllegalException.class, null);
        runTest("ID/\"abc\"", TypeIllegalException.class, null);
        runTest("\"abc\"%ID", TypeIllegalException.class, null);
        runTest("ID%\"abc\"", TypeIllegalException.class, null);
        runTest("\"abc\"^ID", TypeIllegalException.class, null);
        runTest("ID^\"abc\"", TypeIllegalException.class, null);
        runTest("\"abc\"\\ID", TypeIllegalException.class, null);
        runTest("ID\\\"abc\"", TypeIllegalException.class, null);
        runTest("\"abc\"|ID", TypeIllegalException.class, null);
        runTest("ID|\"abc\"", TypeIllegalException.class, null);

    }
    
    public void testBopID()
    {
        
        runTest("ID+ID", null, Type.TypeID);
        runTest("ID-ID", null, Type.TypeID);
        runTest("ID*ID", null, Type.TypeID);
        runTest("ID/ID", null, Type.TypeID);
        runTest("ID%ID", null, Type.TypeID);
        runTest("ID^ID", null, Type.TypeID);
        runTest("ID\\ID", null, Type.TypeID);
        runTest("ID|ID", null, Type.TypeID);
        
    }
    
    public void testBracket()
    {

        runTest("(true)", true, Type.TypeBool);
        runTest("(false)", false, Type.TypeBool);
        runTest("(0)", 0, Type.TypeInt);
        runTest("(10)", 10, Type.TypeInt);
        runTest("(-10)", -10, Type.TypeInt);
        runTest("(0.0)", 0.0f, Type.TypeFloat);
        runTest("(10.0)", 10.0f, Type.TypeFloat);
        runTest("(-10.0)", -10.0f, Type.TypeFloat);
        runTest("(\"abc\")", "abc", Type.TypeString);
        runTest("(\"\")", "", Type.TypeString);

    }
    
    public void testPrecedenceAddMajor()
    {
        
        runTest("5.0+7.0+11.0", 23.0f, Type.TypeFloat);
        runTest("(5.0+7.0)+11.0", 23.0f, Type.TypeFloat);
        runTest("5.0+(7.0+11.0)", 23.0f, Type.TypeFloat);

        runTest("5.0+7.0-11.0", 1.0f, Type.TypeFloat);
        runTest("(5.0+7.0)-11.0", 1.0f, Type.TypeFloat);
        runTest("5.0+(7.0-11.0)", 1.0f, Type.TypeFloat);

        runTest("5.0-7.0+11.0", 9.0f, Type.TypeFloat);
        runTest("(5.0-7.0)+11.0", 9.0f, Type.TypeFloat);
        runTest("5.0-(7.0+11.0)", -13.0f, Type.TypeFloat);

        runTest("5.0+7.0*11.0", 82.0f, Type.TypeFloat);
        runTest("(5.0+7.0)*11.0", 132.0f, Type.TypeFloat);
        runTest("5.0+(7.0*11.0)", 82.0f, Type.TypeFloat);

        runTest("5.0*7.0+11.0", 46.0f, Type.TypeFloat);
        runTest("(5.0*7.0)+11.0", 46.0f, Type.TypeFloat);
        runTest("5.0*(7.0+11.0)", 90.0f, Type.TypeFloat);

        runTest("5.0+7.0/11.0", 5.636363f, Type.TypeFloat);
        runTest("(5.0+7.0)/11.0", 1.090909f, Type.TypeFloat);
        runTest("5.0+(7.0/11.0)", 5.636363f, Type.TypeFloat);
        
        runTest("5.0/7.0+11.0", 11.71428f, Type.TypeFloat);
        runTest("(5.0/7.0)+11.0", 11.71428f, Type.TypeFloat);
        runTest("5.0/(7.0+11.0)", 0.277777f, Type.TypeFloat);
        
        runTest("5.0+7.0%11.0", 12.0f, Type.TypeFloat);
        runTest("(5.0+7.0)%11.0", 1.0f, Type.TypeFloat);
        runTest("5.0+(7.0%11.0)", 12.0f, Type.TypeFloat);
        
        runTest("5.0%7.0+11.0", 16.0f, Type.TypeFloat);
        runTest("(5.0%7.0)+11.0", 16.0f, Type.TypeFloat);
        runTest("5.0%(7.0+11.0)", 5.0f, Type.TypeFloat);
        
        runTest("5.0+7.0^11.0", 1977326748.0f, Type.TypeFloat);
        runTest("(5.0+7.0)^11.0", 743008370688.0f, Type.TypeFloat);
        runTest("5.0+(7.0^11.0)", 1977326748.0f, Type.TypeFloat);
        
        runTest("5.0^7.0+11.0", 78136.0f, Type.TypeFloat);
        runTest("(5.0^7.0)+11.0", 78136.0f, Type.TypeFloat);
        runTest("5.0^(7.0+11.0)", 3814697265625.0f, Type.TypeFloat);
        
        runTest("5.0+7.0\\11.0", 6.193512f, Type.TypeFloat);
        runTest("(5.0+7.0)\\11.0", 1.253451f, Type.TypeFloat);
        runTest("5.0+(7.0\\11.0)", 6.193512f, Type.TypeFloat);
        
        runTest("5.0\\7.0+11.0", 12.25849f, Type.TypeFloat);
        runTest("(5.0\\7.0)+11.0", 12.25849f, Type.TypeFloat);
        runTest("5.0\\(7.0+11.0)", 1.093532f, Type.TypeFloat);
        
        runTest("5.0+7.0|11.0", 5.811507f, Type.TypeFloat);
        runTest("(5.0+7.0)|11.0", 1.036286f, Type.TypeFloat);
        runTest("5.0+(7.0|11.0)", 5.811507f, Type.TypeFloat);
        
        runTest("5.0|7.0+11.0", 11.82708f, Type.TypeFloat);
        runTest("(5.0|7.0)+11.0", 11.82708f, Type.TypeFloat);
        runTest("5.0|(7.0+11.0)", 0.556827f, Type.TypeFloat);

    }
    
    public void testPrecedenceSubMajor()
    {
        
        runTest("5.0-7.0-11.0", -13.0f, Type.TypeFloat);
        runTest("(5.0-7.0)-11.0", -13.0f, Type.TypeFloat);
        runTest("5.0-(7.0-11.0)", 9.0f, Type.TypeFloat);
        
        runTest("5.0-7.0*11.0", -72.0f, Type.TypeFloat);
        runTest("(5.0-7.0)*11.0", -22.0f, Type.TypeFloat);
        runTest("5.0-(7.0*11.0)", -72.0f, Type.TypeFloat);
        
        runTest("5.0*7.0-11.0", 24.0f, Type.TypeFloat);
        runTest("(5.0*7.0)-11.0", 24.0f, Type.TypeFloat);
        runTest("5.0*(7.0-11.0)", -20.0f, Type.TypeFloat);
        
        runTest("5.0-7.0/11.0", 4.363636f, Type.TypeFloat);
        runTest("(5.0-7.0)/11.0",-0.181818f, Type.TypeFloat);
        runTest("5.0-(7.0/11.0)", 4.363636f, Type.TypeFloat);
        
        runTest("5.0/7.0-11.0", -10.28571f, Type.TypeFloat);
        runTest("(5.0/7.0)-11.0", -10.28571f, Type.TypeFloat);
        runTest("5.0/(7.0-11.0)", -1.25f, Type.TypeFloat);
        
        runTest("5.0-7.0%11.0", -2.0f, Type.TypeFloat);
        runTest("(5.0-7.0)%11.0", -2.0f, Type.TypeFloat);
        runTest("5.0-(7.0%11.0)", -2.0f, Type.TypeFloat);
        
        runTest("5.0%7.0-11.0", -6.0f, Type.TypeFloat);
        runTest("(5.0%7.0)-11.0", -6.0f, Type.TypeFloat);
        runTest("5.0%(7.0-11.0)", 1.0f, Type.TypeFloat);
        
        runTest("5.0-7.0^11.0", -1977326738.0f, Type.TypeFloat);
        runTest("(5.0-7.0)^11.0", -2048.0f, Type.TypeFloat);
        runTest("5.0-(7.0^11.0)", -1977326738.0f, Type.TypeFloat);
        
        runTest("5.0^7.0-11.0", 78114.0f, Type.TypeFloat);
        runTest("(5.0^7.0)-11.0", 78114.0f, Type.TypeFloat);
        runTest("5.0^(7.0-11.0)", 0.0016f, Type.TypeFloat);
        
        runTest("5.0-7.0\\11.0", 3.806487f, Type.TypeFloat);
        runTest("(5.0-7.0)\\11.0", Float.NaN, Type.TypeFloat);
        runTest("5.0-(7.0\\11.0)", 3.806487f, Type.TypeFloat);
        
        runTest("5.0\\7.0-11.0", -9.741501f, Type.TypeFloat);
        runTest("(5.0\\7.0)-11.0", -9.741501f, Type.TypeFloat);
        runTest("5.0\\(7.0-11.0)", 0.668740f, Type.TypeFloat);
        
        runTest("5.0-7.0|11.0", 4.188492f, Type.TypeFloat);
        runTest("(5.0-7.0)|11.0", Float.NaN, Type.TypeFloat);
        runTest("5.0-(7.0|11.0)", 4.188492f, Type.TypeFloat);
        
        runTest("5.0|7.0-11.0", -10.17291f, Type.TypeFloat);
        runTest("(5.0|7.0)-11.0", -10.17291f, Type.TypeFloat);
        runTest("5.0|(7.0-11.0)", Float.NaN, Type.TypeFloat);

    }
    
    public void testPrecedenceMulMajor()
    {
        
        runTest("5.0*7.0*11.0", 385.0f, Type.TypeFloat);
        runTest("(5.0*7.0)*11.0", 385.0f, Type.TypeFloat);
        runTest("5.0*(7.0*11.0)", 385.0f, Type.TypeFloat);
        
        runTest("5.0*7.0/11.0", 3.181818f, Type.TypeFloat);
        runTest("(5.0*7.0)/11.0", 3.181818f, Type.TypeFloat);
        runTest("5.0*(7.0/11.0)", 3.181818f, Type.TypeFloat);
        
        runTest("5.0/7.0*11.0", 7.857142f, Type.TypeFloat);
        runTest("(5.0/7.0)*11.0", 7.857142f, Type.TypeFloat);
        runTest("5.0/(7.0*11.0)", 0.064935f, Type.TypeFloat);
        
        runTest("5.0*7.0%11.0", 2.0f, Type.TypeFloat);
        runTest("(5.0*7.0)%11.0", 2.0f, Type.TypeFloat);
        runTest("5.0*(7.0%11.0)", 35.0f, Type.TypeFloat);
        
        runTest("5.0%7.0*11.0", 5.0f, Type.TypeFloat);
        runTest("(5.0%7.0)*11.0", 55.0f, Type.TypeFloat);
        runTest("5.0%(7.0*11.0)", 5.0f, Type.TypeFloat);
        
        runTest("5.0*7.0^11.0", 9886633715.0f, Type.TypeFloat);
        runTest("(5.0*7.0)^11.0", 96549157373046900.0f, Type.TypeFloat);
        runTest("5.0*(7.0^11.0)", 9886633715.0f, Type.TypeFloat);
        
        runTest("5.0^7.0*11.0", 859375.0f, Type.TypeFloat);
        runTest("(5.0^7.0)*11.0", 859375.0f, Type.TypeFloat);
        runTest("5.0^(7.0*3.0)", 476837158203125.0f, Type.TypeFloat);
        
        runTest("5.0*7.0\\11.0", 5.967564f, Type.TypeFloat);
        runTest("(5.0*7.0)\\11.0", 1.38156f, Type.TypeFloat);
        runTest("5.0*(7.0\\11.0)", 5.967564f, Type.TypeFloat);
        
        runTest("5.0\\7.0*11.0", 13.84348f, Type.TypeFloat);
        runTest("(5.0\\7.0)*11.0", 13.84348f, Type.TypeFloat);
        runTest("5.0\\(7.0*11.0)", 1.021121f, Type.TypeFloat);
        
        runTest("5.0*7.0|11.0", 4.057537f, Type.TypeFloat);
        runTest("(5.0*7.0)|11.0", 1.482695f, Type.TypeFloat);
        runTest("5.0*(7.0|11.0)", 4.057537f, Type.TypeFloat);
        
        runTest("5.0|7.0*11.0", 9.097962f, Type.TypeFloat);
        runTest("(5.0|7.0)*11.0", 9.097962f, Type.TypeFloat);
        runTest("5.0|(7.0*11.0)", 0.370513f, Type.TypeFloat);

    }
    
    public void testPrecedenceDivMajor()
    {

        runTest("5.0/7.0/11.0", 0.064935f, Type.TypeFloat);
        runTest("(5.0/7.0)/11.0", 0.064935f, Type.TypeFloat);
        runTest("5.0/(7.0/11.0)", 7.857142f, Type.TypeFloat);
        
        runTest("5.0/7.0%11.0", 0.714285f, Type.TypeFloat);
        runTest("(5.0/7.0)%11.0", 0.714285f, Type.TypeFloat);
        runTest("5.0/(7.0%11.0)", 0.714285f, Type.TypeFloat);
        
        runTest("5.0%7.0/11.0", 0.545454f, Type.TypeFloat);
        runTest("(5.0%7.0)/11.0", 0.454545f, Type.TypeFloat);
        runTest("5.0%(7.0/11.0)", 0.545454f, Type.TypeFloat);
        
        runTest("5.0/7.0^11.0", 0.0f, Type.TypeFloat);
        runTest("(5.0/7.0)^11.0", 0.024694f, Type.TypeFloat);
        runTest("5.0/(7.0^11.0)", 0.0f, Type.TypeFloat);
        
        runTest("5.0^7.0/11.0", 7102.273f, Type.TypeFloat);
        runTest("(5.0^7.0)/11.0", 7102.273f, Type.TypeFloat);
        runTest("5.0^(7.0/11.0)", 2.784832f, Type.TypeFloat);
        
        runTest("5.0/7.0\\11.0", 4.189313f, Type.TypeFloat);
        runTest("(5.0/7.0)\\11.0", 0.969874f, Type.TypeFloat);
        runTest("5.0/(7.0\\11.0)", 4.189313f, Type.TypeFloat);
        
        runTest("5.0\\7.0/11.0", 0.114408f, Type.TypeFloat);
        runTest("(5.0\\7.0)/11.0", 0.114408f, Type.TypeFloat);
        runTest("5.0\\(7.0/11.0)", 12.54242f, Type.TypeFloat);
        
        runTest("5.0/7.0|11.0", 6.161372f, Type.TypeFloat);
        runTest("(5.0/7.0)|11.0", -0.140319f, Type.TypeFloat);
        runTest("5.0/(7.0|11.0)", 6.161372f, Type.TypeFloat);
        
        runTest("5.0|7.0/11.0", 0.075189f, Type.TypeFloat);
        runTest("(5.0|7.0)/11.0", 0.075189f, Type.TypeFloat);
        runTest("5.0|(7.0/11.0)", -3.56082f, Type.TypeFloat);

    }
    
    public void testPrecedenceModMajor()
    {
        
        runTest("5.0%7.0%11.0", 5.0f, Type.TypeFloat);
        runTest("(5.0%7.0)%11.0", 5.0f, Type.TypeFloat);
        runTest("5.0%(7.0%11.0)", 5.0f, Type.TypeFloat);
        
        runTest("5.0%7.0^11.0", 5.0f, Type.TypeFloat);
        runTest("(5.0%7.0)^11.0", 48828125.0f, Type.TypeFloat);
        runTest("5.0%(7.0^11.0)", 5.0f, Type.TypeFloat);
        
        runTest("5.0^7.0%11.0", 3.0f, Type.TypeFloat);
        runTest("(5.0^7.0)%11.0", 3.0f, Type.TypeFloat);
        runTest("5.0^(7.0%11.0)", 78125.0f, Type.TypeFloat);
        
        runTest("5.0%7.0\\11.0", 0.225948f, Type.TypeFloat);
        runTest("(5.0%7.0)\\11.0", 1.157557f, Type.TypeFloat);
        runTest("5.0%(7.0\\11.0)", 0.225948f, Type.TypeFloat);
        
        runTest("5.0\\7.0%11.0", 1.258498f, Type.TypeFloat);
        runTest("(5.0\\7.0)%11.0", 1.258498f, Type.TypeFloat);
        runTest("5.0\\(7.0%11.0)", 1.258498f, Type.TypeFloat);
        
        runTest("5.0%7.0|11.0", 0.130954f, Type.TypeFloat);
        runTest("(5.0%7.0)|11.0", 0.671187f, Type.TypeFloat);
        runTest("5.0%(7.0|11.0)", 0.130954f, Type.TypeFloat);
        
        runTest("5.0|7.0%11.0", 0.827087f, Type.TypeFloat);
        runTest("(5.0|7.0)%11.0", 0.827087f, Type.TypeFloat);
        runTest("5.0|(7.0%11.0)", 0.827087f, Type.TypeFloat);

    }
    
    public void testPrecedencePowMajor()
    {
        
        runTest("5.0^7.0^2.0", 6103515625f, Type.TypeFloat);
        runTest("(5.0^7.0)^2.0", 6103515625f, Type.TypeFloat);
        runTest("5.0^(7.0^2.0)", 17763568394002500000000000000000000f, Type.TypeFloat);
        
        runTest("5.0^7.0\\11.0", 2.784832f, Type.TypeFloat);
        runTest("(5.0^7.0)\\11.0", 2.784832f, Type.TypeFloat);
        runTest("5.0^(7.0\\11.0)", 6.826996f, Type.TypeFloat);
        
        runTest("5.0\\7.0^11.0", 12.54242f, Type.TypeFloat);
        runTest("(5.0\\7.0)^11.0", 12.54242f, Type.TypeFloat);
        runTest("5.0\\(7.0^11.0)", 1.0f, Type.TypeFloat);
        
        runTest("5.0^7.0|11.0", 4.698314f, Type.TypeFloat);
        runTest("(5.0^7.0)|11.0", 4.698314f, Type.TypeFloat);
        runTest("5.0^(7.0|11.0)", 3.69164f, Type.TypeFloat);
        
        runTest("5.0|7.0^11.0", 0.075189f, Type.TypeFloat);
        runTest("(5.0|7.0)^11.0", 0.123898f, Type.TypeFloat);
        runTest("5.0|(7.0^11.0)", 0.075189f, Type.TypeFloat);

    }
    
    public void testPrecedenceRootMajor()
    {
        
        runTest("5.0\\7.0\\2.0", 1.121828f, Type.TypeFloat);
        runTest("(5.0\\7.0)\\2.0", 1.121828f, Type.TypeFloat);
        runTest("5.0\\(7.0\\2.0)", 1.837324f, Type.TypeFloat);
        
        runTest("5.0\\7.0|11.0", 0.095883f, Type.TypeFloat);
        runTest("(5.0\\7.0)|11.0", 0.095883f, Type.TypeFloat);
        runTest("5.0\\(7.0|11.0)", 7.266459f, Type.TypeFloat);

        runTest("5.0|7.0\\11.0", 9.097962f, Type.TypeFloat);
        runTest("(5.0|7.0)\\11.0", 0.982889f, Type.TypeFloat);
        runTest("5.0|(7.0\\11.0)", 9.097962f, Type.TypeFloat);

    }
    
    public void testPrecedenceLogMajor()
    {
        
        runTest("5.0|7.0|2.0", -0.273888f, Type.TypeFloat);
        runTest("(5.0|7.0)|2.0", -0.273888f, Type.TypeFloat);
        runTest("5.0|(7.0|2.0)", 1.559166f, Type.TypeFloat);

    }
    
    public void testTypeMismatch()
    {
        
        runTest("true+0", TypeMismatchException.class, null);
        runTest("true+0.0", TypeMismatchException.class, null);
        runTest("true+\"0\"", TypeMismatchException.class, null);
        runTest("true*0", TypeMismatchException.class, null);
        runTest("true*0.0", TypeMismatchException.class, null);
        runTest("true^0", TypeMismatchException.class, null);
        runTest("true^0.0", TypeMismatchException.class, null);
        runTest("true==0", TypeMismatchException.class, null);
        runTest("true==0.0", TypeMismatchException.class, null);
        runTest("true==\"0\"", TypeMismatchException.class, null);
        runTest("true-=0", TypeMismatchException.class, null);
        runTest("true-=0.0", TypeMismatchException.class, null);
        runTest("true-=\"0\"", TypeMismatchException.class, null);

        runTest("0+true", TypeMismatchException.class, null);
        runTest("0+0.0", TypeMismatchException.class, null);
        runTest("0+\"0\"", TypeMismatchException.class, null);
        runTest("0-0.0", TypeMismatchException.class, null);
        runTest("0-\"0\"", TypeMismatchException.class, null);
        runTest("0*true", TypeMismatchException.class, null);
        runTest("0*0.0", TypeMismatchException.class, null);
        runTest("0/0.0", TypeMismatchException.class, null);
        runTest("0%0.0", TypeMismatchException.class, null);
        runTest("0^true", TypeMismatchException.class, null);
        runTest("0^0.0", TypeMismatchException.class, null);
        runTest("0\\0.0", TypeMismatchException.class, null);
        runTest("0|0.0", TypeMismatchException.class, null);
        runTest("0==true", TypeMismatchException.class, null);
        runTest("0==0.0", TypeMismatchException.class, null);
        runTest("0==\"0\"", TypeMismatchException.class, null);
        runTest("0-=true", TypeMismatchException.class, null);
        runTest("0-=0.0", TypeMismatchException.class, null);
        runTest("0-=\"0\"", TypeMismatchException.class, null);
        runTest("0<0.0", TypeMismatchException.class, null);
        runTest("0<=\"0\"", TypeMismatchException.class, null);
        runTest("0>0.0", TypeMismatchException.class, null);
        runTest("0>=\"0\"", TypeMismatchException.class, null);

        runTest("0.0+true", TypeMismatchException.class, null);
        runTest("0.0+0", TypeMismatchException.class, null);
        runTest("0.0+\"0\"", TypeMismatchException.class, null);
        runTest("0.0-0", TypeMismatchException.class, null);
        runTest("0.0-\"0\"", TypeMismatchException.class, null);
        runTest("0.0*true", TypeMismatchException.class, null);
        runTest("0.0*0", TypeMismatchException.class, null);
        runTest("0.0/0", TypeMismatchException.class, null);
        runTest("0.0%0", TypeMismatchException.class, null);
        runTest("0.0^true", TypeMismatchException.class, null);
        runTest("0.0^0", TypeMismatchException.class, null);
        runTest("0.0\\0", TypeMismatchException.class, null);
        runTest("0.0|0", TypeMismatchException.class, null);
        runTest("0.0==true", TypeMismatchException.class, null);
        runTest("0.0==0", TypeMismatchException.class, null);
        runTest("0.0==\"0\"", TypeMismatchException.class, null);
        runTest("0.0-=true", TypeMismatchException.class, null);
        runTest("0.0-=0", TypeMismatchException.class, null);
        runTest("0.0-=\"0\"", TypeMismatchException.class, null);
        runTest("0.0<0", TypeMismatchException.class, null);
        runTest("0.0<=\"0\"", TypeMismatchException.class, null);
        runTest("0.0>0", TypeMismatchException.class, null);
        runTest("0.0>=\"0\"", TypeMismatchException.class, null);

        runTest("\"0\"+true", TypeMismatchException.class, null);
        runTest("\"0\"+0", TypeMismatchException.class, null);
        runTest("\"0\"+0.0", TypeMismatchException.class, null);
        runTest("\"0\"-0", TypeMismatchException.class, null);
        runTest("\"0\"-0.0", TypeMismatchException.class, null);
        runTest("\"0\"==true", TypeMismatchException.class, null);
        runTest("\"0\"==0", TypeMismatchException.class, null);
        runTest("\"0\"==0.0", TypeMismatchException.class, null);
        runTest("\"0\"-=true", TypeMismatchException.class, null);
        runTest("\"0\"-=0", TypeMismatchException.class, null);
        runTest("\"0\"-=0.0", TypeMismatchException.class, null);
        runTest("\"0\"<0", TypeMismatchException.class, null);
        runTest("\"0\"<=0.0", TypeMismatchException.class, null);
        runTest("\"0\">0", TypeMismatchException.class, null);
        runTest("\"0\">=0.0", TypeMismatchException.class, null);

    }

    public void testCopBool()
    {
        
        runTest("true==true", true, Type.TypeBool);
        runTest("true==false", false, Type.TypeBool);
        runTest("false==true", false, Type.TypeBool);
        runTest("false==false", true, Type.TypeBool);
        runTest("true-=true", false, Type.TypeBool);
        runTest("true-=false", true, Type.TypeBool);
        runTest("false-=true", true, Type.TypeBool);
        runTest("false-=false", false, Type.TypeBool);
        runTest("true<true", TypeIllegalException.class, null);
        runTest("true<false", TypeIllegalException.class, null);
        runTest("false<true", TypeIllegalException.class, null);
        runTest("false<false", TypeIllegalException.class, null);
        runTest("true>true", TypeIllegalException.class, null);
        runTest("true>false", TypeIllegalException.class, null);
        runTest("false>true", TypeIllegalException.class, null);
        runTest("false>false", TypeIllegalException.class, null);
        runTest("true<=true", TypeIllegalException.class, null);
        runTest("true<=false", TypeIllegalException.class, null);
        runTest("false<=true", TypeIllegalException.class, null);
        runTest("false<=false", TypeIllegalException.class, null);
        runTest("true>=true", TypeIllegalException.class, null);
        runTest("true>=false", TypeIllegalException.class, null);
        runTest("false>=true", TypeIllegalException.class, null);
        runTest("false>=false", TypeIllegalException.class, null);
        
        runTest("true==ID", null, Type.TypeBool);
        runTest("ID==true", null, Type.TypeBool);
        runTest("false==ID", null, Type.TypeBool);
        runTest("ID==false", null, Type.TypeBool);
        runTest("true-=ID", null, Type.TypeBool);
        runTest("ID-=true", null, Type.TypeBool);
        runTest("false-=ID", null, Type.TypeBool);
        runTest("ID-=false", null, Type.TypeBool);
        runTest("true<ID", TypeIllegalException.class, null);
        runTest("ID<true", TypeIllegalException.class, null);
        runTest("false<ID", TypeIllegalException.class, null);
        runTest("ID<false", TypeIllegalException.class, null);
        runTest("true>ID", TypeIllegalException.class, null);
        runTest("ID>true", TypeIllegalException.class, null);
        runTest("false>ID", TypeIllegalException.class, null);
        runTest("ID>false", TypeIllegalException.class, null);
        runTest("true<=ID", TypeIllegalException.class, null);
        runTest("ID<=true", TypeIllegalException.class, null);
        runTest("false<=ID", TypeIllegalException.class, null);
        runTest("ID<=false", TypeIllegalException.class, null);
        runTest("true>=ID", TypeIllegalException.class, null);
        runTest("ID>=true", TypeIllegalException.class, null);
        runTest("false>=ID", TypeIllegalException.class, null);
        runTest("ID>=false", TypeIllegalException.class, null);

    }
    
    public void testCopInt()
    {
        
        runTest("50==50", true, Type.TypeBool);
        runTest("50==10", false, Type.TypeBool);
        runTest("10==50", false, Type.TypeBool);
        runTest("10==10", true, Type.TypeBool);
        runTest("50-=50", false, Type.TypeBool);
        runTest("50-=10", true, Type.TypeBool);
        runTest("10-=50", true, Type.TypeBool);
        runTest("10-=10", false, Type.TypeBool);
        runTest("50<50", false, Type.TypeBool);
        runTest("50<10", false, Type.TypeBool);
        runTest("10<50", true, Type.TypeBool);
        runTest("10<10", false, Type.TypeBool);
        runTest("50>50", false, Type.TypeBool);
        runTest("50>10", true, Type.TypeBool);
        runTest("10>50", false, Type.TypeBool);
        runTest("10>10", false, Type.TypeBool);
        runTest("50<=50", true, Type.TypeBool);
        runTest("50<=10", false, Type.TypeBool);
        runTest("10<=50", true, Type.TypeBool);
        runTest("10<=10", true, Type.TypeBool);
        runTest("50>=50", true, Type.TypeBool);
        runTest("50>=10", true, Type.TypeBool);
        runTest("10>=50", false, Type.TypeBool);
        runTest("10>=10", true, Type.TypeBool);

        runTest("10==ID", null, Type.TypeBool);
        runTest("ID==10", null, Type.TypeBool);
        runTest("10-=ID", null, Type.TypeBool);
        runTest("ID-=10", null, Type.TypeBool);
        runTest("10<ID", null, Type.TypeBool);
        runTest("ID<10", null, Type.TypeBool);
        runTest("10>ID", null, Type.TypeBool);
        runTest("ID>10", null, Type.TypeBool);
        runTest("10<=ID", null, Type.TypeBool);
        runTest("ID<=10", null, Type.TypeBool);
        runTest("10>=ID", null, Type.TypeBool);
        runTest("ID>=10", null, Type.TypeBool);

    }
    
    public void testCopFloat()
    {
        
        runTest("3.141==3.141", true, Type.TypeBool);
        runTest("3.141==2.718", false, Type.TypeBool);
        runTest("2.718==3.141", false, Type.TypeBool);
        runTest("2.718==2.718", true, Type.TypeBool);
        runTest("3.141-=3.141", false, Type.TypeBool);
        runTest("3.141-=2.718", true, Type.TypeBool);
        runTest("2.718-=3.141", true, Type.TypeBool);
        runTest("2.718-=2.718", false, Type.TypeBool);
        runTest("3.141<3.141", false, Type.TypeBool);
        runTest("3.141<2.718", false, Type.TypeBool);
        runTest("2.718<3.141", true, Type.TypeBool);
        runTest("2.718<2.718", false, Type.TypeBool);
        runTest("3.141>3.141", false, Type.TypeBool);
        runTest("3.141>2.718", true, Type.TypeBool);
        runTest("2.718>3.141", false, Type.TypeBool);
        runTest("2.718>2.718", false, Type.TypeBool);
        runTest("3.141<=3.141", true, Type.TypeBool);
        runTest("3.141<=2.718", false, Type.TypeBool);
        runTest("2.718<=3.141", true, Type.TypeBool);
        runTest("2.718<=2.718", true, Type.TypeBool);
        runTest("3.141>=3.141", true, Type.TypeBool);
        runTest("3.141>=2.718", true, Type.TypeBool);
        runTest("2.718>=3.141", false, Type.TypeBool);
        runTest("2.718>=2.718", true, Type.TypeBool);

        runTest("10.0==ID", null, Type.TypeBool);
        runTest("ID==10.0", null, Type.TypeBool);
        runTest("10.0-=ID", null, Type.TypeBool);
        runTest("ID-=10.0", null, Type.TypeBool);
        runTest("10.0<ID", null, Type.TypeBool);
        runTest("ID<10.0", null, Type.TypeBool);
        runTest("10.0>ID", null, Type.TypeBool);
        runTest("ID>10.0", null, Type.TypeBool);
        runTest("10.0<=ID", null, Type.TypeBool);
        runTest("ID<=10.0", null, Type.TypeBool);
        runTest("10.0>=ID", null, Type.TypeBool);
        runTest("ID>=10.0", null, Type.TypeBool);

    }
    
    public void testCopString()
    {
        
        runTest("\"abc\"==\"abc\"", true, Type.TypeBool);
        runTest("\"abc\"==\"def\"", false, Type.TypeBool);
        runTest("\"\"==\"def\"", false, Type.TypeBool);
        runTest("\"abc\"==\"\"", false, Type.TypeBool);
        runTest("\"\"==\"\"", true, Type.TypeBool);
        runTest("\"abc\"-=\"abc\"", false, Type.TypeBool);
        runTest("\"abc\"-=\"def\"", true, Type.TypeBool);
        runTest("\"\"-=\"def\"", true, Type.TypeBool);
        runTest("\"abc\"-=\"\"", true, Type.TypeBool);
        runTest("\"\"-=\"\"", false, Type.TypeBool);
        runTest("\"abc\"<\"abc\"", false, Type.TypeBool);
        runTest("\"abc\"<\"def\"", true, Type.TypeBool);
        runTest("\"abc\">\"abc\"", false, Type.TypeBool);
        runTest("\"abc\">\"def\"", false, Type.TypeBool);
        runTest("\"abc\"<=\"abc\"", true, Type.TypeBool);
        runTest("\"abc\"<=\"def\"", true, Type.TypeBool);
        runTest("\"abc\">=\"abc\"", true, Type.TypeBool);
        runTest("\"abc\">=\"def\"", false, Type.TypeBool);

        runTest("\"abc\"==ID", null, Type.TypeBool);
        runTest("ID==\"abc\"", null, Type.TypeBool);
        runTest("\"abc\"-=ID", null, Type.TypeBool);
        runTest("ID-=\"abc\"", null, Type.TypeBool);
        runTest("\"abc\"<ID", null, Type.TypeBool);
        runTest("ID<\"abc\"", null, Type.TypeBool);
        runTest("\"abc\">ID", null, Type.TypeBool);
        runTest("ID>\"abc\"", null, Type.TypeBool);
        runTest("\"abc\"<=ID", null, Type.TypeBool);
        runTest("ID<=\"abc\"", null, Type.TypeBool);
        runTest("\"abc\">=ID", null, Type.TypeBool);
        runTest("ID>=\"abc\"", null, Type.TypeBool);

    }
    
    public void testCopID()
    {
        
        runTest("ID==ID", null, Type.TypeID);
        runTest("ID-=ID", null, Type.TypeID);
        runTest("ID<ID", null, Type.TypeID);
        runTest("ID>ID", null, Type.TypeID);
        runTest("ID<=ID", null, Type.TypeID);
        runTest("ID>=ID", null, Type.TypeID);
        
    }

    public void testVariables()
    {
        
        runTest("a:int=2", 2, Type.TypeInt);
        runTest("a:int=2;a", 2, Type.TypeInt);
        runTest("a=2;a:int=a", 2, Type.TypeInt);

        runTest("a:bool=a;a=0", TypeMismatchException.class, null);
        runTest("a:bool=a;a=0.0", TypeMismatchException.class, null);
        runTest("a:bool=a;a=\"0\"", TypeMismatchException.class, null);
        runTest("a:int=a;a=true", TypeMismatchException.class, null);
        runTest("a:int=a;a=0.0", TypeMismatchException.class, null);
        runTest("a:int=a;a=\"0\"", TypeMismatchException.class, null);
        runTest("a:float=a;a=true", TypeMismatchException.class, null);
        runTest("a:float=a;a=0", TypeMismatchException.class, null);
        runTest("a:float=a;a=\"0\"", TypeMismatchException.class, null);
        runTest("a:string=a;a=true", TypeMismatchException.class, null);
        runTest("a:string=a;a=0", TypeMismatchException.class, null);
        runTest("a:string=a;a=0.0", TypeMismatchException.class, null);

        runTest("a:bool=true", true, Type.TypeBool);
        runTest("a:bool=1", true, Type.TypeBool);
        runTest("a:bool=1.0", true, Type.TypeBool);
        runTest("a:bool=\"true\"", true, Type.TypeBool);
        runTest("a:int=true", 1, Type.TypeInt);
        runTest("a:int=1", 1, Type.TypeInt);
        runTest("a:int=1.0", 1, Type.TypeInt);
        runTest("a:int=\"1\"", 1, Type.TypeInt);
        runTest("a:float=true", 1.0f, Type.TypeFloat);
        runTest("a:float=1", 1.0f, Type.TypeFloat);
        runTest("a:float=1.0", 1.0f, Type.TypeFloat);
        runTest("a:float=\"1\"", 1.0f, Type.TypeFloat);
        runTest("a:string=true", "true", Type.TypeString);
        runTest("a:string=0", "0", Type.TypeString);
        runTest("a:string=0.0", "0.0", Type.TypeString);
        runTest("a:string=\"hi\"", "hi", Type.TypeString);

        runTest("a:int=10;if(true){a}", 10, Type.TypeInt);
        runTest("a:int=10;if(true){a=5};a", 5, Type.TypeInt);
        runTest("a:int=10;if(true){a:int=5};a", 10, Type.TypeInt);

        runTest("a:int=5;b:int=3;a=b;a", 3, Type.TypeInt);
        
        runTest("a:int=5;a:int=3", TypeExistsException.class, null);
        runTest("a:int=5;a:float=3", TypeExistsException.class, null);
        
    }

    public void testFunctions()
    {
        
        runTest("a:int()={5}", null, Type.TypeID);
        runTest("a:int()={5};a:int()={3}", TypeExistsException.class, null);
        runTest("a:int()={5};a:int=3", TypeExistsException.class, null);
        runTest("a:int=3;a:int()={5}", TypeExistsException.class, null);
        runTest("a:int()={5};a()", 5, Type.TypeInt);
        runTest("a:int()={5};a:int=4", TypeExistsException.class, null);
        runTest("a:int=4;a:int()={5}", TypeExistsException.class, null);
        runTest("a:int=4;b:int()={a}", null, Type.TypeInt);
        runTest("a:int=4;b:int()={a};b()", 4, Type.TypeInt);
        runTest("a:int(a:int, b:int)={a+b};a(1, 2)", 3, Type.TypeInt);
        runTest("a:int(a:int)={if(a>0){~~~a(a-1)+1}else{0}};a(5)", 5, Type.TypeInt);
        runTest("a:int(a:int)={a};a", TypeMismatchException.class, null);
        runTest("a:int(a:int)={a};a()", TypeMismatchException.class, null);
        runTest("a:int(a:int)={a};a(1, 2)", TypeMismatchException.class, null);
        runTest("a:int()={1};a(1)", TypeMismatchException.class, null);
        runTest("a:int()={1};a", TypeMismatchException.class, null);
        runTest("a:in()={1};a", TypeUnknownException.class, null);
        runTest("a:int(a:in)={1};a", TypeUnknownException.class, null);
        runTest("a:int()={a()};a()", StackOverflowError.class, null);
        
    }
    
    public void testScope()
    {
        
        runTest("a:int=4;b:int(a:int)={a:int=2;a};b(3)", 2, Type.TypeInt);
        runTest("a:int=4;b:int(a:int)={a:int=2;~a};b(3)", 3, Type.TypeInt);
        runTest("a:int=4;b:int(a:int)={a:int=2;~~a};b(3)", 4, Type.TypeInt);
        runTest("a:int=5;if(true){a:int=4;~a}", 5, Type.TypeInt);
        runTest("a:int=5;{a:float=1.0;a}", 1.0f, Type.TypeFloat);
        runTest("a:int=5;{a:float=1.0;a};a", 5, Type.TypeInt);

    }

    private static void runTest
    (   String program,
        Object resultValue,
        Type resultType
    ){  RealParserThread asyncParser = new RealParserThread();
        asyncParser.startParser(program, resultValue, resultType);
    }

    static class RealParserThread implements Runnable
    {

        public void startParser
        (   String program,
            Object resultValue,
            Type resultType
        ){  int wait = 10;

            _program = program;
            _resultValue = resultValue;
            _resultType = resultType;

            Thread thread = new Thread(this);
            thread.setPriority(Thread.MIN_PRIORITY);
            thread.start();

            wait = 20;
            while(wait > 0 && thread.isAlive() == true)
            {   try { Thread.sleep(10); }
                catch(InterruptedException e) { e.printStackTrace(); }
                wait--;
            }
            
            synchronized(_sync)
            {   if(_terminator != null)
                    _terminator.terminate();
            }

            wait = 20;
            while(wait > 0 && thread.isAlive() == true)
            {   try { Thread.sleep(10); }
                catch(InterruptedException e) { e.printStackTrace(); }
                wait--;
            }

            synchronized(_sync)
            {   if(_terminator != null)
                    System.err.println("Failed to release");
            }

        }

        public void run()
        {

            RealParser realParser = new RealParser();
            try
            {
                AstNode astNode = realParser.parse(_program);
                StructureVisitor structureVisitor = new StructureVisitor();
                TypeVisitor typeVisitor = new TypeVisitor();
                InterpretVisitor interpreterVisitor = new InterpretVisitor();
                DumpVisitor dumpVisitor = new DumpVisitor(new PrintStream(new OutputStream() {
                    @Override
                    public void write(int arg0) throws IOException { }
                }), astNode);
                _terminator = interpreterVisitor;
                astNode.applyVisitor(structureVisitor);
                astNode.applyVisitor(typeVisitor);
                astNode.applyVisitor(interpreterVisitor);
                astNode.applyVisitor(dumpVisitor);

                List<InterpreterResult> results = interpreterVisitor.getResults();
                
                InterpreterResult result = results.get(results.size() - 1);
                
                if(_resultValue == null && result.isId() == false
                || _resultType.equals(result.getType()) == false
                || _resultValue != null
                && areEqual(_resultValue, result.getValue()) == false)
                    throw new Exception("Unexpected result: " + result.toString());

            }
            catch(Throwable e)
            {   if(_resultValue != null && _resultValue.equals(e.getClass()))
                    ;
                else
                {   System.err.println("[" + _program + "], [" + _resultValue + "], [" + _resultType + "]");
                    e.printStackTrace();
                }
            }
            synchronized(_sync) { _terminator = null; }
            
        }

        private boolean areEqual(Object a, Object b) throws Exception
        {

            if(a instanceof Double)
                throw new Exception("Expected Float, Received Double: " + a);
            
            if(a instanceof Float && b instanceof Float)
            {   float af = (Float)a;
                float bf = (Float)b;
                return
                    Float.isNaN(af) && Float.isNaN(bf)
                 || Float.isInfinite(af) && Float.isInfinite(bf)
                 || af == bf
                 || af >= bf - 0.00001f && af < bf + 0.00001f;
            }
            else
                return a.equals(b);
            
        }
        
        private String _program;
        private Object _resultValue;
        private Type _resultType;
        private AstVisitorTerminator _terminator;
        private Object _sync = new Object();

    }

}
