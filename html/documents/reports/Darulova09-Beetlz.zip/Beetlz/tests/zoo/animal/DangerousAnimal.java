package zoo.animal;
  

/**
 * @author evka
 *
 */
public interface DangerousAnimal {

}
