package zoo.animal;

public @interface Info {  
    String name();
    String birthDate();
    }
