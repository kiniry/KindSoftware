package zoo_faults.animal;
  

/**
 * @author evka
 *
 */
public interface DangerousAnimal {

}
