package zoo_faults.animal;

public @interface Info {  
    String name();
    String birthDate();
    }
