/**
 * 
 */
package zoo_faults.personnels;

import java.io.Serializable;

/**
 * A class about managers.
 * Who have ghosts in their cabinets.
 * @author evka
 * @version 0.x
 */
public class Manager implements Serializable, Runnable{
  //@ public model int experience;
  
  //@ public ghost int casper;
  
  //@ public model pure int calculateExperience(int years);
  
  //@ public model Manager(String name);
  
  public static void main(String[] args) { }
  
  public void manage(){}

  
  public void run() {  }

}
