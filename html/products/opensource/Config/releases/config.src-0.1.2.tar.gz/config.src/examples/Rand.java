import java.util.*;

public class Rand {
    public static void main(String[] args) {
        Random rand = new Random();
        final int NC = 100;
        final int NV = 70;

        for (int i = 0; i < NC; i++) {
            final int clauseSize = 3;
            for (int lit = 0; lit < clauseSize; lit++) {
                boolean sign = (rand.nextInt() & 1) != 0;
                int var = rand.nextInt(NV) + 1;

                if (lit != 0) System.out.print(" | ");
                System.out.print((sign ? "" : "!") + "v" + var);
            } 
            System.out.println(";");
        }
    }
}