package ie.ucd.config;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

import java.util.Set;
import java.util.Collection;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.*;

import java.io.*;

import ie.ucd.solver.*;

import ie.ucd.config.reading.*;


public class Main extends JFrame {
    private List proofList;
    private List violatedList;

    static final long serialVersionUID = 55566677;

    Collection<Variable> vars;
    Set<Clause> clauses;

    HashMap<Variable, JCheckBox> cbs = new HashMap<Variable, JCheckBox>();
    HashMap<JCheckBox, Variable> cbToVars = new HashMap<JCheckBox, Variable>();

    Configurator conf;

    Set<Clause> violations = null;

    ActionListener cbAction = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                JCheckBox cb= (JCheckBox)ae.getSource();
                Variable v = cbToVars.get(cb);
                if (cb.isSelected()) conf.select(v);
                else conf.retract(v);
                update();
            }
        };

    ActionListener QuitAction = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                System.exit(0);
            }
        };

    ActionListener CompletionAction = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                completion();
            }
        };

    private void completion() {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));

        Map<Variable, Boolean> model = conf.computeModel();
        System.out.println("model " + model);
        for (Map.Entry<Variable, Boolean> v_b : model.entrySet()) {
            Variable v = v_b.getKey();
            Boolean vv = v_b.getValue();
            JCheckBox cb = cbs.get(v);

            if (!vv) continue;
            if (cb.isSelected()) continue;

            cb.setSelected(v_b.getValue());
            conf.select(v);
            update();
            System.out.println("setting " + v + " -> " + vv);
        }
        update();
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    Variable proofDisplayed = null;
    MouseMotionListener cbMouse = new MouseMotionListener() {
            public void mouseDragged(MouseEvent e) {}

            public void mouseMoved(MouseEvent e) {
                JCheckBox cb= (JCheckBox)e.getSource();
                Variable v = cbToVars.get(cb);
                if (proofDisplayed == v) return;

                Set<Clause> prfs = conf.getProofs().get(v);
                proofList.removeAll();
                proofDisplayed = null;
                String expl = "Explanation";
                if (prfs != null) {
                    proofDisplayed = v;
                    expl = "Explanation (" + v.toString() + ")";
                    for (Clause c : prfs) {
                        proofList.add(c.toString());
                    }
                }

                ((TitledBorder)(jpProofs.getBorder())).setTitle(expl);
                jpProofs.revalidate(); jpProofs.repaint();
            }
        };


    public Collection<Clause> testSat() {
        Solver s = new Solver();
        s.init(clauses);
        if (!s.solve()) {
            return s.computeProof();
        } else {
            return null;
        }
    }

    int updateCounter = 0;
    long totalTime = 0;
    private void update() {
        long startTime = System.currentTimeMillis();

        proofList.removeAll();
        proofDisplayed = null;

        Map<Variable, Set<Boolean>> varStates = conf.testUnassigned();
        for (Map.Entry<Variable, Set<Boolean>> v_vs : varStates.entrySet()) {
            Variable v = v_vs.getKey();
            Set<Boolean> vs = v_vs.getValue();
            JCheckBox cb = cbs.get(v);

            assert vs.size() != 0;
            assert !conf.getUserDecisions().contains(v);

            if (vs.size() == 1) {
                boolean enabledValue = choice(vs);
                cb.setSelected(enabledValue);
                cb.setEnabled(false);
            } else {
                assert vs.size() == 2;
                cb.setSelected(false);
                cb.setEnabled(true);
            }
        }

        // Stats
        long endTime = System.currentTimeMillis();
        long time = endTime - startTime;
        totalTime += time;
        ++updateCounter;
        System.err.println("update time: " + time + "ms");
        System.err.println("average time: " + (totalTime/updateCounter) + "ms");

        // Unsat configs
        violations = Solver.isModel(collectAssignments(), clauses);
        if (violations ==  null) {
            violatedList.removeAll();
            jlModelLabel.setText("Complete Valuation");
        } else {
            violatedList.removeAll();
            for (Clause c : violations) violatedList.add(c.toString());
            jlModelLabel.setText("Partial Valuation");
        }

    }


    HashMap<Variable, Boolean> collectAssignments() {
        HashMap<Variable, Boolean> retv = new HashMap<Variable, Boolean>();
        for (Variable v : vars) {
            JCheckBox cb = cbs.get(v);
            retv.put(v, cb.isSelected());
        }
        return retv;
    }

    JLabel jlModelLabel;
    JPanel rightPanel = null;
    TitledBorder tbProofs = null;
    JPanel jpProofs = null;

    private void addRightPanelComponent(JComponent com) {
        com.setAlignmentX(Component.CENTER_ALIGNMENT);
        rightPanel.add(com);
    }

    public void init() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBorder(BorderFactory.createRaisedBevelBorder());

        jlModelLabel = new JLabel("Partial valuation");
        jlModelLabel.setBorder(new LineBorder(Color.BLACK));
        jlModelLabel.setHorizontalAlignment(SwingConstants.CENTER);
        addRightPanelComponent(jlModelLabel);

        JButton jbCompletion =  new JButton("Valuation Completion");
        jbCompletion.addActionListener(CompletionAction);
        addRightPanelComponent(jbCompletion);

        JButton jbQuit = new JButton("Quit");
        jbQuit.addActionListener(QuitAction);
        addRightPanelComponent(jbQuit);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBorder(BorderFactory.createRaisedBevelBorder());
        buttonPanel.setLayout(new GridLayout(0, 3));
        for (Variable v : vars) {
            JCheckBox cb = new JCheckBox(v.toString());
            cb.addActionListener(cbAction);
            cb.addMouseMotionListener(cbMouse);
            cbs.put(v, cb);
            cbToVars.put(cb, v);
            buttonPanel.add(cb);
        }
        JPanel jpLists = new JPanel();
        jpLists.setLayout(new GridLayout(0, 2));
        tbProofs = new TitledBorder("Explanation");
        jpProofs = new JPanel(new BorderLayout()); jpProofs.setBorder(tbProofs);
        JPanel jpViolations = new JPanel(new BorderLayout()); jpViolations.setBorder(new TitledBorder("Unsatisfied constraints"));
        proofList = new List(); jpProofs.add(proofList);
        violatedList = new List(); jpViolations.add(violatedList);

        jpLists.add(jpProofs, BorderLayout.WEST);
        jpLists.add(jpViolations, BorderLayout.EAST);

        mainPanel.add(buttonPanel, BorderLayout.CENTER);
        mainPanel.add(rightPanel, BorderLayout.EAST);
        mainPanel.add(jpLists, BorderLayout.SOUTH);

        add(mainPanel);
    }

    public static void main(String[] args) throws IOException {
        Clause.clikePrinting = true;
        Solver.getLogger().setLevel(Level.SEVERE);

        if (args.length == 0) {
            System.err.println("File name expected");
            System.exit(1); 
        }

        FileInputStream in = null;
        ClauseReader r = null;

        try{
            in = new FileInputStream(args[args.length - 1]);
            r = new ClauseReader(in);
        } catch (IOException e) {
            System.err.println("Couldn't open the input file.");
            System.exit(1); 
        }

        ClauseReaderOutput ro = r.read();
        // Test if the reading was successful
        if (ro == null) {
            System.out.println("couldn't read clauses("  + r.getErrorDescription() + ")");
            System.exit(1);
        }

        Main m = new Main();
        m.vars = ro.getVars();
        m.clauses = ro.getClauses();
        m.conf = new Configurator(m.vars, m.clauses);
        System.out.println(m.vars);
        System.out.println(m.clauses);

        m.init();

        Collection<Clause> refutation =  m.testSat();
        if (refutation != null) {
            //            JOptionPane jop = new JOptionPane("Unsatisfiable input constraint!",  JOptionPane.ERROR_MESSAGE);
            String refut = "";
            for (Clause c : refutation) {
                refut += "\n";
                refut += "   " + c.toString();
            }
            JOptionPane.showMessageDialog(null,
                                          "Unsatisfiable input constraint!" + refut,
                                          "Error",
                                          JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        m.update();


        m.pack();
        m.setVisible(true);
    }

    static boolean choice(Set<Boolean> booleanSet) {
        return booleanSet.iterator().next();
    }
}

