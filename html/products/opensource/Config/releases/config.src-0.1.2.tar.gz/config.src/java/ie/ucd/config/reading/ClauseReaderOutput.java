package ie.ucd.config.reading;

import java.util.*;
import ie.ucd.solver.Clause;
import ie.ucd.solver.Variable;


/**
 * Class storin the output of the ClauseReader class.
 *
 * @author Mikolas Janota
 */
public class ClauseReaderOutput {
    Collection<Variable> vars;
    Set<Clause> clauses;

    public ClauseReaderOutput(Collection<Variable> vars, Set<Clause> clauses) {
        this.vars = vars;
        this.clauses = clauses;
    }

    public Collection<Variable> getVars () { return vars;   }
    public Set<Clause> getClauses() { return clauses;  }
}