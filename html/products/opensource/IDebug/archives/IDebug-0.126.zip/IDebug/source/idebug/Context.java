/*
 * Software Engineering Tools.
 *
 * $Id: Context.jass,v 1.8 2001/05/29 05:05:58 kiniry Exp $
 *
 * Copyright (c) 1997-2001 Joseph Kiniry
 * Copyright (c) 2000-2001 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS
 * IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL KIND SOFTWARE OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebug;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;

/**
 * <p> Context is the data structure that holds the information that is
 * relevent to debugging on a per-thread and a per- threadgroup basis. </p>
 *
 * <p> Each thread within a program is either in a debugging state or it is
 * not.  To signal that it is in the debugging state, that thread should do
 * the following (perhaps in an initDebug() method):
 * 
 * <ol> 
 * <li> Create a new Context object for that thread.  E.g.  <code>Context
 * debugContext = new Context();</code> All of the following method calls
 * are applied to this object, unless otherwise noted. </li>
 *
 * <li> Call the <code>turnOn();</code> to turn debugging on for this
 * thread. </li>
 *
 * <li> Add any new debugging categories specific to that thread with one
 * or more of the <code>addCategory()</code> methods. </li>
 *
 * <li> If this thread is only interested in the debugging output from a
 * specific set of classes, the <code>addClass()</code> methods can be used
 * to specify specific methods of interest.  Note that you'll likely want
 * to prefix the series of "class additions" with a
 * <code>removeClass(Thread.currentThread(), "*");</code> to flush the
 * context of the class narrowing/widening. </li>
 *
 * <li> Set the debug level that the thread is interested in with one of
 * the <code>setLevel()</code> methods. </li>
 * </ol>
 *
 * </p>
 *
 * <p> Now your thread has a valid debugging context, encapsulated in
 * its Context object.  This object is then passed to the Debug class
 * via the <code>addContext()</code> method so that the debugging
 * runtime system knows the threads context. </p>
 *
 * @version $Revision: 1.8 $ $Date: 2001/05/29 05:05:58 $
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @see Debug
 * @see DebugConstants
 *
 * @design Most of this class used to be called PerDebugElement and
 * was used in package versions 0.01 through 0.17.
 * @design changeonly{} specifications are not used here because the
 * clone() method is part of the IDebug context design and is not
 * implemented for changeonly semantics.
 */

public class Context implements Cloneable, Serializable
{
  // Attributes

  /**
   * <p> This class contains several core instance variables:
   *
   * <ol>
   * <li> <code>isOn</code> is a boolean that indicates if debugging for
   * this element (thread or threadgroup) is turned on. </li>
   *
   * <li> <code>level</code> is an integer that indicates the current
   * debugging level for this element.  Its value ranges from
   * <code>LEVEL_MIN</code> to <code>LEVEL_MAX</code> of the current
   * installed <code>DebugConstantInterface</code>. </li>
   *
   * <li> <code>categoryHashtable</code> is a hashtable containing
   * information on all categories defined in this debugging context and
   * their severity levels.  A key of this hashtable is the category (type
   * <code>String</code>), while the data value is an <code>Integer</code>
   * representing the severity level of the category. </li>
   *
   * <li> <code>classHashtable</code> is a hashtable containing information
   * on all classes that have debugging enabled or disabled in this
   * context.  A key of this hashtable is the <code>String</code>
   * representation of a class (<code>Class.getName()</code>), while a data
   * value is a <code>Boolean</code> indicating if a the given class has
   * debugging enabled. </li> 
   * </ol>
   * </p>
   *
   * <p> Context objects are stored in the class-global per-thread and
   * per-threadgroup hashtables of the <code>Debug</code> class, hashed on
   * references to the thread or thread group, respectively. </p>
   */
  
  /**
   * @serial The debugging constants for this class.
   */
  
  private DebugConstants debugConstants = null;
  
  /**
   * @serial A flag indicating if debugging is enabled for this
   * context.  If (isOn == false), all Debug calls like assert() and
   * print(), but for the query and state change functions (like
   * isOn(), turnOn(), etc.), are short-circuited and do nothing.
   */
  
  private boolean isOn;

  /**
   * @serial The current debug level of this context.
   * @design Higher valued levels usually indicate higher priorities.
   * E.g. A level 9 message is in the default implementation an asssertion;
   * if it fails, the program exits.  A level 5 message is an error and the
   * user should probably be informed of the problem.  You can override
   * this behavior by subtyping DebugConstants and installing the new
   * constant during the construction of a Context.
   */

  private int level;

  /**
   * @serial A hashtable that binds category keys (Strings) to levels
   * (Integers).
   */

  private Hashtable categoryHashtable;

  /**
   * @serial A hashtable that binds class names (Strings) to enable flags
   * (Booleans).
   */

  private Hashtable classHashtable;

  /**
   * The thread that owns this context.
   */

  private transient Thread thread;

  /** 
   * <p> The object used by this thread to control debugging output device.
   * All debugging messages that come from the owning thread will use this
   * output interface. </p>
   */

  private transient DebugOutput debugOutputInterface;

  /**
   * <p> The standard constructor.  The thread that is constructing the
   * context is the "owning thread".  All calls to this context will be
   * recognized only in the context of the original constructing
   * thread. </p>
   *
   * <p> The constructor initializes all the static data-structures used by
   * the Context class.  Note that the <code>initCategories()</code> method
   * is automatically called as necessary to initialize the default
   * categories database of the Context class. </p>
   *
   * @concurrency CONCURRENT
   * @modifies isOn, level, categoryHashtable, classHashtable,
   *           debugConstants, debugOutputInterface, thread
   * @param c an implementation of the <code>DebugConstants</code> that
   * defines the semantics of this debug context.
   * @param d an implementation of <code>DebugOutput</code> that defines
   * the semantics of debugging output.
   */

  public Context(DebugConstants c, DebugOutput d)
  {
    /** require [dc_non_null] (c != null);
                [do_non_null] (d != null); **/

    isOn = false;
    level = 0;
    categoryHashtable = new Hashtable();
    classHashtable = new Hashtable();
    classHashtable.put("*", new Boolean(true));
    debugConstants = c;
    debugConstants.initCategories(categoryHashtable);
    debugOutputInterface = d;
    thread = Thread.currentThread();

    /** ensure [isOn_initialized] (isOn == false);
               [level_initialized] (level == 0);
               [categoryHashtable_initialized] (categoryHashtable != null);
               [classHashtable_initialized] (classHashtable != null);
               [debugConstants_initialized] (debugConstants != null);
               [debugOutputInterface_initialized] 
                 (debugOutputInterface != null);
               [thread_initialized] (thread != null); **/
  }

  /**
   * <p> Used to clone a Context for another thread.  Should be called
   * <em>only</em> by the thread that is going to use/modify the
   * context. </p>
   *
   * @concurrency CONCURRENT
   * @modifies QUERY
   * @return the clone of the Context.
   */

  public Object clone()
  {
    Context contextClone = null;
    try {
      contextClone = (Context)super.clone();
    } catch (CloneNotSupportedException cnse) {
      throw new RuntimeException(cnse.getMessage());
    }
    contextClone.thread = Thread.currentThread();
    contextClone.debugOutputInterface = debugOutputInterface;

    return contextClone;

    /** ensure [Result_non_null] (Result != null); **/
  } 

  /**
   * @return the thread that owns this context.
   *
   * @concurrency CONCURRENT
   * @modifies QUERY
   */

  public Thread getThread()
  {
    return thread;

    /** ensure [Result_is_correct] (Result == thread); **/
  }

  /**
   * <p> Turns on debugging facilities for the owner thread.  Note that if
   * you do not <code>turnOff()</code> debugging for this thread before it
   * becomes in active in the system, it will not be garbage collected,
   * since it is referenced by the Context object. </p>
   *
   * @concurrency GUARDED
   * @modifies isOn
   */

  public synchronized void turnOn()
  {
    isOn = true;

    /** ensure [isOn_is_true] (isOn == true); **/
  }
  
  /**
   * <p> Turns off debugging facilities for the owner thread.  Note that if
   * you do not <code>turnOff</code> debugging for this thread before it
   * becomes in active in the system, it will not be garbage collected,
   * since it is referenced by the Context object. </p>
   *
   * @concurrency GUARDED
   * @modifies isOn
   * @review Create a garbage collection thread for Debug to clean up dead
   * threads?
   */

  public synchronized void turnOff()
  {
    isOn = false;

    /** ensure [isOn_is_false] (isOn == false); **/
  }

  /**
   * @concurrency GUARDED
   * @modifies QUERY
   * @return a boolean indicating if any debugging is turned on.
   */

  public synchronized boolean isOn()
  {
    return isOn;
  }

  /**
   * <p> Adds a category to the database of legal debugging categories for
   * the owner thread.  Once a category exists in the database, its
   * debugging level cannot be changed without removing and re-adding the
   * category to the database. </p>
   *
   * @concurrency GUARDED
   * @modifies categoryHashtable
   * @param category the category to add to the global set of categories.
   * @param level the debugging level associated with the passed category.
   * @return a boolean indicating if the category was sucessfully added to
   * the database.  A false indicates either the category was already in
   * the database at a different level or the parameters were invalid.
   */

  public synchronized boolean addCategory(String category, int level)
  {
    /** require [category_non_null] (category != null);
                [category_length_positive] (category.length() > 0);
                [level_in_valid_range] validLevel(level); **/

    // See if an entry for the passed category exists.
    if (categoryHashtable.containsKey(category)) {
      if (((Integer)(categoryHashtable.get(category))).intValue() != level)
        return false;
      else
        return true;
    }

    // Add a new entry for the passed category.
    categoryHashtable.put(category, new Integer(level));

    return true;

    /** ensure [category_added] containsCategory(category); **/
  }

  /**
   * <p> Removes a category from the database of legal debugging categories
   * for the owner thread. </p>
   *
   * @concurrency GUARDED
   * @modifies categoryHashtable
   * @param category the category to remove.
   * @return a boolean indicating if the category was sucessfully
   * removed from the database.  A false indicates that the parameters
   * were invalid.
   */
  
  public synchronized boolean removeCategory(String category)
  {
    /** require [category_non_null] (category != null);
                [category_length_positive] (category.length() > 0); **/

    // If is in the hashtable, remove it.
    boolean Result = false;
    if (categoryHashtable.containsKey(category)) {
      categoryHashtable.remove(category);
      return true;
    } else return false;

    /** ensure [category_removed] !containsCategory(category); **/
  }

  /**
   * @concurrency GUARDED
   * @modifies QUERY
   * @param category is the category to lookup.
   * @return a boolean indicating if a category is in the class-global
   * category database.
   */

  public synchronized boolean containsCategory(String category)
  {
    /** require [category_non_null] (category != null);
                [category_length_positive] (category.length() > 0); **/

    return (categoryHashtable.containsKey(category));
  }

  /**
   * @concurrency GUARDED
   * @modifies QUERY
   * @param category is the category to lookup.
   * @return the level of the category provided it is in the category
   * database of this context.
   */

  public synchronized int getCategoryLevel(String category)
  {
    /** require [category_non_null] (category != null);
                [category_length_positive] (category.length() > 0); 
                [contains_category] containsCategory(category); **/

    return ((Integer)(categoryHashtable.get(category))).intValue();
  }

  /**
   * @concurrency GUARDED
   * @modifies QUERY
   * @return an enumeration that is the list of per-thread debugging
   * categories that are currently in this Context's category
   * database.  A zero-length enumeration will be returned if there
   * are not categories defined in the database as of yet.
   * @see Hashtable#elements
   */

  public synchronized Enumeration listCategories()
  {
    return (categoryHashtable.elements());
  }

  /**
   * @return a boolean indicating that this Context's database of classes
   * contains the specified class.
   * 
   * @concurrency GUARDED
   * @modifies QUERY
   * @param className the name of the class to check.
   */

  public synchronized boolean containsClass(String className)
  {
    /** require [className_non_null] (className != null);
                [className_length_positive] (className.length() > 0); **/

    return classHashtable.containsKey(className);
  }

  /**
   * @return a boolean indicating that this Context's database of classes
   * contains the specified class.
   * 
   * @concurrency GUARDED
   * @modifies QUERY
   * @param classRef the class to check.
   */

  public synchronized boolean containsClass(Class classRef)
  {
    /** require [classRef_non_null] (classRef != null); **/

    return containsClass(classRef.getName());
  }

  /**
   * <p> Adds a class to this Context's database of classes that have
   * debugging enabled. </p>
   *
   * @concurrency GUARDED
   * @modifies classHashtable
   * @param classRef the class to add to the global table of classes
   * that have debugging enabled.
   */

  public synchronized void addClass(Class classRef)
  {
    /** require [classRef_non_null] (classRef != null); **/

    Utilities.addClassToHashtable(classHashtable, 
                                  classRef.getName());
  }

  /**
   * <p> Adds a class to this Context's database of classes that have
   * debugging enabled. Note that a class of "*" means that all classes
   * will now have debugging enabled for the owning thread.  There is no
   * way to "undo" such a command short of manually adding the individual
   * classes back to the database. (Or, equivalently, removing the
   * complement.) </p>
   *
   * @concurrency GUARDED
   * @modifies classHashtable
   * @param className the name of the class to add.
   */
  
  public synchronized void addClass(String className)
  {
    /** require [className_non_null] (className != null);
                [className_length_positive] (className.length() > 0); **/

    Utilities.addClassToHashtable(classHashtable, 
                                  className);
  }

  /**
   * <p> Removes a class from this Context's database of classes that have
   * debugging enabled. </p>
   *
   * @concurrency GUARDED
   * @modifies classHashtable
   * @param classRef the class to remove from this Context's table of
   * classes that have debugging enabled.
   */

  public synchronized void removeClass(Class classRef)
  {
    /** require [classRef_non_null] (classRef != null); **/

    Utilities.removeClassFromHashtable(classHashtable, 
                                       classRef.getName());
  }

  /**
   * <p> Removes a class from this Context's database of classes that have
   * debugging enabled.  Note that a class of "*" means that all classes
   * will be removed and debugging disabled.  There is no way to "undo"
   * such a command. </p>
   *
   * @concurrency GUARDED
   * @modifies classHashtable
   * @param className the class to remove from this Context's table of
   * classes that have debugging enabled. 
   */

  public synchronized void removeClass(String className)
  {
    /** require [className_non_null] (className != null);
                [className_length_positive] (className.length() > 0); **/

    Utilities.removeClassFromHashtable(classHashtable, 
                                       className);
  }

  /**
   * <p> Returns an enumeration that is the list of classes that have
   * debugging enabled in this Context. </p>
   *
   * @concurrency GUARDED
   * @modifies QUERY
   * @return an enumeration that is the list of the classes that
   * currently have debugging enabled (they are in the class database)
   * for the owning thread. Returns a zero-length enumeration if there
   * are no enabled classes.
   * @see Hashtable#elements
   */
  
  public synchronized Enumeration listClasses()
  {
    return (classHashtable.elements());
  }
  
  /**
   * <p> Set a new debugging level for the owning thread. </p>
   *
   * @concurrency GUARDED
   * @modifies level
   * @param l the new debugging level.
   */
  
  public synchronized void setLevel(int l)
  {
    /** require [valid_level] validLevel(l); **/

    level = l;

    /** ensure [level_set] (getLevel() == l); **/
  }

  /**
   * @concurrency GUARDED
   * @modifies QUERY
   * @return the current debugging level for the owning thread.
   */
  
  public synchronized int getLevel()
  {
    return level;
  }

  /**
   * @concurrency CONCURRENT
   * @modifies QUERY
   * @return the <code>DebugOutput</code> for the owning thread.
   */
  
  public DebugOutput getOutputInterface()
  {
    return debugOutputInterface;
  }

  /**
   * @concurrency CONCURRENT
   * @modifies QUERY
   * @return a flag indicating if the provided level is valid.
   * @param l the level to check.
   */

  public boolean validLevel(int l)
  {
    return ((l >= DebugConstants.LEVEL_MIN) && 
            (l <= DebugConstants.LEVEL_MAX));
  }

  // Protected Methods
  // Package Methods
  // Private Methods

  /** invariant [level_in_valid_range] validLevel(getLevel()); **/

} // end of class Context

/*
 * Local Variables:
 * Mode: Java
 * fill-column: 75
 * End:
 */
