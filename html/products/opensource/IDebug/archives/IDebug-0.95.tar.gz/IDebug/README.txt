
                           README for IDebug 0.95
     _________________________________________________________________
   
   Welcome to IDebug, an advanced debugging framework for Java!
   
Source Code

   This release of IDebug does include source code. See the [1]source
   directory for more information.
   
   If you wish to contribute to IDebug, please email
   [2]idebug@kindsoftware.com and we can discuss our process (e.g.
   patches, CVS access, contributor maintaining ownership of
   additions/changes, etc.).
   
Documentation

   This release of IDebug comes with three kinds of documentation.
    1. Full [3]Javadoc-generated documentation is included in the
       docs/javadoc directory.
    2. A [4]technical report describing IDebug is included in the
       directory docs/manual. This document isn't a true "user's manual".
       Such a document will be included in the 1.0 release of IDebug.
    3. We have a full UML specification of IDebug, but the documentation
       was generated with an old version of [5]TogetherJ (2.X) and is
       thus not very pretty, readable, or useful in its current form. We
       are looking into redrawing the documentation in a more
       web-friendly tool like a new version of TogetherJ, [6]Visio 2000,
       or perhaps an Open Source modeling tool like [7]ArgoUML.
       Additionally, we have switched to using the [8]BON modeling
       language and process for all of our projects, so perhaps we'll
       rewrite our UML specification in BON for a future release.
    4. Miscellaneous other documentation ([9]release notes, [10]FAQ,
       [11]TODO list, etc.) are included in several text files in the
       same directory as this file.
    5. Use the source! The source code, or more specifically, the full
       [12]Design by Contract specification that can be found in the
       source, is your best guide toward the correct use of IDebug. We,
       of course, use the excellent [13]Infospheres Java Code Standard in
       IDebug.
       
Using IDebug

   To learn how to use IDebug, one should read the IDebug [14]technical
   report and peruse the [15]Javadoc documentation. Additionally, the
   source code for the IDebug blackbox test suite has been included in
   the [16]source/idebug/examples directory, which should be very
   revealing to the interested developer. In that same directory one can
   find an example extension to the DebugConstants interface called
   FrenchConstants.
   Add the IDebug jar file to your CLASSPATH to use IDebug.
   
Questions or comments?

   Please email [17]idebug@kindsoftware.com.
     _________________________________________________________________
   
   [ [18]Index ] [ Readme ] [ [19]FAQ ] [ [20]Release Notes ] [ [21]To-Do
                           List ] [ [22]License ]
     _________________________________________________________________
   
     [23]Best Viewed With Any Browser. [24]XHTML 1.0 Checked! [25]CSS,
                             Level 2 Checked! 
   
   
    by Joseph R. Kiniry <joe@kindsoftware.com>
    
   Last modified: Sun Jun 25 22:54:17 PDT 2000

References

   1. file://localhost/mnt/ext2/home/kiniry/Projects/IDebug/source
   2. mailto:idebug@kindsoftware.com
   3. file://localhost/mnt/ext2/home/kiniry/Projects/IDebug/docs/javadoc/index.html
   4. file://localhost/mnt/ext2/home/kiniry/Projects/IDebug/docs/manual/index.html
   5. http://www.togetherj.com/
   6. http://www.microsoft.com/office/visio/
   7. http://argouml.tigris.org/
   8. http://www.eiffel.com/products/bon.html
   9. file://localhost/mnt/ext2/home/kiniry/Projects/IDebug/RELEASE_NOTES.html
  10. file://localhost/mnt/ext2/home/kiniry/Projects/IDebug/FAQ.html
  11. file://localhost/mnt/ext2/home/kiniry/Projects/IDebug/TODO.html
  12. http://www.eiffel.com/doc/manuals/technology/contract/page.html
  13. http://www.infospheres.caltech.edu/resources/code_standards/java_standard.html
  14. file://localhost/mnt/ext2/home/kiniry/Projects/IDebug/docs/manual/index.html
  15. file://localhost/mnt/ext2/home/kiniry/Projects/IDebug/docs/javadoc/index.html
  16. file://localhost/mnt/ext2/home/kiniry/Projects/IDebug/source/idebug/examples/
  17. mailto:idebug@kindsoftware.com
  18. file://localhost/mnt/ext2/home/kiniry/Projects/IDebug/index.html
  19. file://localhost/mnt/ext2/home/kiniry/Projects/IDebug/FAQ.html
  20. file://localhost/mnt/ext2/home/kiniry/Projects/IDebug/RELEASE_NOTES.html
  21. file://localhost/mnt/ext2/home/kiniry/Projects/IDebug/TODO.html
  22. file://localhost/mnt/ext2/home/kiniry/Projects/IDebug/LICENSE.html
  23. http://www.anybrowser.org/campaign/
  24. http://validator.w3.org/check/referer
  25. http://jigsaw.w3.org/css-validator/check/referer
