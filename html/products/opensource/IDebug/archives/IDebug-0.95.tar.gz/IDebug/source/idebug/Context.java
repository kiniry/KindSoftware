/*
 * Software Engineering Tools.
 *
 * $Id: Context.java,v 1.4 2000/06/26 05:39:34 kiniry Exp $
 *
 * Copyright (c) 1997-2000 Joseph Kiniry
 * Copyright (c) 2000 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL SRI INTERNATIONAL OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebug;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;

/**
 * <P> Context is the data structure that holds the information that
 * is relevent to debugging on a per-thread and a per- threadgroup
 * basis.
 *
 * <P> Each thread within a program is either in a debugging state or
 * it is not.  To signal that it is in the debugging state, that
 * thread should do the following (perhaps in an initDebug() method):
 * 
 * <OL> 
 * <LI> Create a new Context object for that thread.  E.g.
 * <CODE>Context debugContext = new Context();</CODE> All of the
 * following method calls are applied to this object, unless otherwise
 * noted.
 *
 * <LI> Call the <CODE>turnOn();</CODE> to turn debugging on for this thread.
 *
 * <LI> Add any new debugging categories specific to that thread with
 * one or more of the <CODE>addCategory()</CODE> methods.
 *
 * <LI> If this thread is only interested in the debugging output from
 * a specific set of classes, the <CODE>addClass()</CODE> methods can
 * be used to specify specific methods of interest.  Note that you'll
 * likely want to prefix the series of "class additions" with a
 * <CODE>removeClass(Thread.currentThread(), "*");</CODE> to flush the
 * context of the class narrowing/widening.
 *
 * <LI> Set the debug level that the thread is interested in with one
 * of the <CODE>setLevel()</CODE> methods.  
 *</OL>
 *
 * <P> Now your thread has a valid debugging context, encapsulated in
 * its Context object.  This object is then passed to the Debug class
 * via the <CODE>addContext()</CODE> method so that the debugging
 * runtime system knows the threads context.
 *
 * @version $Revision: 1.4 $ $Date: 2000/06/26 05:39:34 $
 * @author Joseph R. Kiniry
 * @see Debug
 * @see DebugConstants
 * @design Most of this class used to be called PerDebugElement and
 * was used in package versions 0.01 through 0.17.
 *
 * @invariant ((level >= debugConstants.LEVEL_MIN) && 
 *             (level <= debugConstants.LEVEL_MAX)) Debug level must be 
 *                                                  within a valid range.
 */

public class Context implements Cloneable, Serializable
{
  /**
   * <P> This class contains exactly three instance variables:
   *
   * <OL>
   * <LI> isOn is a boolean that indicates if debugging for this
   * element (thread or threadgroup) is turned on.
   *
   * <LI> level is an integer that indicates the current debugging
   * level for this element.  Its value ranges from LEVEL_MIN to
   * LEVEL_MAX of the current installed DebugConstantInterface.
   *
   * <LI> categoryHashtable is a Hashtable containing information on
   * all categories defined in this debugging context and their
   * severity levels.  A key of this hashtable is the category
   * (Strings), while the data value is an Integer representing the
   * severity level of the category.
   *
   * <LI> classHashtable is a Hashtable containing information on all
   * Classes that have debugging enabled or disabled in this context.
   * A key of this hashtable is the String representation of a Class
   * (Class.getName()), while a data value is a Boolean indicating if
   * a the given class has debugging enabled.  </OL>
   *
   * <P> Context objects are stored in the class-global per-thread and
   * per-threadgroup hashtables of the Debug class, hashed on
   * references to the thread or threadgroup, respectively.
   */
  
  /**
   * @serial The debugging constants for this Debug class.
   *
   * @supplierRole debugConstants
   */
  
  DebugConstants debugConstants = null;
  
  
  /**
   * @serial A flag indicating if debugging is enabled for this
   * context.  If (isOn == false), all Debug calls like assert() and
   * print(), but for the query and state change functions (like
   * isOn(), turnOn(), etc.) are short-circuited and do nothing.
   */
  
  boolean isOn;


  /**
   * @serial The current debug level of this context.
   * @design Higher valued levels usually indicate higher priorities.
   * E.g. A level 9 message is in the default implementation an
   * asssertion; if it fails, the program exits.  A level 5 message is
   * an error and the user should probably be informed of the problem.
   * You can override this behavior by subtyping DebugConstants and
   * installing the new constant during the construction of a Context.
   * @values (debugConstants.LEVEL_MIN <= level <= debugConstants.LEVEL_MAX)

   */

  int level;


  /**
   * @serial A hashtable that binds category keys (Strings) to levels
   * (ints).
   */

  Hashtable categoryHashtable;


  /**
   * @serial A hashtable that binds class names (Strings) to Booleans.
   */

  Hashtable classHashtable;


  /**
   * The thread that ownes this context.
   */

  transient Thread thread;


  /** 
   * <P> The class used by this thread to control debugging output
   * device.  All debugging messages that come from the owning thread
   * will use this output interface.
   *
   * @supplierRole debugOutputInterface
   */

  transient public DebugOutput debugOutputInterface;


  /**
   * <P> Constructor for Context.  Note that the thread that is
   * constructing the context is the "owning thread".  All calls to
   * this context will be recognized only in the context of the
   * original constructing thread.
   *
   * @param debugConstantsInterface an implementation of the
   * DebugConstants that defines the semantics of this debug context.
   * @param debugOutputInterface an implementation of DebugOutput that
   * defines the semantics of debugging output.
   */

  public Context(DebugConstants debugConstantsInterface,
                      DebugOutput debugOutputInterface)
  {
    init(debugConstantsInterface, debugOutputInterface);
  }
  

  /**
   * <P> Initialize all the static data-structures used by the Context
   * class.  Note that the initCategories() method is automatically
   * called as necessary to initialize the default categories database
   * of the Context class.
   *
   * @concurrency CONCURRENT
   * @modifies isOn, level, categoryHashtable, classHashtable,
   * debugConstants, thread
   * @param debugConstantsInterface an implementation of the
   * DebugConstants that defines the semantics of this debug
   * context.
   * @param debugOutputInterface an implementation of
   * DebugOutput that defines the semantics of debugging
   * output.
   * @postcondition ((isOn == false) && (level == 0) &&
   * (categoryHashtable != null) && (classHashtable != null) &&
   * (debugConstants != null) && (debugOutputInterface != null) &&
   * (thread != null))
   * @uses DebugConstants.initCategories()
   */

  void init(DebugConstants debugConstantsInterface,
            DebugOutput debugOutputInterface)
  {
    isOn = false;
    level = 0;
    categoryHashtable = new Hashtable();
    classHashtable = new Hashtable();
    classHashtable.put("*", new Boolean(true));
    this.debugConstants = debugConstantsInterface;
    debugConstants.initCategories(categoryHashtable);
    this.debugOutputInterface = debugOutputInterface;
    thread = Thread.currentThread();
  }


  /**
   * <P> Used to clone a Context for another thread.  Should be called
   * <EM>only</EM> by the thread that is going to use/modify the
   * context.
   *
   * @return the clone of the Context.
   * @exception CloneNotSupportedException IF (false) Never thrown by
   * this method.
   */

  public Object clone() throws CloneNotSupportedException
  {
    Object object = super.clone();
    ((Context)object).thread = Thread.currentThread();
    return object;
  } 


  /**
   * @return the thread that owns this context.
   */

  public Thread getThread()
  {
    return thread;
  }


  /**
   * <P> Turns on debugging facilities for the owner thread.  Note
   * that if you do not turnOff debugging for this thread before it
   * becomes in active in the system, it will not be garbage
   * collected, since it is referenced by the Context object.
   *
   * @concurrency GUARDED
   */

  public synchronized void turnOn()
  {
    isOn = true;
  }
  

  /**
   * <P> Turns off debugging facilities for the owner thread.  Note
   * that if you do not turnOff debugging for this thread before it
   * becomes in active in the system, it will not be garbage
   * collected, since it is referenced by the Context object.
   *
   * @concurrency GUARDED
   * @review kiniry Create a garbage collection thread for Debug to
   * clean up dead threads?
   * @uses turnOnOff()
   */

  public synchronized void turnOff()
  {
    isOn = false;
  }


  /**
   * Returns a boolean indicating if any debugging is turned on.
   *
   * @concurrency GUARDED
   * @modifies (QUERY)
   * @return a boolean indicating if any debugging is turned on.
   * @uses isOn
   */

  public synchronized boolean isOn()
  {
    return isOn;
  }
  

  /**
   * Adds a category to the database of legal debugging categories for
   * the owner thread.  Once a category exists in the database, its
   * debugging level cannot be changed without removing and re-adding
   * the category to the database.
   *
   * @concurrency GUARDED
   * @precondition ((category != null) && (category.length() > 0) &&
   * (0 <= level) && (level <= 9))
   * @modifies threadHashtable
   * @param category the category to add to the global set of 
   * categories.
   * @param level the debugging level associated with the passed
   * category.
   * @return a boolean indicating if the category was sucessfully
   * added to the database.  A false indicates either the category was
   * already in the database at a different level or the parameters
   * were invalid.
   * @uses threadHashtable
   */

  public synchronized boolean addCategory(String category, int level)
  {
    // See if an entry for the passed category exists.
    if (categoryHashtable.containsKey(category))
    {
      if (((Integer)(categoryHashtable.get(category))).intValue() != level)
        return false;
      else
        return true;
    }

    // Add a new entry for the passed category.
    categoryHashtable.put(category, new Integer(level));
    return true;
  }


  /**
   * Removes a category from the database of legal debugging
   * categories for the owner thread.
   *
   * @concurrency GUARDED
   * @precondition ((category != null) && (category.length() > 0))
   * @modifies threadHashtable
   * @param category the category to remove.
   * @return a boolean indicating if the category was sucessfully
   * removed from the database.  A false indicates that the parameters
   * were invalid.
   * @uses threadHashtable
   */
  
  public synchronized boolean removeCategory(String category)
  {
    // If is in the hashtable, remove it.
    if (categoryHashtable.containsKey(category))
    {
      categoryHashtable.remove(category);
      return true;
    }
    else return false;
  }


  /**
   * Returns a boolean indicating if a category is registered in
   * this Context's category database.
   *
   * @concurrency GUARDED
   * @precondition ((category != null) &&  (category.length() > 0))
   * @param category is the category to lookup.
   * @return a boolean indicating if a category is in the class-global
   * category database.
   */

  public synchronized boolean containsCategory(String category)
  {
    return (categoryHashtable.containsKey(category));
  }
  

  /**
   * Returns an enumeration that is the list of debugging categories
   * that are currently in this Context's category database.
   *
   * @concurrency GUARDED
   * @return an enumeration that is the list of per-thread debugging
   * categories that are currently in this Context's category
   * database.  A zero-length enumeration will be returned if there
   * are not categories defined in the database as of yet.
   * @uses threadHashtable
   * @see Hashtable#elements
   */

  public synchronized Enumeration listCategories()
  {
    return (categoryHashtable.elements());
  }
  

  /**
   * Adds a class to this Context's database of classes that have
   * debugging enabled.
   *
   * @concurrency GUARDED
   * @precondition (classRef != null)
   * @modifies threadHashtable
   * @param classRef the class to add to the global table of classes
   * that have debugging enabled.
   * @return a boolean indicating if the class was sucessfully added
   * to the database or if the class was already in the database.  A
   * false indicates that the the passed parameters were invalid.
   * @uses threadHashtable, addClassToHashtable()
   */

  public synchronized boolean addClass(Class classRef)
  {
    return Utilities.addClassToHashtable(classHashtable, 
                                              classRef.getName());
  }
  

  /**
   * Adds a class to this Context's database of classes that have
   * debugging enabled. Note that a class of "*" means that all
   * classes will now have debugging enabled for the owning thread.
   * There is no way to "undo" such a command short of manually adding
   * the individual classes back to the database. (Or, equivalently,
   * removing the complement.)
   *
   * @concurrency GUARDED
   * @precondition ((className != null) && (className.length() > 0))
   * @modifies threadHashtable
   * @param className the name of the class to add.
   * @return a boolean indicating if the class was sucessfully added
   * to the database or if the class was already in the database.  A
   * false indicates that the the passed parameters were invalid.
   * @uses threadHashtable, addClassToHashtable()
   */
  
  public synchronized boolean addClass(String className)
  {
    return Utilities.addClassToHashtable(classHashtable, className);
  }


  /**
   * Removes a class from this Context's database of classes that
   * have debugging enabled.
   *
   * @concurrency GUARDED
   * @precondition (classRef != null)
   * @param classRef the class to remove from this Context's
   * table of classes that have debugging enabled.
   * @return a boolean indicating if the class was removed from the
   * database sucessfully.  A false indicates that the class was
   * not in the database.
   * @uses threadHashtable, removeClassFromHashtable()
   */

  public synchronized boolean removeClass(Class classRef)
  {
    return Utilities.removeClassFromHashtable(classHashtable, 
                                                   classRef.getName());
  }


  /**
   * Removes a class from this Context's database of classes that
   * have debugging enabled.  Note that a class of "*" means that all
   * classes will be removed and debugging disabled.  There is no way
   * to "undo" such a command.
   *
   * @concurrency GUARDED
   * @precondition ((className != null) && (className.length() > 0))
   * @param className the class to remove from this Context's
   * table of classes that have debugging enabled.
   * @return a boolean indicating if the class was removed from the
   * database sucessfully.  A false indicates that the class was
   * not in the database.
   * @uses threadHashtable, removeClassFromHashtable()
   */

  public synchronized boolean removeClass(String className)
  {
    return Utilities.removeClassFromHashtable(classHashtable, 
                                                   className);
  }


  /**
   * Returns an enumeration that is the list of classes that have
   * debugging enabled in this Context.
   *
   * @concurrency GUARDED
   * @return an enumeration that is the list of the classes that
   * currently have debugging enabled (they are in the class database)
   * for the owning thread. Returns a zero-length enumeration if there
   * are no enabled classes.
   * @uses threadHashtable
   * @see Hashtable#elements
   */
  
  public synchronized Enumeration listClasses()
  {
    return (classHashtable.elements());
  }
  

  /**
   * Set a new debugging level for the owning thread.
   *
   * @concurrency GUARDED
   * @precondition ((level >= DebugConstants.LEVEL_MIN) && 
   * (level <= DebugConstants.LEVEL_MAX))
   * @modifies threadHashtable
   * @param level the new debugging level.
   * @return a boolean indicating whether the level change succeeded.
   * The only reason why a setLevel might fail is if the level passed
   * is out of range.  In such a case, the method will return a false.
   * @uses level, DebugConstants.LEVEL_MIN,
   * DebugConstants.LEVEL_MAX
   */
  
  public synchronized boolean setLevel(int level)
  {
    if ((level >= DebugConstants.LEVEL_MIN) && 
        (level <= DebugConstants.LEVEL_MAX))    
    {
      this.level = level;
      return true;
    }
    else return false;
  }


  /**
   * Returns the debugging level for the owning thread.
   *
   * @concurrency GUARDED
   * @return the current debugging level for the owning thread.  If no
   * debugging level is defined at all for the thread, a
   * DebugConstants.INVALID_THREAD is returned.
   * @uses threadHashtable
   */
  
  public synchronized int getLevel()
  {
    return level;
  }
}
