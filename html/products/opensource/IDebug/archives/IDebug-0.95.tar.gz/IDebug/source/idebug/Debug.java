/*
 * Software Engineering Tools.
 *
 * $Id: Debug.java,v 1.5 2000/06/26 05:39:34 kiniry Exp $
 *
 * Copyright (c) 1997-2000 Joseph Kiniry
 * Copyright (c) 2000 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL SRI INTERNATIONAL OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebug;

import java.util.Enumeration;
import java.util.Hashtable;

/** 
 * <P> Debug is the core class of the Infospheres debugging facilities.
 *
 * <P> The Debug class is used as the central facility for configuring
 * debugging for a component.
 *
 * <P> All printing and logging commands are handled in the
 * DebugOutput classes.
 *
 * <P> All assertions are handled in the Assertion class.
 *
 * <P> This debug package is meant to help, in general, produce high
 * quality, high confidence, code.
 *
 * <P> The Debug facility is non-static.  The first thing your
 * component or application needs to do is construct a new Debug
 * object.  If you wish to install an alternate implementation of the
 * debugging constants (i.e. categories, levels, error messages,
 * etc.), pass your implementation of DebuggingConstantsInterface to
 * the constructor of Debug.
 *
 * <P> Each thread that calls the Debug class has, potentially, a
 * different context.  Elements of this context include a notion of
 * current message level, message types, classes currently under
 * inspection, and whether debugging is turned on or off.
 *
 * <P> Threads create new debugging contexts by constructing a Context
 * object and calling its methods.  This Context is then passed to the
 * Debug object to change the current global debugging context at
 * runtime.
 *
 * <P> In brief, the Debug class is normally used in the following
 * manner.  A more detailed discussion of the use of this class can be
 * found in the full documentation for the Infospheres debugging
 * package.  See the debug package's <A HREF="../index.html">main
 * index</A> for more information.
 *
 * <P> Each thread needs to construct a debugging context (see the
 * Context class for details) to detail its specific debugging needs.
 * After creating a valid debugging context, encapsulated in the
 * Context object, the object is passed to this class (Debug) via the
 * <CODE>addContext()</CODE> method so that the debugging runtime
 * system knows the thread's context.  Note that the debug runtime
 * keeps a reference to the passed Context, it does not make a copy of
 * it.  Thus, you can modify the Context (change debugging levels, add
 * new thread-specific categories, etc.)  after the context is
 * installed and changes will be noted immediately by the debug
 * runtime.
 *
 * <P> Finally, you have to direct the output of the debugging
 * runtime.  This is accomplished by constructing an implementation of
 * the <code>DebugOutput</code>, e.g. <code>ConsoleOutput</code>.
 * This object is then passed to your Debug object via the
 * <code>Debug.setOutputInterface()</code> method.
 *
 * <P> You're ready to rock and roll.  Call
 * <CODE>debug.getAssert()</CODE> to get a reference to your debug
 * runtime's Assert class.  Finally, if you chose not to install your
 * own implementation of DebugConstants, call
 * <CODE>debug.getDebugConstants()</CODE> to get a reference to your
 * debug constants.
 *
 * <P> Then, simply use <CODE>assert.assert()</CODE>, the
 * <CODE>print()</CODE>, <CODE>println()</CODE> of your DebugOutput,
 * and/or <CODE>Utilities.dumpStack()</CODE> methods in your code as
 * necessary.
 *
 * <P> Note that all class-specific debugging is <EM>additive</EM> and
 * <EM>reductive</EM>.  You can either remove all classes from the
 * debugging table then add classes one by one, or you can add all
 * <EM>potential</EM> classes then remove them one by one at this
 * time.  Meaning, when you perform an add of "*", you are
 * <EM>not</EM> adding all classes currently defined in this VM; you
 * are adding all classes currently defined and all classes that might
 * ever be defined in this VM.
 *
 * @version $Revision: 1.5 $ $Date: 2000/06/26 05:39:34 $
 * @author  Joseph R. Kiniry
 * @history Versions 0.01 through 0.10 were developed as
 * <CODE>edu.caltech.cs.kiniry.coding.Debug</CODE>.  New revision
 * history began when class was moved to
 * <CODE>edu.caltech.cs.infospheres.util.Debug</CODE>.  Six versions
 * were developed while in this package.  The code was then moved to
 * Joe's PhD repository and refactoring began to take place as of
 * cumulative version 0.17.
 *
 * @todo kiniry Possible future enhancements:
 * <OL>
 * <LI> New derivative: persistence mobile debug object.
 * <LI> GUI interface to runtime debugging.
 * <LI> Garbage collection thread for Debug to clean up stopped
 * threads.
 * <LI> Support for ThreadGroup contexts.
 * </OL>
 *
 * @review kiniry To make debugging classes as robust as possible, we
 * need to decide if they should not throw exceptions at all and only
 * return error values if outright failures occur in processing, or
 * throw real exceptions, etc.  Once javap is built, this will be
 * something of a non-issue (since the user will not have to type the
 * exception-handling code at all).
 *
 * @review kiniry Should all precondition/postcondition checks be
 * assertions?  This would lower the robustness of the code.  Perhaps
 * this means that the definitions for @pre/postconditions need be
 * refined (i.e. are they always assertions or not?).
 *
 * @review kiniry Should assertions always call stackDump()?  Should
 * they always call System.exit()?  That's not very nice or robust,
 * and it certainly doesn't support distributed debugging well.
 * Perhaps we can throw some kind of InterruptedException in the
 * thread?
 *
 * @review kiniry Should null or zero-length debugging messages be
 * permitted?  Wouldn't this increase robustness?
 *
 * @review kiniry Are print() and println() methods both necessary?
 * Why not just print()?  Similar to the isOn() controversy.
 *
 * @review kiniry Should calls to println with an ASSERTION_LEVEL
 * cause the calling thread to stop, as in a real assertion?  This
 * complicates the semantics of the print() methods.
 *
 * @review kiniry Addition of an exception stack trace printing
 * mechanism (as per dmz, 15 January).
 *
 * @review kiniry Addition of a system property to turn global
 * debugging on/off (as per dmz, 15 January).
 *
 * @design General Debug design obtained through group consensus in
 * mid November, 1997.
 *
 * @todo kiniry Should the global DebugOutput be public?  Should a
 * client be able to get a reference to it via a call to the
 * appropriate getter instead?  I.e. Detect whether the thread is in a
 * per-thread debugging state and, if not, return the global output
 * interface?
 */

public class Debug
{
  /** 
   * threadHashtable is a hashtable of all threads that have some
   * per-thread specific debugging attributes defined.  Per-thread
   * attributes include categories and classes.  A key of this
   * hashtable is a reference to a Thread, while a data value is a
   * Context object which contains the information specific to this
   * thread.
   *
   * threadHashtable always has an two entries, one under the key
   * "GLOBAL_CATEGORIES" and one under the key "GLOBAL_CLASSES".
   * These entries contain all the class-global categories and
   * class-specific information for debugging, respectively.
   *
   * Internal class handling is somewhat complicated.  If the
   * expression "*" is <EM>removed</EM>, the database is simply
   * cleared.  If the expression "*" is <EM>added</EM>, the entry is
   * inserted in the table.  So, if one removes specific classes after
   * removing "*", or if one adds specific classes after adding "*",
   * there is no change to the database.  <EM>But</EM>, if you remove
   * specific classes after adding "*", or if you add specific classes
   * after removing "*", your changes will be noted.  I.e. Debug
   * handles both additive and reductive specification of classes.
   *
   * @note Debug is the core class of the Infospheres debugging
   * facilities.
   *
   * The Debug class is used as the central facility for configuring
   * debugging for a component.
   */

  Hashtable threadHashtable = null;


  /**
   * The debugging constants for this Debug class.
   *
   * @modifies SINGLE-ASSIGNMENT
   *
   * @supplierRole debugConstants
   */

  DebugConstants debugConstants = null;


  /**
   * The current "global" (Debug scoped) flag indicating if any
   * debugging is enabled.  If (isOn == false), all calls like
   * Assert.assert() and DebugOutput.print(), but for the query and
   * state change functions (like isOn(), turnOn(), etc.)  are
   * short-circuited and do nothing.
   */

  boolean isOn = false;


  /**
   * The current global (Debug scoped) debug level of the Debug class.
   * @design Higher valued levels usually indicate higher priorities.
   * E.g. A level 9 message is in the default implementation an
   * asssertion; if it fails, the program exits.  A level 5 message is
   * an error and the user should probably be informed of the problem.
   * You can override this behavior by subtyping DebugConstants and
   * installing the new constant set when constructing Debug.  @values
   * (debugConstants.LEVEL_MIN <= level <= debugConstants.LEVEL_MAX)
   */

  int level = 0;


  /**
   * The Assert object associated with this Debug object, when
   * instantiated.
   *
   * @modifies SINGLE-ASSIGNMENT
   *
   * @supplierRole assert
   */

  Assert assert = null;


  /**
   * Private debugging utility class that encapsulates several helpful
   * algorithms.
   *
   * @modifies SINGLE-ASSIGNMENT
   *
   * @supplierRole debugUtilities
   */
  
  Utilities debugUtilities = null;


  /**
   * The class used by this thread to control debugging output device.
   * All global debugging messages will use this interface for output.
   *
   * @supplierRole debugOutputInterface
   */

  transient public DebugOutput debugOutputInterface;


  /**
   * Construct a new Debug class.  Note that the method
   * <code>setOutputInterface</code> need be called on the newly
   * constructed Debug object before it can be used.
   */

  public Debug()
  {
    init(new DefaultDebugConstants());
  }

  
  /**
   * Construct a new Debug class.  Note that the method
   * <code>setOutputInterface</code> need be called on the newly
   * constructed Debug object before it can be used.
   *
   * @param debugConstantsInterface an implementation of the
   * DebugConstants that defines the semantics of this debug context.
   */

  public Debug(DebugConstants debugConstantsInterface)
  {
    init(debugConstantsInterface);
  }
  

  /**
   * Initialize all the static data-structures used by the Debug
   * class.  Note that the initCategories() method is automatically
   * called as necessary to initialize the default categories database
   * of the Debug class.  @concurrency CONCURRENT @modifies
   * threadHashtable
   *
   * @param debugConstantsInterface an implementation of the
   * DebugConstants that defines the semantics of this debug context.
   * @postcondition (threadHashtable != null) @uses
   * DebugConstants.initCategories()
   */

  private void init(DebugConstants debugConstantsInterface)
  {
    threadHashtable = new Hashtable();
    Hashtable categoryHashtable = new Hashtable();
    threadHashtable.put("GLOBAL_CATEGORIES", categoryHashtable);
    this.debugConstants = debugConstantsInterface;
    debugConstants.initCategories(categoryHashtable);
    Hashtable classHashtable = new Hashtable();
    threadHashtable.put("GLOBAL_CLASSES", classHashtable);
    classHashtable.put("*", new Boolean(true));

    // Note that we need to actually initialize our own debugging
    // context!
    assert = new Assert(this);

    debugUtilities = new Utilities(this);
  }


  /**
   * Set the global output interface to a new DebugOutput.
   *
   * @param debugOutputInterface the new output interface.
   */

  public void setOutputInterface(DebugOutput d)
  {
    this.debugOutputInterface = d;
  }
  

  /**
   * @return the Assert object associated with this Debug object.
   */

  public Assert getAssert()
  {
    return assert;
  }


  /**
   * @return the DebugOutput corresponding to the invoking thread or,
   * if that thread has no interface, the global output interface.
   */

  public DebugOutput getOutputInterface()
  {
    Thread currentThread = Thread.currentThread();
    
    if (threadHashtable.containsKey(currentThread))
    {
      Context debugContext = 
        (Context)(threadHashtable.get(currentThread));
      return debugContext.debugOutputInterface;
    }
    else return this.debugOutputInterface;
  }


  /**
   * @return the DebugConstants for this Debug object.
   */

  public DebugConstants getDebugConstants()
  {
    return debugConstants;
  }
  

  /**
   * Returns a boolean indicating if any debugging is turned on.
   *
   * @concurrency GUARDED
   * @modifies (QUERY)
   * @return a boolean indicating if any debugging is turned on.
   * @uses isOn
   */

  public synchronized boolean isOn()
  {
    return isOn;
  }
  

  /**
   * Returns a boolean indicating whether any debugging facilities are
   * turned on for a particular thread.
   *
   * @concurrency GUARDED
   * @precondition (thread != null)
   * @modifies (QUERY)
   * @postcondition Debugging turned on for passed thread.
   * @param thread is the thread that we are interested in.
   * @return a boolean indicating whether any debugging facilities are
   * turned on for a particular thread.
   * @uses threadHashtable
   */

  public synchronized boolean isOn(Thread thread)
  {
    // Make sure that there is a legal entry in the threadHashtable
    // for this particular thread.
    if (threadHashtable.containsKey(thread))
    {
      // Get the object that describes the per-thread debugging state.
      Context debugContext = 
      (Context)(threadHashtable.get(thread));

      return debugContext.isOn;
    }
    else return false;
  }
  

  /**
   * Returns a boolean indicating if any debugging is turned off.
   *
   * @concurrency GUARDED
   * @modifies (QUERY)
   * @return a boolean indicating if any debugging is turned on.
   * @review kiniry Are the isOff() methods necessary at all?
   * @uses isOn()
   */

  public synchronized boolean isOff()
  {
    return (!isOn());
  }
  

  /**
   * Returns a boolean indicating whether any debugging facilities are
   * turned off for a particular thread.
   *
   * @concurrency GUARDED
   * @precondition (thread != null)
   * @modifies (QUERY)
   * @param thread is the thread that we are interested in.
   * @return a boolean indicating whether any debugging facilities are
   * turned off for a particular thread.
   * @review kiniry Are the isOff() methods necessary at all?
   * @uses isOff(java.lang.Thread)
   */

  public synchronized boolean isOff(Thread thread)
  {
    return (!isOn(thread));
  }
  

  /**
   * Turns on class-global debugging facilities.
   *
   * @concurrency GUARDED
   * @modifies (isOn) - set to true.
   * @uses isOn
   */

  public synchronized void turnOn()
  {
    isOn = true;
  }


  /**
   * Turns off class-global debugging facilities.
   *
   * @concurrency GUARDED
   * @modifies (isOn) - is set to false.
   * @uses isOn
   */

  public synchronized void turnOff()
  {
    isOn = false;
  }


  /**
   * Adds a category to a hashtable of legal debugging categories.
   * Once a category exists in the database, its debugging level
   * cannot be changed without removing and readding the category
   * to the database.
   *
   * @concurrency GUARDED
   * @precondition ((category != null) && (category.length() > 0) &&
   * (0 <= level) && (level <= 9) && (hashtable != null))
   * @modifies hashtable
   * @param hashtable the hashtable to remove the class from.
   * @param category the category to add to the set of defined
   * categories.
   * @param level the debugging level associated with the passed
   * category.
   * @return a boolean indicating if the category was sucessfully
   * added to the database.  A false indicates either the category was
   * already in the database at a different level or the parameters
   * were invalid.
   */

  private synchronized boolean 
    addCategoryToHashtable(Hashtable hashtable, String category, int level)
  {
    // See if an entry for the passed category exists.
    if (hashtable.containsKey(category))
    {
      if (((Integer)(hashtable.get(category))).intValue() != level)
        return false;
      else
        return true;
    }

    // Add a new entry for the passed category.
    hashtable.put(category, new Integer(level));
    return true;
  }


  /**
   * Adds a category to the database of legal debugging categories.
   * Once a category exists in the database, its debugging level
   * cannot be changed.
   *
   * @concurrency GUARDED
   * @precondition ((category != null) && (category.length() > 0) &&
   * (0 <= level) && (level <= 9))
   * @modifies threadHashtable
   * @param category the category to add to the global set of 
   * categories.
   * @param level the debugging level associated with the passed
   * category.
   * @return a boolean indicating if the category was sucessfully
   * added to the database.  A false indicates either the category was
   * already in the database at a different level or the parameters
   * were invalid.
   * @uses threadHashtable, addCategoryToHashtable()
   */

  public synchronized boolean addCategory(String category, 
                                          int level)
  {
    // Get a reference to the global category hashtable.
    Hashtable categoryHashtable = 
      (Hashtable)(threadHashtable.get("GLOBAL_CATEGORIES"));

    return addCategoryToHashtable(categoryHashtable, category, level);
  }
  

  /**
   * Removes a category from a database of legal debugging categories.
   *
   * @concurrency GUARDED
   * @precondition ((hashtable != null) && (category != null) &&
   * (category.length() > 0))
   * @param hashtable is the thread that we are interested in.
   * @param category the category to remove.
   * @return a boolean indicating if the category was sucessfully
   * removed from the database.  A false indicates that the parameters
   * were invalid.
   */

  private synchronized boolean 
    removeCategoryFromHashtable(Hashtable hashtable, String category)
  {
    // If is in the hashtable, remove it.
    if (hashtable.containsKey(category))
      hashtable.remove(category);
    
    return true;
  }
  

  /**
   * Removes a category to the database of legal debugging categories.
   *
   * @concurrency GUARDED
   * @precondition ((category != null) && (category.length() > 0))
   * @param category the category to remove.
   * @return a boolean indicating if the category was sucessfully
   * removed from the database.  A false indicates that the parameters
   * were invalid.
   * @uses threadHashtable, removeCategoryFromHashtable()
   */

  public synchronized boolean removeCategory(String category)
  {
    // Get a reference to the global category hashtable.
    Hashtable categoryHashtable = 
      (Hashtable)(threadHashtable.get("GLOBAL_CATEGORIES"));

    return removeCategoryFromHashtable(categoryHashtable, category);
  }


  /**
   * Returns a boolean indicating if a category is in the class-global
   * category database.
   *
   * @concurrency GUARDED
   * @precondition ((category != null) && (category.length() > 0))
   * @param category is the category to lookup.
   * @return a boolean indicating if a category is in the class-global
   * category database.
   */

  public synchronized boolean containsCategory(String category)
  {
    // Get global category hashtable.
    Hashtable hashtable = 
      (Hashtable)(threadHashtable.get("GLOBAL_CATEGORIES"));
    
    // If entry exists, return a true; otherwise return a false.
    return (hashtable.containsKey(category));
  }
  

  /**
   * Returns an Enumeration that is the list of class-global debugging
   * categories that are currently in the category database.
   *
   * @concurrency GUARDED
   * @return an Enumeration that is the list of class-global debugging
   * categories that are currently in the category database.
   * @uses threadHashtable
   * @see Hashtable#elements
   */

  public synchronized Enumeration listCategories()
  {
    // Get global category hashtable.
    Hashtable hashtable = 
      (Hashtable)(threadHashtable.get("GLOBAL_CATEGORIES"));
    
    return (hashtable.elements());
  }


  /**
   * Adds a class the the class-global database of classes that
   * have debugging enabled.
   *
   * @concurrency GUARDED
   * @precondition (classRef != null)
   * @modifies threadHashtable
   * @param classRef the class to add to the global table of classes
   * that have debugging enabled.
   * @return a boolean indicating if the class was sucessfully added
   * to the database or if the class was already in the database.  A
   * false indicates that the the passed parameters were invalid.
   * @uses threadHashtable, addClassToHashtable()
   */

  public synchronized boolean addClass(Class classRef)
  {
    //  Get a reference to the global class hashtable.
    Hashtable classHashtable = 
      (Hashtable)(threadHashtable.get("GLOBAL_CLASSES"));

    return Utilities.addClassToHashtable(classHashtable, 
                                              classRef.getName());
  }
  

  /**
   * Adds a class the the class-global database of classes that have
   * debugging enabled. Note that a class of "*" means that all
   * classes will now have debugging enabled.  There is no way to
   * "undo" such a command short of manually adding the individual
   * classes back to the database. (Or, equivalently, removing the
   * complement.)
   *
   * @concurrency GUARDED
   * @precondition ((className != null) && (className.length() > 0))
   * @modifies threadHashtable
   * @param className the name of the class to add.
   * @return a boolean indicating if the class was sucessfully added
   * to the database or if the class was already in the database.  A
   * false indicates that the the passed parameters were invalid.
   * @uses threadHashtable, addClassToHashtable()
   */

  public synchronized boolean addClass(String className)
  {
    //  Get a reference to the global class hashtable.
    Hashtable classHashtable = 
      (Hashtable)(threadHashtable.get("GLOBAL_CLASSES"));

    return Utilities.addClassToHashtable(classHashtable, className);
  }
  

  /**
   * Removes a class the the class-global database of classes that
   * have debugging enabled.
   *
   * @concurrency GUARDED
   * @modifies threadHashtable
   * @precondition (classRef != null)
   * @param classRef the class to remove.
   * @return a boolean indicating if the class was removed from the
   * database sucessfully.  A false indicates that the class was
   * not in the database.
   * @uses threadHashtable, removeClassFromHashtable()
   */

  public synchronized boolean removeClass(Class classRef)
  {
    //  Get a reference to the global class hashtable.
    Hashtable classHashtable = 
      (Hashtable)(threadHashtable.get("GLOBAL_CLASSES"));

    return Utilities.removeClassFromHashtable(classHashtable, 
                                                   classRef.getName());
  }


  /**
   * Removes a class the the class-global database of classes that
   * have debugging enabled.  Removes a class from a database of
   * debugging-enabled classes.  Note that a class of "*" means that
   * all classes will be removed and debugging disabled.  There is no
   * way to "undo" such a command.
   *
   * @concurrency GUARDED
   * @precondition ((className != null) && (className.length() > 0))
   * @modifies threadHashtable
   * @param className the name of the class to remove.
   * @return a boolean indicating if the class was removed from the
   * database sucessfully.  A false indicates that the class was
   * not in the database.
   * @uses threadHashtable, removeClassFromHashtable()
   */

  public synchronized boolean removeClass(String className)
  {
    //  Get a reference to the global class hashtable.
    Hashtable classHashtable = 
      (Hashtable)(threadHashtable.get("GLOBAL_CLASSES"));

    return Utilities.removeClassFromHashtable(classHashtable, 
                                                   className);
  }


  /**
   * Get the Context for a specific thread.
   *
   * @concurrency GUARDED
   * @param thread the thread that we are interested in.
   * @return the Context corresponding to thread, or null if no
   * such context exists.
   */

  public synchronized Context getContext(Thread thread)
  {
    if (threadHashtable.containsKey(thread))
      return (Context)(threadHashtable.get(thread));
    else return null;
  }


  /**
   * Adds a Context to the the class-global database of threads
   * that have debugging context.
   *
   * @concurrency GUARDED
   * @precondition (debugContext != null)
   * @param debugContext is the Context that we are interested in
   * adding.
   * @modifies threadHashtable
   * @return a boolean indicating if the Context was added to the
   * database sucessfully or that the thread was already in the
   * database.  A false indicates that the Context was invalid.
   * @uses threadHashtable
   */

  public synchronized boolean addContext(Context debugContext)
  {
    if (debugContext != null)
    {
      threadHashtable.put(debugContext.getThread(), debugContext);
      return true;
    }
    else return false;
  }
  

  /**
   * Removes a Context from the the class-global database of
   * threads that have debugging context.
   *
   * @concurrency GUARDED
   * @precondition (debugContext != null)
   * @param debugContext is the Context that we are interested in
   * removing.
   * @modifies threadHashtable
   * @return a boolean indicating if the Context was removed from
   * the database sucessfully or that the thread was not in the
   * database at all.  A false indicates that the Context was
   * invalid or not in the table.
   * @uses threadHashtable
   */

  public synchronized boolean 
    removeContext(Context debugContext)
  {
    if ((debugContext != null) && 
        (threadHashtable.containsKey(debugContext)))
    {
      threadHashtable.remove(debugContext);
      return true;
    }
    else return false;
  }


  /**
   * Returns an Enumeration that is the list of class-global classes
   * that have debugging enabled.
   *
   * @concurrency GUARDED
   * @modifies threadHashtable
   * @return an Enumeration that is the list of class-global classes
   * that currently have debugging enabled (they are in the class
   * database). Returns a null if a null is passed, otherwise a
   * zero-length Enumeration will be returned if there is no
   * information on the thread at all.
   * @uses threadHashtable
   * @see Hashtable#elements
   */

  public synchronized Enumeration listClasses()
  {
    // Get global category hashtable.
    Hashtable hashtable = 
      (Hashtable)(threadHashtable.get("GLOBAL_CLASSES"));
    
    return (hashtable.elements());
  }
  

  /**
   * Set a new class-global debugging level.
   *
   * @concurrency GUARDED
   * @precondition ((l >= debugConstants.LEVEL_MIN) && 
   * (l <= debugConstants.LEVEL_MAX))
   * @modifies level
   * @param level the new debugging level.
   * @return a boolean indicating whether the level change succeeded.
   * The only reason why a setLevel might fail is if the level passed
   * is out of range.
   * @uses level
   */

  public synchronized boolean setLevel(int level)
  {
    if ((level >= debugConstants.LEVEL_MIN) && 
        (level <= debugConstants.LEVEL_MAX))
    {
      this.level = level;
      return true;
    }
    else return false;
    
  }


  /**
   * Returns the current class-global debugging level.
   *
   * @concurrency GUARDED
   * @return the current class-global debugging level.
   * @uses level
   */

  public synchronized int getLevel()
  {
    return level;
  }
  

  /**
   * Returns an Enumeration that is the list of class-global threads
   * that have debugging enabled.
   *
   * @concurrency GUARDED
   * @modifies threadHashtable
   * @return an Enumeration that is the list of class-global threads
   * that currently have debugging enabled (they are in the thread
   * database).
   * @uses threadHashtable
   * @see Hashtable#keys
   */

  public synchronized Enumeration listThreads()
  {
    return threadHashtable.keys();
  }
}
