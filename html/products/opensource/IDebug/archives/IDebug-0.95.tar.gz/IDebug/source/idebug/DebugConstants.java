/*
 * Software Engineering Tools.
 *
 * $Id: DebugConstants.java,v 1.5 2000/06/26 05:39:34 kiniry Exp $
 *
 * Copyright (c) 1997-2000 Joseph Kiniry
 * Copyright (c) 2000 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL SRI INTERNATIONAL OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebug;

import java.util.Hashtable;

/**
 * DebugConstants is an interface that collects the various
 * constants of the debugging package including debug level ranges,
 * standard debugging messages, etc.  It can be subtyped to change the
 * various values contained herein for specific debugging subpackages,
 * applications, etc.  An example of such a subtype is included as
 * FrenchConstants. The default categories are specified in
 * the following table.
 * <TABLE ALIGN=ABSCENTER BORDER=1 CELLSPACING=0 CELLPADDING=0>
 * <TR>
 * <TD> <STRONG>Category</STRONG> </TD>
 * <TD> <STRONG>Level</STRONG> </TD>
 * <TD> <STRONG>Description</STRONG> </TD>
 * </TR>
 * <TR>
 * <TD> ASSERTION </TD>
 * <TD> 9 </TD>
 * <TD> The highest level category that exists.  Assertions are
 * predicates that <STRONG>must</STRONG> be true.  If an assertion
 * is false, a stack dump takes place and the object in question
 * should shut down in an orderly fashion.
 * Note that a single assertion should be made for each predicate
 * that is in the precondition, postcondition, requires, and ensures
 * expressions for every method. </TD>
 * </TR>
 * <TR>
 * <TD> FAILURE </TD>
 * <TD> 9 </TD>
 * <TD> The highest level category that exists.  Sometimes a object
 * need fail outside an assertion.  This default category provides
 * this functionality.  If a failure is seen, a stack dump takes
 * place and the object in question should shut down in an orderly
 * fashion.</TD>
 * </TR>
 * <TR>
 * <TD> CRITICAL </TD>
 * <TD> 7 </TD>
 * <TD> Very important problems/errors that will eventually cause
 * Failures or Assertions should be tagged as Critical.  The
 * user/system must be information of such problems but the object
 * in question need not shut down immediately and can potentially
 * recover.  Typical examples of Critial errors are resource-related
 * errors (out of memory, disk space, cpu time, etc.).</TD>
 * </TR>
 * <TR>
 * <TD> ERROR </TD>
 * <TD> 5 </TD>
 * <TD> This is the standard error level.  An Error means "something
 * went wrong and the user should probably be notified whether the
 * the system can automatically recover properly or not".</TD>
 * </TR>
 * <TR>
 * <TD> WARNING </TD>
 * <TD> 3 </TD>
 * <TD> A warning is a message that says something has gone wrong
 * but it's not terribly serious.  Warnings are often, but not always,
 * communicated on to the user.</TD>
 * </TR>
 * <TR>
 * <TD> NOTICE </TD>
 * <TD> 1 </TD>
 * <TD> A notice is simply a progress message.  Notices are used to
 * track a thread of control during debugging.</TD>
 * </TR>
 * </TABLE>
 *
 * @version $Revision: 1.5 $ $Date: 2000/06/26 05:39:34 $
 * @author Joseph R. Kiniry
 * @see Debug
 * @see Context
 * @see DefaultDebugConstants
 * @see idebug.examples.FrenchConstants
 */

public interface DebugConstants
{
  /**
   * The minimum debug level.
   *
   * @design Higher valued levels usually indicate higher priorities.
   * E.g.  a level 9 message is in the default implementation an
   * asssertion; if it fails, the program exits.  A level 5 message is
   * an error and the user should probably be informed of the problem.
   * You can override this behavior by subtyping
   * DebugConstants and installing the new constant set with
   * the Debug.XXX() method.
   */

  int LEVEL_MIN = 0;


  /**
   * The maximum debug level.
   */

  int LEVEL_MAX = 9;


  /**
   * Various messages that can be localized or otherwise customized.
   */

  String ERROR_STRING = "Error";
  String FAILED_ASSERTION_STRING = "Failed assertion";


  // The default debugging levels are pre-defined to simplify the use
  // of the print() and println() functions for simple debugging.

  /**
   * The highest level category that exists.  Assertions are
   * predicates that <STRONG>must</STRONG> be true.  If an assertion
   * is false, a stack dump takes place and the object in question
   * should shut down in an orderly fashion.
   * Note that a single assertion should be made for each predicate
   * that is in the precondition, postcondition, requires, and ensures
   * expressions for every method.
   */

  int ASSERTION_LEVEL = 9;

  /**
   * The highest level category that exists.  Sometimes a object
   * need fail outside an assertion.  This default category provides
   * this functionality.  If a failure is seen, a stack dump takes
   * place and the object in question should shut down in an orderly
   * fashion.
   */

  int FAILURE_LEVEL = 9;

  /**
   * Very important problems/errors that will eventually cause
   * Failures or Assertions should be tagged as Critical.  The
   * user/system must be information of such problems but the object
   * in question need not shut down immediately and can potentially
   * recover.  Typical examples of Critial errors are resource-related
   * errors (out of memory, disk space, cpu time, etc.).
   */

  int CRITICAL_LEVEL = 7;

  /**
   * This is the standard error level.  An Error means "something
   * went wrong and the user should probably be notified whether the
   * the system can automatically recover properly or not".
   */

  int ERROR_LEVEL = 5;

  /**
   * A warning is a message that says something has gone wrong
   * but it's not terribly serious.  Warnings are often, but not always,
   * communicated on to the user.
   */

  int WARNING_LEVEL = 3;

  /**
   * A notice is simply a progress message.  Notices are used to
   * track a thread of control during debugging.
   */

  int NOTICE_LEVEL = 1;

  // The default debugging categories are pre-defined to simplify the
  // use of the print() and println() functions for simple debugging.

  /**
   * The highest level category that exists.  Assertions are
   * predicates that <STRONG>must</STRONG> be true.  If an assertion
   * is false, a stack dump takes place and the object in question
   * should shut down in an orderly fashion.
   * Note that a single assertion should be made for each predicate
   * that is in the precondition, postcondition, requires, and ensures
   * expressions for every method.
   */

  String ASSERTION = "ASSERTION";

  /**
   * The highest level category that exists.  Sometimes a object
   * need fail outside an assertion.  This default category provides
   * this functionality.  If a failure is seen, a stack dump takes
   * place and the object in question should shut down in an orderly
   * fashion.
   */

  String FAILURE = "FAILURE";

  /**
   * Very important problems/errors that will eventually cause
   * Failures or Assertions should be tagged as Critical.  The
   * user/system must be information of such problems but the object
   * in question need not shut down immediately and can potentially
   * recover.  Typical examples of Critial errors are resource-related
   * errors (out of memory, disk space, cpu time, etc.).
   */

  String CRITICAL = "CRITICAL";

  /**
   * This is the standard error level.  An Error means "something
   * went wrong and the user should probably be notified whether the
   * the system can automatically recover properly or not".
   */

  String ERROR = "ERROR";

  /**
   * A warning is a message that says something has gone wrong
   * but it's not terribly serious.  Warnings are often, but not always,
   * communicated on to the user.
   */

  String WARNING = "WARNING";

  /**
   * A notice is simply a progress message.  Notices are used to
   * track a thread of control during debugging.
   */

  String NOTICE = "NOTICE";

  // Error condition for the Debug class.

  /**
   * Indicates that an invalid thread was passed to a thread-related
   * method in idebug.Debug.
   */

  int INVALID_THREAD = -1;

  /**
   * Initializes default categories of debugging facilities.
   *
   * @concurrency CONCURRENT
   * @precondition (hashtable != null) Parameters must be valid.
   * @modifies (hashtable) Default categories with complementary
   * levels are inserted into the hashtable.
   * @postcondition (hashtable.size() == 6) We are inserting the
   * default six types of categories into the default implementation
   * of DebugConstants.
   * @param hashtable is the hashtable to initialize.
   */

  void initCategories(Hashtable hashtable);
}
