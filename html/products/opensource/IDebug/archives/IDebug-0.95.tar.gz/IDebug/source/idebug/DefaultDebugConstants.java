/*
 * Software Engineering Tools.
 *
 * $Id: DefaultDebugConstants.java,v 1.5 2000/06/26 06:34:24 kiniry Exp $
 *
 * Copyright (c) 1997-2000 Joseph Kiniry
 * Copyright (c) 2000 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL SRI INTERNATIONAL OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebug;

import java.util.Hashtable;

/**
 * The default implementation of debug semantics for the IDebug
 * framework.
 *
 * @version $Revision: 1.5 $ $Date: 2000/06/26 06:34:24 $
 * @author Joseph R. Kiniry
 */

public class DefaultDebugConstants implements DebugConstants
{
  /**
   * Initializes default categories of debugging facilities.
   *
   * @concurrency CONCURRENT
   * @precondition (hashtable != null) Parameters must be valid.
   * @modifies (hashtable) Default categories with complementary
   * levels are inserted into the hashtable.
   * @postcondition (hashtable.size() == 6) We are inserting the
   * default six types of categories into the default implementation
   * of DebugConstants.
   * @param hashtable is the hashtable to initialize.
   *
   * The default debug categories are documented in
   * DebugConstants.
   *
   * @uses println()
   */

  public void initCategories(Hashtable hashtable)
  {
    hashtable.put(ASSERTION, new Integer(ASSERTION_LEVEL));
    hashtable.put(FAILURE, new Integer(FAILURE_LEVEL));
    hashtable.put(CRITICAL, new Integer(CRITICAL_LEVEL));
    hashtable.put(ERROR, new Integer(ERROR_LEVEL));
    hashtable.put(WARNING, new Integer(WARNING_LEVEL));
    hashtable.put(NOTICE, new Integer(NOTICE_LEVEL));

    return;
  }
}
