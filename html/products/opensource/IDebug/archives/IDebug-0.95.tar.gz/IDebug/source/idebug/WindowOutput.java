/*
 * Software Engineering Tools.
 *
 * $Id: WindowOutput.java,v 1.4 2000/06/26 05:39:36 kiniry Exp $
 *
 * Copyright (c) 1997-2000 Joseph Kiniry
 * Copyright (c) 2000 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL SRI INTERNATIONAL OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebug;

import java.io.Writer;

/**
 * The primary class used to send messages to a window created by
 * the IDebug framework.  This class has <em>not</em> been implementated
 * yet.  It is empty.
 *
 * @version $Revision: 1.4 $ $Date: 2000/06/26 05:39:36 $
 * @author Joseph R. Kiniry
 * @see DebugOutput
 * @see Context
 * @see Debug
 */

public class WindowOutput implements DebugOutput
{
  /**
   * The Debug object associated with this WindowOutput object.
   *
   * @supplierRole debug
   */
  
  private Debug debug;
  
  
  /**
   * Construct a new WindowOutput class.
   *
   * @param debug the Debug class associated with this
   * WindowOutput.
   */
  
  public WindowOutput(Debug d)
  {
    this.debug = d;
  }
  
  
  /**
   * Print out the debugging message, no questions asked.
   * @concurrency CONCURRENT
   * @param category is the category of this message.
   * @param message is the debugging message to print.
   */
  
  public synchronized void printMsg(String category, String message)
  {
  }
  
  
  /**
   * Print out the debugging message, no questions asked.
   *
   * @concurrency CONCURRENT
   * @returns a boolean indicating if the message was printed.
   * @param level The debugging level of this message.
   * @param message The debugging message to print.
   */

  public synchronized void printMsg(int level, String message)
  {
  }
  
  
  /**
   * Print out the debugging message, no questions asked.
   *
   * @concurrency CONCURRENT
   * @param message The debugging message to print.
   */
  
  public synchronized void printMsg(String message)
  {
  }
  
  
  /**
   * Print out a debugging message if the debugging context warrents.
   *
   * @concurrency CONCURRENT
   * @precondition ((level >= DebugConstants.LEVEL_MIN) && 
   * (level <= DebugConstants.LEVEL_MAX) && (message != null) && 
   * (message.length() > 0))
   * @returns a boolean indicating if the message was printed.
   * @param level The debugging level of this message.
   * @param message The debugging message to print.
   */
  
  public synchronized boolean print(int level, String message)
  {
    return false;
  }
  
  
  
  /**
   * Print out an object if the debugging context warrents.
   *
   * @concurrency CONCURRENT
   * @precondition ((level >= DebugConstants.LEVEL_MIN) && 
   * (level <= DebugConstants.LEVEL_MAX) && (object != null))
   * @returns a boolean indicating if the message was printed.
   * @param level The debugging level of this message.
   * @param object The object to print.
   */
  
  public synchronized boolean print(int level, Object object)
  {
    return false;
  }
  
  
  
  /**
   * Print out an object if the debugging context warrents.
   *
   * @concurrency CONCURRENT
   * @precondition ((category != null) && (category.length() > 0) &&
   * (object != null))
   * @returns a boolean indicating if the message was printed.
   * @param category The category of this message.
   * @param object The object to print.
   */
  
  public synchronized boolean print(String category, Object object)
  {
    return false;
  }
  
  
  
  /**
   * Print out a debugging message if the debugging context warrents.
   *
   * @concurrency CONCURRENT
   * @precondition ((category != null) && (category.length() > 0) &&
   * (message != null) && (message.length() > 0))
   * @returns a boolean indicating if the message was printed.
   * @param category The category of this message.
   * @param message The debugging message to print.
   */
  
  public synchronized boolean print(String category, String message)
  {
    return false;
  }
  
  
  
  /**
   * Print out an object if the debugging context warrents.
   *
   * @concurrency CONCURRENT
   * @precondition ((category != null) && (category.length() > 0) &&
   * (object != null))
   * @returns a boolean indicating if the message was printed.
   * @param category The category of this message.
   * @param object The object to print.
   */
  
  public synchronized boolean println(String category, Object object)
  {
    return false;
  }
  
  
  
  /**
   * Print out a debugging message if the debugging context warrents.
   *
   * @concurrency CONCURRENT
   * @precondition ((category != null) && (category.length() > 0) &&
   * (message != null) && (message.length() > 0))
   * @returns a boolean indicating if the message was printed.
   * @param category The category of this message.
   * @param message The debugging message to print.
   */
  
  public synchronized boolean println(String category, String message)
  {
    return false;
  }
  
  
  
  /**
   * Print out an object if the debugging context warrents.
   *
   * @concurrency CONCURRENT
   * @precondition ((level >= DebugConstants.LEVEL_MIN) && 
   * (level <= DebugConstants.LEVEL_MAX) && (object != null))
   * @returns a boolean indicating if the message was printed.
   * @param level The debugging level of this message.
   * @param object The object to print.
   */
  
  public synchronized boolean println(int level, Object object)
  {
    return false;
  }
  
  
  
  /**
   * Print out a debugging message if the debugging context warrents.
   *
   * @concurrency CONCURRENT
   * @precondition ((level >= DebugConstants.LEVEL_MIN) && 
   * (level <= DebugConstants.LEVEL_MAX) && (message != null) && 
   * (message.length() > 0))
   * @returns a boolean indicating if the message was printed.
   * @param level The debugging level of this message.
   * @param message The debugging message to print.
   */
  
  public synchronized boolean println(int level, String message)
  {
    return false;
  }
  
  
  
  /**
   * Returns a Writer for this output interface if one is available.
   *
   * @concurrency CONCURRENT
   * @return a Writer for this output interface if one is available.
   * @see java.io.Writer
   */
  
  public Writer getWriter()
  {
    return null;
  }
}
