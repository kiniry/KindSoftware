/*
 * Software Engineering Tools.
 *
 * $Id: WriterOutput.java,v 1.4 2000/06/26 05:39:36 kiniry Exp $
 *
 * Copyright (c) 1997-2000 Joseph Kiniry
 * Copyright (c) 2000 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL SRI INTERNATIONAL OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebug;

import java.io.PrintWriter;
import java.io.Writer;

/**
 * The primary class used to send debugging messages to a 
 * PrintWriter output channel.
 * @version $Revision: 1.4 $ $Date: 2000/06/26 05:39:36 $
 * @author Joseph R. Kiniry
 * @see DebugOutput
 * @see Context
 * @see Debug
 */

public class WriterOutput implements DebugOutput
{
  /**
   * The Debug object associated with this Assert object.
   *
   * @supplierRole debug
   */

  private Debug debug;
  

  /**
   * The output channel used by this WriterOutput.
   */

  PrintWriter printWriter = new PrintWriter(System.err, true);


  /**
   * Constructor for WriterOutput.
   *
   * @param debug the Debug class associated with this
   * WriterOutput.
   */

  public WriterOutput(Debug d)
  {
    super();
    this.debug = d;
  }
  

  /**
   * Constructor for WriterOutput.
   *
   * @param debug the Debug class associated with this
   * WriterOutput.
   * @param printWriter the new PrintWriter for this
   * WriterOutput.
   * @precondition ((debug != null) && (printWriter != null))
   */

  public WriterOutput(Debug d, PrintWriter p)
  {
    this.debug = d;
    this.printWriter = p;
  }


  /**
   * Set a new PrintWriter for this WriterOutput.
   *
   * @param printWriter the new PrintWriter for this
   * WriterOutput.
   * @precondition (printWriter != null)
   */

  public void setPrintWriter(PrintWriter p)
  {
    this.printWriter = p;
  }
  

  /**
   * Print out the debugging message, no questions asked.
   *
   * @concurrency GUARDED
   * @param category is the category of this message.
   * @param message is the debugging message to print.
   * @uses System.err.print()
   */

  public synchronized void printMsg(String category, String message)
  {
    System.err.print("<" + category + ">: " + message);
  }


  /**
   * Print out the debugging message, no questions asked.
   *
   * @concurrency GUARDED
   * @returns a boolean indicating if the message was printed.
   * @param level The debugging level of this message.
   * @param message The debugging message to print.
   * @uses System.err.print()
   */

  public synchronized void printMsg(int level, String message)
  {
    System.err.print("[" + level + "]: " + message);
  }


  /**
   * Print out the debugging message, no questions asked.
   *
   * @concurrency GUARDED
   * @param message The debugging message to print.
   * @uses System.err.print();
   */

  public synchronized void printMsg(String message)
  {
    System.err.print(message);
  }


  /**
   * Print out a debugging message if the debugging context warrents.
   *
   * @concurrency GUARDED
   * @returns a boolean indicating if the message was printed.
   * @param category is the category of this message.
   * @param message is the debugging message to print.
   * @uses threadHashtable, printMsg()
   */

  public synchronized boolean print(String category, String message)
  {
    if (debug.debugUtilities.categoryTest(category))
    {
      printMsg(category, message);
      return true;
    }
    else
      return false;
  }


  /**
   * Print out a debugging message if the debugging context warrents.
   *
   * @concurrency GUARDED
   * @returns a boolean indicating if the message was printed.
   * @param category is the category of this message.
   * @param object is the object that should be printed.
   * @uses print()
   */

  public synchronized boolean print(String category, Object object)
  {
    return print(category, object.toString());
  }


  /**
   * Print out a debugging message if the debugging context warrents.
   *
   * @concurrency GUARDED
   * @returns a boolean indicating if the message was printed.
   * @param level The debugging level of this message.
   * @param message The debugging message to print.
   * @uses threadHashtable
   */

  public synchronized boolean print(int level, String message)
  {
    if (debug.debugUtilities.levelTest(level))
    {
      printMsg(level, message);
      return true;
    }
    else return false;
  }


  /**
   * Print out an object if the debugging context warrents.
   *
   * @concurrency GUARDED
   * @returns a boolean indicating if the message was printed.
   * @param level The debugging level of this message.
   * @param object The object to print.
   * @uses print()
   */

  public synchronized boolean print(int level, Object object)
  {
    return print(level, object.toString());
  }
  

  /**
   * Print out an object if the debugging context warrents.
   *
   * @concurrency GUARDED
   * @returns a boolean indicating if the message was printed.
   * @param category The category of this message.
   * @param object The object to print.
   * @uses print()
   */

  public synchronized boolean println(String category, Object object)
  {
    return println(category, object.toString());
  }

  
  /**
   * Print out a debugging message if the debugging context warrents.
   *
   * @concurrency GUARDED
   * @returns a boolean indicating if the message was printed.
   * @param category The category of this message.
   * @param message The debugging message to print.
   * @uses print()
   */

  public synchronized boolean println(String category, String message)
  {
    return print(category, message + "\n");
  }


  /**
   * Print out an object if the debugging context warrents.
   *
   * @concurrency GUARDED
   * @returns a boolean indicating if the message was printed.
   * @param level The debugging level of this message.
   * @param object The object to print.
   * @uses print()
   */

  public synchronized boolean println(int level, Object object)
  {
    return println(level, object.toString());
  }


  /**
   * Print out a debugging message if the debugging context warrents.
   *
   * @concurrency GUARDED
   * @returns a boolean indicating if the message was printed.
   * @param level The debugging level of this message.
   * @param message The debugging message to print.
   * @uses print(int, java.lang.String)
   */

  public synchronized boolean println(int level, String message)
  {
    return print(level, message + "\n");
  }


  /**
   * Returns a Writer for this output interface if one is available.
   *
   * @concurrency CONCURRENT
   * @return a Writer for this output interface if one is available.
   * @see java.io.Writer
   */

  public synchronized Writer getWriter()
  {
    return printWriter;
  }
}

