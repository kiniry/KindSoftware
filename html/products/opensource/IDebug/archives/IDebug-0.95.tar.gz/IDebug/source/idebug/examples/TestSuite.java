/*
 * Software Engineering Tools.
 *
 * $Id: TestSuite.java,v 1.4 2000/06/26 05:39:37 kiniry Exp $
 *
 * Copyright (c) 1997-2000 Joseph Kiniry
 * Copyright (c) 2000 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL SRI INTERNATIONAL OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebug.examples;

/**
 * TestSuite is the black-box testsuite for the Debug class.
 * @version $Date: 2000/06/26 05:39:37 $
 * @author Joseph R. Kiniry
 *
 * @history Tests originally were located in a main() method of the
 * Debug class.  They were moved to this class as of version 0.15 (or
 * so) of Debug to reduce Debug's (already large) code size.  The
 * tests were then rewritten to conform to the new debug interface as
 * of debug version 0.18.  Real version is (0.05 + Id - 1) at this
 * point in time.
 * @design The success boolean is a running indicator of the success
 * of the test suite.  The return value of every method in Debug is
 * checked and and-ed, as appropriate, with success.  I.e. If any one
 * such method returns a value we didn't expect, we would be and-ing
 * with a false and the final value would be a false.
 *
 * @note The top-level class of the IDebug test suite.
 */

public class TestSuite
{
  /**
   * A main() that contains the test code for the Debug class.
   *
   * @design Since the debug package now is non-static, we have to
   * start up our own thread of control.
   */

  public static void main(String [] argv)
  {
    TestSuiteThread testSuiteThread = new TestSuiteThread();
    testSuiteThread.start();
  }
  /**@shapeType DependencyLink*/
  /*#  TestSuiteThread lnkUnnamed*/
}
