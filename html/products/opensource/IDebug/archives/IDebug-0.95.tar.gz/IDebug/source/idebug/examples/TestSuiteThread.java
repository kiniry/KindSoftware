/*
 * Software Engineering Tools.
 *
 * $Id: TestSuiteThread.java,v 1.5 2000/06/26 05:39:37 kiniry Exp $
 *
 * Copyright (c) 1997-2000 Joseph Kiniry
 * Copyright (c) 2000 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL SRI INTERNATIONAL OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebug.examples;

import idebug.Assert;
import idebug.ConsoleOutput;
import idebug.Context;
import idebug.Debug;
import idebug.DebugConstants;
import idebug.DebugOutput;
import idebug.DefaultDebugConstants;

/**
 * TestSuite is the black-box testsuite for the Debug class.
 *
 * @version $Date: 2000/06/26 05:39:37 $
 * @author Joseph R. Kiniry
 *
 * @note The actual code of the IDebug test suite.
 */

public class TestSuiteThread extends Thread
{
  boolean value;
  boolean success = true;
  
  public void run()
  {
    Debug debug = new Debug();
    
    System.out.println("TESTING DEBUG CLASS.\n");
    
    System.out.println("Class-global testing\n" +
                       "====================");
    
    // Collect all the necessary references to the debugging modules.
    
    // Assert assert = debug.getAssert();
    DebugConstants debugConstants = debug.getDebugConstants();
    DebugOutput debugOutput = new ConsoleOutput(debug);
    debug.setOutputInterface(debugOutput);
    
    // First we will test the default configuration (console output,
    // no new levels or categories.
    
    // Class-global testing.
    success &= (!debugOutput.println(debugConstants.ASSERTION_LEVEL, 
                                     "FAILED"));
    if (!success)
      System.err.println("FALURE #0");
    success &= (!debugOutput.println(debugConstants.ASSERTION, "FAILED"));
    if (!success)
      System.err.println("FALURE #1");
    
    debug.turnOn();
    success &= debugOutput.println(debugConstants.FAILURE_LEVEL, "PASSED");
    if (!success)
      System.err.println("FALURE #2");
    
    success &= debugOutput.println(debugConstants.FAILURE, "PASSED");
    if (!success)
      System.err.println("FALURE #3");
    
    success &= debug.setLevel(debugConstants.ERROR_LEVEL);
    if (!success)
      System.err.println("FALURE #4");
    
    success &= (!debugOutput.println(debugConstants.ERROR_LEVEL-1, "FAILED"));
    if (!success)
      System.err.println("FALURE #5");
    
    success &= (!debugOutput.println(debugConstants.WARNING, "FAILED"));
    if (!success)
      System.err.println("FALURE #6");
    
    success &= debugOutput.println(debugConstants.ERROR_LEVEL, "PASSED");
    if (!success)
      System.err.println("FALURE #7");
    
    success &= debugOutput.println(debugConstants.ERROR, "PASSED");
    if (!success)
      System.err.println("FALURE #8");
    
    success &= debugOutput.println(debugConstants.ERROR_LEVEL+1, "PASSED");
    if (!success)
      System.err.println("FALURE #9");
    
    success &= debugOutput.println(debugConstants.CRITICAL, "PASSED");
    if (!success)
      System.err.println("FALURE #10");
    
    success &= debugOutput.println(debugConstants.ASSERTION_LEVEL, "PASSED");
    if (!success)
      System.err.println("FALURE #11");
    
    success &= debugOutput.println(debugConstants.ASSERTION, "PASSED");
    if (!success)
      System.err.println("FALURE #12");
    
    /*
     success &= (!debug.setLevel(-1));
     success &= (!debug.setLevel(10));
     */
    
    success &= debug.setLevel(0);
    if (!success)
      System.err.println("FALURE #13");
    
    success &= debugOutput.println(0, "PASSED");    
    if (!success)
      System.err.println("FALURE #14");
    
    success &= debugOutput.println(debugConstants.NOTICE_LEVEL, "PASSED");
    if (!success)
      System.err.println("FALURE #15");
    
    success &= debugOutput.println(debugConstants.NOTICE, "PASSED");
    if (!success)
      System.err.println("FALURE #16");
    
    success &= debugOutput.println(debugConstants.ASSERTION_LEVEL, "PASSED");
    if (!success)
      System.err.println("FALURE #17");
    
    success &= debugOutput.println(debugConstants.ASSERTION, "PASSED");    
    if (!success)
      System.err.println("FALURE #18");
    
    /*
     success &= (!debugOutput.println(-1, "FAILED"));
     success &= (!debugOutput.println(10, "FAILED"));
     */
    
    success &= debug.addCategory("NETWORK_6", 6);
    if (!success)
      System.err.println("FALURE #19");
    
    success &= debug.addCategory("NETWORK_5", 5);
    if (!success)
      System.err.println("FALURE #20");
    
    success &= debug.addCategory("NETWORK_4", 4);
    if (!success)
      System.err.println("FALURE #21");
    
    success &= debug.setLevel(5);
    if (!success)
      System.err.println("FALURE #22");
    
    success &= debugOutput.println(5, "PASSED");
    if (!success)
      System.err.println("FALURE #23");
    
    success &= debugOutput.println("NETWORK_5", "PASSED");
    if (!success)
      System.err.println("FALURE #24");
    
    success &= (!debugOutput.println("NETWORK_4", "FAILED"));
    if (!success)
      System.err.println("FALURE #25");
    
    success &= debugOutput.println("NETWORK_6", "PASSED");
    if (!success)
      System.err.println("FALURE #26");
    
    success &= debug.removeCategory("NETWORK_5");
    if (!success)
      System.err.println("FALURE #27");
    
    success &= (!debugOutput.println("NETWORK_5", "FAILED"));
    if (!success)
      System.err.println("FALURE #28");
    
    debug.turnOff();
    
    System.out.println("\nPer-thread testing\n" +
                       "====================");
    
    // Per-thread testing begins.
    
    Context debugContext = 
      new Context(new DefaultDebugConstants(),
                       new ConsoleOutput(debug));
    
    // Note that we have turned off global debugging, so all of the
    // following is testing the case when a thread has debugging on
    // and global debugging is off.  A bit later, we'll turn global
    // debugging back on and the various "fall-back" scenarios.
    
    debugContext.turnOn();
    
    success &= debugContext.setLevel(debugConstants.ERROR_LEVEL);
    if (!success)
      System.err.println("FALURE #30");
    
    success &= debugContext.addCategory("PERTHREAD-1", 
                                        debugConstants.ERROR_LEVEL-1);
    if (!success)
      System.err.println("FALURE #31");
    
    success &= debugContext.addCategory("PERTHREAD+1", 
                                        debugConstants.ERROR_LEVEL+1);
    if (!success)
      System.err.println("FALURE #32");
    
    // Install the new context.
    
    debug.addContext(debugContext);
    
    success &= debugOutput.println(debugConstants.ERROR_LEVEL, "SUCCESS");
    if (!success)
      System.err.println("FALURE #33");
    
    success &= debugOutput.println(debugConstants.ERROR_LEVEL+1, "SUCCESS");
    if (!success)
      System.err.println("FALURE #34");
    
    success &= (!debugOutput.println(debugConstants.ERROR_LEVEL-1, "FAILURE"));
    if (!success)
      System.err.println("FALURE #35");
    
    success &= (!debugOutput.println("PERTHREAD-1", "FAILURE"));
    if (!success)
      System.err.println("FALURE #36");
    
    success &= debugOutput.println("PERTHREAD+1", "SUCCESS");
    if (!success)
      System.err.println("FALURE #37");
    
    success &= debugContext.setLevel(debugConstants.ERROR_LEVEL-1);
    if (!success)
      System.err.println("FALURE #38");
    
    success &= debugOutput.println(debugConstants.ERROR_LEVEL+1, "SUCCESS");
    if (!success)
      System.err.println("FALURE #39");
    
    success &= debugOutput.println(debugConstants.ERROR_LEVEL-1, "SUCCESS");
    if (!success)
      System.err.println("FALURE #40");
    
    success &= debugOutput.println("PERTHREAD-1", "SUCCESS");
    if (!success)
      System.err.println("FALURE #41");
    
    success &= debugOutput.println("PERTHREAD+1", "SUCCESS");
    if (!success)
      System.err.println("FALURE #42");
    
    // Now, we'll turn back on global debugging and try some tricky
    // combinations.
    
    debug.turnOn();
    
    // Global level is where we left it (5).  Current thread level is
    // ERROR_LEVEL-1, which is 4.  So, let's change the global to
    // ERROR_LEVEL and the per-thread to CRITICAL_LEVEL and see if we
    // can still get a rise out of the system.
    
    debug.setLevel(debugConstants.ERROR_LEVEL);
    debugContext.setLevel(debugConstants.CRITICAL_LEVEL);
    
    success &= debugOutput.println(debugConstants.CRITICAL, "SUCCESS");
    if (!success)
      System.err.println("FALURE #43");
    
    success &= (!debugOutput.println(debugConstants.NOTICE, "FAILURE"));
    if (!success)
      System.err.println("FALURE #44");
    
    // This should succeed because the global level is ERROR_LEVEL.
    success &= debugOutput.println(debugConstants.ERROR, "SUCCESS");
    if (!success)
      System.err.println("FALURE #45");
    
    success &= debugOutput.println(debugConstants.FAILURE, "SUCCESS");
    if (!success)
      System.err.println("FALURE #46");
    
    // End of tests
    System.out.println("Testing concluded.");
    
    if (success)
      System.out.println("Debugging tests succeeded!");
    else
      System.out.println("Debugging tests failed!");
  }
}
