/*
 * Software Engineering Tools.
 *
 * $Id: Assert.jass,v 1.8 2001/05/29 05:05:58 kiniry Exp $
 *
 * Copyright (c) 1997-2001 Joseph Kiniry
 * Copyright (c) 2000-2001 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS
 * IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL KIND SOFTWARE OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebughc;

/**
 * <p> The core interface to making assertions. </p>
 *
 * @version $Revision: 1.8 $ $Date: 2001/05/29 05:05:58 $
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @see Debug
 * @see Context
 */

public class Assert implements Cloneable
{
  // Attributes

  /**
   * <p> The <code>Debug</code> object associated with this
   * <code>Assert</code> object. </p>
   *
   * @modifies SINGLE-ASSIGNMENT
   */

  private Debug debug;

  // Inherited Methods

  public Object clone()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "clone()", true), jassParameters);
  	java.lang.Object jassResult;

    try {
  		jassResult = ( super.clone());
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "clone()", false), jassParameters);


  		return jassResult;
    } catch (CloneNotSupportedException cnse) {
      throw new RuntimeException(cnse.getMessage());
    }
  }

  // Constructors

  /**
   * <p> Construct a new <code>Assert</code> class. </p>
   *
   * @modifies debug
   */

  Assert(Debug d)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(d)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "Assert(idebughc.Debug)", true), jassParameters);


  	idebughc.Assert jassOld = (idebughc.Assert)this.clone();
  	/* precondition */
  	if (!((d!=null))) throw new jass.runtime.PreconditionException("idebughc.Assert","Assert(idebughc.Debug)",86,"d_non_null");

    debug = d;
  	/* postcondition */
  	if (!((debug==d))) throw new jass.runtime.PostconditionException("idebughc.Assert","Assert(idebughc.Debug)",90,"debug_is_valid");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "Assert(idebughc.Debug)", false), jassParameters);

  }
  
  // Public Methods

  /**
   * <p> Assert that the passed boolean expression evaluates to true.  If
   * it does not, the assertion fails, a stack dump takes place via the
   * current debugging output channel, and a
   * <var>FailedAssertionException</var> is thrown. </p>
   *
   * <dl><dt><b>Ensures:</b></dt><dd><code><b>exception_thrown_correctly</b>: (assertion==true)</code></dd></dl> 
@param assertion is the boolean expression to assert.
   *
   * @concurrency GUARDED
   * @modifies QUERY
   * @postcondition ((assertion == false) implies 
   *                 (throw new FailedAssertionException))
   */

  public static synchronized void assert(boolean assertion)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(assertion)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(null, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "assert(boolean)", true), jassParameters);


    if (!assertion) {
      Utilities.dumpStackSafe();
      throw new FailedAssertionException();
    }
  	/* postcondition */
  	if (!((assertion==true))) throw new jass.runtime.PostconditionException("idebughc.Assert","assert(boolean)",117,"exception_thrown_correctly");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(null, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "assert(boolean)", false), jassParameters);

    // cannnot use changeonly{] in static methods because there is no this
    // to reference.
  }

  /**
   * <p> Assert that the passed boolean expression evaluates to true.  If
   * it does not, the assertion fails, a stack dump takes place, and a
   * <var>FailedAssertionException</var> is thrown. </p>
   *
   * <dl><dt><b>Ensures:</b></dt><dd><code><b>exception_thrown_correctly</b>: (assertion==true)</code></dd></dl> 
@param assertion is the boolean expression to assert.
   * @param assertionString is the text of the assertion itself.
   *
   * @concurrency GUARDED
   * @modifies QUERY
   * @postcondition ((assertion == false) implies 
   *                 (throw new FailedAssertionException))
   */

  public synchronized void assert(boolean assertion, String assertionString)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(assertion), new jass.runtime.traceAssertion.Parameter(assertionString)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "assert(boolean,java.lang.String)", true), jassParameters);


  	idebughc.Assert jassOld = (idebughc.Assert)this.clone();
    if (!assertion) {
      String output = debug.getDebugConstants().FAILED_ASSERTION_STRING + 
        " `" + assertionString + "'\n";
      debug.getOutputInterface().printMsg(output);
      Utilities.dumpStackSafe();
      throw new FailedAssertionException(output);
    }
  	/* postcondition */
  	if (!((assertion==true))) throw new jass.runtime.PostconditionException("idebughc.Assert","assert(boolean,java.lang.String)",146,"exception_thrown_correctly");
  	if (!(jass.runtime.Tool.referenceEquals(debug,jassOld.debug))) throw new jass.runtime.PostconditionException("idebughc.Assert","assert(boolean,java.lang.String)",-1,"Method has changed old value.");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "assert(boolean,java.lang.String)", false), jassParameters);

  }

  /**
   * <p> Assert that the passed boolean expression evaluates to true.  If
   * it does not, the assertion fails, the message is displayed, a stack
   * dump takes place, and a <var>FailedAssertionException</var> is
   * thrown. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>message_is_non_null</b>: (message!=null)</code></dd></dl> 
<dl><dt><b>Ensures:</b></dt><dd><code><b>exception_thrown_correctly</b>: (assertion==true)</code></dd></dl> 
@param assertion is the boolean expression to assert.
   * @param assertionString is the text of the assertion itself.
   * @param message the debugging message to print if the assertion fails.
   * The method <code>toString()</code> is called on the message object.
   *
   * @concurrency GUARDED
   * @modifies QUERY
   * @postcondition ((assertion == false) implies 
   *                 (throw new FailedAssertionException))
   */

  public synchronized void assert(boolean assertion, 
                                  String assertionString, 
                                  Object message)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(assertion), new jass.runtime.traceAssertion.Parameter(assertionString), new jass.runtime.traceAssertion.Parameter(message)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "assert(boolean,java.lang.String,java.lang.Object)", true), jassParameters);


  	idebughc.Assert jassOld = (idebughc.Assert)this.clone();
  	/* precondition */
  	if (!((message!=null))) throw new jass.runtime.PreconditionException("idebughc.Assert","assert(boolean,java.lang.String,java.lang.Object)",171,"message_is_non_null");

    if (!assertion) {
      String output = debug.getDebugConstants().FAILED_ASSERTION_STRING + 
        " `" + assertionString + "': " + message.toString() + "\n";
      debug.getOutputInterface().printMsg(output);
      Utilities.dumpStackSafe();
      throw new FailedAssertionException(output);
    }
  	/* postcondition */
  	if (!((assertion==true))) throw new jass.runtime.PostconditionException("idebughc.Assert","assert(boolean,java.lang.String,java.lang.Object)",181,"exception_thrown_correctly");
  	if (!(jass.runtime.Tool.referenceEquals(debug,jassOld.debug))) throw new jass.runtime.PostconditionException("idebughc.Assert","assert(boolean,java.lang.String,java.lang.Object)",-1,"Method has changed old value.");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "assert(boolean,java.lang.String,java.lang.Object)", false), jassParameters);

  }

	protected void finalize () throws java.lang.Throwable {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "finalize()", true), jassParameters);
		super.finalize();
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "finalize()", false), jassParameters);
	}

	public boolean equals (java.lang.Object par0) {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(par0)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "equals(java.lang.Object)", true), jassParameters);
		boolean returnValue = super.equals(par0);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(returnValue)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "equals(java.lang.Object)", false), jassParameters);
		return returnValue;
	}

	public java.lang.String toString () {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "toString()", true), jassParameters);
		java.lang.String returnValue = super.toString();
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(returnValue)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Assert", "toString()", false), jassParameters);
		return returnValue;
	}

  // Protected Methods
  // Package Methods
  // Private Methods

} // end of class Assert

/*
 * Local Variables:
 * Mode: Java
 * fill-column: 75
 * End:
 */
