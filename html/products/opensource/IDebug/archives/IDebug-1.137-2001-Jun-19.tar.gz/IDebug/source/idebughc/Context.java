/*
 * Software Engineering Tools.
 *
 * $Id: Context.jass,v 1.8 2001/05/29 05:05:58 kiniry Exp $
 *
 * Copyright (c) 1997-2001 Joseph Kiniry
 * Copyright (c) 2000-2001 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS
 * IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL KIND SOFTWARE OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebughc;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;

/**
 * <p> Context is the data structure that holds the information that is
 * relevent to debugging on a per-thread and a per- threadgroup basis. </p>
 *
 * <p> Each thread within a program is either in a debugging state or it is
 * not.  To signal that it is in the debugging state, that thread should do
 * the following (perhaps in an initDebug() method):
 * 
 * <ol> 
 * <li> Create a new Context object for that thread.  E.g.  <code>Context
 * debugContext = new Context();</code> All of the following method calls
 * are applied to this object, unless otherwise noted. </li>
 *
 * <li> Call the <code>turnOn();</code> to turn debugging on for this
 * thread. </li>
 *
 * <li> Add any new debugging categories specific to that thread with one
 * or more of the <code>addCategory()</code> methods. </li>
 *
 * <li> If this thread is only interested in the debugging output from a
 * specific set of classes, the <code>addClass()</code> methods can be used
 * to specify specific methods of interest.  Note that you'll likely want
 * to prefix the series of "class additions" with a
 * <code>removeClass(Thread.currentThread(), "*");</code> to flush the
 * context of the class narrowing/widening. </li>
 *
 * <li> Set the debug level that the thread is interested in with one of
 * the <code>setLevel()</code> methods. </li>
 * </ol>
 *
 * </p>
 *
 * <p> Now your thread has a valid debugging context, encapsulated in
 * its Context object.  This object is then passed to the Debug class
 * via the <code>addContext()</code> method so that the debugging
 * runtime system knows the threads context. </p>
 *
 * <dl><dt><b>Invariant:</b></dt><dd><code><b>level_in_valid_range</b>: validLevel(getLevel())</code></dd></dl> 
@version $Revision: 1.8 $ $Date: 2001/05/29 05:05:58 $
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @see Debug
 * @see DebugConstants
 *
 * @design Most of this class used to be called PerDebugElement and
 * was used in package versions 0.01 through 0.17.
 * @design changeonly{} specifications are not used here because the
 * clone() method is part of the IDebug context design and is not
 * implemented for changeonly semantics.
 */

public class Context implements Cloneable, Serializable
{
  // Attributes

  /**
   * <p> This class contains several core instance variables:
   *
   * <ol>
   * <li> <code>isOn</code> is a boolean that indicates if debugging for
   * this element (thread or threadgroup) is turned on. </li>
   *
   * <li> <code>level</code> is an integer that indicates the current
   * debugging level for this element.  Its value ranges from
   * <code>LEVEL_MIN</code> to <code>LEVEL_MAX</code> of the current
   * installed <code>DebugConstantInterface</code>. </li>
   *
   * <li> <code>categoryHashtable</code> is a hashtable containing
   * information on all categories defined in this debugging context and
   * their severity levels.  A key of this hashtable is the category (type
   * <code>String</code>), while the data value is an <code>Integer</code>
   * representing the severity level of the category. </li>
   *
   * <li> <code>classHashtable</code> is a hashtable containing information
   * on all classes that have debugging enabled or disabled in this
   * context.  A key of this hashtable is the <code>String</code>
   * representation of a class (<code>Class.getName()</code>), while a data
   * value is a <code>Boolean</code> indicating if a the given class has
   * debugging enabled. </li> 
   * </ol>
   * </p>
   *
   * <p> Context objects are stored in the class-global per-thread and
   * per-threadgroup hashtables of the <code>Debug</code> class, hashed on
   * references to the thread or thread group, respectively. </p>
   */
  
  /**
   * @serial The debugging constants for this class.
   */
  
  private DebugConstants debugConstants = null;
  
  /**
   * @serial A flag indicating if debugging is enabled for this
   * context.  If (isOn == false), all Debug calls like assert() and
   * print(), but for the query and state change functions (like
   * isOn(), turnOn(), etc.), are short-circuited and do nothing.
   */
  
  private boolean isOn;

  /**
   * @serial The current debug level of this context.
   * @design Higher valued levels usually indicate higher priorities.
   * E.g. A level 9 message is in the default implementation an asssertion;
   * if it fails, the program exits.  A level 5 message is an error and the
   * user should probably be informed of the problem.  You can override
   * this behavior by subtyping DebugConstants and installing the new
   * constant during the construction of a Context.
   */

  private int level;

  /**
   * @serial A hashtable that binds category keys (Strings) to levels
   * (Integers).
   */

  private Hashtable categoryHashtable;

  /**
   * @serial A hashtable that binds class names (Strings) to enable flags
   * (Booleans).
   */

  private Hashtable classHashtable;

  /**
   * The thread that owns this context.
   */

  private transient Thread thread;

  /** 
   * <p> The object used by this thread to control debugging output device.
   * All debugging messages that come from the owning thread will use this
   * output interface. </p>
   */

  private transient DebugOutput debugOutputInterface;

  /**
   * <p> The standard constructor.  The thread that is constructing the
   * context is the "owning thread".  All calls to this context will be
   * recognized only in the context of the original constructing
   * thread. </p>
   *
   * <p> The constructor initializes all the static data-structures used by
   * the Context class.  Note that the <code>initCategories()</code> method
   * is automatically called as necessary to initialize the default
   * categories database of the Context class. </p>
   *
   * @concurrency CONCURRENT
   * @modifies isOn, level, categoryHashtable, classHashtable,
   *           debugConstants, debugOutputInterface, thread
   * @param c an implementation of the <code>DebugConstants</code> that
   * defines the semantics of this debug context.
   * @param d an implementation of <code>DebugOutput</code> that defines
   * the semantics of debugging output.
   */

  public Context(DebugConstants c, DebugOutput d)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(c), new jass.runtime.traceAssertion.Parameter(d)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "Context(idebughc.DebugConstants,idebughc.DebugOutput)", true), jassParameters);


  	/* precondition */
  	if (!((c!=null))) throw new jass.runtime.PreconditionException("idebughc.Context","Context(idebughc.DebugConstants,idebughc.DebugOutput)",209,"dc_non_null");
  	if (!((d!=null))) throw new jass.runtime.PreconditionException("idebughc.Context","Context(idebughc.DebugConstants,idebughc.DebugOutput)",210,"do_non_null");

    isOn = false;
    level = 0;
    categoryHashtable = new Hashtable();
    classHashtable = new Hashtable();
    classHashtable.put("*", new Boolean(true));
    debugConstants = c;
    debugConstants.initCategories(categoryHashtable);
    debugOutputInterface = d;
    thread = Thread.currentThread();
  	/* postcondition */
  	if (!((isOn==false))) throw new jass.runtime.PostconditionException("idebughc.Context","Context(idebughc.DebugConstants,idebughc.DebugOutput)",222,"isOn_initialized");
  	if (!((level==0))) throw new jass.runtime.PostconditionException("idebughc.Context","Context(idebughc.DebugConstants,idebughc.DebugOutput)",223,"level_initialized");
  	if (!((categoryHashtable!=null))) throw new jass.runtime.PostconditionException("idebughc.Context","Context(idebughc.DebugConstants,idebughc.DebugOutput)",224,"categoryHashtable_initialized");
  	if (!((classHashtable!=null))) throw new jass.runtime.PostconditionException("idebughc.Context","Context(idebughc.DebugConstants,idebughc.DebugOutput)",225,"classHashtable_initialized");
  	if (!((debugConstants!=null))) throw new jass.runtime.PostconditionException("idebughc.Context","Context(idebughc.DebugConstants,idebughc.DebugOutput)",226,"debugConstants_initialized");
  	if (!((debugOutputInterface!=null))) throw new jass.runtime.PostconditionException("idebughc.Context","Context(idebughc.DebugConstants,idebughc.DebugOutput)",228,"debugOutputInterface_initialized");
  	if (!((thread!=null))) throw new jass.runtime.PostconditionException("idebughc.Context","Context(idebughc.DebugConstants,idebughc.DebugOutput)",229,"thread_initialized");
  	/* invariant */
  	jassCheckInvariant("at end of method Context(idebughc.DebugConstants,idebughc.DebugOutput).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "Context(idebughc.DebugConstants,idebughc.DebugOutput)", false), jassParameters);

  }

  /**
   * <p> Used to clone a Context for another thread.  Should be called
   * <em>only</em> by the thread that is going to use/modify the
   * context. </p>
   *
   * <dl><dt><b>Ensures:</b></dt><dd><code><b>Result_non_null</b>: (Result!=null)</code></dd></dl> 
@concurrency CONCURRENT
   * @modifies QUERY
   * @return the clone of the Context.
   */

  public Object clone()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "clone()", true), jassParameters);
  	java.lang.Object jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method clone().");
    Context contextClone = null;
    try {
      contextClone = (Context)super.clone();
    } catch (CloneNotSupportedException cnse) {
      throw new RuntimeException(cnse.getMessage());
    }
    contextClone.thread = Thread.currentThread();
    contextClone.debugOutputInterface = debugOutputInterface;
  	jassResult = ( contextClone);
  	/* postcondition */
  	if (!((jassResult!=null))) throw new jass.runtime.PostconditionException("idebughc.Context","clone()",255,"Result_non_null");
  	/* invariant */
  	jassCheckInvariant("before return in method clone().");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "clone()", false), jassParameters);


  	return jassResult;
  } 

  /**
   * <dl><dt><b>Ensures:</b></dt><dd><code><b>Result_is_correct</b>: (Result==thread)</code></dd></dl> 
@return the thread that owns this context.
   *
   * @concurrency CONCURRENT
   * @modifies QUERY
   */

  public Thread getThread()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "getThread()", true), jassParameters);
  	java.lang.Thread jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method getThread().");
  	jassResult = ( thread);
  	/* postcondition */
  	if (!((jassResult==thread))) throw new jass.runtime.PostconditionException("idebughc.Context","getThread()",269,"Result_is_correct");
  	/* invariant */
  	jassCheckInvariant("before return in method getThread().");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "getThread()", false), jassParameters);


  	return jassResult;
  }

  /**
   * <p> Turns on debugging facilities for the owner thread.  Note that if
   * you do not <code>turnOff()</code> debugging for this thread before it
   * becomes in active in the system, it will not be garbage collected,
   * since it is referenced by the Context object. </p>
   *
   * <dl><dt><b>Ensures:</b></dt><dd><code><b>isOn_is_true</b>: (isOn==true)</code></dd></dl> 
@concurrency GUARDED
   * @modifies isOn
   */

  public synchronized void turnOn()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "turnOn()", true), jassParameters);


  	/* invariant */
  	jassCheckInvariant("at begin of method turnOn().");
    isOn = true;
  	/* postcondition */
  	if (!((isOn==true))) throw new jass.runtime.PostconditionException("idebughc.Context","turnOn()",286,"isOn_is_true");
  	/* invariant */
  	jassCheckInvariant("at end of method turnOn().");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "turnOn()", false), jassParameters);

  }
  
  /**
   * <p> Turns off debugging facilities for the owner thread.  Note that if
   * you do not <code>turnOff</code> debugging for this thread before it
   * becomes in active in the system, it will not be garbage collected,
   * since it is referenced by the Context object. </p>
   *
   * <dl><dt><b>Ensures:</b></dt><dd><code><b>isOn_is_false</b>: (isOn==false)</code></dd></dl> 
@concurrency GUARDED
   * @modifies isOn
   * @review Create a garbage collection thread for Debug to clean up dead
   * threads?
   */

  public synchronized void turnOff()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "turnOff()", true), jassParameters);


  	/* invariant */
  	jassCheckInvariant("at begin of method turnOff().");
    isOn = false;
  	/* postcondition */
  	if (!((isOn==false))) throw new jass.runtime.PostconditionException("idebughc.Context","turnOff()",305,"isOn_is_false");
  	/* invariant */
  	jassCheckInvariant("at end of method turnOff().");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "turnOff()", false), jassParameters);

  }

  /**
   * @concurrency GUARDED
   * @modifies QUERY
   * @return a boolean indicating if any debugging is turned on.
   */

  public synchronized boolean isOn()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "isOn()", true), jassParameters);
  	boolean jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method isOn().");
  	jassResult = ( isOn);
  	/* invariant */
  	jassCheckInvariant("before return in method isOn().");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "isOn()", false), jassParameters);


  	return jassResult;
  }

  /**
   * <p> Adds a category to the database of legal debugging categories for
   * the owner thread.  Once a category exists in the database, its
   * debugging level cannot be changed without removing and re-adding the
   * category to the database. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>category_non_null</b>: (category!=null) &&<br><b>category_length_positive</b>: (category.length()>0) &&<br><b>level_in_valid_range</b>: validLevel(level)</code></dd></dl> 
<dl><dt><b>Ensures:</b></dt><dd><code><b>category_added</b>: containsCategory(category)</code></dd></dl> 
@concurrency GUARDED
   * @modifies categoryHashtable
   * @param category the category to add to the global set of categories.
   * @param level the debugging level associated with the passed category.
   * @return a boolean indicating if the category was sucessfully added to
   * the database.  A false indicates either the category was already in
   * the database at a different level or the parameters were invalid.
   */

  public synchronized boolean addCategory(String category, int level)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(category), new jass.runtime.traceAssertion.Parameter(level)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "addCategory(java.lang.String,int)", true), jassParameters);
  	boolean jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method addCategory(java.lang.String,int).");
  	/* precondition */
  	if (!((category!=null))) throw new jass.runtime.PreconditionException("idebughc.Context","addCategory(java.lang.String,int)",336,"category_non_null");
  	if (!((category.length()>0))) throw new jass.runtime.PreconditionException("idebughc.Context","addCategory(java.lang.String,int)",337,"category_length_positive");
  	if (!(jassInternal_validLevel(level))) throw new jass.runtime.PreconditionException("idebughc.Context","addCategory(java.lang.String,int)",338,"level_in_valid_range");

    // See if an entry for the passed category exists.
    if (categoryHashtable.containsKey(category)) {
      if (((Integer)(categoryHashtable.get(category))).intValue() != level) {
      	jassResult = ( false);
      	/* postcondition */
      	if (!(jassInternal_containsCategory(category))) throw new jass.runtime.PostconditionException("idebughc.Context","addCategory(java.lang.String,int)",353,"category_added");
      	/* invariant */
      	jassCheckInvariant("before return in method addCategory(java.lang.String,int).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "addCategory(java.lang.String,int)", false), jassParameters);


      	return jassResult;
      }
      else {
      	jassResult = ( true);
      	/* postcondition */
      	if (!(jassInternal_containsCategory(category))) throw new jass.runtime.PostconditionException("idebughc.Context","addCategory(java.lang.String,int)",353,"category_added");
      	/* invariant */
      	jassCheckInvariant("before return in method addCategory(java.lang.String,int).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "addCategory(java.lang.String,int)", false), jassParameters);


      	return jassResult;
      }
    }

    // Add a new entry for the passed category.
    categoryHashtable.put(category, new Integer(level));
  	jassResult = ( true);
  	/* postcondition */
  	if (!(jassInternal_containsCategory(category))) throw new jass.runtime.PostconditionException("idebughc.Context","addCategory(java.lang.String,int)",353,"category_added");
  	/* invariant */
  	jassCheckInvariant("before return in method addCategory(java.lang.String,int).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "addCategory(java.lang.String,int)", false), jassParameters);


  	return jassResult;
  }

  /**
   * <p> Removes a category from the database of legal debugging categories
   * for the owner thread. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>category_non_null</b>: (category!=null) &&<br><b>category_length_positive</b>: (category.length()>0)</code></dd></dl> 
<dl><dt><b>Ensures:</b></dt><dd><code><b>category_removed</b>: containsCategory(category)</code></dd></dl> 
@concurrency GUARDED
   * @modifies categoryHashtable
   * @param category the category to remove.
   * @return a boolean indicating if the category was sucessfully
   * removed from the database.  A false indicates that the parameters
   * were invalid.
   */
  
  public synchronized boolean removeCategory(String category)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(category)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "removeCategory(java.lang.String)", true), jassParameters);
  	boolean jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method removeCategory(java.lang.String).");
  	/* precondition */
  	if (!((category!=null))) throw new jass.runtime.PreconditionException("idebughc.Context","removeCategory(java.lang.String)",370,"category_non_null");
  	if (!((category.length()>0))) throw new jass.runtime.PreconditionException("idebughc.Context","removeCategory(java.lang.String)",371,"category_length_positive");

    // If is in the hashtable, remove it.
    boolean Result = false;
    if (categoryHashtable.containsKey(category)) {
      categoryHashtable.remove(category);
    		jassResult = ( true);
    		/* postcondition */
    		if (!(!jassInternal_containsCategory(category))) throw new jass.runtime.PostconditionException("idebughc.Context","removeCategory(java.lang.String)",380,"category_removed");
    		/* invariant */
    		jassCheckInvariant("before return in method removeCategory(java.lang.String).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "removeCategory(java.lang.String)", false), jassParameters);


    		return jassResult;
    } else {
    	jassResult = ( false);
    	/* postcondition */
    	if (!(!jassInternal_containsCategory(category))) throw new jass.runtime.PostconditionException("idebughc.Context","removeCategory(java.lang.String)",380,"category_removed");
    	/* invariant */
    	jassCheckInvariant("before return in method removeCategory(java.lang.String).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "removeCategory(java.lang.String)", false), jassParameters);


    	return jassResult;
    }
  }

  /**
   * <dl><dt><b>Requires:</b></dt><dd><code><b>category_non_null</b>: (category!=null) &&<br><b>category_length_positive</b>: (category.length()>0)</code></dd></dl> 
@concurrency GUARDED
   * @modifies QUERY
   * @param category is the category to lookup.
   * @return a boolean indicating if a category is in the class-global
   * category database.
   */

  public synchronized boolean containsCategory(String category)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(category)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "containsCategory(java.lang.String)", true), jassParameters);
  	boolean jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method containsCategory(java.lang.String).");
  	/* precondition */
  	if (!((category!=null))) throw new jass.runtime.PreconditionException("idebughc.Context","containsCategory(java.lang.String)",393,"category_non_null");
  	if (!((category.length()>0))) throw new jass.runtime.PreconditionException("idebughc.Context","containsCategory(java.lang.String)",394,"category_length_positive");
  	jassResult = ( (categoryHashtable.containsKey(category)));
  	/* invariant */
  	jassCheckInvariant("before return in method containsCategory(java.lang.String).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "containsCategory(java.lang.String)", false), jassParameters);


  	return jassResult;
  }

  /**
   * <dl><dt><b>Requires:</b></dt><dd><code><b>category_non_null</b>: (category!=null) &&<br><b>category_length_positive</b>: (category.length()>0) &&<br><b>contains_category</b>: containsCategory(category)</code></dd></dl> 
@concurrency GUARDED
   * @modifies QUERY
   * @param category is the category to lookup.
   * @return the level of the category provided it is in the category
   * database of this context.
   */

  public synchronized int getCategoryLevel(String category)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(category)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "getCategoryLevel(java.lang.String)", true), jassParameters);
  	int jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method getCategoryLevel(java.lang.String).");
  	/* precondition */
  	if (!((category!=null))) throw new jass.runtime.PreconditionException("idebughc.Context","getCategoryLevel(java.lang.String)",409,"category_non_null");
  	if (!((category.length()>0))) throw new jass.runtime.PreconditionException("idebughc.Context","getCategoryLevel(java.lang.String)",410,"category_length_positive");
  	if (!(jassInternal_containsCategory(category))) throw new jass.runtime.PreconditionException("idebughc.Context","getCategoryLevel(java.lang.String)",411,"contains_category");
  	jassResult = ( ((Integer)(categoryHashtable.get(category))).intValue());
  	/* invariant */
  	jassCheckInvariant("before return in method getCategoryLevel(java.lang.String).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "getCategoryLevel(java.lang.String)", false), jassParameters);


  	return jassResult;
  }

  /**
   * @concurrency GUARDED
   * @modifies QUERY
   * @return an enumeration that is the list of per-thread debugging
   * categories that are currently in this Context's category
   * database.  A zero-length enumeration will be returned if there
   * are not categories defined in the database as of yet.
   * @see Hashtable#elements
   */

  public synchronized Enumeration listCategories()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "listCategories()", true), jassParameters);
  	java.util.Enumeration jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method listCategories().");
  	jassResult = ( (categoryHashtable.elements()));
  	/* invariant */
  	jassCheckInvariant("before return in method listCategories().");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "listCategories()", false), jassParameters);


  	return jassResult;
  }

  /**
   * <dl><dt><b>Requires:</b></dt><dd><code><b>className_non_null</b>: (className!=null) &&<br><b>className_length_positive</b>: (className.length()>0)</code></dd></dl> 
@return a boolean indicating that this Context's database of classes
   * contains the specified class.
   * 
   * @concurrency GUARDED
   * @modifies QUERY
   * @param className the name of the class to check.
   */

  public synchronized boolean containsClass(String className)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(className)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "containsClass(java.lang.String)", true), jassParameters);
  	boolean jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method containsClass(java.lang.String).");
  	/* precondition */
  	if (!((className!=null))) throw new jass.runtime.PreconditionException("idebughc.Context","containsClass(java.lang.String)",442,"className_non_null");
  	if (!((className.length()>0))) throw new jass.runtime.PreconditionException("idebughc.Context","containsClass(java.lang.String)",443,"className_length_positive");
  	jassResult = ( classHashtable.containsKey(className));
  	/* invariant */
  	jassCheckInvariant("before return in method containsClass(java.lang.String).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "containsClass(java.lang.String)", false), jassParameters);


  	return jassResult;
  }

  /**
   * <dl><dt><b>Requires:</b></dt><dd><code><b>classRef_non_null</b>: (classRef!=null)</code></dd></dl> 
@return a boolean indicating that this Context's database of classes
   * contains the specified class.
   * 
   * @concurrency GUARDED
   * @modifies QUERY
   * @param classRef the class to check.
   */

  public synchronized boolean containsClass(Class classRef)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(classRef)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "containsClass(java.lang.Class)", true), jassParameters);
  	boolean jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method containsClass(java.lang.Class).");
  	/* precondition */
  	if (!((classRef!=null))) throw new jass.runtime.PreconditionException("idebughc.Context","containsClass(java.lang.Class)",459,"classRef_non_null");
  	jassResult = ( containsClass(classRef.getName()));
  	/* invariant */
  	jassCheckInvariant("before return in method containsClass(java.lang.Class).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "containsClass(java.lang.Class)", false), jassParameters);


  	return jassResult;
  }

  /**
   * <p> Adds a class to this Context's database of classes that have
   * debugging enabled. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>classRef_non_null</b>: (classRef!=null)</code></dd></dl> 
@concurrency GUARDED
   * @modifies classHashtable
   * @param classRef the class to add to the global table of classes
   * that have debugging enabled.
   */

  public synchronized void addClass(Class classRef)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(classRef)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "addClass(java.lang.Class)", true), jassParameters);


  	/* invariant */
  	jassCheckInvariant("at begin of method addClass(java.lang.Class).");
  	/* precondition */
  	if (!((classRef!=null))) throw new jass.runtime.PreconditionException("idebughc.Context","addClass(java.lang.Class)",476,"classRef_non_null");

    Utilities.addClassToHashtable(classHashtable, 
                                  classRef.getName());
  	/* invariant */
  	jassCheckInvariant("at end of method addClass(java.lang.Class).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "addClass(java.lang.Class)", false), jassParameters);

  }

  /**
   * <p> Adds a class to this Context's database of classes that have
   * debugging enabled. Note that a class of "*" means that all classes
   * will now have debugging enabled for the owning thread.  There is no
   * way to "undo" such a command short of manually adding the individual
   * classes back to the database. (Or, equivalently, removing the
   * complement.) </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>className_non_null</b>: (className!=null) &&<br><b>className_length_positive</b>: (className.length()>0)</code></dd></dl> 
@concurrency GUARDED
   * @modifies classHashtable
   * @param className the name of the class to add.
   */
  
  public synchronized void addClass(String className)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(className)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "addClass(java.lang.String)", true), jassParameters);


  	/* invariant */
  	jassCheckInvariant("at begin of method addClass(java.lang.String).");
  	/* precondition */
  	if (!((className!=null))) throw new jass.runtime.PreconditionException("idebughc.Context","addClass(java.lang.String)",497,"className_non_null");
  	if (!((className.length()>0))) throw new jass.runtime.PreconditionException("idebughc.Context","addClass(java.lang.String)",498,"className_length_positive");

    Utilities.addClassToHashtable(classHashtable, 
                                  className);
  	/* invariant */
  	jassCheckInvariant("at end of method addClass(java.lang.String).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "addClass(java.lang.String)", false), jassParameters);

  }

  /**
   * <p> Removes a class from this Context's database of classes that have
   * debugging enabled. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>classRef_non_null</b>: (classRef!=null)</code></dd></dl> 
@concurrency GUARDED
   * @modifies classHashtable
   * @param classRef the class to remove from this Context's table of
   * classes that have debugging enabled.
   */

  public synchronized void removeClass(Class classRef)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(classRef)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "removeClass(java.lang.Class)", true), jassParameters);


  	/* invariant */
  	jassCheckInvariant("at begin of method removeClass(java.lang.Class).");
  	/* precondition */
  	if (!((classRef!=null))) throw new jass.runtime.PreconditionException("idebughc.Context","removeClass(java.lang.Class)",516,"classRef_non_null");

    Utilities.removeClassFromHashtable(classHashtable, 
                                       classRef.getName());
  	/* invariant */
  	jassCheckInvariant("at end of method removeClass(java.lang.Class).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "removeClass(java.lang.Class)", false), jassParameters);

  }

  /**
   * <p> Removes a class from this Context's database of classes that have
   * debugging enabled.  Note that a class of "*" means that all classes
   * will be removed and debugging disabled.  There is no way to "undo"
   * such a command. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>className_non_null</b>: (className!=null) &&<br><b>className_length_positive</b>: (className.length()>0)</code></dd></dl> 
@concurrency GUARDED
   * @modifies classHashtable
   * @param className the class to remove from this Context's table of
   * classes that have debugging enabled. 
   */

  public synchronized void removeClass(String className)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(className)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "removeClass(java.lang.String)", true), jassParameters);


  	/* invariant */
  	jassCheckInvariant("at begin of method removeClass(java.lang.String).");
  	/* precondition */
  	if (!((className!=null))) throw new jass.runtime.PreconditionException("idebughc.Context","removeClass(java.lang.String)",536,"className_non_null");
  	if (!((className.length()>0))) throw new jass.runtime.PreconditionException("idebughc.Context","removeClass(java.lang.String)",537,"className_length_positive");

    Utilities.removeClassFromHashtable(classHashtable, 
                                       className);
  	/* invariant */
  	jassCheckInvariant("at end of method removeClass(java.lang.String).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "removeClass(java.lang.String)", false), jassParameters);

  }

  /**
   * <p> Returns an enumeration that is the list of classes that have
   * debugging enabled in this Context. </p>
   *
   * @concurrency GUARDED
   * @modifies QUERY
   * @return an enumeration that is the list of the classes that
   * currently have debugging enabled (they are in the class database)
   * for the owning thread. Returns a zero-length enumeration if there
   * are no enabled classes.
   * @see Hashtable#elements
   */
  
  public synchronized Enumeration listClasses()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "listClasses()", true), jassParameters);
  	java.util.Enumeration jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method listClasses().");
  	jassResult = ( (classHashtable.elements()));
  	/* invariant */
  	jassCheckInvariant("before return in method listClasses().");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "listClasses()", false), jassParameters);


  	return jassResult;
  }
  
  /**
   * <p> Set a new debugging level for the owning thread. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>valid_level</b>: validLevel(l)</code></dd></dl> 
<dl><dt><b>Ensures:</b></dt><dd><code><b>level_set</b>: (getLevel()==l)</code></dd></dl> 
@concurrency GUARDED
   * @modifies level
   * @param l the new debugging level.
   */
  
  public synchronized void setLevel(int l)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(l)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "setLevel(int)", true), jassParameters);


  	/* invariant */
  	jassCheckInvariant("at begin of method setLevel(int).");
  	/* precondition */
  	if (!(jassInternal_validLevel(l))) throw new jass.runtime.PreconditionException("idebughc.Context","setLevel(int)",571,"valid_level");

    level = l;
  	/* postcondition */
  	if (!((jassInternal_getLevel()==l))) throw new jass.runtime.PostconditionException("idebughc.Context","setLevel(int)",575,"level_set");
  	/* invariant */
  	jassCheckInvariant("at end of method setLevel(int).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "setLevel(int)", false), jassParameters);

  }

  /**
   * @concurrency GUARDED
   * @modifies QUERY
   * @return the current debugging level for the owning thread.
   */
  
  public synchronized int getLevel()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "getLevel()", true), jassParameters);
  	int jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method getLevel().");
  	jassResult = ( level);
  	/* invariant */
  	jassCheckInvariant("before return in method getLevel().");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "getLevel()", false), jassParameters);


  	return jassResult;
  }

  /**
   * @concurrency CONCURRENT
   * @modifies QUERY
   * @return the <code>DebugOutput</code> for the owning thread.
   */
  
  public DebugOutput getOutputInterface()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "getOutputInterface()", true), jassParameters);
  	idebughc.DebugOutput jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method getOutputInterface().");
  	jassResult = ( debugOutputInterface);
  	/* invariant */
  	jassCheckInvariant("before return in method getOutputInterface().");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "getOutputInterface()", false), jassParameters);


  	return jassResult;
  }

  /**
   * @concurrency CONCURRENT
   * @modifies QUERY
   * @return a flag indicating if the provided level is valid.
   * @param l the level to check.
   */

  public boolean validLevel(int l)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(l)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "validLevel(int)", true), jassParameters);
  	boolean jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method validLevel(int).");
  	jassResult = ( ((l >= DebugConstants.LEVEL_MIN) && 
            (l <= DebugConstants.LEVEL_MAX)));
  	/* invariant */
  	jassCheckInvariant("before return in method validLevel(int).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "validLevel(int)", false), jassParameters);


  	return jassResult;
  }

	/* --- The following methods of class idebughc.Context are generated by JASS --- */


  
  
  public synchronized int jassInternal_getLevel()
  {
    return level;
  }


  

  public boolean jassInternal_validLevel(int l)
  {
    return ((l >= DebugConstants.LEVEL_MIN) && 
            (l <= DebugConstants.LEVEL_MAX));
  }


  

  public synchronized boolean jassInternal_containsCategory(String category)
  {

    return (categoryHashtable.containsKey(category));
  }

	private void jassCheckInvariant(String msg) {
		if (!(jassInternal_validLevel(jassInternal_getLevel()))) throw new jass.runtime.InvariantException("idebughc.Context",null,617,"Exception occured "+msg+" (level_in_valid_range)");
	}


	protected void finalize () throws java.lang.Throwable {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "finalize()", true), jassParameters);
		super.finalize();
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "finalize()", false), jassParameters);
	}

	public boolean equals (java.lang.Object par0) {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(par0)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "equals(java.lang.Object)", true), jassParameters);
		boolean returnValue = super.equals(par0);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(returnValue)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "equals(java.lang.Object)", false), jassParameters);
		return returnValue;
	}

	public java.lang.String toString () {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "toString()", true), jassParameters);
		java.lang.String returnValue = super.toString();
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(returnValue)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "Context", "toString()", false), jassParameters);
		return returnValue;
	}

} // end of class Context

/*
 * Local Variables:
 * Mode: Java
 * fill-column: 75
 * End:
 */
