/*
 * Software Engineering Tools.
 *
 * $Id: WriterOutput.jass,v 1.8 2001/05/29 05:05:58 kiniry Exp $
 *
 * Copyright (c) 1997-2001 Joseph Kiniry
 * Copyright (c) 2000-2001 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS
 * IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL KIND SOFTWARE OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebughc;

import java.io.PrintWriter;
import java.io.Writer;

/**
 * <p> The primary class used to send debugging messages to a
 * <code>PrintWriter</code> output channel. </p>
 *
 * <dl><dt><b>Invariant:</b></dt><dd><code><b>printWriter_non_null</b>: (printWriter!=null)</code></dd></dl> 
@version $Revision: 1.8 $ $Date: 2001/05/29 05:05:58 $
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @concurrency (GUARDED) All methods are synchronized.
 * @see Context
 * @see Debug 
 */

public class WriterOutput extends DebugOutputBase 
  implements DebugOutput, Cloneable
{
  // Attributes

  /**
   * <p> The output channel used by this <code>WriterOutput</code>
   * object. </p>
   */

  private PrintWriter printWriter = new PrintWriter(System.err);

  // Inherited Methods

  public synchronized void printMsg(String category, String message)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(category), new jass.runtime.traceAssertion.Parameter(message)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "printMsg(java.lang.String,java.lang.String)", true), jassParameters);


  	/* invariant */
  	jassCheckInvariant("at begin of method printMsg(java.lang.String,java.lang.String).");
    printWriter.print("<" + category + ">: " + message);
    printWriter.flush();
  	/* invariant */
  	jassCheckInvariant("at end of method printMsg(java.lang.String,java.lang.String).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "printMsg(java.lang.String,java.lang.String)", false), jassParameters);

  }

  public synchronized void printMsg(int level, String message)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(level), new jass.runtime.traceAssertion.Parameter(message)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "printMsg(int,java.lang.String)", true), jassParameters);


  	/* invariant */
  	jassCheckInvariant("at begin of method printMsg(int,java.lang.String).");
    printWriter.print("[" + level + "]: " + message);
    printWriter.flush();
  	/* invariant */
  	jassCheckInvariant("at end of method printMsg(int,java.lang.String).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "printMsg(int,java.lang.String)", false), jassParameters);

  }

  public synchronized void printMsg(String message)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(message)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "printMsg(java.lang.String)", true), jassParameters);


  	/* invariant */
  	jassCheckInvariant("at begin of method printMsg(java.lang.String).");
    printWriter.print(message);
    printWriter.flush();
  	/* invariant */
  	jassCheckInvariant("at end of method printMsg(java.lang.String).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "printMsg(java.lang.String)", false), jassParameters);

  }

  public synchronized Writer getWriter()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "getWriter()", true), jassParameters);
  	java.io.Writer jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method getWriter().");
  	jassResult = ( printWriter);
  	/* invariant */
  	jassCheckInvariant("before return in method getWriter().");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "getWriter()", false), jassParameters);


  	return jassResult;
  }

  public Object clone()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "clone()", true), jassParameters);
  	java.lang.Object jassResult;

  	/* invariant */
  	jassCheckInvariant("at begin of method clone().");
    try {
  		jassResult = ( super.clone());
  		/* invariant */
  		jassCheckInvariant("before return in method clone().");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "clone()", false), jassParameters);


  		return jassResult;
    } catch (CloneNotSupportedException cnse) {
      throw new RuntimeException(cnse.getMessage());
    }
  }

  // Constructors

  /**
   * <p> Constructor for <code>WriterOutput</code>. </p>
   *
   * @param d the <code>Debug</code> object associated with this
   * <code>WriterOutput</code>.
   */

  public WriterOutput(Debug d)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(d)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "WriterOutput(idebughc.Debug)", true), jassParameters);


  	idebughc.WriterOutput jassOld = (idebughc.WriterOutput)this.clone();
  	/* precondition */
  	if (!((d!=null))) throw new jass.runtime.PreconditionException("idebughc.WriterOutput","WriterOutput(idebughc.Debug)",114,"d_non_null");

    debug = d;
  	/* postcondition */
  	if (!((debug==d))) throw new jass.runtime.PostconditionException("idebughc.WriterOutput","WriterOutput(idebughc.Debug)",118,"debug_is_valid");
  	if (!(jass.runtime.Tool.referenceEquals(printWriter,jassOld.printWriter))) throw new jass.runtime.PostconditionException("idebughc.WriterOutput","WriterOutput(idebughc.Debug)",-1,"Method has changed old value.");
  	/* invariant */
  	jassCheckInvariant("at end of method WriterOutput(idebughc.Debug).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "WriterOutput(idebughc.Debug)", false), jassParameters);

  }

  /**
   * <p> Constructor for <code>WriterOutput</code>. </p>
   *
   * @param debug the <code>Debug</code> class associated with this
   * <code>WriterOutput</code>. 
   * @param printWriter the new <code>PrintWriter</code> for this
   * <code>WriterOutput</code>.
   */

  public WriterOutput(Debug d, PrintWriter p)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(d), new jass.runtime.traceAssertion.Parameter(p)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "WriterOutput(idebughc.Debug,java.io.PrintWriter)", true), jassParameters);


  	idebughc.WriterOutput jassOld = (idebughc.WriterOutput)this.clone();
  	/* precondition */
  	if (!((d!=null))) throw new jass.runtime.PreconditionException("idebughc.WriterOutput","WriterOutput(idebughc.Debug,java.io.PrintWriter)",133,"d_non_null");
  	if (!((p!=null))) throw new jass.runtime.PreconditionException("idebughc.WriterOutput","WriterOutput(idebughc.Debug,java.io.PrintWriter)",134,"p_non_null");

    debug = d;
    printWriter = p;
  	/* postcondition */
  	if (!((debug==d))) throw new jass.runtime.PostconditionException("idebughc.WriterOutput","WriterOutput(idebughc.Debug,java.io.PrintWriter)",139,"debug_is_valid");
  	if (!((printWriter==p))) throw new jass.runtime.PostconditionException("idebughc.WriterOutput","WriterOutput(idebughc.Debug,java.io.PrintWriter)",140,"printWriter_is_valid");
  	/* invariant */
  	jassCheckInvariant("at end of method WriterOutput(idebughc.Debug,java.io.PrintWriter).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "WriterOutput(idebughc.Debug,java.io.PrintWriter)", false), jassParameters);

  }

  // Public Methods

  /**
   * <p> Set a new <code>PrintWriter</code>.
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>p_non_null</b>: (p!=null)</code></dd></dl> 
<dl><dt><b>Ensures:</b></dt><dd><code><b>printWriter_is_valid</b>: (printWriter==p)</code></dd></dl> 
@param p the new <code>PrintWriter</code>.
   */

  public void setPrintWriter(PrintWriter p)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(p)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "setPrintWriter(java.io.PrintWriter)", true), jassParameters);


  	/* invariant */
  	jassCheckInvariant("at begin of method setPrintWriter(java.io.PrintWriter).");
  	idebughc.WriterOutput jassOld = (idebughc.WriterOutput)this.clone();
  	/* precondition */
  	if (!((p!=null))) throw new jass.runtime.PreconditionException("idebughc.WriterOutput","setPrintWriter(java.io.PrintWriter)",154,"p_non_null");

    printWriter = p;
  	/* postcondition */
  	if (!((printWriter==p))) throw new jass.runtime.PostconditionException("idebughc.WriterOutput","setPrintWriter(java.io.PrintWriter)",158,"printWriter_is_valid");
  	if (!(jass.runtime.Tool.referenceEquals(debug,jassOld.debug))) throw new jass.runtime.PostconditionException("idebughc.WriterOutput","setPrintWriter(java.io.PrintWriter)",-1,"Method has changed old value.");
  	/* invariant */
  	jassCheckInvariant("at end of method setPrintWriter(java.io.PrintWriter).");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "setPrintWriter(java.io.PrintWriter)", false), jassParameters);

  }

	/* --- The following methods of class idebughc.WriterOutput are generated by JASS --- */

	private void jassCheckInvariant(String msg) {
		if (!((printWriter!=null))) throw new jass.runtime.InvariantException("idebughc.WriterOutput",null,166,"Exception occured "+msg+" (printWriter_non_null)");
	}


	protected void finalize () throws java.lang.Throwable {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "finalize()", true), jassParameters);
		super.finalize();
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "finalize()", false), jassParameters);
	}

	public boolean equals (java.lang.Object par0) {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(par0)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "equals(java.lang.Object)", true), jassParameters);
		boolean returnValue = super.equals(par0);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(returnValue)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "equals(java.lang.Object)", false), jassParameters);
		return returnValue;
	}

	public java.lang.String toString () {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "toString()", true), jassParameters);
		java.lang.String returnValue = super.toString();
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(returnValue)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "WriterOutput", "toString()", false), jassParameters);
		return returnValue;
	}

} // end of class WriterOutput

/*
 * Local Variables:
 * Mode: Java
 * fill-column: 75
 * End:
 */
