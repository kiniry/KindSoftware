/*
 * Software Engineering Tools.
 *
 * $Id: SimpleCollect.jass,v 1.2 2001/05/29 05:05:58 kiniry Exp $
 *
 * Copyright (c) 1997-2001 Joseph Kiniry
 * Copyright (c) 2000-2001 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS
 * IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL KIND SOFTWARE OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebughc.examples;

import idebughc.*;
import java.util.Enumeration;
import java.util.Hashtable;

/**
 * <p> A default simple core interface to gathering statistics. </p>
 *
 * <p> Users of IDebug wishing to keep statistics on their system need to
 * inherit from this abstract class and implement the protected methods.
 * The simplest means to collect statistics are to use a hashtable keyed on
 * statistic (since their <code>hashCode</code> is valid) and store
 * <code>Double</code> objects corresponding to the current value of that
 * statistic.  This class implements this method as an example and for
 * use. </p>
 *
 * <p> Note that this class performs <strong>no filtering
 * whatsoever</strong>.  Regardless of the current debug context, etc.,
 * this class will keep track of all statistics. </p>
 *
 * @version $Revision: 1.2 $ $Date: 2001/05/29 05:05:58 $
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @see Statistic
 * @see Collect 
 */

public class SimpleCollect extends Collect implements Cloneable
{
  // Attributes

  /**
   * <p> A table used to hold the data being collected. </p>
   */

  private Hashtable data;
  
  // Inherited methods

  public Object clone()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "clone()", true), jassParameters);
  	java.lang.Object jassResult;

    try {
  		jassResult = ( super.clone());
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "clone()", false), jassParameters);


  		return jassResult;
    } catch (CloneNotSupportedException cnse) {
      throw new RuntimeException(cnse.getMessage());
    }
  }

  /**
   * <p> Register a statistic with the collector. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>statistic_non_null</b>: (statistic!=null)</code></dd></dl> 
<dl><dt><b>Ensures:</b></dt><dd><code><b>statistic_registered</b>: isRegistered(statistic)</code></dd></dl> 
@param statistic the statistic to register.
   */

  public void register(Statistic statistic)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(statistic)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "register(idebughc.Statistic)", true), jassParameters);


  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","register(idebughc.Statistic)",96,"statistic_non_null");

    super.register(statistic);
    reset(statistic);
  	/* postcondition */
  	if (!(isRegistered(statistic))) throw new jass.runtime.PostconditionException("idebughc.examples.SimpleCollect","register(idebughc.Statistic)",101,"statistic_registered");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "register(idebughc.Statistic)", false), jassParameters);

  }

  /**
   * <p> Unregister a statistic with the collector. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>statistic_non_null</b>: (statistic!=null)</code></dd></dl> 
<dl><dt><b>Ensures:</b></dt><dd><code><b>statistic_registered</b>: isRegistered(statistic)</code></dd></dl> 
@param statistic the statistic to unregister.
   */

  public void unregister(Statistic statistic)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(statistic)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "unregister(idebughc.Statistic)", true), jassParameters);


  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","unregister(idebughc.Statistic)",112,"statistic_non_null");

    super.unregister(statistic);
    data.remove(statistic);
  	/* postcondition */
  	if (!(!isRegistered(statistic))) throw new jass.runtime.PostconditionException("idebughc.examples.SimpleCollect","unregister(idebughc.Statistic)",117,"statistic_registered");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "unregister(idebughc.Statistic)", false), jassParameters);

  }

  /**
   * <p> What is the current value for specific statistic? </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>statistic_non_null</b>: (statistic!=null)</code></dd></dl> 
@param statistic the statistic being modified.
   * @return the old value of the statistic.
   */

  public double currentValue(Statistic statistic)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(statistic)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "currentValue(idebughc.Statistic)", true), jassParameters);
  	double jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","currentValue(idebughc.Statistic)",129,"statistic_non_null");
  	jassResult = ( ((Double)data.get(statistic)).doubleValue());
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "currentValue(idebughc.Statistic)", false), jassParameters);


  	return jassResult;
  }

  /**
   * <p> Report on a particular statistic. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>statistic_non_null</b>: (statistic!=null)</code></dd></dl> 
@param statistic the statistic being reported on.
   * @return a simple <code>String</code> textual report.
   */

  public Object report(Statistic statistic)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(statistic)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "report(idebughc.Statistic)", true), jassParameters);
  	java.lang.Object jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","report(idebughc.Statistic)",143,"statistic_non_null");
  	jassResult = ( "[" + statistic.getID() + "]" + 
     ( ((Double)data.get(statistic)).doubleValue() * statistic.getScale()) +
      " " + statistic.getUnits());
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "report(idebughc.Statistic)", false), jassParameters);


  	return jassResult;
  }

  /**
   * <p> Report on all statistics. </p>
   *
   * @return a report on all statistics as a concatented
   * <code>String</code> textual report.
   * @see #report(Statistic)
   */

  public Object reportAll()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "reportAll()", true), jassParameters);
  	java.lang.Object jassResult;

    String fullReport = new String();
    Enumeration keys = data.keys();

    while (keys.hasMoreElements()) {
      fullReport = fullReport + report((Statistic)keys.nextElement()) + "\n";
    }
  	jassResult = ( fullReport);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "reportAll()", false), jassParameters);


  	return jassResult;
  }

  /**
   * <p> Increment a statistic by a specified value. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>statistic_non_null</b>: (statistic!=null)</code></dd></dl> 
@param statistic the statistic being modified.
   * @param value the amount to increment the statistic.
   * @return the old value of the statistic.
   */

  public double increment(Statistic statistic, double value)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(statistic), new jass.runtime.traceAssertion.Parameter(value)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "increment(idebughc.Statistic,double)", true), jassParameters);
  	double jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","increment(idebughc.Statistic,double)",179,"statistic_non_null");

    double oldValue = currentValue(statistic);
    
    data.put(statistic, new Double(oldValue + value));
  	jassResult = ( oldValue);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "increment(idebughc.Statistic,double)", false), jassParameters);


  	return jassResult;
  }
  
  /**
   * <p> Increment a statistic by the default value. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>statistic_non_null</b>: (statistic!=null)</code></dd></dl> 
@param statistic the statistic being modified.
   * @return the old value of the statistic.
   */

  public double increment(Statistic statistic)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(statistic)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "increment(idebughc.Statistic)", true), jassParameters);
  	double jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","increment(idebughc.Statistic)",196,"statistic_non_null");

    double oldValue = currentValue(statistic);

    data.put(statistic, new Double(oldValue + statistic.getIncrement()));
  	jassResult = ( oldValue);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "increment(idebughc.Statistic)", false), jassParameters);


  	return jassResult;
  }
 
  /**
   * <p> Decrement a statistic by a specified value. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>statistic_non_null</b>: (statistic!=null)</code></dd></dl> 
@param statistic the statistic being modified.
   * @param value the amount to decrement the statistic.
   * @return the old value of the statistic.
   */

  public double decrement(Statistic statistic, double value)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(statistic), new jass.runtime.traceAssertion.Parameter(value)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "decrement(idebughc.Statistic,double)", true), jassParameters);
  	double jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","decrement(idebughc.Statistic,double)",214,"statistic_non_null");

    double oldValue = currentValue(statistic);
    
    data.put(statistic, new Double(oldValue - value));
  	jassResult = ( oldValue);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "decrement(idebughc.Statistic,double)", false), jassParameters);


  	return jassResult;
  }

  /**
   * <p> Decrement a statistic by the default value. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>statistic_non_null</b>: (statistic!=null)</code></dd></dl> 
@param statistic the statistic being modified.
   * @return the old value of the statistic.
   */

  public double decrement(Statistic statistic)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(statistic)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "decrement(idebughc.Statistic)", true), jassParameters);
  	double jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","decrement(idebughc.Statistic)",231,"statistic_non_null");

    double oldValue = currentValue(statistic);
    
    data.put(statistic, new Double(oldValue + statistic.getDecrement()));
  	jassResult = ( oldValue);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "decrement(idebughc.Statistic)", false), jassParameters);


  	return jassResult;
  }

  /**
   * <p> Reset a statistic to the default start value. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>statistic_non_null</b>: (statistic!=null)</code></dd></dl> 
@param statistic the statistic to reset.
   * @return the old value of the statistic.
   */

  public double reset(Statistic statistic)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(statistic)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "reset(idebughc.Statistic)", true), jassParameters);
  	double jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","reset(idebughc.Statistic)",248,"statistic_non_null");

    double oldValue = currentValue(statistic);

    data.put(statistic, new Double(statistic.getStart()));
  	jassResult = ( oldValue);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "reset(idebughc.Statistic)", false), jassParameters);


  	return jassResult;
  }
  
  /**
   * <p> Set a statistic to a specific value. </p>
   *
   * <dl><dt><b>Requires:</b></dt><dd><code><b>statistic_non_null</b>: (statistic!=null)</code></dd></dl> 
@param statistic the statistic being modified.
   * @param value the new value of the statistic.
   * @return the old value of the statistic.
   */

  public double set(Statistic statistic, double value)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(statistic), new jass.runtime.traceAssertion.Parameter(value)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "set(idebughc.Statistic,double)", true), jassParameters);
  	double jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","set(idebughc.Statistic,double)",266,"statistic_non_null");

    double oldValue = currentValue(statistic);

    data.put(statistic, new Double(value));
  	jassResult = ( oldValue);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "set(idebughc.Statistic,double)", false), jassParameters);


  	return jassResult;
  }
  
  // Constructors

  /**
   * <p> Construct a new <code>SimpleCollect</code> class. </p>
   */

  public SimpleCollect()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "SimpleCollect()", true), jassParameters);


    data = new Hashtable();
  	/* postcondition */
  	if (!((data!=null))) throw new jass.runtime.PostconditionException("idebughc.examples.SimpleCollect","SimpleCollect()",284,"data_initialized");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "SimpleCollect()", false), jassParameters);

  }

	/* --- The following methods of class idebughc.examples.SimpleCollect are generated by JASS --- */


	protected void finalize () throws java.lang.Throwable {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "finalize()", true), jassParameters);
		super.finalize();
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "finalize()", false), jassParameters);
	}

	public boolean equals (java.lang.Object par0) {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(par0)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "equals(java.lang.Object)", true), jassParameters);
		boolean returnValue = super.equals(par0);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(returnValue)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "equals(java.lang.Object)", false), jassParameters);
		return returnValue;
	}

	public java.lang.String toString () {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "toString()", true), jassParameters);
		java.lang.String returnValue = super.toString();
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(returnValue)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "toString()", false), jassParameters);
		return returnValue;
	}

	public boolean checkDebugCollectRef (idebughc.Debug par0) {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(par0)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "checkDebugCollectRef(idebughc.Debug)", true), jassParameters);
		boolean returnValue = super.checkDebugCollectRef(par0);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(returnValue)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "checkDebugCollectRef(idebughc.Debug)", false), jassParameters);
		return returnValue;
	}

	public boolean checkStatisticID (idebughc.Statistic par0) {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(par0)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "checkStatisticID(idebughc.Statistic)", true), jassParameters);
		boolean returnValue = super.checkStatisticID(par0);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(returnValue)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "checkStatisticID(idebughc.Statistic)", false), jassParameters);
		return returnValue;
	}

	public boolean isRegistered (idebughc.Statistic par0) {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(par0)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "isRegistered(idebughc.Statistic)", true), jassParameters);
		boolean returnValue = super.isRegistered(par0);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(returnValue)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc.examples", "SimpleCollect", "isRegistered(idebughc.Statistic)", false), jassParameters);
		return returnValue;
	}
    
  // Public Methods
  // Protected Methods
  // Package Methods
  // Private Methods

} // end of class SimpleCollect

/*
 * Local Variables:
 * Mode: Java
 * fill-column: 75
 * End: 
 */
