
                             README for IDebug
     _________________________________________________________________

   Welcome to IDebug, an advanced debugging framework for Java!

Source Code

   This release of IDebug does include source code. See the [1]source
   directory for more information.

   If you wish to contribute to IDebug, please email
   [2]idebug@kindsoftware.com and we can discuss our process (e.g.
   patches, CVS access, contributor maintaining ownership of
   additions/changes, etc.).

Documentation

   This release of IDebug comes with several sets of documentation.
    1. The IDebug [3]brief, a short summary of the framework.
    2. A [4]design overview for a top-level perspective of the system.
       This document includes system requirements, background, and a
       design dictionary.
    3. A full [5]BON specification of IDebug. See [6]ISE's BON summary
       for more information on BON.
       Note that in the design overview and BON specification we call the
       general system being specified the "Monitoring" system. IDebug is
       an implementation of this specification.
    4. Full [7]Javadoc-generated documentation is included in the
       docs/javadoc directory.
    5. A [8]technical report describing IDebug is included in the
       directory docs/manual. This document isn't a true "user's manual".
       Such a document will be included in the 1.0 release of IDebug.
    6. Miscellaneous other documentation ([9]release notes, [10]FAQ,
       [11]TODO list, etc.) are included in several text files in the
       same directory as this file.
    7. Use the source! The source code, or more specifically, the full
       [12]Design by Contract specification that can be found in the
       source, is your best guide toward the correct use of IDebug. We,
       of course, use the excellent [13]Infospheres Java Code Standard in
       IDebug.

Using IDebug

   To learn how to use IDebug, one should read the IDebug [14]technical
   report and peruse the [15]Javadoc documentation. The [16]BON
   specification is also quite useful in getting a more top-level view of
   the architecture. Additionally, the source code for the IDebug
   blackbox test suite has been included in the
   [17]source/idebug/testsuite directory, which should be very revealing
   to the interested developer. In that same directory one can find an
   example extension to the DebugConstants interface called
   FrenchConstants.

   Simply add the IDebug jar file to your CLASSPATH to use IDebug. We
   suggest using the idebughc class for all development and testing and
   switching to the interface-identical idebug package for system
   delivery.

Questions or comments?

   Please email [18]idebug@kindsoftware.com.
     _________________________________________________________________

   [ [19]Index ] [ Readme ] [ [20]FAQ ] [ [21]Release Notes ] [ [22]To-Do
                                   List ]
   [ [23]Technical Report ] [ [24]BON ] [ [25]Javadocs ] [ [26]License ]
     _________________________________________________________________

     [27]Best Viewed With Any Browser. [28]XHTML 1.0 Checked! [29]CSS,
                             Level 2 Checked! 


    by Joseph R. Kiniry <kiniry@kindsoftware.com>

   Last modified: Tue Jun 19 09:44:02 PDT 2001

References

   1. file://localhost/home/kiniry/Projects/Java/IDebug/source
   2. mailto:idebug@kindsoftware.com
   3. file://localhost/home/kiniry/Projects/Java/IDebug/docs/brief.txt
   4. file://localhost/home/kiniry/Projects/Java/IDebug/docs/Monitoring.txt
   5. file://localhost/home/kiniry/Projects/Java/IDebug/docs/BON/index.html
   6. http://www.eiffel.com/products/bon.html
   7. file://localhost/home/kiniry/Projects/Java/IDebug/docs/javadoc/index.html
   8. file://localhost/home/kiniry/Projects/Java/IDebug/docs/manual/index.html
   9. file://localhost/home/kiniry/Projects/Java/IDebug/RELEASE_NOTES.html
  10. file://localhost/home/kiniry/Projects/Java/IDebug/FAQ.html
  11. file://localhost/home/kiniry/Projects/Java/IDebug/TODO.html
  12. http://www.eiffel.com/doc/manuals/technology/contract/page.html
  13. http://www.infospheres.caltech.edu/resources/code_standards/java_standard.html
  14. file://localhost/home/kiniry/Projects/Java/IDebug/docs/manual/index.html
  15. file://localhost/home/kiniry/Projects/Java/IDebug/docs/javadoc/index.html
  16. file://localhost/home/kiniry/Projects/Java/IDebug/docs/BON/index.html
  17. file://localhost/home/kiniry/Projects/Java/IDebug/source/idebug/testsuite/
  18. mailto:idebug@kindsoftware.com
  19. file://localhost/home/kiniry/Projects/Java/IDebug/index.html
  20. file://localhost/home/kiniry/Projects/Java/IDebug/FAQ.html
  21. file://localhost/home/kiniry/Projects/Java/IDebug/RELEASE_NOTES.html
  22. file://localhost/home/kiniry/Projects/Java/IDebug/TODO.html
  23. file://localhost/home/kiniry/Projects/Java/IDebug/docs/manual/index.html
  24. file://localhost/home/kiniry/Projects/Java/IDebug/docs/BON/index.html
  25. file://localhost/home/kiniry/Projects/Java/IDebug/docs/javadoc/index.html
  26. file://localhost/home/kiniry/Projects/Java/IDebug/LICENSE.html
  27. http://www.anybrowser.org/campaign/
  28. http://validator.w3.org/check/referer
  29. http://jigsaw.w3.org/css-validator/check/referer
