/*
 * Software Engineering Tools.
 *
 * $Id: ServletLogOutput.jass,v 1.9 2001/06/09 07:56:04 kiniry Exp $
 *
 * Copyright (c) 1997-2001 Joseph Kiniry
 * Copyright (c) 2000-2001 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS
 * IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL KIND SOFTWARE OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebughc;

import java.io.Writer;
import java.util.Enumeration;
import javax.servlet.*;

/**
 * <p> The class used to send debugging messages from within Java
 * servlets. </p>
 *
 * @version $Revision: 1.9 $ $Date: 2001/06/09 07:56:04 $
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @concurrency (GUARDED) All methods are synchronized.
 */

public class ServletLogOutput extends DebugOutputBase 
  implements DebugOutput, Cloneable
{
  // Attributes

  /**
   * <p> The <code>ServletContext</code> instance associated with this
   * instance of ServletLogOutput. </p>
   */

  private ServletContext servletContext;

  // Inherited Methods

  public Object clone()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "clone()", true), jassParameters);
  	java.lang.Object jassResult;

    try {
  		jassResult = ( super.clone());
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "clone()", false), jassParameters);


  		return jassResult;
    } catch (CloneNotSupportedException cnse) {
      throw new RuntimeException(cnse.getMessage());
    }
  }

  public synchronized void printMsg(String category, String message)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(category), new jass.runtime.traceAssertion.Parameter(message)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "printMsg(java.lang.String,java.lang.String)", true), jassParameters);


    servletContext.log("<" + category + ">: " + message);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "printMsg(java.lang.String,java.lang.String)", false), jassParameters);

  }

  public synchronized void printMsg(int level, String message)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(level), new jass.runtime.traceAssertion.Parameter(message)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "printMsg(int,java.lang.String)", true), jassParameters);


    servletContext.log("[" + level + "]: " + message);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "printMsg(int,java.lang.String)", false), jassParameters);

  }

  public synchronized void printMsg(String message)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(message)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "printMsg(java.lang.String)", true), jassParameters);


    servletContext.log(message);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "printMsg(java.lang.String)", false), jassParameters);

  }

  public synchronized Writer getWriter()
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "getWriter()", true), jassParameters);
  	java.io.Writer jassResult;

  	jassResult = ( null);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "getWriter()", false), jassParameters);


  	return jassResult;
  }

  // Constructors

  /**
   * <p> Construct a new <code>ServletLogOutput</code> object for debugging
   * purposes. A dummy <code>ServletContext</code> will be created and
   * output will go to <code>System.err</code>. </p>
   *
   * @param d the <code>Debug</code> class associated with this
   * <code>ServletLogOutput</code>.
   */
  
  public ServletLogOutput(Debug d)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(d)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "ServletLogOutput(idebughc.Debug)", true), jassParameters);


  	idebughc.ServletLogOutput jassOld = (idebughc.ServletLogOutput)this.clone();
  	/* precondition */
  	if (!((d!=null))) throw new jass.runtime.PreconditionException("idebughc.ServletLogOutput","ServletLogOutput(idebughc.Debug)",112,"d_non_null");

    debug = d;
    servletContext = new DummyServletContext();
  	/* postcondition */
  	if (!((debug==d))) throw new jass.runtime.PostconditionException("idebughc.ServletLogOutput","ServletLogOutput(idebughc.Debug)",117,"debug_valid");
  	if (!((servletContext!=null))) throw new jass.runtime.PostconditionException("idebughc.ServletLogOutput","ServletLogOutput(idebughc.Debug)",118,"servletContext_valid");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "ServletLogOutput(idebughc.Debug)", false), jassParameters);

  }

  /**
   * <p> Construct a new <code>ServletLogOutput</code> object. </p>
   *
   * @param d the <code>Debug</code> class associated with this
   * <code>ServletLogOutput</code>.
   * @param s the <code>ServletContext</code> associated with this instance
   * of <code>ServletLogOutput</code>.
   */
  
  public ServletLogOutput(Debug d, ServletContext s)
  {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(d), new jass.runtime.traceAssertion.Parameter(s)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "ServletLogOutput(idebughc.Debug,javax.servlet.ServletContext)", true), jassParameters);


  	idebughc.ServletLogOutput jassOld = (idebughc.ServletLogOutput)this.clone();
  	/* precondition */
  	if (!((d!=null))) throw new jass.runtime.PreconditionException("idebughc.ServletLogOutput","ServletLogOutput(idebughc.Debug,javax.servlet.ServletContext)",133,"d_non_null");
  	if (!((s!=null))) throw new jass.runtime.PreconditionException("idebughc.ServletLogOutput","ServletLogOutput(idebughc.Debug,javax.servlet.ServletContext)",134,"s_non_null");

    debug = d;
    servletContext = s;
  	/* postcondition */
  	if (!((debug==d))) throw new jass.runtime.PostconditionException("idebughc.ServletLogOutput","ServletLogOutput(idebughc.Debug,javax.servlet.ServletContext)",139,"debug_valid");
  	if (!((servletContext==s))) throw new jass.runtime.PostconditionException("idebughc.ServletLogOutput","ServletLogOutput(idebughc.Debug,javax.servlet.ServletContext)",140,"servletContext_valid");
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "ServletLogOutput(idebughc.Debug,javax.servlet.ServletContext)", false), jassParameters);

  }

  // Public Methods
  // Protected Methods
  // Package Methods
  // Private Methods
  // Inner Classes

  /**
   * <p> <code>DummyServletContext</code> is a dummy placeholder
   * <code>ServletContext</code> used during white and blackbox testing.  It
   * includes just enough code so that utilization of <code>log()</code> and
   * <code>getRealPath()</code> work.  All other methods return
   * <code>null</code>. </p>
   *
   * @history This class comes from the Jiki.
   * @see <a href="http://www.jiki.org/">Jiki.Org</a> 
   **/

  private class DummyServletContext implements ServletContext
  {
    DummyServletContext()
    {
      super();
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "DummyServletContext()", true), jassParameters);


      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "DummyServletContext()", false), jassParameters);

    }
    
    public Servlet getServlet(String name) throws ServletException
    {
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(name)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "getServlet(java.lang.String)", true), jassParameters);
    	javax.servlet.Servlet jassResult;

    	jassResult = ( null);
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "getServlet(java.lang.String)", false), jassParameters);


    	return jassResult;
    }

    public Enumeration getServlets()
    {
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "getServlets()", true), jassParameters);
    	java.util.Enumeration jassResult;

    	jassResult = ( null);
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "getServlets()", false), jassParameters);


    	return jassResult;
    }

    public Enumeration getServletNames()
    {
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "getServletNames()", true), jassParameters);
    	java.util.Enumeration jassResult;

    	jassResult = ( null);
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "getServletNames()", false), jassParameters);


    	return jassResult;
    }
    
    public void log(String msg)
    {
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(msg)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "log(java.lang.String)", true), jassParameters);


      System.err.print(msg);
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "log(java.lang.String)", false), jassParameters);

    }
  
    public void log(Exception exception, String msg)
    {
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(exception), new jass.runtime.traceAssertion.Parameter(msg)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "log(java.lang.Exception,java.lang.String)", true), jassParameters);


      System.err.print(msg);
      exception.printStackTrace(System.err);
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "log(java.lang.Exception,java.lang.String)", false), jassParameters);

    }
  
    public String getRealPath(String path)
    {
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(path)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "getRealPath(java.lang.String)", true), jassParameters);
    	java.lang.String jassResult;

    	jassResult = ( path);
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "getRealPath(java.lang.String)", false), jassParameters);


    	return jassResult;
    }

    public String getMimeType(String file)
    {
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(file)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "getMimeType(java.lang.String)", true), jassParameters);
    	java.lang.String jassResult;

    	jassResult = ( null);
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "getMimeType(java.lang.String)", false), jassParameters);


    	return jassResult;
    }
  
    public String getServerInfo()
    {
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "getServerInfo()", true), jassParameters);
    	java.lang.String jassResult;

    	jassResult = ( "DummyServletContext, originally a part of Jiki " +
        "- http://www.jiki.org/.");
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "getServerInfo()", false), jassParameters);


    	return jassResult;
    }
  
    public Object getAttribute(String name)
    {
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(name)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "getAttribute(java.lang.String)", true), jassParameters);
    	java.lang.Object jassResult;

    	jassResult = ( null);
      jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(jassResult)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput$DummyServletContext", "getAttribute(java.lang.String)", false), jassParameters);


    	return jassResult;
    }
  }

	/* --- The following methods of class idebughc.ServletLogOutput are generated by JASS --- */


	protected void finalize () throws java.lang.Throwable {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "finalize()", true), jassParameters);
		super.finalize();
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "finalize()", false), jassParameters);
	}

	public boolean equals (java.lang.Object par0) {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(par0)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "equals(java.lang.Object)", true), jassParameters);
		boolean returnValue = super.equals(par0);
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(returnValue)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "equals(java.lang.Object)", false), jassParameters);
		return returnValue;
	}

	public java.lang.String toString () {
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jass.runtime.traceAssertion.Parameter[] jassParameters; jassParameters = new jass.runtime.traceAssertion.Parameter[] {}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "toString()", true), jassParameters);
		java.lang.String returnValue = super.toString();
    jass.runtime.traceAssertion.CommunicationManager.internalAction = true; jassParameters = new jass.runtime.traceAssertion.Parameter[] {new jass.runtime.traceAssertion.Parameter(returnValue)}; jass.runtime.traceAssertion.CommunicationManager.internalAction = false; jass.runtime.traceAssertion.CommunicationManager.communicate(this, new jass.runtime.traceAssertion.MethodReference("idebughc", "ServletLogOutput", "toString()", false), jassParameters);
		return returnValue;
	}

} // end of class ServletLogOutput

/*
 * Local Variables:
 * Mode: Java
 * fill-column: 75
 * End:
 */

