
                             README for IDebug
     _________________________________________________________________

   Welcome to IDebug, an advanced debugging framework for Java!

Source Code

   This  release  of  IDebug  does  include  source  code. See the source
   directory for more information.

   If    you    wish    to    contribute    to   IDebug,   please   email
   [1]idebug@kindsoftware.com  and  we  can  discuss  our  process  (e.g.
   patches,    CVS   access,   contributor   maintaining   ownership   of
   additions/changes, etc.).

Documentation

   This release of IDebug comes with several sets of documentation.
    1. The IDebug [2]brief, a short summary of the framework.
    2. A  [3]design  overview  for a top-level perspective of the system.
       This  document  includes  system  requirements,  background, and a
       design dictionary.
    3. A  full  [4]BON  specification of IDebug. See [5]ISE's BON summary
       for more information on BON.
       Note that in the design overview and BON specification we call the
       general  system being specified the "Monitoring" system. IDebug is
       an implementation of this specification.
    4. Full   [6]Javadoc-generated   documentation  is  included  in  the
       docs/javadoc directory.
    5. A  [7]technical  report  describing  IDebug  is  included  in  the
       directory docs/manual. This document isn't a true "user's manual".
       Such a document will be included in the 1.0 release of IDebug.
    6. Miscellaneous   other  documentation  ([8]release  notes,  [9]FAQ,
       [10]TODO  list,  etc.)  are  included in several text files in the
       same directory as this file.
    7. Use  the  source!  The source code, or more specifically, the full
       [11]Design  by  Contract  specification  that  can be found in the
       source,  is  your best guide toward the correct use of IDebug. We,
       of  course,  use the excellent [12]KindSoftware Coding Standard in
       IDebug.

Using IDebug

   To  learn  how to use IDebug, one should read the IDebug [13]technical
   report   and   peruse   the  [14]Javadoc  documentation.  The  [15]BON
   specification is also quite useful in getting a more top-level view of
   the  architecture.  Additionally,  the  source  code  for  the  IDebug
   blackbox test suite has been included in the
   [16]source/idebug/testsuite  directory, which should be very revealing
   to  the  interested  developer. In that same directory one can find an
   example    extension    to   the   DebugConstants   interface   called
   FrenchConstants.

   Simply  add  the  IDebug  jar file to your CLASSPATH to use IDebug. We
   suggest  using  the idebughc class for all development and testing and
   switching   to  the  interface-identical  idebug  package  for  system
   delivery.

Questions or comments?

   Please email [17]idebug@kindsoftware.com.
     _________________________________________________________________

   [ [18]Index ] [ Readme ] [ [19]FAQ ] [ [20]Release Notes ] [ [21]To-Do
                                   List ]
   [ [22]Technical Report ] [ [23]BON ] [ [24]Javadocs ] [ [25]License ]
     _________________________________________________________________

     [26]Best Viewed With Any Browser. [27]XHTML 1.0 Checked! [28]CSS,
                             Level 2 Checked! 


    by Joseph R. Kiniry <kiniry@kindsoftware.com>

   Last modified: Thu Dec 27 23:00:06 PST 2001

References

   1. mailto:idebug@kindsoftware.com
   2. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/docs/brief.txt
   3. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/docs/Monitoring.txt
   4. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/docs/BON/index.html
   5. http://www.eiffel.com/products/bon.html
   6. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/docs/javadoc/index.html
   7. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/docs/manual/index.html
   8. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/RELEASE_NOTES.html
   9. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/FAQ.html
  10. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/TODO.html
  11. http://www.eiffel.com/doc/manuals/technology/contract/page.html
  12. http://www.kindsoftware.com//documents/whitepapers/
  13. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/docs/manual/index.html
  14. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/docs/javadoc/index.html
  15. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/docs/BON/index.html
  16. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/source/idebug/testsuite/
  17. mailto:idebug@kindsoftware.com
  18. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/index.html
  19. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/FAQ.html
  20. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/RELEASE_NOTES.html
  21. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/TODO.html
  22. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/docs/manual/index.html
  23. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/docs/BON/index.html
  24. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/docs/javadoc/index.html
  25. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/IDebug/LICENSE.html
  26. http://www.anybrowser.org/campaign/
  27. http://validator.w3.org/check/referer
  28. http://jigsaw.w3.org/css-validator/check/referer
