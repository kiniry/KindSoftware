/*
 * Software Engineering Tools.
 *
 * $Id: ServletLogOutput.jass,v 1.10 2001/12/21 22:16:49 kiniry Exp $
 *
 * Copyright (c) 1997-2001 Joseph Kiniry
 * Copyright (c) 2000-2001 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS
 * IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL KIND SOFTWARE OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebughc;

import java.io.InputStream;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Set;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

/**
 * <p> The class used to send debugging messages from within Java
 * servlets. </p>
 *
 * @version $Revision: 1.10 $ $Date: 2001/12/21 22:16:49 $
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @concurrency (GUARDED) All methods are synchronized.
 */

public class ServletLogOutput extends DebugOutputBase 
  implements DebugOutput, Cloneable
{
  // Attributes

  /**
   * <p> The <code>ServletContext</code> instance associated with this
   * instance of ServletLogOutput. </p>
   */

  private ServletContext servletContext;

  // Inherited Methods

  public Object clone()
  {  	java.lang.Object jassResult;

    try {
  		jassResult = ( super.clone());
  		return jassResult;
    } catch (CloneNotSupportedException cnse) {
      throw new RuntimeException(cnse.getMessage());
    }
  }

  public synchronized void printMsg(String category, String message)
  {

    servletContext.log("<" + category + ">: " + message);
  }

  public synchronized void printMsg(int level, String message)
  {

    servletContext.log("[" + level + "]: " + message);
  }

  public synchronized void printMsg(String message)
  {

    servletContext.log(message);
  }

  public synchronized Writer getWriter()
  {  	java.io.Writer jassResult;

  	jassResult = ( null);
  	return jassResult;
  }

  // Constructors

  /**
   * <p> Construct a new <code>ServletLogOutput</code> object for debugging
   * purposes. A dummy <code>ServletContext</code> will be created and
   * output will go to <code>System.err</code>. </p>
   *
   * @param d the <code>Debug</code> class associated with this
   * <code>ServletLogOutput</code>.
   */
  
  public ServletLogOutput(Debug d)
  {

  	/* precondition */
  	if (!((d!=null))) throw new jass.runtime.PreconditionException("idebughc.ServletLogOutput","ServletLogOutput(idebughc.Debug)",119,"d_non_null");

    debug = d;
    servletContext = new DummyServletContext();
  }

  /**
   * <p> Construct a new <code>ServletLogOutput</code> object. </p>
   *
   * @param d the <code>Debug</code> class associated with this
   * <code>ServletLogOutput</code>.
   * @param s the <code>ServletContext</code> associated with this instance
   * of <code>ServletLogOutput</code>.
   */
  
  public ServletLogOutput(Debug d, ServletContext s)
  {

  	/* precondition */
  	if (!((d!=null))) throw new jass.runtime.PreconditionException("idebughc.ServletLogOutput","ServletLogOutput(idebughc.Debug,javax.servlet.ServletContext)",140,"d_non_null");
  	if (!((s!=null))) throw new jass.runtime.PreconditionException("idebughc.ServletLogOutput","ServletLogOutput(idebughc.Debug,javax.servlet.ServletContext)",141,"s_non_null");

    debug = d;
    servletContext = s;
  }

  // Public Methods
  // Protected Methods
  // Package Methods
  // Private Methods
  // Inner Classes

  /**
   * <p> <code>DummyServletContext</code> is a dummy placeholder
   * <code>ServletContext</code> used during white and blackbox testing.  It
   * includes just enough code so that utilization of <code>log()</code> and
   * <code>getRealPath()</code> work.  All other methods return
   * <code>null</code>. </p>
   *
   * @history This class comes from the Jiki.
   * @see <a href="http://www.jiki.org/">Jiki.Org</a> 
   **/

  private class DummyServletContext implements ServletContext
  {
    DummyServletContext() { super();
 }
    
    public ServletContext getContext(String uripath)
    {    	javax.servlet.ServletContext jassResult;

    	jassResult = ( null);
    	return jassResult; }

    public int getMajorVersion() {    	int jassResult;

    	jassResult = ( 0);
    	return jassResult; }

    public int getMinorVersion() {    	int jassResult;

    	jassResult = ( 0);
    	return jassResult; }

    public String getMimeType(String file) {    	java.lang.String jassResult;

    	jassResult = ( null);
    	return jassResult; }

    public Set getResourcePaths(String path) {    	java.util.Set jassResult;

    	jassResult = ( null);
    	return jassResult; }

    public URL getResource(String path) throws MalformedURLException
    {    	java.net.URL jassResult;

    	jassResult = ( null);
    	return jassResult; }

    public InputStream getResourceAsStream(String path)
    {    	java.io.InputStream jassResult;

    	jassResult = ( null);
    	return jassResult; }

    public RequestDispatcher getRequestDispatcher(String path)
    {    	javax.servlet.RequestDispatcher jassResult;

    	jassResult = ( null);
    	return jassResult; }

    public RequestDispatcher getNamedDispatcher(java.lang.String name)
    {    	javax.servlet.RequestDispatcher jassResult;

    	jassResult = ( null);
    	return jassResult; }

    public Servlet getServlet(String name) throws ServletException
    {    	javax.servlet.Servlet jassResult;

    	jassResult = ( null);
    	return jassResult; }

    public Enumeration getServlets() {    	java.util.Enumeration jassResult;

    	jassResult = ( null);
    	return jassResult; }

    public Enumeration getServletNames() {    	java.util.Enumeration jassResult;

    	jassResult = ( null);
    	return jassResult; }
    
    public void log(String msg) {
 System.err.print(msg); }
  
    public void log(Exception exception, String msg) 
    {

      System.err.print(msg);
      exception.printStackTrace(System.err);
    }

    public void log(String msg, Throwable throwable)
    {

      System.err.print(msg);
      throwable.printStackTrace(System.err);
    }
  
    public String getRealPath(String path) {    	java.lang.String jassResult;

    	jassResult = ( path);
    	return jassResult; }

    public String getServerInfo()
    {    	java.lang.String jassResult;

    	jassResult = ( "DummyServletContext, originally a part of Jiki " +
        "- http://www.jiki.org/.");
    	return jassResult;
    }

    public String getInitParameter(String name) {    	java.lang.String jassResult;

    	jassResult = ( null);
    	return jassResult; }

    public Enumeration getInitParameterNames() {    	java.util.Enumeration jassResult;

    	jassResult = ( null);
    	return jassResult; }
  
    public Object getAttribute(String name) {    	java.lang.Object jassResult;

    	jassResult = ( null);
    	return jassResult; }

    public Enumeration getAttributeNames() {    	java.util.Enumeration jassResult;

    	jassResult = ( null);
    	return jassResult; }

    public void setAttribute(String name, Object object) {
 }
    
    public void removeAttribute(String name) {
 }

    public String getServletContextName() {    	java.lang.String jassResult;

    	jassResult = ( null);
    	return jassResult; }
  }

} // end of class ServletLogOutput

/*
 * Local Variables:
 * Mode: Java
 * fill-column: 75
 * End:
 */

