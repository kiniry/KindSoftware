/*
 * Software Engineering Tools.
 *
 * $Id: SimpleCollect.jass,v 1.2 2001/05/29 05:05:58 kiniry Exp $
 *
 * Copyright (c) 1997-2001 Joseph Kiniry
 * Copyright (c) 2000-2001 KindSoftware, LLC
 * Copyright (c) 1997-1999 California Institute of Technology
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * - Neither the name of the Joseph Kiniry, KindSoftware, nor the
 * California Institute of Technology, nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS
 * IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL KIND SOFTWARE OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package idebughc.examples;

import idebughc.*;
import java.util.Enumeration;
import java.util.Hashtable;

/**
 * <p> A default simple core interface to gathering statistics. </p>
 *
 * <p> Users of IDebug wishing to keep statistics on their system need to
 * inherit from this abstract class and implement the protected methods.
 * The simplest means to collect statistics are to use a hashtable keyed on
 * statistic (since their <code>hashCode</code> is valid) and store
 * <code>Double</code> objects corresponding to the current value of that
 * statistic.  This class implements this method as an example and for
 * use. </p>
 *
 * <p> Note that this class performs <strong>no filtering
 * whatsoever</strong>.  Regardless of the current debug context, etc.,
 * this class will keep track of all statistics. </p>
 *
 * @version $Revision: 1.2 $ $Date: 2001/05/29 05:05:58 $
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @see Statistic
 * @see Collect 
 */

public class SimpleCollect extends Collect implements Cloneable
{
  // Attributes

  /**
   * <p> A table used to hold the data being collected. </p>
   */

  private Hashtable data;
  
  // Inherited methods

  public Object clone()
  {  	java.lang.Object jassResult;

    try {
  		jassResult = ( super.clone());
  		return jassResult;
    } catch (CloneNotSupportedException cnse) {
      throw new RuntimeException(cnse.getMessage());
    }
  }

  /**
   * <p> Register a statistic with the collector. </p>
   *
   * @param statistic the statistic to register.
   @require
<b>statistic_non_null</b>: <code>(<code>statistic!=null</code>)</code>
@ensure
<b>statistic_registered</b>: <code>isRegistered(<code>statistic</code>)</code>
*/

  public void register(Statistic statistic)
  {

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","register(idebughc.Statistic)",96,"statistic_non_null");

    super.register(statistic);
    reset(statistic);
  }

  /**
   * <p> Unregister a statistic with the collector. </p>
   *
   * @param statistic the statistic to unregister.
   @require
<b>statistic_non_null</b>: <code>(<code>statistic!=null</code>)</code>
@ensure
<b>statistic_registered</b>: <code>isRegistered(<code>statistic</code>)</code>
*/

  public void unregister(Statistic statistic)
  {

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","unregister(idebughc.Statistic)",112,"statistic_non_null");

    super.unregister(statistic);
    data.remove(statistic);
  }

  /**
   * <p> What is the current value for specific statistic? </p>
   *
   * @param statistic the statistic being modified.
   * @return the old value of the statistic.
   @require
<b>statistic_non_null</b>: <code>(<code>statistic!=null</code>)</code>
*/

  public double currentValue(Statistic statistic)
  {  	double jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","currentValue(idebughc.Statistic)",129,"statistic_non_null");
  	jassResult = ( ((Double)data.get(statistic)).doubleValue());
  	return jassResult;
  }

  /**
   * <p> Report on a particular statistic. </p>
   *
   * @param statistic the statistic being reported on.
   * @return a simple <code>String</code> textual report.
   @require
<b>statistic_non_null</b>: <code>(<code>statistic!=null</code>)</code>
*/

  public Object report(Statistic statistic)
  {  	java.lang.Object jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","report(idebughc.Statistic)",143,"statistic_non_null");
  	jassResult = ( "[" + statistic.getID() + "]" + 
     ( ((Double)data.get(statistic)).doubleValue() * statistic.getScale()) +
      " " + statistic.getUnits());
  	return jassResult;
  }

  /**
   * <p> Report on all statistics. </p>
   *
   * @return a report on all statistics as a concatented
   * <code>String</code> textual report.
   * @see #report(Statistic)
   */

  public Object reportAll()
  {  	java.lang.Object jassResult;

    String fullReport = new String();
    Enumeration keys = data.keys();

    while (keys.hasMoreElements()) {
      fullReport = fullReport + report((Statistic)keys.nextElement()) + "\n";
    }
  	jassResult = ( fullReport);
  	return jassResult;
  }

  /**
   * <p> Increment a statistic by a specified value. </p>
   *
   * @param statistic the statistic being modified.
   * @param value the amount to increment the statistic.
   * @return the old value of the statistic.
   @require
<b>statistic_non_null</b>: <code>(<code>statistic!=null</code>)</code>
*/

  public double increment(Statistic statistic, double value)
  {  	double jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","increment(idebughc.Statistic,double)",179,"statistic_non_null");

    double oldValue = currentValue(statistic);
    
    data.put(statistic, new Double(oldValue + value));
  	jassResult = ( oldValue);
  	return jassResult;
  }
  
  /**
   * <p> Increment a statistic by the default value. </p>
   *
   * @param statistic the statistic being modified.
   * @return the old value of the statistic.
   @require
<b>statistic_non_null</b>: <code>(<code>statistic!=null</code>)</code>
*/

  public double increment(Statistic statistic)
  {  	double jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","increment(idebughc.Statistic)",196,"statistic_non_null");

    double oldValue = currentValue(statistic);

    data.put(statistic, new Double(oldValue + statistic.getIncrement()));
  	jassResult = ( oldValue);
  	return jassResult;
  }
 
  /**
   * <p> Decrement a statistic by a specified value. </p>
   *
   * @param statistic the statistic being modified.
   * @param value the amount to decrement the statistic.
   * @return the old value of the statistic.
   @require
<b>statistic_non_null</b>: <code>(<code>statistic!=null</code>)</code>
*/

  public double decrement(Statistic statistic, double value)
  {  	double jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","decrement(idebughc.Statistic,double)",214,"statistic_non_null");

    double oldValue = currentValue(statistic);
    
    data.put(statistic, new Double(oldValue - value));
  	jassResult = ( oldValue);
  	return jassResult;
  }

  /**
   * <p> Decrement a statistic by the default value. </p>
   *
   * @param statistic the statistic being modified.
   * @return the old value of the statistic.
   @require
<b>statistic_non_null</b>: <code>(<code>statistic!=null</code>)</code>
*/

  public double decrement(Statistic statistic)
  {  	double jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","decrement(idebughc.Statistic)",231,"statistic_non_null");

    double oldValue = currentValue(statistic);
    
    data.put(statistic, new Double(oldValue + statistic.getDecrement()));
  	jassResult = ( oldValue);
  	return jassResult;
  }

  /**
   * <p> Reset a statistic to the default start value. </p>
   *
   * @param statistic the statistic to reset.
   * @return the old value of the statistic.
   @require
<b>statistic_non_null</b>: <code>(<code>statistic!=null</code>)</code>
*/

  public double reset(Statistic statistic)
  {  	double jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","reset(idebughc.Statistic)",248,"statistic_non_null");

    double oldValue = currentValue(statistic);

    data.put(statistic, new Double(statistic.getStart()));
  	jassResult = ( oldValue);
  	return jassResult;
  }
  
  /**
   * <p> Set a statistic to a specific value. </p>
   *
   * @param statistic the statistic being modified.
   * @param value the new value of the statistic.
   * @return the old value of the statistic.
   @require
<b>statistic_non_null</b>: <code>(<code>statistic!=null</code>)</code>
*/

  public double set(Statistic statistic, double value)
  {  	double jassResult;

  	/* precondition */
  	if (!((statistic!=null))) throw new jass.runtime.PreconditionException("idebughc.examples.SimpleCollect","set(idebughc.Statistic,double)",266,"statistic_non_null");

    double oldValue = currentValue(statistic);

    data.put(statistic, new Double(value));
  	jassResult = ( oldValue);
  	return jassResult;
  }
  
  // Constructors

  /**
   * <p> Construct a new <code>SimpleCollect</code> class. </p>
   */

  public SimpleCollect()
  {

    data = new Hashtable();
  }

	/* --- The following methods of class idebughc.examples.SimpleCollect are generated by JASS --- */

    
  // Public Methods
  // Protected Methods
  // Package Methods
  // Private Methods

} // end of class SimpleCollect

/*
 * Local Variables:
 * Mode: Java
 * fill-column: 75
 * End: 
 */
