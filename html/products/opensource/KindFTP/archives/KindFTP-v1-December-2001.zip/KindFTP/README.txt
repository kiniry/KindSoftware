
                             README for KindFTP
     _________________________________________________________________

   Welcome  to  KindFTP,  a  Java  implementation  of  the  FTP  (RFC959)
   protocol.

Source Code

   This  release  of  KindFTP does include source code. See the [1]source
   directory for more information.

   If    you    wish    to    contribute   to   KindFTP,   please   email
   [2]kindftp@kindsoftware.com  and  we  can  discuss  our  process (e.g.
   patches,    CVS   access,   contributor   maintaining   ownership   of
   additions/changes, etc.).

Documentation

   This release of KindFTP comes with several sets of documentation.
    1. The KindFTP [3]brief, a short summary of the package.
    2. Full   [4]Javadoc-generated   documentation  is  included  in  the
       docs/javadoc directory.
    3. Miscellaneous   other  documentation  ([5]release  notes,  [6]FAQ,
       [7]TODO list, etc.) are included in several text files in the same
       directory as this file.
    4. Use  the  source!  The source code, or more specifically, the full
       [8]Design  by  Contract  specification  that  can  be found in the
       source,  is  your best guide toward the correct use of KindFTP. We
       use the excellent [9]KindSoftware Code Standard for KindFTP.

Using KindFTP

   To  learn  how to use KindFTP, one should read the KindFTP [10]Javadoc
   documentation.  Additionally, the source code for the KindFTP blackbox
   test  suite  has  been included, which should be very revealing to the
   interested developer.

   Simply add one of the KindFTP jar files, depending on whether you want
   to use the instrumented version of the code or not, and the IDebug jar
   file  to  your CLASSPATH to use KindFTP. All library files are located
   in the libs directory.

Questions or comments?

   Please email [11]kindftp@kindsoftware.com.
     _________________________________________________________________

   [ [12]Index ] [ Readme ] [ [13]FAQ ] [ [14]Release Notes ] [ [15]To-Do
                                   List ]
                      [ [16]Javadocs ] [ [17]License ]
     _________________________________________________________________

     [18]Best Viewed With Any Browser. [19]XHTML 1.0 Checked! [20]CSS,
                             Level 2 Checked! 


    by Joseph R. Kiniry <kiniry@kindsoftware.com>

   Last modified: Wed Dec 26 23:08:33 PST 2001

References

   1. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source
   2. mailto:kindftp@kindsoftware.com
   3. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/docs/brief.txt
   4. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/docs/javadoc/index.html
   5. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/RELEASE_NOTES.html
   6. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/FAQ.html
   7. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/TODO.html
   8. http://www.eiffel.com/doc/manuals/technology/contract/page.html
   9. http://www.kindsoftware.com/documents/whitepapers/code_standards/
  10. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/docs/javadoc/index.html
  11. mailto:kindftp@kindsoftware.com
  12. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/index.html
  13. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/FAQ.html
  14. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/RELEASE_NOTES.html
  15. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/TODO.html
  16. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/docs/javadoc/index.html
  17. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/LICENSE.html
  18. http://www.anybrowser.org/campaign/
  19. http://validator.w3.org/check/referer
  20. http://jigsaw.w3.org/css-validator/check/referer
