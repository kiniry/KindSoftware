/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: CommandReader.java,v 1.3 2001/12/27 06:52:14 kiniry Exp $
 */

package kindftp;

import java.io.IOException;
import java.io.PushbackReader;
import java.io.Reader;

/**
 * <p> A line-oriented reader with pushback. </p>
 *
 */

public class CommandReader
{
  // Private attributes
  private final PushbackReader pushbackReader;

  // Constructors

  /**
   * <p> Create a new command reader. </p>
   *
   * @param in The reader from which characters will be read.
   * @pre in != null
   */

  public CommandReader(Reader in)
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ boolean __pre_passed = false; // true if at least one pre-cond conj. passed.
/*|*/ // checking kindftp.CommandReader::CommandReader(java.io.PushbackReader)
/*|*/ if (! __pre_passed ) {
/*|*/ if ( (in != null /* do not check prepassed */ ))   __pre_passed = true; // succeeded in: kindftp.CommandReader::CommandReader(java.io.PushbackReader)
/*|*/ else
/*|*/   __pre_passed = false; // failed in: kindftp.CommandReader::CommandReader(java.io.PushbackReader)
/*|*/ }
/*|*/ if (!__pre_passed) {
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/CommandReader.java:34: error: precondition violated (kindftp.CommandReader::CommandReader(java.io.PushbackReader)): (/*declared in kindftp.CommandReader::CommandReader(java.io.PushbackReader)*/ (in != null)) "
/*|*/ ); }}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String txt = "";  if (ex.getClass()==java.lang.Error.class) { txt = ex.toString();; }
/*|*/   else txt = "/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/CommandReader.java:34:  exception <<"+ex+">> occured while evaluating PRE-condition in /home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/CommandReader.java:34:  kindftp.CommandReader::CommandReader(java.io.PushbackReader)): (/*declared in kindftp.CommandReader::CommandReader(java.io.PushbackReader)*/ (in != null)) "
/*|*/ ;
/*|*/   throw new java.lang.Error(txt);}
/*|*/ 
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    pushbackReader = new PushbackReader(in);
  

}

  /**
   * <p> Create a new command reader with a buffer of the given size. </p>
   *
   * @param in The reader from which characters will be read.
   * @param size The size of the command reader.
   * @exception IllegalArgumentException if size is <= 0
   * @pre in != null
   */

  public CommandReader(Reader in, int size)
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ boolean __pre_passed = false; // true if at least one pre-cond conj. passed.
/*|*/ // checking kindftp.CommandReader::CommandReader(java.io.PushbackReader,int)
/*|*/ if (! __pre_passed ) {
/*|*/ if ( (in != null /* do not check prepassed */ ))   __pre_passed = true; // succeeded in: kindftp.CommandReader::CommandReader(java.io.PushbackReader,int)
/*|*/ else
/*|*/   __pre_passed = false; // failed in: kindftp.CommandReader::CommandReader(java.io.PushbackReader,int)
/*|*/ }
/*|*/ if (!__pre_passed) {
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/CommandReader.java:48: error: precondition violated (kindftp.CommandReader::CommandReader(java.io.PushbackReader,int)): (/*declared in kindftp.CommandReader::CommandReader(java.io.PushbackReader,int)*/ (in != null)) "
/*|*/ ); }}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String txt = "";  if (ex.getClass()==java.lang.Error.class) { txt = ex.toString();; }
/*|*/   else txt = "/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/CommandReader.java:48:  exception <<"+ex+">> occured while evaluating PRE-condition in /home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/CommandReader.java:48:  kindftp.CommandReader::CommandReader(java.io.PushbackReader,int)): (/*declared in kindftp.CommandReader::CommandReader(java.io.PushbackReader,int)*/ (in != null)) "
/*|*/ ;
/*|*/   throw new java.lang.Error(txt);}
/*|*/ 
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    pushbackReader = new PushbackReader(in, size);
  

}
  
  // Public Methods

  /**
   * <p> Close the stream. </p>
   *
   * @exception IOException If an I/O error occurs.
   */

  public void close() throws IOException
  {

    if (pushbackReader != null)
      pushbackReader.close();
  

}

  /**
   * <p> Tell whether this stream is ready to be read. </p>
   *
   * @exception IOException If an I/O error occurs.
   */

  public boolean ready() throws IOException
  {

    

if (pushbackReader != null)
      return pushbackReader.ready();
    else return false;
  }

  /**
   * <p> Read a line of text. A line is considered to be terminated by any
   * one of a line feed ('\n'), a carriage return ('\r'), or a carriage
   * return followed immediately by a linefeed. </p>
   *
   * @return A String containing the contents of the line, not including
   * any line-termination characters, or null if the end of the stream has
   * been reached. 
   * @exception IOException If an I/O error occurs.
   */
  
  public String readLine() throws IOException
  {

    int character = 0, optional = 0;
    StringBuffer buffer = new StringBuffer(80);

    do {
      while(true) {
        if (pushbackReader.ready()) {
          character = pushbackReader.read();
          break;
        }
        else
          try {
            Thread.currentThread().sleep(10);
          } catch (InterruptedException ie) {
            // empty
          }
      } 
      if ((character != '\n') || (character != '\r'))
        buffer.append((char)character);
    } while ((character != '\n') && (character != '\r'));

    // If the last character was a carriage return we have to look for an
    // optional following linefeed.
    if (character == '\r') {
      optional = pushbackReader.read();
      if (optional != '\n') {
        pushbackReader.unread(optional);
      }
    }

    

return buffer.toString();
  }

  /**
   * <p> Unread (pushback) a line of text.  The line should not be
   * terminated by any one of a line feed ('\n'), a carriage return ('\r'),
   * or a carriage return followed immediately by a linefeed. </p>
   *
   * @param a String containing the contents of the line, not including
   * any line-termination characters, to be unread.
   * @exception IOException If an I/O error occurs.
   */

  public void unReadLine(String line) throws IOException
  {

    pushbackReader.unread(line.toCharArray());
  

}

} // end of class CommandReader
