/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: IDebugInit.java,v 1.7 2001/12/27 06:52:26 kiniry Exp $
 */

package kindftp;

import idebug.*;

/**
 * <p> A class that centralizes initialization of the IDebug framework for
 * KindFTP. </p>
 *
 * <p> The various get* methods cannot be called until the <tt>init()</tt>
 * method has been called and has completed. </p>
 *
 * @design I'd like to be able to express "invariant stable(initialized)"
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Initial creation.
 * @version $Revision: 1.7 $ $Date: 2001/12/27 06:52:26 $ 
 * @since KindFTP initial release.
 * 
 * @todo Add support for lack of IDebug.
 *
 * @see <a href="http://www.kindsoftware.com/products/opensource/IDebug/">IDebug</a>
 * @see #init
 * @invariant initialized implies 
 *                ((debug != null) && (assert != null) &&
 *                 (debugConstants != null) && (debugOutput != null))
 */

public class IDebugInit
{
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ // Keeps track of calling chain to avoid recursive invariant checks.
/*|*/ // Avoids inv checks in public methods that are called from private ones.
/*|*/ // Stores bookkeeping information -- key: thread, value: call level
/*|*/ protected transient java.util.Hashtable __icl_ = new java.util.Hashtable(1);
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_entry__kindftp_IDebugInit(Thread thread, String loc) throws java.lang.Error {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/     __check_invariant____kindftp_IDebugInit(loc);
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_exit__kindftp_IDebugInit(Thread thread, String loc) throws java.lang.Error {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if (((Integer)__icl_.get(thread)).intValue() == 1 ) {
/*|*/     try {
/*|*/       __check_invariant____kindftp_IDebugInit(loc);
/*|*/     } finally {
/*|*/       __icl_.remove(thread); // remove from bookkeeping, before checking (resoliant wrt exceptions)
/*|*/   }}
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()-1));
/*|*/ }
/*|*/ // Default constructor automatically added to check invariant at implicit return.
/*|*/ // n.b. superclass chaining (call to super()) will be inserted by compiler.
/*|*/ public IDebugInit() throws java.lang.Error {
/*|*/   __check_invariant____kindftp_IDebugInit("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:36: default constructor kindftp.IDebugInit::IDebugInit() does not establish all class invariants at it's exit [class kindftp.IDebugInit does not explicitly define a default constructor. Therefore the compiler implicitly generated a public, empty default constructor] ");
/*|*/ }
/*|*/ // Tests the invariants of the class and its superclasses.
/*|*/ // This method is public (see note below) to give subclasses (potentially in different packages),
/*|*/ // acccess to the inv of superclasses (and to let the reflection API find the.
/*|*/ // method)
/*|*/ //
/*|*/ public synchronized void __check_invariant____kindftp_IDebugInit( String location ) throws java.lang.Error {
/*|*/ try {
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!(  ((debug != null) && (assert != null) && (debugConstants != null) && (debugOutput != null)) )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftp.IDebugInit): "+
/*|*/     "initialized implies  ((debug != null) && (assert != null) && (debugConstants != null) && (debugOutput != null))");}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String msg = "";
/*|*/   if (ex.getClass()==java.lang.Error.class) { msg = ex.toString(); }
/*|*/   else msg = location + " exception <<"+ex+">> occured while evaluating the class INVARIANT.";
/*|*/   throw new java.lang.Error(msg);}
/*|*/ 
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
  // Private Attributes

  // Debugging subsystem variables.
  private static Debug debug;
  private static Assert assert;
  private static DebugConstants debugConstants;
  private static DebugOutput debugOutput;

  // Indiates that debugging variables have been initialized.
  // @modifies SINGLE-ASSIGNMENT
  private static boolean initialized = false;

  // Public Methods

  /**
   * <p> Initialize the debugging subsystem of KindFTP. </p>
   *
   * @post getDebug() != null
   * @post getDebugOutput() != null
   * @post getAssert() != null
   * @post getDebugConstants() != null
   * @post initialized
   */

  public static void init()
  {

    debug = new Debug();
    assert = debug.getAssert();
    debugConstants = debug.getDebugConstants();
    debugOutput = new WindowOutput(debug);
    debug.setOutputInterface(debugOutput);

    Context debugContext = new Context(debugConstants, debugOutput);
    // If you wish to add a new category to the debugging system, this
    // is where to do it.
    debugContext.addCategory("FTP", 2);
    debugContext.addCategory("TEST", 2);
    debugContext.turnOn();
    debug.addContext(debugContext);
    debug.turnOn();
    debug.setLevel(debugConstants.NOTICE_LEVEL);
    initialized = true;
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ if (!(getDebug() != null)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:62: error: postcondition violated (kindftp.IDebugInit::init()): "+
/*|*/   "getDebug() != null");
/*|*/ if (!(getDebugOutput() != null)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:62: error: postcondition violated (kindftp.IDebugInit::init()): "+
/*|*/   "getDebugOutput() != null");
/*|*/ if (!(getAssert() != null)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:62: error: postcondition violated (kindftp.IDebugInit::init()): "+
/*|*/   "getAssert() != null");
/*|*/ if (!(getDebugConstants() != null)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:62: error: postcondition violated (kindftp.IDebugInit::init()): "+
/*|*/   "getDebugConstants() != null");
/*|*/ if (!(initialized)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:62: error: postcondition violated (kindftp.IDebugInit::init()): "+
/*|*/   "initialized");}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String txt = "";  if (ex.getClass()==java.lang.Error.class) { txt = ex.toString();; }
/*|*/   else txt = "/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:62:  exception <<"+ex+">> occured while evaluating POST-condition in /home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:62:  kindftp.IDebugInit::init()";
/*|*/   throw new java.lang.Error(txt);}
/*|*/ 
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  /**
   * @return a reference to the <code>Debug</code> instance associated with
   * KindFTP.
   *
   * @pre initialized #IllegalStateException
   * @post return != null
   */

  public static Debug getDebug()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ idebug.Debug __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ boolean __pre_passed = false; // true if at least one pre-cond conj. passed.
/*|*/ // checking kindftp.IDebugInit::getDebug()
/*|*/ if (! __pre_passed ) {
/*|*/ if ( (initialized /* do not check prepassed */ ))   __pre_passed = true; // succeeded in: kindftp.IDebugInit::getDebug()
/*|*/ else
/*|*/   __pre_passed = false; // failed in: kindftp.IDebugInit::getDebug()
/*|*/ }
/*|*/ if (!__pre_passed) {
/*|*/   throw new IllegalStateException ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:90: error: precondition violated (kindftp.IDebugInit::getDebug()): (/*declared in kindftp.IDebugInit::getDebug()*/ (initialized)) "
/*|*/ ); }}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String txt = "";  if (ex.getClass()==IllegalStateException.class) { txt = ex.toString();; }
/*|*/   else txt = "/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:90:  exception <<"+ex+">> occured while evaluating PRE-condition in /home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:90:  kindftp.IDebugInit::getDebug()): (/*declared in kindftp.IDebugInit::getDebug()*/ (initialized)) "
/*|*/ ;
/*|*/   throw new java.lang.Error(txt);}
/*|*/ 
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ /*
return debug;

/*|*/ 
/*|*/ __return_value_holder_ =  debug;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/   
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ if (!(__return_value_holder_ != null)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:90: error: postcondition violated (kindftp.IDebugInit::getDebug()): "+
/*|*/   "(/*return*/  debug) != null");}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String txt = "";  if (ex.getClass()==java.lang.Error.class) { txt = ex.toString();; }
/*|*/   else txt = "/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:90:  exception <<"+ex+">> occured while evaluating POST-condition in /home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:90:  kindftp.IDebugInit::getDebug()";
/*|*/   throw new java.lang.Error(txt);}
/*|*/ 
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ return __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#

}

  /**
   * @return a reference to the implementation of <code>DebugOutput</code>
   * associated with KindFTP.
   *
   * @pre initialized #IllegalStateException
   * @post return != null
   */

  public static DebugOutput getDebugOutput()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ idebug.DebugOutput __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ boolean __pre_passed = false; // true if at least one pre-cond conj. passed.
/*|*/ // checking kindftp.IDebugInit::getDebugOutput()
/*|*/ if (! __pre_passed ) {
/*|*/ if ( (initialized /* do not check prepassed */ ))   __pre_passed = true; // succeeded in: kindftp.IDebugInit::getDebugOutput()
/*|*/ else
/*|*/   __pre_passed = false; // failed in: kindftp.IDebugInit::getDebugOutput()
/*|*/ }
/*|*/ if (!__pre_passed) {
/*|*/   throw new IllegalStateException ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:103: error: precondition violated (kindftp.IDebugInit::getDebugOutput()): (/*declared in kindftp.IDebugInit::getDebugOutput()*/ (initialized)) "
/*|*/ ); }}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String txt = "";  if (ex.getClass()==IllegalStateException.class) { txt = ex.toString();; }
/*|*/   else txt = "/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:103:  exception <<"+ex+">> occured while evaluating PRE-condition in /home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:103:  kindftp.IDebugInit::getDebugOutput()): (/*declared in kindftp.IDebugInit::getDebugOutput()*/ (initialized)) "
/*|*/ ;
/*|*/   throw new java.lang.Error(txt);}
/*|*/ 
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ /*
return debugOutput;

/*|*/ 
/*|*/ __return_value_holder_ =  debugOutput;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/   
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ if (!(__return_value_holder_ != null)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:103: error: postcondition violated (kindftp.IDebugInit::getDebugOutput()): "+
/*|*/   "(/*return*/  debugOutput) != null");}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String txt = "";  if (ex.getClass()==java.lang.Error.class) { txt = ex.toString();; }
/*|*/   else txt = "/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:103:  exception <<"+ex+">> occured while evaluating POST-condition in /home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:103:  kindftp.IDebugInit::getDebugOutput()";
/*|*/   throw new java.lang.Error(txt);}
/*|*/ 
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ return __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#

}
  
  /**
   * @return a reference to the implementation of <code>Assert</code>
   * associated with KindFTP.
   *
   * @pre initialized #IllegalStateException
   * @post return != null
   */

  public static Assert getAssert()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ idebug.Assert __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ boolean __pre_passed = false; // true if at least one pre-cond conj. passed.
/*|*/ // checking kindftp.IDebugInit::getAssert()
/*|*/ if (! __pre_passed ) {
/*|*/ if ( (initialized /* do not check prepassed */ ))   __pre_passed = true; // succeeded in: kindftp.IDebugInit::getAssert()
/*|*/ else
/*|*/   __pre_passed = false; // failed in: kindftp.IDebugInit::getAssert()
/*|*/ }
/*|*/ if (!__pre_passed) {
/*|*/   throw new IllegalStateException ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:116: error: precondition violated (kindftp.IDebugInit::getAssert()): (/*declared in kindftp.IDebugInit::getAssert()*/ (initialized)) "
/*|*/ ); }}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String txt = "";  if (ex.getClass()==IllegalStateException.class) { txt = ex.toString();; }
/*|*/   else txt = "/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:116:  exception <<"+ex+">> occured while evaluating PRE-condition in /home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:116:  kindftp.IDebugInit::getAssert()): (/*declared in kindftp.IDebugInit::getAssert()*/ (initialized)) "
/*|*/ ;
/*|*/   throw new java.lang.Error(txt);}
/*|*/ 
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ /*
return assert;

/*|*/ 
/*|*/ __return_value_holder_ =  assert;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/   
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ if (!(__return_value_holder_ != null)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:116: error: postcondition violated (kindftp.IDebugInit::getAssert()): "+
/*|*/   "(/*return*/  assert) != null");}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String txt = "";  if (ex.getClass()==java.lang.Error.class) { txt = ex.toString();; }
/*|*/   else txt = "/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:116:  exception <<"+ex+">> occured while evaluating POST-condition in /home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:116:  kindftp.IDebugInit::getAssert()";
/*|*/   throw new java.lang.Error(txt);}
/*|*/ 
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ return __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#

}
  
  /**
   * @return a reference to the implementation of
   * <code>DebugConstants</code> associated with KindFTP.
   *
   * @pre initialized #IllegalStateException
   * @post return != null
   */

  public static DebugConstants getDebugConstants()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ idebug.DebugConstants __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ boolean __pre_passed = false; // true if at least one pre-cond conj. passed.
/*|*/ // checking kindftp.IDebugInit::getDebugConstants()
/*|*/ if (! __pre_passed ) {
/*|*/ if ( (initialized /* do not check prepassed */ ))   __pre_passed = true; // succeeded in: kindftp.IDebugInit::getDebugConstants()
/*|*/ else
/*|*/   __pre_passed = false; // failed in: kindftp.IDebugInit::getDebugConstants()
/*|*/ }
/*|*/ if (!__pre_passed) {
/*|*/   throw new IllegalStateException ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:129: error: precondition violated (kindftp.IDebugInit::getDebugConstants()): (/*declared in kindftp.IDebugInit::getDebugConstants()*/ (initialized)) "
/*|*/ ); }}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String txt = "";  if (ex.getClass()==IllegalStateException.class) { txt = ex.toString();; }
/*|*/   else txt = "/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:129:  exception <<"+ex+">> occured while evaluating PRE-condition in /home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:129:  kindftp.IDebugInit::getDebugConstants()): (/*declared in kindftp.IDebugInit::getDebugConstants()*/ (initialized)) "
/*|*/ ;
/*|*/   throw new java.lang.Error(txt);}
/*|*/ 
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ /*
return debugConstants;

/*|*/ 
/*|*/ __return_value_holder_ =  debugConstants;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/   
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ if (!(__return_value_holder_ != null)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:129: error: postcondition violated (kindftp.IDebugInit::getDebugConstants()): "+
/*|*/   "(/*return*/  debugConstants) != null");}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String txt = "";  if (ex.getClass()==java.lang.Error.class) { txt = ex.toString();; }
/*|*/   else txt = "/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:129:  exception <<"+ex+">> occured while evaluating POST-condition in /home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/IDebugInit.java:129:  kindftp.IDebugInit::getDebugConstants()";
/*|*/   throw new java.lang.Error(txt);}
/*|*/ 
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ return __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#

}
  
} // end of class IDebugInit
