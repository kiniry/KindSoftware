/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: ReplyCodes.java,v 1.6 2001/12/20 07:42:30 kiniry Exp $
 */

package kindftp;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;

/**
 * <p> Reply codes for debugging purposes. </p>
 *
 * <p> The codes' English interpretations are stored in a hashtable for
 * lookup using <tt>convertCode</tt>.  They are taken directory from
 * RFC959. </p>
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Initial creation.
 * @version $Revision: 1.6 $ $Date: 2001/12/20 07:42:30 $ 
 * @since KindFTP initial release.
 *
 * @todo Convert static constant strings in static initializer into
 * references to command codes herein.
 */

public class ReplyCodes extends Hashtable
{
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ // Keeps track of calling chain to avoid recursive invariant checks.
/*|*/ // Avoids inv checks in public methods that are called from private ones.
/*|*/ // Stores bookkeeping information -- key: thread, value: call level
/*|*/ protected transient java.util.Hashtable __icl_ = new java.util.Hashtable(1);
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_entry__kindftp_ReplyCodes(Thread thread, String loc)  {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/     __check_invariant____kindftp_ReplyCodes(loc);
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_exit__kindftp_ReplyCodes(Thread thread, String loc)  {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if (((Integer)__icl_.get(thread)).intValue() == 1 ) {
/*|*/     try {
/*|*/       __check_invariant____kindftp_ReplyCodes(loc);
/*|*/     } finally {
/*|*/       __icl_.remove(thread); // remove from bookkeeping, before checking (resoliant wrt exceptions)
/*|*/   }}
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()-1));
/*|*/ }
/*|*/ // Default constructor automatically added to check invariant at implicit return.
/*|*/ // n.b. superclass chaining (call to super()) will be inserted by compiler.
/*|*/ public ReplyCodes()  {
/*|*/   __check_invariant____kindftp_ReplyCodes("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftp/ReplyCodes.java:31: default constructor kindftp.ReplyCodes::ReplyCodes() does not establish all class invariants at it's exit [class kindftp.ReplyCodes does not explicitly define a default constructor. Therefore the compiler implicitly generated a public, empty default constructor] ");
/*|*/ }
/*|*/ // Tests the invariants of the class and its superclasses.
/*|*/ // This method is public (see note below) to give subclasses (potentially in different packages),
/*|*/ // acccess to the inv of superclasses (and to let the reflection API find the.
/*|*/ // method)
/*|*/ //
/*|*/ public synchronized void __check_invariant____kindftp_ReplyCodes( String location )  {
/*|*/ try {
/*|*/ }
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String msg = "";
/*|*/   if (ex.getClass()==java.lang.Error.class) { msg = ex.toString(); }
/*|*/   else msg = location + " exception <<"+ex+">> occured while evaluating the class INVARIANT.";
/*|*/   throw new java.lang.Error(msg);}
/*|*/ 
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
  // Private attributes

  private static final Hashtable replyCodes = new Hashtable();

  /**
   * <p> Convert the numeric FTP code specified in the parameter
   * <code>code</code> to a English description, taken from RFC959. </p>
   *
   * @param code the code to convert.
   * @return a string conversion of the code.
   */
  
  public static String convertCode(int code)
  {

    

return (String)replyCodes.get(Integer.toString(code));
  }

  /**
   * <p> First-digit encoding of reply values.  See RFC959 for more
   * information. </p>
   */

  public static final int POSITIVE_PRELIMINARY = 1;
  public static final int POSITIVE_COMPLETION = 2;
  public static final int POSITIVE_INTERMEDIATE = 3;
  public static final int TRANSIENT_NEGATIVE_COMPLETION = 4;
  public static final int PERMANENT_NEGATIVE_COMPLETION = 5;

  /**
   * <p> Second-digit encoding of reply values.  See RFC959 for more
   * information. </p>
   */

  public static final int SYNTAX = 0;
  public static final int INFORMATION = 1;
  public static final int CONNECTIONS = 2;
  public static final int AUTHENTICATION_AND_ACCOUNTING = 3;
  public static final int UNSPECIFIED = 4;
  public static final int FILE_SYSTEM = 5;

  /**
   * <p> 100 block of reply codes.  See RFC959 for more information. </p>
   */

  public static final int RESTART_MARKER_REPLY = 110;
  public static final int SERVICE_READY_IN_NNN_MINUTES = 120;
  public static final int DATA_CONNECTION_ALREADY_OPEN_TRANFER_STARTING = 125;
  public static final int FILE_STATUS_OK_ABOUT_TO_OPEN_DATA_CONNECTION = 150;

  /**
   * <p> 200 block of reply codes.  See RFC959 for more information. </p>
   */

  public static final int COMMAND_OK = 200;
  public static final int COMMAND_NOT_IMPLEMENTED_SUPERFLUOUS = 202;
  public static final int STATUS_OR_HELP_REPLY = 211;
  public static final int DIRECTORY_STATUS = 212;
  public static final int FILE_STATUS = 213;
  public static final int HELP_MESSAGE = 214;
  public static final int SYSTEM_TYPE = 215;
  public static final int SERVICE_READY_FOR_NEW_USER = 220;
  public static final int SERVICE_CLOSING_CONTROL_CONNECTION = 221;
  public static final int DATA_CONNECTION_OPEN_NO_TRANSFER_IN_PROGRESS = 225;
  public static final int CLOSING_DATA_CONNECTION_AFTER_SUCCESSFUL_ACTION = 226;
  public static final int ENTERING_PASSIVE_MODE = 227;
  public static final int USER_LOGGED_IN = 230;
  public static final int FILE_ACTION_OK_AND_COMPLETED = 250;
  public static final int DIRECTORY_CREATED = 257;

  /**
   * <p> 300 block of reply codes.  See RFC959 for more information. </p>
   */

  public static final int USER_NAME_OK = 331;
  public static final int NEED_ACCOUNT_FOR_LOGIN = 332;
  public static final int REQUESTED_ACTION_PENDING_MORE_INFO = 350;

  /**
   * <p> 400 block of reply codes.  See RFC959 for more information. </p>
   */

  public static final int SERVICE_NOT_AVAILABLE_CLOSING_CONTROL_CONNECTION = 421;
  public static final int CANNOT_OPEN_DATA_CONNECTION = 425;
  public static final int CONNECTION_CLOSED_TRANSFER_ABORTED = 426;
  public static final int ACTION_NOT_TAKEN_FILE_UNAVAILABLE_FILE_BUSY = 450;
  public static final int ACTION_ABORTED_LOCAL_ERROR = 451;
  public static final int ACTION_NOT_TAKEN_INSUFFICIENT_STORAGE_SPACE = 452;

  /**
   * <p> 500 block of reply codes.  See RFC959 for more information. </p>
   */

  public static final int SYNTAX_ERROR_IN_COMMAND = 500;
  public static final int SYNTAX_ERROR_IN_PARAMETERS = 501;
  public static final int COMMAND_NOT_IMPLEMENTED = 502;
  public static final int BAD_SEQUENCE_OF_COMMANDS = 503;
  public static final int COMMAND_NOT_IMPLEMENTED_FOR_THAT_PARAMETER = 504;
  public static final int NOT_LOGGED_IN = 530;
  public static final int NEED_ACCOUNT = 532;
  public static final int ACTION_NOT_TAKEN_FILE_UNAVAILABLE = 550;
  public static final int ACTION_ABORTED_PAGE_TYPE_UNKNOWN = 551;
  public static final int ACTION_ABORTED_EXCEEDED_STORAGE_ALLOCATION = 552;
  public static final int ACTION_NOT_TAKEN_FILE_NAME_NOT_ALLOWED = 553;

  /**
   * <p> Collections of oft-used errors for postcondition checks. </p>
   */

  public static final int[] standardErrors0 = { 
    SYNTAX_ERROR_IN_COMMAND, SYNTAX_ERROR_IN_PARAMETERS, 
    COMMAND_NOT_IMPLEMENTED, SERVICE_NOT_AVAILABLE_CLOSING_CONTROL_CONNECTION };

  public static final int[] standardErrors1 = { 
    SYNTAX_ERROR_IN_COMMAND, SYNTAX_ERROR_IN_PARAMETERS, 
    COMMAND_NOT_IMPLEMENTED, SERVICE_NOT_AVAILABLE_CLOSING_CONTROL_CONNECTION,
    ACTION_NOT_TAKEN_FILE_UNAVAILABLE };

  public static final int[] standardErrors2 = { 
    SYNTAX_ERROR_IN_COMMAND, SYNTAX_ERROR_IN_PARAMETERS, 
    COMMAND_NOT_IMPLEMENTED_FOR_THAT_PARAMETER, 
    SERVICE_NOT_AVAILABLE_CLOSING_CONTROL_CONNECTION, NOT_LOGGED_IN };

  public static boolean isStandardError_500_501_502_421(int code)
  {

    for(int i=0; i < standardErrors0.length; i++)
      if(standardErrors0[i] == code)
        return true;
    

return false;
  }

  public static boolean isStandardError_500_501_502_421_530(int code)
  {

    for(int i=0; i < standardErrors1.length; i++)
      if(standardErrors1[i] == code)
        return true;
    

return false;
  }

  public static boolean isStandardError_500_501_504_421_530(int code)
  {

    for(int i=0; i < standardErrors2.length; i++)
      if(standardErrors2[i] == code)
        return true;
    

return false;
  }

  // A static initializer for the replyCodes hashtable.

  static 
  {
    // 100 block of reply codes.
    replyCodes.put("110", 
                   "Restart marker reply.  In this case, the text is exact " +
                   "and not left to the\nparticular implementation; it must " +
                   "read: MARK yyyy = mmmm Where yyyy is\nUser-process data " +
                   "stream marker, and mmmm server's equivalent marker (note\n" +
                   "the spaces between markers and \"=\").\n");
    replyCodes.put("120", "Service ready in nnn minutes.");
    replyCodes.put("125", "Data connection already open; transfer starting. ");
    replyCodes.put("150", "File status okay; about to open data connection.");

    // 200 block of reply codes.
    replyCodes.put("200", "Command okay.");
    replyCodes.put("202", "Command not implemented, superfluous at this site. ");
    replyCodes.put("211", "System status, or system help reply.");
    replyCodes.put("212", "Directory status.");
    replyCodes.put("213", "File status.");
    replyCodes.put("214", 
                   "Help message. On how to use the server or the meaning of " +
                   "a particular non-\nstandard command. This reply is useful " +
                   "only to the human user.");
    replyCodes.put("215", 
                   "NAME system type. Where NAME is an official system name " +
                   "from the list in\nthe Assigned Numbers document.");
    replyCodes.put("220", "Service ready for new user.");
    replyCodes.put("221", 
                   "Service closing control connection. Logged out if " +
                   "appropriate.");
    replyCodes.put("225", "Data connection open; no transfer in progress.");
    replyCodes.put("226", 
                   "Closing data connection. Requested file action successful " +
                   "(for example,\nfile transfer or file abort).");
    replyCodes.put("227", "Entering Passive Mode (h1,h2,h3,h4,p1,p2).");
    replyCodes.put("230", "User logged in, proceed.");
    replyCodes.put("250", "Requested file action okay, completed.");
    replyCodes.put("257", "\"PATHNAME\" created.");

    // 300 block of reply codes.
    replyCodes.put("331", "User name okay, need password.");
    replyCodes.put("332", "Need account for login.");
    replyCodes.put("350", "Requested file action pending further information.");

    // 400 block of reply codes.
    replyCodes.put("421", 
                   "Service not available, closing control connection. This may " +
                   "be a reply to\nany command if the service knows it must " +
                   "shut down.");
    replyCodes.put("425", "Can't open data connection.");
    replyCodes.put("426", "Connection closed; transfer aborted.");
    replyCodes.put("450", 
                   "Requested file action not taken. File unavailable (e.g., " +
                   "file busy).");
    replyCodes.put("451", "Requested action aborted: local error in processing. ");
    replyCodes.put("452", 
                   "Requested action not taken. Insufficient storage space in " +
                   "system.");

    // 500 block of reply codes.
    replyCodes.put("500", 
                   "Syntax error, command unrecognized. This may include errors " +
                   "such as\ncommand line too long. ");
    replyCodes.put("501", "Syntax error in parameters or arguments.");
    replyCodes.put("502", "Command not implemented.");
    replyCodes.put("503", "Bad sequence of commands.");
    replyCodes.put("504", "Command not implemented for that parameter.");
    replyCodes.put("530", "Not logged in.");
    replyCodes.put("532", "Need account for storing files.");
    replyCodes.put("550", 
                   "Requested action not taken. File unavailable (e.g., file " +
                   "not found, no access).");
    replyCodes.put("551", "Requested action aborted: page type unknown.");
    replyCodes.put("552", 
                   "Requested file action aborted. Exceeded storage allocation " +
                   "(for current\ndirectory or dataset).");
    replyCodes.put("553", "Requested action not taken. File name not allowed.");
  }

} // end of class ReplyCodes
