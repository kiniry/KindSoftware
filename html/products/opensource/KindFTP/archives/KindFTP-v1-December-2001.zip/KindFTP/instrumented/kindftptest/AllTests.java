/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: AllTests.java,v 1.3 2001/12/20 07:42:30 kiniry Exp $
 */

package kindftptest;

import idebug.*;
import junit.framework.*;

/**
 * <p> A suite of all blackbox tests for the <code>kindftp</code>
 * package. </p>
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history 8 Dec 2001 - Created class and started using jUnit.
 * @version $Revision: 1.3 $ $Date: 2001/12/20 07:42:30 $ 
 * @since KindFTP initial release.
 * @see <a href="http://www.junit.org">jUnit</a>
 */

public class AllTests
{
  // Private Attributes.

  // Public Methods

  public static void main (String[] args) {

    junit.textui.TestRunner.run (suite());
  

}

  public static Test suite() {
 
    TestSuite suite = new TestSuite("All KindFTP Tests.");
    suite.addTest(FTPProxyTestSuite.suite());

    

return suite;
  }
   
} // end of class AllTests
