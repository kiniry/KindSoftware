/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: FTPProxyInitialTestCases.java,v 1.11 2001/12/27 09:23:14 kiniry Exp $
 */

package kindftptest;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import junit.framework.Test;
import junit.framework.TestSuite;
import kindftp.FTPProxy;
import kindftp.ReplyCodes;

/**
 * <p> Test cases for all <code>FTPProxy</code> basic commands that are not
 * send and receive commands. </p>
 *
 * <p> The various get* methods cannot be called until the init() method
 * has been called and has completed. </p>
 *
 * @design I'd like to be able to express "invariant stable(initialized)"
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Initial creation.
 * @version $Revision: 1.11 $ $Date: 2001/12/27 09:23:14 $ 
 * @since KindFTP initial release.
 * 
 * @todo kiniry - Add support for lack of IDebug.
 *
 * @see <a href="http://www.kindsoftware.com/products/opensource/IDebug/">IDebug</a>
 *
 * @invariant initialized implies 
 *                ((debug != null) && (assert != null) &&
 *                 (debugConstants != null) && (debugOutput != null))
 */

public class FTPProxyInitialTestCases extends IDebugTestCase
{
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ // Keeps track of calling chain to avoid recursive invariant checks.
/*|*/ // Avoids inv checks in public methods that are called from private ones.
/*|*/ // Stores bookkeeping information -- key: thread, value: call level
/*|*/ protected transient java.util.Hashtable __icl_ = new java.util.Hashtable(1);
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread thread, String loc) throws java.lang.Error {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/     __check_invariant____kindftptest_FTPProxyInitialTestCases(loc);
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread thread, String loc) throws java.lang.Error {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if (((Integer)__icl_.get(thread)).intValue() == 1 ) {
/*|*/     try {
/*|*/       __check_invariant____kindftptest_FTPProxyInitialTestCases(loc);
/*|*/     } finally {
/*|*/       __icl_.remove(thread); // remove from bookkeeping, before checking (resoliant wrt exceptions)
/*|*/   }}
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()-1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting DO NOT check the invariant (i.e. for non-default constr.)
/*|*/ private synchronized void __inc_icl_at_entry__kindftptest_FTPProxyInitialTestCases(Thread thread)  {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Tests the invariants of the class and its superclasses.
/*|*/ // This method is public (see note below) to give subclasses (potentially in different packages),
/*|*/ // acccess to the inv of superclasses (and to let the reflection API find the.
/*|*/ // method)
/*|*/ //
/*|*/ public synchronized void __check_invariant____kindftptest_FTPProxyInitialTestCases( String location ) throws java.lang.Error {
/*|*/ try {
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!(  ((debug != null) && (assert != null) && (debugConstants != null) && (debugOutput != null)) )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.FTPProxyInitialTestCases): "+
/*|*/     "initialized implies  ((debug != null) && (assert != null) && (debugConstants != null) && (debugOutput != null))");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debug != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debug != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( assert != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies assert != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugConstants != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugConstants != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugOutput != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugOutput != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugCategory != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugCategory != null");}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String msg = "";
/*|*/   if (ex.getClass()==java.lang.Error.class) { msg = ex.toString(); }
/*|*/   else msg = location + " exception <<"+ex+">> occured while evaluating the class INVARIANT.";
/*|*/   throw new java.lang.Error(msg);}
/*|*/ 
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
  // Private Attributes.

  // Constructors

  public FTPProxyInitialTestCases(String name)
  {
    super(name);
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ __inc_icl_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread());
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 

/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally {
/*|*/ __inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:48:  just before exit kindftptest.FTPProxyInitialTestCases::FTPProxyInitialTestCases(java.lang.String) ");}
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  // Public Methods

  /**
   * @design If/when we make these tests independent, this method can be
   * removed and the automatic test extraction of jUnit can be used. </p>
   */

  public static Test suite() {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ junit.framework.Test __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    TestSuite suite = new TestSuite();
    suite.addTest(new FTPProxyInitialTestCases("testBuildProxy"));
    suite.addTest(new FTPProxyInitialTestCases("testAnnounce"));
    suite.addTest(new FTPProxyInitialTestCases("testConnect"));
    suite.addTest(new FTPProxyInitialTestCases("testAnonymousLogin"));
    suite.addTest(new FTPProxyInitialTestCases("testACCT"));
    suite.addTest(new FTPProxyInitialTestCases("testSMNT"));
    suite.addTest(new FTPProxyInitialTestCases("testSTAT"));
    suite.addTest(new FTPProxyInitialTestCases("testType"));
    suite.addTest(new FTPProxyInitialTestCases("testCurrentDirectoryStatus"));
    suite.addTest(new FTPProxyInitialTestCases("testHELP"));
    suite.addTest(new FTPProxyInitialTestCases("testHELPonCDUP"));
    suite.addTest(new FTPProxyInitialTestCases("testNOOP"));
    suite.addTest(new FTPProxyInitialTestCases("testCWDtoTmp"));
    suite.addTest(new FTPProxyInitialTestCases("testCDUP"));
    suite.addTest(new FTPProxyInitialTestCases("testCWDHome"));
    suite.addTest(new FTPProxyInitialTestCases("testREIN"));
    suite.addTest(new FTPProxyInitialTestCases("testPORT"));
    suite.addTest(new FTPProxyInitialTestCases("testPASV"));
    suite.addTest(new FTPProxyInitialTestCases("testTYPE"));
    suite.addTest(new FTPProxyInitialTestCases("testSTRU"));
    suite.addTest(new FTPProxyInitialTestCases("testMODE"));
    suite.addTest(new FTPProxyInitialTestCases("testALLO"));
    suite.addTest(new FTPProxyInitialTestCases("testCWDtest_directory"));
    suite.addTest(new FTPProxyInitialTestCases("testRename"));
    suite.addTest(new FTPProxyInitialTestCases("testMKDtest_create"));
    suite.addTest(new FTPProxyInitialTestCases("testRMD"));
    suite.addTest(new FTPProxyInitialTestCases("testMKDtest_delete"));
    suite.addTest(new FTPProxyInitialTestCases("testDELE"));
    suite.addTest(new FTPProxyInitialTestCases("testPWD"));
    suite.addTest(new FTPProxyInitialTestCases("testTYPEA"));
    suite.addTest(new FTPProxyInitialTestCases("testPASV"));
    suite.addTest(new FTPProxyInitialTestCases("testLISTdot"));
    suite.addTest(new FTPProxyInitialTestCases("testPASV"));
    suite.addTest(new FTPProxyInitialTestCases("testLISTtmp"));
    suite.addTest(new FTPProxyInitialTestCases("testPASV"));
    suite.addTest(new FTPProxyInitialTestCases("testNLSTdot"));
    suite.addTest(new FTPProxyInitialTestCases("testPASV"));
    suite.addTest(new FTPProxyInitialTestCases("testNLSTtmp"));
    suite.addTest(new FTPProxyInitialTestCases("testSITE"));

    
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ /*
return suite;

/*|*/ 
/*|*/ __return_value_holder_ =  suite;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/   

/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ return __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#

}

  // Our first test suite are the following sequence of tests in exactly
  // the order listed here.

  /**
   * @post FTPProxyTestSetup.proxy != null
   */

  public void testBuildProxy()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:112:  just after entry kindftptest.FTPProxyInitialTestCases::testBuildProxy() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    debugOutput.println(debugCategory, "Building FTPProxy....");

    try {
      FTPProxyTestSetup.proxy = 
        new FTPProxy(InetAddress.getByName(FTPProxyTestSetup.FTPServer), 
                     FTPProxyTestSetup.FTPPort, 
                     debug, debugOutput);
    } catch (UnknownHostException uhe) {
      fail(uhe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ if (!(FTPProxyTestSetup.proxy != null)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:112: error: postcondition violated (kindftptest.FTPProxyInitialTestCases::testBuildProxy()): "+
/*|*/   "FTPProxyTestSetup.proxy != null");}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String txt = "";  if (ex.getClass()==java.lang.Error.class) { txt = ex.toString();; }
/*|*/   else txt = "/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:112:  exception <<"+ex+">> occured while evaluating POST-condition in /home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:112:  kindftptest.FTPProxyInitialTestCases::testBuildProxy()";
/*|*/   throw new java.lang.Error(txt);}
/*|*/ 
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:112:  just before exit kindftptest.FTPProxyInitialTestCases::testBuildProxy() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  /**
   * <p> Announce the test is running.  This should/will probably be
   * removed soon. </p>
   */

  public void testAnnounce()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:131:  just after entry kindftptest.FTPProxyInitialTestCases::testAnnounce() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    debugOutput.println(debugCategory, "===========================");
    debugOutput.println(debugCategory, "Running FTPProxy test code.");
    debugOutput.println(debugCategory, "===========================");
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:131:  just before exit kindftptest.FTPProxyInitialTestCases::testAnnounce() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Connect to the server. </p>
   */

  public void testConnect()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:142:  just after entry kindftptest.FTPProxyInitialTestCases::testConnect() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      // Connect to the server.
      debugOutput.println(debugCategory, "Connecting to server....");
      FTPProxyTestSetup.proxy.connect();
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:142:  just before exit kindftptest.FTPProxyInitialTestCases::testConnect() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  /**
   * <p> Anonymously login to the test server. </p>
   */
  
  public void testAnonymousLogin()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:157:  just after entry kindftptest.FTPProxyInitialTestCases::testAnonymousLogin() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      // Login to the server as anonymous.
      debugOutput.println(debugCategory, "Logging in as anonymous.");
      FTPProxyTestSetup.proxy.USER("anonymous");
      // A WAIT state indicates that the server is waiting for a password.
      assertTrue("Anonymous username must be ok.",
                 FTPProxyTestSetup.proxy.getReplyCode() == 
                 ReplyCodes.USER_NAME_OK);
      // No password should be necessary for anonymous user.
      FTPProxyTestSetup.proxy.PASS("kiniry@kindsoftware.com");
      assertTrue("User must be logged in.",
                 FTPProxyTestSetup.proxy.getReplyCode() ==
                 ReplyCodes.USER_LOGGED_IN);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:157:  just before exit kindftptest.FTPProxyInitialTestCases::testAnonymousLogin() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  /**
   * <p> Issue the ACCT command to the server.  To test this we need a
   * server capable of supporting ACCT.  We do not have such at this time.
   * This should throw an exception since our server doesn't support
   * ACCT. </p>
   */
  
  public void testACCT()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:184:  just after entry kindftptest.FTPProxyInitialTestCases::testACCT() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Attempt to issue an ACCT command.");
      FTPProxyTestSetup.proxy.ACCT(".");
      assertTrue((FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS) ||
                 (FTPProxyTestSetup.proxy.getReplyCode() == 
                  ReplyCodes.COMMAND_NOT_IMPLEMENTED));
    } catch (IOException ioe) {
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:184:  just before exit kindftptest.FTPProxyInitialTestCases::testACCT() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  /**
   * <p> Attempt to issue an SMNT command.  This should throw an exception
   * since our server doesn't support SMNT. </p>
   */

  public void testSMNT()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:202:  just after entry kindftptest.FTPProxyInitialTestCases::testSMNT() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Attempt to issue an SMNT command.");
      FTPProxyTestSetup.proxy.SMNT(".");
      assertTrue((FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS) ||
                 (FTPProxyTestSetup.proxy.getReplyCode() == 
                  ReplyCodes.COMMAND_NOT_IMPLEMENTED));
    } catch (IOException ioe) {
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:202:  just before exit kindftptest.FTPProxyInitialTestCases::testSMNT() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  /**
   * <p> Check the server status. </p>
   */

  public void testSTAT()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:219:  just after entry kindftptest.FTPProxyInitialTestCases::testSTAT() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Checking server status.");
      FTPProxyTestSetup.proxy.STAT(null);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:219:  just before exit kindftptest.FTPProxyInitialTestCases::testSTAT() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Check the type of server. </p>
   */

  public void testType()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:235:  just after entry kindftptest.FTPProxyInitialTestCases::testType() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.print(debugCategory, "Requesting server type.");
      FTPProxyTestSetup.proxy.SYST();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:235:  just before exit kindftptest.FTPProxyInitialTestCases::testType() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Check the current directory status. </p>
   */

  public void testCurrentDirectoryStatus()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:251:  just after entry kindftptest.FTPProxyInitialTestCases::testCurrentDirectoryStatus() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Checking status of '.': ");
      FTPProxyTestSetup.proxy.STAT(".");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:251:  just before exit kindftptest.FTPProxyInitialTestCases::testCurrentDirectoryStatus() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Run the general help command. </p>
   */

  public void testHELP()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:267:  just after entry kindftptest.FTPProxyInitialTestCases::testHELP() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Asking for general help from server: ");
      FTPProxyTestSetup.proxy.HELP(null);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:267:  just before exit kindftptest.FTPProxyInitialTestCases::testHELP() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Run help command on the CDUP command. </p>
   */

  public void testHELPonCDUP()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:283:  just after entry kindftptest.FTPProxyInitialTestCases::testHELPonCDUP() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Asking for help from server on CDUP: ");
      FTPProxyTestSetup.proxy.HELP("CDUP");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:283:  just before exit kindftptest.FTPProxyInitialTestCases::testHELPonCDUP() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Issuing a NOOP command. </p>
   */

  public void testNOOP()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:299:  just after entry kindftptest.FTPProxyInitialTestCases::testNOOP() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Issuing a NOOP.");
      FTPProxyTestSetup.proxy.NOOP();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:299:  just before exit kindftptest.FTPProxyInitialTestCases::testNOOP() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Change directory to a <tt>~/tmp</tt> directory. </p>
   */

  public void testCWDtoTmp()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:314:  just after entry kindftptest.FTPProxyInitialTestCases::testCWDtoTmp() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      // Change current working directory to /tmp.
      debugOutput.println(debugCategory, 
                          "Change current working directory to ~/tmp");
      FTPProxyTestSetup.proxy.CWD("~/tmp");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:314:  just before exit kindftptest.FTPProxyInitialTestCases::testCWDtoTmp() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  /**
   * <p> Go up one directory level. </p>
   */

  public void testCDUP()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:331:  just after entry kindftptest.FTPProxyInitialTestCases::testCDUP() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, 
                          "Change current working directory via CDUP.");
      FTPProxyTestSetup.proxy.CDUP();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:331:  just before exit kindftptest.FTPProxyInitialTestCases::testCDUP() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Change directory to the user home directory. </p>
   */

  public void testCWDHome()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:347:  just after entry kindftptest.FTPProxyInitialTestCases::testCWDHome() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Go back to home directory ('~/').");
      FTPProxyTestSetup.proxy.CWD("~/");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:347:  just before exit kindftptest.FTPProxyInitialTestCases::testCWDHome() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Attempt to issue an REIN command.  If we succeed, login again.
   * If we don't get an error, then just print the message. </p>
   *
   * @todo Need to finish this test once REIN is really done.
   */

  public void testREIN()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:365:  just after entry kindftptest.FTPProxyInitialTestCases::testREIN() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.print(debugCategory, "Attempt to issue an REIN command.");
      FTPProxyTestSetup.proxy.REIN();
      if (FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS) {
        debugOutput.println(debugCategory, 
                            "Succeeded....logging in again.");
        debugOutput.println(debugCategory, 
                 ReplyCodes.convertCode(FTPProxyTestSetup.proxy.getReplyCode()));
        FTPProxyTestSetup.proxy.USER("kindftp");
        FTPProxyTestSetup.proxy.PASS("test");
      } else {
        assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.FAILURE);
        debugOutput.println(debugCategory, 
                 ReplyCodes.convertCode(FTPProxyTestSetup.proxy.getReplyCode()));
      }
    } catch (IOException ioe) {
      debugOutput.println(debugCategory, 
                          "Failed - server doesn't support REIN (OK).");
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:365:  just before exit kindftptest.FTPProxyInitialTestCases::testREIN() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Issue a PORT command (even though we aren't starting a connection
   * by hand). </p>
   */

  public void testPORT()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:393:  just after entry kindftptest.FTPProxyInitialTestCases::testPORT() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Issuing a PORT command.");
      FTPProxyTestSetup.proxy.PORT(InetAddress.getByName("localhost"), 1138);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:393:  just before exit kindftptest.FTPProxyInitialTestCases::testPORT() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Issue a PASV command. </p>
   */

  public void testPASV()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:408:  just after entry kindftptest.FTPProxyInitialTestCases::testPASV() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Issuing a PASV command.");
      FTPProxyTestSetup.proxy.PASV();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:408:  just before exit kindftptest.FTPProxyInitialTestCases::testPASV() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Switch TYPE a couple of times. Since only types A and I are
   * supported by our test server, we only switch between them. </p>
   */

  public void testTYPE()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:424:  just after entry kindftptest.FTPProxyInitialTestCases::testTYPE() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Switching to TYPE A then I.");
      FTPProxyTestSetup.proxy.TYPE('A');
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      FTPProxyTestSetup.proxy.TYPE('I');
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:424:  just before exit kindftptest.FTPProxyInitialTestCases::testTYPE() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  /**
   * <p> Switch to TYPE 'A'. </p>
   */

  public void testTYPEA()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:441:  just after entry kindftptest.FTPProxyInitialTestCases::testTYPEA() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Switching to TYPE A.");
      FTPProxyTestSetup.proxy.TYPE('A');
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:441:  just before exit kindftptest.FTPProxyInitialTestCases::testTYPEA() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Issue a STRU command.  Only "F" works on our test server, so that
   * is all we test right now. </p>
   */

  public void testSTRU()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:457:  just after entry kindftptest.FTPProxyInitialTestCases::testSTRU() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Issue a STRU F command.");
      FTPProxyTestSetup.proxy.STRU('F');
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:457:  just before exit kindftptest.FTPProxyInitialTestCases::testSTRU() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Issue a MODE command.  Only "S" works on our test server, so that
   * is all we test right now. </p>
   */

  public void testMODE()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:473:  just after entry kindftptest.FTPProxyInitialTestCases::testMODE() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Issue a MODE S command.");
      FTPProxyTestSetup.proxy.MODE('S');
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:473:  just before exit kindftptest.FTPProxyInitialTestCases::testMODE() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Issue a ALLO command.  It is ignored by our test server. </p>
   */

  public void testALLO()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:488:  just after entry kindftptest.FTPProxyInitialTestCases::testALLO() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Issue a ALLO 10000 command.");
      FTPProxyTestSetup.proxy.ALLO(10000, 0);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:488:  just before exit kindftptest.FTPProxyInitialTestCases::testALLO() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Change to the <tt>~/test_directory</tt> directory. </p>
   */

  public void testCWDtest_directory()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:503:  just after entry kindftptest.FTPProxyInitialTestCases::testCWDtest_directory() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, 
                          "Change to the '~/test_directory' directory.");
      FTPProxyTestSetup.proxy.CWD("~/test_directory");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:503:  just before exit kindftptest.FTPProxyInitialTestCases::testCWDtest_directory() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Rename the file <tt>rename_file</tt> to <tt>renamed_file</tt>,
   * then rename back. </p>
   */

  public void testRename()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:520:  just after entry kindftptest.FTPProxyInitialTestCases::testRename() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory,
                          "Renaming file 'rename_file' to 'renamed_file', " +
                          "then rename back.");
      FTPProxyTestSetup.proxy.RNFR("rename_file");
      FTPProxyTestSetup.proxy.RNTO("renamed_file");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      FTPProxyTestSetup.proxy.RNFR("renamed_file");
      FTPProxyTestSetup.proxy.RNTO("rename_file");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:520:  just before exit kindftptest.FTPProxyInitialTestCases::testRename() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Make a directory called <tt>test_create</tt>. </p>
   */

  public void testMKDtest_create()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:541:  just after entry kindftptest.FTPProxyInitialTestCases::testMKDtest_create() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Make a 'test_create' directory.");
      FTPProxyTestSetup.proxy.MKD("test_create");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:541:  just before exit kindftptest.FTPProxyInitialTestCases::testMKDtest_create() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Remove the directory called <tt>test_create</tt>. </p>
   */

  public void testRMD()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:556:  just after entry kindftptest.FTPProxyInitialTestCases::testRMD() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Remove the 'test_create' directory.");
      FTPProxyTestSetup.proxy.RMD("test_create");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:556:  just before exit kindftptest.FTPProxyInitialTestCases::testRMD() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Make a directory called <tt>test_delete</tt>. </p>
   */

  public void testMKDtest_delete()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:571:  just after entry kindftptest.FTPProxyInitialTestCases::testMKDtest_delete() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Make a 'test_delete' directory.");
      FTPProxyTestSetup.proxy.MKD("test_delete");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:571:  just before exit kindftptest.FTPProxyInitialTestCases::testMKDtest_delete() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Delete the directory called <tt>test_delete</tt> by using DELE
   * command. </p>
   */

  public void testDELE()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:587:  just after entry kindftptest.FTPProxyInitialTestCases::testDELE() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, 
                          "Deleting 'test_delete' directory with DELE.");
      FTPProxyTestSetup.proxy.DELE("test_delete");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:587:  just before exit kindftptest.FTPProxyInitialTestCases::testDELE() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Print out the current working directory. </p>
   */

  public void testPWD()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:603:  just after entry kindftptest.FTPProxyInitialTestCases::testPWD() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.print(debugCategory, "Current working directory: ");
      FTPProxyTestSetup.proxy.PWD();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:603:  just before exit kindftptest.FTPProxyInitialTestCases::testPWD() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> List the current directory (<tt>.</tt>).</p>
   */

  public void testLISTdot()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:619:  just after entry kindftptest.FTPProxyInitialTestCases::testLISTdot() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Listing of current directory: ");
      FTPProxyTestSetup.proxy.LIST(".");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:619:  just before exit kindftptest.FTPProxyInitialTestCases::testLISTdot() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> List the directory <tt>~/tmp</tt>. </p>
   */

  public void testLISTtmp()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:635:  just after entry kindftptest.FTPProxyInitialTestCases::testLISTtmp() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      FTPProxyTestSetup.proxy.PASV();
      debugOutput.println(debugCategory, "Listing of directory '~/tmp': ");
      FTPProxyTestSetup.proxy.LIST("~/tmp");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:635:  just before exit kindftptest.FTPProxyInitialTestCases::testLISTtmp() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> NList the current directory (<tt>.</tt>). </p>
   */

  public void testNLSTdot()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:652:  just after entry kindftptest.FTPProxyInitialTestCases::testNLSTdot() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      FTPProxyTestSetup.proxy.PASV();
      debugOutput.println(debugCategory, "NList of current directory: ");
      FTPProxyTestSetup.proxy.NLST(".");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:652:  just before exit kindftptest.FTPProxyInitialTestCases::testNLSTdot() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> NList the directory <tt>~/tmp</tt>. </p>
   */

  public void testNLSTtmp()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:669:  just after entry kindftptest.FTPProxyInitialTestCases::testNLSTtmp() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      FTPProxyTestSetup.proxy.CWD("~/");
      FTPProxyTestSetup.proxy.PASV();
      debugOutput.println(debugCategory, "NList of directory '~/tmp': ");
      FTPProxyTestSetup.proxy.NLST("tmp");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:669:  just before exit kindftptest.FTPProxyInitialTestCases::testNLSTtmp() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Attempt a SITE command.  Our test server understands SITE IDLE. </p>
   */

  public void testSITE()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:687:  just after entry kindftptest.FTPProxyInitialTestCases::testSITE() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, "Attempt SITE IDLE command.");
      FTPProxyTestSetup.proxy.SITE("IDLE");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);      
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyInitialTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyInitialTestCases.java:687:  just before exit kindftptest.FTPProxyInitialTestCases::testSITE() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  // A shorthand to check the last response.

  private String lastResponse()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ java.lang.String __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ /*
return FTPProxyTestSetup.proxy.getLastResponse();

/*|*/ 
/*|*/ __return_value_holder_ =  FTPProxyTestSetup.proxy.getLastResponse();
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/   

/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ return __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#

}
  
} // end of class FTPProxyInitialTests
