/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: FTPProxyMiscTestCases.java,v 1.4 2001/12/20 07:42:30 kiniry Exp $
 */

package kindftptest;

import java.io.IOException;
import java.util.Date;
import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * <p> Test commands that check the status of files on the server. </p>
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Initial creation.
 * @version $Revision: 1.4 $ $Date: 2001/12/20 07:42:30 $ 
 * @since KindFTP initial release.
 */

public class FTPProxyMiscTestCases extends IDebugTestCase
{
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ // Keeps track of calling chain to avoid recursive invariant checks.
/*|*/ // Avoids inv checks in public methods that are called from private ones.
/*|*/ // Stores bookkeeping information -- key: thread, value: call level
/*|*/ protected transient java.util.Hashtable __icl_ = new java.util.Hashtable(1);
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_entry__kindftptest_FTPProxyMiscTestCases(Thread thread, String loc) throws java.lang.Error {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/     __check_invariant____kindftptest_FTPProxyMiscTestCases(loc);
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_exit__kindftptest_FTPProxyMiscTestCases(Thread thread, String loc) throws java.lang.Error {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if (((Integer)__icl_.get(thread)).intValue() == 1 ) {
/*|*/     try {
/*|*/       __check_invariant____kindftptest_FTPProxyMiscTestCases(loc);
/*|*/     } finally {
/*|*/       __icl_.remove(thread); // remove from bookkeeping, before checking (resoliant wrt exceptions)
/*|*/   }}
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()-1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting DO NOT check the invariant (i.e. for non-default constr.)
/*|*/ private synchronized void __inc_icl_at_entry__kindftptest_FTPProxyMiscTestCases(Thread thread)  {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Tests the invariants of the class and its superclasses.
/*|*/ // This method is public (see note below) to give subclasses (potentially in different packages),
/*|*/ // acccess to the inv of superclasses (and to let the reflection API find the.
/*|*/ // method)
/*|*/ //
/*|*/ public synchronized void __check_invariant____kindftptest_FTPProxyMiscTestCases( String location ) throws java.lang.Error {
/*|*/ try {
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debug != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debug != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( assert != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies assert != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugConstants != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugConstants != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugOutput != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugOutput != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugCategory != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugCategory != null");}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String msg = "";
/*|*/   if (ex.getClass()==java.lang.Error.class) { msg = ex.toString(); }
/*|*/   else msg = location + " exception <<"+ex+">> occured while evaluating the class INVARIANT.";
/*|*/   throw new java.lang.Error(msg);}
/*|*/ 
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
  // Constructors

  public FTPProxyMiscTestCases(String name)
  {
    super(name);
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ __inc_icl_at_entry__kindftptest_FTPProxyMiscTestCases(Thread.currentThread());
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 

/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally {
/*|*/ __inv_check_at_exit__kindftptest_FTPProxyMiscTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyMiscTestCases.java:29:  just before exit kindftptest.FTPProxyMiscTestCases::FTPProxyMiscTestCases(java.lang.String) ");}
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  // Public Methods

  public static Test suite() {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ junit.framework.Test __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    TestSuite suite = new TestSuite();
    suite.addTest(new FTPProxyMiscTestCases("testMDTM"));
    suite.addTest(new FTPProxyMiscTestCases("testSIZE"));
    
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ /*
return suite;

/*|*/ 
/*|*/ __return_value_holder_ =  suite;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/   

/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ return __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#

}

  /**
   * <p> Test the MDTM command on a file
   * <tt>~/test_directory/reply_codes.ser</tt>. </p>
   */

  public void testMDTM()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyMiscTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyMiscTestCases.java:48:  just after entry kindftptest.FTPProxyMiscTestCases::testMDTM() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    Date lastModTime = null;
    
    try {
      lastModTime = 
        FTPProxyTestSetup.proxy.MDTM("~/test_directory/reply_codes.ser");
      assertNotNull(lastModTime);
      debugOutput.println(debugCategory, 
                          "Last modification time of " +
                          "'~/test_directory/reply_codes.ser' is " +
                          lastModTime);
    } catch (IOException ioe) {
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyMiscTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyMiscTestCases.java:48:  just before exit kindftptest.FTPProxyMiscTestCases::testMDTM() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  /**
   * <p> Check the size of the file
   * <tt>~/test_directory/reply_codes.ser</tt>. </p>
   */

  public void testSIZE()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyMiscTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyMiscTestCases.java:70:  just after entry kindftptest.FTPProxyMiscTestCases::testSIZE() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    long size = -1;

    try {
      size = FTPProxyTestSetup.proxy.SIZE("~/test_directory/reply_codes.ser");
      assertTrue(size != -1);
      debugOutput.println(debugCategory, 
            "Size of '~/test_directory/reply_codes.ser' is " + size);
    } catch (IOException ioe) {
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyMiscTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyMiscTestCases.java:70:  just before exit kindftptest.FTPProxyMiscTestCases::testSIZE() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
} // end of class FTPProxyMiscTestCases
