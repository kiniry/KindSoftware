/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: FTPProxyReceiveTestCases.java,v 1.7 2001/12/20 07:42:30 kiniry Exp $
 */

package kindftptest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import kindftp.FTPProxy;
import kindftp.ReplyCodes;

/**
 * <p> A set of blackbox tests for the RETR command. </p>
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Initial creation.
 * @version $Revision: 1.7 $ $Date: 2001/12/20 07:42:30 $ 
 * @since KindFTP initial release.
 */

public class FTPProxyReceiveTestCases extends IDebugTestCase
{
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ // Keeps track of calling chain to avoid recursive invariant checks.
/*|*/ // Avoids inv checks in public methods that are called from private ones.
/*|*/ // Stores bookkeeping information -- key: thread, value: call level
/*|*/ protected transient java.util.Hashtable __icl_ = new java.util.Hashtable(1);
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_entry__kindftptest_FTPProxyReceiveTestCases(Thread thread, String loc) throws java.lang.Error {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/     __check_invariant____kindftptest_FTPProxyReceiveTestCases(loc);
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_exit__kindftptest_FTPProxyReceiveTestCases(Thread thread, String loc) throws java.lang.Error {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if (((Integer)__icl_.get(thread)).intValue() == 1 ) {
/*|*/     try {
/*|*/       __check_invariant____kindftptest_FTPProxyReceiveTestCases(loc);
/*|*/     } finally {
/*|*/       __icl_.remove(thread); // remove from bookkeeping, before checking (resoliant wrt exceptions)
/*|*/   }}
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()-1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting DO NOT check the invariant (i.e. for non-default constr.)
/*|*/ private synchronized void __inc_icl_at_entry__kindftptest_FTPProxyReceiveTestCases(Thread thread)  {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Tests the invariants of the class and its superclasses.
/*|*/ // This method is public (see note below) to give subclasses (potentially in different packages),
/*|*/ // acccess to the inv of superclasses (and to let the reflection API find the.
/*|*/ // method)
/*|*/ //
/*|*/ public synchronized void __check_invariant____kindftptest_FTPProxyReceiveTestCases( String location ) throws java.lang.Error {
/*|*/ try {
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debug != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debug != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( assert != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies assert != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugConstants != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugConstants != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugOutput != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugOutput != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugCategory != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugCategory != null");}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String msg = "";
/*|*/   if (ex.getClass()==java.lang.Error.class) { msg = ex.toString(); }
/*|*/   else msg = location + " exception <<"+ex+">> occured while evaluating the class INVARIANT.";
/*|*/   throw new java.lang.Error(msg);}
/*|*/ 
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
  // Constructors

  public FTPProxyReceiveTestCases(String name)
  {
    super(name);
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ __inc_icl_at_entry__kindftptest_FTPProxyReceiveTestCases(Thread.currentThread());
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 

/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally {
/*|*/ __inv_check_at_exit__kindftptest_FTPProxyReceiveTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyReceiveTestCases.java:39:  just before exit kindftptest.FTPProxyReceiveTestCases::FTPProxyReceiveTestCases(java.lang.String) ");}
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  // Public Methods

  public static Test suite() {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ junit.framework.Test __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    TestSuite suite = new TestSuite();
    suite.addTest(new FTPProxyReceiveTestCases("testRETR_text"));
    suite.addTest(new FTPProxyReceiveTestCases("testRETR_text_streaming"));
    suite.addTest(new FTPProxyReceiveTestCases("testRETR_binary"));
    suite.addTest(new FTPProxyReceiveTestCases("testRETR_binary_streaming"));
    suite.addTest(new FTPProxyReceiveTestCases("testRETR_subdir_text"));
    suite.addTest(
          new FTPProxyReceiveTestCases("testRETR_subdir_text_streaming"));

    
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ /*
return suite;

/*|*/ 
/*|*/ __return_value_holder_ =  suite;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/   

/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ return __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#

}

  /**
   * <p> Retrieve the file <tt>file.txt</tt> in non-streaming mode. </p>
   */

  public void testRETR_text()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyReceiveTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyReceiveTestCases.java:63:  just after entry kindftptest.FTPProxyReceiveTestCases::testRETR_text() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, 
                          "Retrieving text file 'file.txt'....");
      FTPProxyTestSetup.proxy.CWD("~/tmp/");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.RETR("file.txt", false);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      
      // Print the contents of the received file.
      File file = FTPProxyTestSetup.proxy.getDataFile();
      assertNotNull(file);
      BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
      assertNotNull(bufferedReader);

      String line = null;
      do {
        line = bufferedReader.readLine();
        if (line != null)
          debugOutput.println(debugCategory, line);
      } while (line != null);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyReceiveTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyReceiveTestCases.java:63:  just before exit kindftptest.FTPProxyReceiveTestCases::testRETR_text() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Retrieve the file <tt>file.txt</tt> in streaming mode. </p>
   */

  public void testRETR_text_streaming()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyReceiveTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyReceiveTestCases.java:95:  just after entry kindftptest.FTPProxyReceiveTestCases::testRETR_text_streaming() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, 
                          "Retrieving text file 'file.txt'....");
      FTPProxyTestSetup.proxy.CWD("~/tmp/");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.RETR("file.txt", true);
      assertTrue((FTPProxyTestSetup.proxy.getPrefix() == 
                  ReplyCodes.POSITIVE_PRELIMINARY) ||
                 (FTPProxyTestSetup.proxy.getPrefix() == 
                  ReplyCodes.POSITIVE_COMPLETION));

      // Print the contents of the file as we stream it.
      BufferedReader bufferedReader = 
        new BufferedReader(
            new InputStreamReader(FTPProxyTestSetup.proxy.getInputStream()));
      assertNotNull(bufferedReader);

      String line = null;
      do {
        line = bufferedReader.readLine();
        if (line != null)
          debugOutput.println(debugCategory, line);
    
      } while (line != null);
      bufferedReader.close();

      // Complete command handshake.
      FTPProxyTestSetup.proxy.completeCommandHandshake();
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyReceiveTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyReceiveTestCases.java:95:  just before exit kindftptest.FTPProxyReceiveTestCases::testRETR_text_streaming() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Retrieve the binary file <tt>bar.zip</tt> in non-streaming
   * mode and check its contents. </p>
   */

  public void testRETR_binary()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyReceiveTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyReceiveTestCases.java:136:  just after entry kindftptest.FTPProxyReceiveTestCases::testRETR_binary() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, 
                          "Retrieving zip file 'bar.zip'....");
      FTPProxyTestSetup.proxy.CWD("~/tmp/");
      FTPProxyTestSetup.proxy.TYPE('I');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.RETR("bar.zip", false);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);

      // Print the entries in the zip file.
      File file = FTPProxyTestSetup.proxy.getDataFile();
      assertNotNull(file);
      ZipFile zipFile = new ZipFile(file);
      assertNotNull(zipFile);
      
      for (Enumeration contents = zipFile.entries(); 
           contents.hasMoreElements();)
        debugOutput.println(debugCategory, contents.nextElement());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyReceiveTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyReceiveTestCases.java:136:  just before exit kindftptest.FTPProxyReceiveTestCases::testRETR_binary() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Retrieve the binary file <tt>bar.zip</tt> in streaming mode and
   * check its contents. </p>
   */

  public void testRETR_binary_streaming()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyReceiveTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyReceiveTestCases.java:166:  just after entry kindftptest.FTPProxyReceiveTestCases::testRETR_binary_streaming() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, 
                          "Retrieving zip file 'bar.zip'....");
      FTPProxyTestSetup.proxy.CWD("~/tmp/");
      FTPProxyTestSetup.proxy.TYPE('I');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.RETR("bar.zip", true);
      assertTrue((FTPProxyTestSetup.proxy.getPrefix() == 
                  ReplyCodes.POSITIVE_PRELIMINARY) ||
                 (FTPProxyTestSetup.proxy.getPrefix() == 
                  ReplyCodes.POSITIVE_COMPLETION));

      // Print the contents of the file as we stream it.
      ZipInputStream zipInputStream = 
        new ZipInputStream(FTPProxyTestSetup.proxy.getInputStream());
      assertNotNull(zipInputStream);

      ZipEntry zipEntry = null;
      do {
        zipEntry = zipInputStream.getNextEntry();
        if (zipEntry != null)
          debugOutput.println(debugCategory, zipEntry.toString());
      } while (zipEntry != null);
      zipInputStream.close();

      // Complete command handshake.
      FTPProxyTestSetup.proxy.completeCommandHandshake();
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyReceiveTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyReceiveTestCases.java:166:  just before exit kindftptest.FTPProxyReceiveTestCases::testRETR_binary_streaming() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Retrieve the text file <tt>tmp/file.txt</tt> in non-streaming
   * mode after changing to the home directory. </p>
   */

  public void testRETR_subdir_text()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyReceiveTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyReceiveTestCases.java:205:  just after entry kindftptest.FTPProxyReceiveTestCases::testRETR_subdir_text() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, 
                          "Retrieving text file 'tmp/file.txt'....");
      FTPProxyTestSetup.proxy.CWD("~/");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.RETR("tmp/file.txt", false);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);

      // Print the contents of the file.
      File file = FTPProxyTestSetup.proxy.getDataFile();
      assertNotNull(file);
      BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
      assertNotNull(bufferedReader);

      String line = null;
      do {
        line = bufferedReader.readLine();
        if (line != null)
          debugOutput.println(debugCategory, line);
      } while (line != null);
      bufferedReader.close();
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyReceiveTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyReceiveTestCases.java:205:  just before exit kindftptest.FTPProxyReceiveTestCases::testRETR_subdir_text() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Retrieve the text file <tt>tmp/file.txt</tt> in streaming mode
   * after changing to the home directory. </p>
   */

  public void testRETR_subdir_text_streaming()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxyReceiveTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyReceiveTestCases.java:239:  just after entry kindftptest.FTPProxyReceiveTestCases::testRETR_subdir_text_streaming() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      // ------------------------------------------------------------
      // Test a text file in a directory ('tmp/file.txt').
      // Test streaming mode.
      debugOutput.println(debugCategory,
                          "Retrieving text file 'tmp/file.txt'....");
      FTPProxyTestSetup.proxy.CWD("~/");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.RETR("tmp/file.txt", true);
      assertTrue((FTPProxyTestSetup.proxy.getPrefix() == 
                  ReplyCodes.POSITIVE_PRELIMINARY) ||
                 (FTPProxyTestSetup.proxy.getPrefix() == 
                  ReplyCodes.POSITIVE_COMPLETION));

      // Print the contents of the file.
      BufferedReader bufferedReader = 
        new BufferedReader(
            new InputStreamReader(FTPProxyTestSetup.proxy.getInputStream()));
      assertNotNull(bufferedReader);

      String line = null;
      do {
        line = bufferedReader.readLine();
        if (line != null)
          debugOutput.println(debugCategory, line);
      } while (line != null);
      bufferedReader.close();

      // Complete command handshake.
      FTPProxyTestSetup.proxy.completeCommandHandshake();
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxyReceiveTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyReceiveTestCases.java:239:  just before exit kindftptest.FTPProxyReceiveTestCases::testRETR_subdir_text_streaming() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

} // end of class FTPProxyReceiveTestCases
