/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: FTPProxySendTestCases.java,v 1.6 2001/12/20 07:42:30 kiniry Exp $
 */

package kindftptest;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import kindftp.FTPProxy;
import kindftp.ReplyCodes;

/**
 * <p> A set of blackbox tests for the STOR command. </p>
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Initial creation.
 * @version $Revision: 1.6 $ $Date: 2001/12/20 07:42:30 $ 
 * @since KindFTP initial release.
 */

public class FTPProxySendTestCases extends IDebugTestCase
{
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ // Keeps track of calling chain to avoid recursive invariant checks.
/*|*/ // Avoids inv checks in public methods that are called from private ones.
/*|*/ // Stores bookkeeping information -- key: thread, value: call level
/*|*/ protected transient java.util.Hashtable __icl_ = new java.util.Hashtable(1);
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_entry__kindftptest_FTPProxySendTestCases(Thread thread, String loc) throws java.lang.Error {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/     __check_invariant____kindftptest_FTPProxySendTestCases(loc);
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_exit__kindftptest_FTPProxySendTestCases(Thread thread, String loc) throws java.lang.Error {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if (((Integer)__icl_.get(thread)).intValue() == 1 ) {
/*|*/     try {
/*|*/       __check_invariant____kindftptest_FTPProxySendTestCases(loc);
/*|*/     } finally {
/*|*/       __icl_.remove(thread); // remove from bookkeeping, before checking (resoliant wrt exceptions)
/*|*/   }}
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()-1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting DO NOT check the invariant (i.e. for non-default constr.)
/*|*/ private synchronized void __inc_icl_at_entry__kindftptest_FTPProxySendTestCases(Thread thread)  {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Tests the invariants of the class and its superclasses.
/*|*/ // This method is public (see note below) to give subclasses (potentially in different packages),
/*|*/ // acccess to the inv of superclasses (and to let the reflection API find the.
/*|*/ // method)
/*|*/ //
/*|*/ public synchronized void __check_invariant____kindftptest_FTPProxySendTestCases( String location ) throws java.lang.Error {
/*|*/ try {
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debug != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debug != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( assert != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies assert != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugConstants != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugConstants != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugOutput != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugOutput != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugCategory != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugCategory != null");}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String msg = "";
/*|*/   if (ex.getClass()==java.lang.Error.class) { msg = ex.toString(); }
/*|*/   else msg = location + " exception <<"+ex+">> occured while evaluating the class INVARIANT.";
/*|*/   throw new java.lang.Error(msg);}
/*|*/ 
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
  // Constructors

  public FTPProxySendTestCases(String name)
  {
    super(name);
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ __inc_icl_at_entry__kindftptest_FTPProxySendTestCases(Thread.currentThread());
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 

/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally {
/*|*/ __inv_check_at_exit__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:37:  just before exit kindftptest.FTPProxySendTestCases::FTPProxySendTestCases(java.lang.String) ");}
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  // Public Methods

  public static Test suite() {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ junit.framework.Test __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    TestSuite suite = new TestSuite();
    suite.addTest(new FTPProxySendTestCases("testSTOR_text"));
    suite.addTest(new FTPProxySendTestCases("testSTOR_text_streaming"));
    suite.addTest(new FTPProxySendTestCases("testSTOR_binary"));
    suite.addTest(new FTPProxySendTestCases("testSTOR_binary_streaming"));
    suite.addTest(new FTPProxySendTestCases("testSTOR_subdir_text"));
    suite.addTest(new FTPProxySendTestCases("testSTOR_subdir_text_streaming"));
    suite.addTest(new FTPProxySendTestCases("testSTOR_subdir_object"));

    
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ /*
return suite;

/*|*/ 
/*|*/ __return_value_holder_ =  suite;
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/   

/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ return __return_value_holder_;
/*|*/ //-------------------------------------------------------------------------------#*#

}

  /**
   * <p> Send a text file to the server in non-streaming mode. </p>
   */

  public void testSTOR_text()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:61:  just after entry kindftptest.FTPProxySendTestCases::testSTOR_text() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, 
                          "Sending text file '/tmp/file.txt' " +
                          "in non-streaming mode....");
      FTPProxyTestSetup.proxy.CWD("~/test_directory");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.STOR("file_non-streaming.txt", 
                                   new File("/tmp/file.txt"));
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:61:  just before exit kindftptest.FTPProxySendTestCases::testSTOR_text() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Send a text file to the server in streaming mode. </p>
   */

  public void testSTOR_text_streaming()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:82:  just after entry kindftptest.FTPProxySendTestCases::testSTOR_text_streaming() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      debugOutput.println(debugCategory, 
                          "Sending text file '/tmp/file.txt' " +
                          "in streaming mode....");
      FTPProxyTestSetup.proxy.CWD("~/test_directory");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.STOR("file-streaming.txt");

      // Build the streams for reading and writing the data.
      PrintWriter printWriter = 
        new PrintWriter(FTPProxyTestSetup.proxy.getOutputStream());
      BufferedReader bufferedReader = 
        new BufferedReader(new FileReader("/tmp/file.txt"));
      assertNotNull(printWriter);
      assertNotNull(bufferedReader);

      // Stream the data to the server.
      String line = null;
      do {
        line = bufferedReader.readLine();
        if (line != null)
          printWriter.println(line);
      } while (line != null);
      printWriter.flush();

      // Close channels *before* completing the command handshake.
      bufferedReader.close();
      printWriter.close();

      // Perform necessary post-streaming store command handshake.
      FTPProxyTestSetup.proxy.completeCommandHandshake();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:82:  just before exit kindftptest.FTPProxySendTestCases::testSTOR_text_streaming() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Send a binary file to the server in non-streaming mode. </p>
   */

  public void testSTOR_binary()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:126:  just after entry kindftptest.FTPProxySendTestCases::testSTOR_binary() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      FTPProxyTestSetup.proxy.CWD("~/test_directory");
      FTPProxyTestSetup.proxy.TYPE('I');
      FTPProxyTestSetup.proxy.PASV();
      debugOutput.println(debugCategory, 
                          "Sending zip file 'bar_non-streaming.zip' " +
                          "in non-streaming mode....");
      FTPProxyTestSetup.proxy.STOR("bar_non-streaming.zip", 
                                   new File("/tmp/bar.zip"));
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:126:  just before exit kindftptest.FTPProxySendTestCases::testSTOR_binary() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Send a binary file to the server in streaming mode. </p>
   */

  public void testSTOR_binary_streaming()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:147:  just after entry kindftptest.FTPProxySendTestCases::testSTOR_binary_streaming() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      FTPProxyTestSetup.proxy.CWD("~/test_directory");
      FTPProxyTestSetup.proxy.TYPE('I');
      FTPProxyTestSetup.proxy.PASV();
      debugOutput.println(debugCategory, 
                          "Sending zip file 'bar_streaming.zip' in " +
                          "streaming mode....");
      FTPProxyTestSetup.proxy.STOR("bar_streaming.zip");

      // Build the streams for reading and writing the data.
      FileInputStream fileInputStream = new FileInputStream("/tmp/bar.zip");
      byte [] buffer = new byte [1024];
      int available = 0, bytesRead = 0;
      BufferedOutputStream bufferedOutputStream = 
        FTPProxyTestSetup.proxy.getOutputStream();
      assertNotNull(fileInputStream);
      assertNotNull(bufferedOutputStream);

      // Stream the data to the server.
      while (true) {
        available = fileInputStream.available();
        // Only read in as much as we can hold.
        if (available > 1024)
          available = 1024;
        if (available != 0) {
          bytesRead = fileInputStream.read(buffer, 0, available);
          if (bytesRead != -1)
            bufferedOutputStream.write(buffer, 0, bytesRead);
        } else break;
      }
      bufferedOutputStream.flush();

      // Close channels *before* completing the command handshake.
      fileInputStream.close();
      bufferedOutputStream.close();

      // Perform necessary post-streaming store command handshake.
      FTPProxyTestSetup.proxy.completeCommandHandshake();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:147:  just before exit kindftptest.FTPProxySendTestCases::testSTOR_binary_streaming() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  /**
   * <p> Store a text file using non-streaming mode to a subdirectory on
   * the server. </p>
   */
  
  public void testSTOR_subdir_text()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:198:  just after entry kindftptest.FTPProxySendTestCases::testSTOR_subdir_text() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      FTPProxyTestSetup.proxy.CWD("~/");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      debugOutput.println(debugCategory, 
                          "Sending text file " +
                          "'test_directory/file_dir_non-streaming.txt' " +
                          "in non-streaming mode....");
      FTPProxyTestSetup.proxy.STOR("test_directory/file_dir_non-streaming.txt", 
                                   new File("/tmp/file.txt"));
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:198:  just before exit kindftptest.FTPProxySendTestCases::testSTOR_subdir_text() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  /**
   * <p> Store a text file using streaming mode to a subdirectory on the
   * server. </p>
   */
  
  public void testSTOR_subdir_text_streaming()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:221:  just after entry kindftptest.FTPProxySendTestCases::testSTOR_subdir_text_streaming() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      FTPProxyTestSetup.proxy.CWD("~/");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      debugOutput.println(debugCategory, 
                          "Sending text file " +
                          "'test_directory/file_dir-streaming.txt' " +
                          "in streaming mode....");
      FTPProxyTestSetup.proxy.STOR("test_directory/file_dir-streaming.txt");

      // Build the streams for reading and writing the data.
      FileInputStream fileInputStream = new FileInputStream("/tmp/file.txt");
      byte [] buffer = new byte [1024];
      int available = 0, bytesRead = 0;
      BufferedOutputStream bufferedOutputStream = 
        FTPProxyTestSetup.proxy.getOutputStream();
      assertNotNull(fileInputStream);
      assertNotNull(bufferedOutputStream);

      // Stream the data to the server.
      while (true) {
        available = fileInputStream.available();
        // Only read in as much as we can hold.
        if (available > 1024)
          available = 1024;
        if (available != 0) {
          bytesRead = fileInputStream.read(buffer, 0, available);
          if (bytesRead != -1)
            bufferedOutputStream.write(buffer, 0, bytesRead);
        } else break;
      }
      bufferedOutputStream.flush();

      // Close channels *before* completing STOR.
      fileInputStream.close();
      bufferedOutputStream.close();

      // Perform necessary post-streaming store command handshake.
      FTPProxyTestSetup.proxy.completeCommandHandshake();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:221:  just before exit kindftptest.FTPProxySendTestCases::testSTOR_subdir_text_streaming() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
  /**
   * <p> Store a serialized object using non-streaming mode to a
   * subdirectory on the server. </p>
   */
  
  public void testSTOR_subdir_object()
  {
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ this.__inv_check_at_entry__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:273:  just after entry kindftptest.FTPProxySendTestCases::testSTOR_subdir_object() ");
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ /*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
    try {
      // Reply codes for debugging.
      ReplyCodes replyCodes = new ReplyCodes();
      FTPProxyTestSetup.proxy.CWD("~/");
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.STOR("test_directory/reply_codes.ser", 
                                   replyCodes);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally { 
/*|*/   this.__inv_check_at_exit__kindftptest_FTPProxySendTestCases(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxySendTestCases.java:273:  just before exit kindftptest.FTPProxySendTestCases::testSTOR_subdir_object() ");
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

} // end of class FTPProxySendTestCases
