/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: FTPProxyTestSetup.java,v 1.7 2001/12/27 06:52:47 kiniry Exp $
 */

package kindftptest;

import idebug.Assert;
import idebug.Debug;
import idebug.DebugConstants;
import idebug.DebugOutput;
import java.io.IOException;
import java.net.InetAddress;
import junit.extensions.TestSetup;
import junit.framework.Test;
import kindftp.FTPProxy;
import kindftp.IDebugInit;

/**
 * <p> Shared setup code for the Blackbox testsuite for the class
 * <code>FTPProxy</code>. </p>
 *
 * <p> This setup code initializes IDebug components and reads in test
 * configuration information. </p>

 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Factored out of main FTPProxy class.
 * @version $Revision: 1.7 $ $Date: 2001/12/27 06:52:47 $ 
 * @since KindFTP initial release.
 * @see "RFC959 for more information."
 * @see <a href="http://www.junit.org/">jUnit</a>
 * @see <a href="http://www.kindsoftware.com/products/opensource/IDebug/">IDebug</a>
 */

public class FTPProxyTestSetup extends TestSetup
{
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ // Keeps track of calling chain to avoid recursive invariant checks.
/*|*/ // Avoids inv checks in public methods that are called from private ones.
/*|*/ // Stores bookkeeping information -- key: thread, value: call level
/*|*/ protected transient java.util.Hashtable __icl_ = new java.util.Hashtable(1);
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_entry__kindftptest_FTPProxyTestSetup(Thread thread, String loc)  {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/     __check_invariant____kindftptest_FTPProxyTestSetup(loc);
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_exit__kindftptest_FTPProxyTestSetup(Thread thread, String loc)  {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if (((Integer)__icl_.get(thread)).intValue() == 1 ) {
/*|*/     try {
/*|*/       __check_invariant____kindftptest_FTPProxyTestSetup(loc);
/*|*/     } finally {
/*|*/       __icl_.remove(thread); // remove from bookkeeping, before checking (resoliant wrt exceptions)
/*|*/   }}
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()-1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting DO NOT check the invariant (i.e. for non-default constr.)
/*|*/ private synchronized void __inc_icl_at_entry__kindftptest_FTPProxyTestSetup(Thread thread)  {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Tests the invariants of the class and its superclasses.
/*|*/ // This method is public (see note below) to give subclasses (potentially in different packages),
/*|*/ // acccess to the inv of superclasses (and to let the reflection API find the.
/*|*/ // method)
/*|*/ //
/*|*/ public synchronized void __check_invariant____kindftptest_FTPProxyTestSetup( String location )  {
/*|*/ try {
/*|*/ }
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String msg = "";
/*|*/   if (ex.getClass()==java.lang.Error.class) { msg = ex.toString(); }
/*|*/   else msg = location + " exception <<"+ex+">> occured while evaluating the class INVARIANT.";
/*|*/   throw new java.lang.Error(msg);}
/*|*/ 
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
  // Private Attributes.

  // Default values for test server.
  private static final String defaultFTPServer = "localhost";
  private static final int defaultFTPPort = 21;
  private static final String defaultFTPUser = "kindftptest";
  private static final String defaultFTPPassword = "bekind";

  // Actual values used in testing; initially set to defaults above and
  // customized by readTestProperties().
  static String FTPServer = defaultFTPServer;
  static int FTPPort = defaultFTPPort;
  static String FTPUser = defaultFTPUser;
  static String FTPPassword = defaultFTPPassword;
  static InetAddress FTPServerInetAddress = null;
  static FTPProxy proxy = null;

  // Constructors

  public FTPProxyTestSetup(Test test)
  {
    super(test);
  


}
  
  // Public Methods

  /**
   * <p> Set up the debugging subsystem then read in the blackbox test
   * configuration. </p>
   */

  public void setUp() {

    // Setup the debugging subsystem.
    setupDebug();
    // Read in customized test values.
    readTestProperties();
  

}

  public void tearDown()
  {

    try {
      // Disconnect from the server.
      IDebugTestCase.debugOutput.println(IDebugTestCase.debugCategory,
                                         "Disconnect from the server....");
      if (proxy != null)
        proxy.QUIT();
    } catch (IOException ioe) {
        fail(ioe.getMessage());
    }
  

}

  // Private Methods

  /**
   * <p> Setup the debugging subsystem. </p>
   *
   * @post IDebugTestCase.debug != null
   * @post IDebugTestCase.debugConstants != null
   * @post IDebugTestCase.debugOutput != null
   * @post IDebugTestCase.assert != null
   * @post IDebugTestCase.debugCategory.equals("NOTICE")
   * @post IDebugTestCase.initialized == true
   */

  private static void setupDebug()
  {

    // Setup debugging subsystem.
    IDebugInit.init();
    IDebugTestCase.debug = IDebugInit.getDebug();
    IDebugTestCase.debugConstants = IDebugInit.getDebugConstants();
    IDebugTestCase.debugOutput = IDebugInit.getDebugOutput();
    IDebugTestCase.assert = IDebugInit.getAssert();
    IDebugTestCase.debugCategory = "NOTICE";
    IDebugTestCase.initialized = true;
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ try {
/*|*/ if (!(IDebugTestCase.debug != null)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyTestSetup.java:104: error: postcondition violated (kindftptest.FTPProxyTestSetup::setupDebug()): "+
/*|*/   "IDebugTestCase.debug != null");
/*|*/ if (!(IDebugTestCase.debugConstants != null)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyTestSetup.java:104: error: postcondition violated (kindftptest.FTPProxyTestSetup::setupDebug()): "+
/*|*/   "IDebugTestCase.debugConstants != null");
/*|*/ if (!(IDebugTestCase.debugOutput != null)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyTestSetup.java:104: error: postcondition violated (kindftptest.FTPProxyTestSetup::setupDebug()): "+
/*|*/   "IDebugTestCase.debugOutput != null");
/*|*/ if (!(IDebugTestCase.assert != null)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyTestSetup.java:104: error: postcondition violated (kindftptest.FTPProxyTestSetup::setupDebug()): "+
/*|*/   "IDebugTestCase.assert != null");
/*|*/ if (!(IDebugTestCase.debugCategory.equals("NOTICE"))) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyTestSetup.java:104: error: postcondition violated (kindftptest.FTPProxyTestSetup::setupDebug()): "+
/*|*/   "IDebugTestCase.debugCategory.equals(\"NOTICE\")");
/*|*/ if (!(IDebugTestCase.initialized == true)) 
/*|*/   throw new java.lang.Error ("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyTestSetup.java:104: error: postcondition violated (kindftptest.FTPProxyTestSetup::setupDebug()): "+
/*|*/   "IDebugTestCase.initialized == true");}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String txt = "";  if (ex.getClass()==java.lang.Error.class) { txt = ex.toString();; }
/*|*/   else txt = "/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyTestSetup.java:104:  exception <<"+ex+">> occured while evaluating POST-condition in /home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyTestSetup.java:104:  kindftptest.FTPProxyTestSetup::setupDebug()";
/*|*/   throw new java.lang.Error(txt);}
/*|*/ 
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}

  /**
   * <p> Read in a properties file for configuring non-default test values
   * for the following parameters for the test proxy constructor. </p>
   */

  private static void readTestProperties()
  {

    // read in a property file and set FTPServer et al to customized
    // values.
  

}

} // end of class FTPProxyTestSetup
