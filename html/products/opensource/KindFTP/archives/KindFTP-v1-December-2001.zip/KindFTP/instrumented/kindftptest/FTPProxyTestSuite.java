/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: FTPProxyTestSuite.java,v 1.4 2001/12/20 07:42:30 kiniry Exp $
 */

package kindftptest;

import junit.extensions.TestSetup;
import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * <p> Blackbox testsuite for the class <code>FTPProxy</code>. </p>
 *
 * <p> This test code expects the following test configuration by default:
 * <ul>
 *   <li> An FTP server running on localhost. </li>
 *   <li> Anonymous access enabled on server. </li>
 *   <li> The existence of a test user "kindftp" with password "test". </li>
 *   <li> The existence of a directory called "test_directory" in both the
 *        user kindftp's home directory as well as the anonymous ftp user home
 *        directory. </li>
 *   <li> The existence of a file called "rename_file" in both directories
 *        named "test_directory". </li>
 *   <li> The existence of a directory called "/tmp" on the FTP server. </li>
 *   <li> The existence of files "file.txt", "foo.jar" and "bar.zip" in
 *        the directory "/tmp".  "file.txt" is a text file, "foo.jar" is a JAR
 *        file, and "bar.zip" is a ZIP file. </li>
 *   <li> All the aforementioned directories and files must be owned by
 *        their respective users so that rename, get, and store commands work
 *        properly. </li>
 *   <li> The test code expects that the FTP server does <em>not</em>
 *        implement the ACCT, SMNT, and REIN commands. </li>
 *   <li> The server should permit renames by anonymous users. </li>
 * </ul>
 * </p>
 *
 * <p> If wuftpd is used for testing, the following command line is
 * probably the most appropriate: <tt>wu.ftpd -v -l -L -i -o -X -S -a</tt>
 * <br /> Note that the access file should let the anonymous and kindftp
 * users perform uploads, downloads, and renames. </p>
 *
 * @design As per TODO file, we need to refine this test suite so that all
 * tests have no dependency on client or server state.
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Factored out of main FTPProxy class.
 * @version $Revision: 1.4 $ $Date: 2001/12/20 07:42:30 $ 
 * @since KindFTP initial release.
 * @see "RFC959 for more information."
 * @see <a href="http://www.junit.org/">jUnit</a>
 */

public class FTPProxyTestSuite extends TestSuite
{
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ // Keeps track of calling chain to avoid recursive invariant checks.
/*|*/ // Avoids inv checks in public methods that are called from private ones.
/*|*/ // Stores bookkeeping information -- key: thread, value: call level
/*|*/ protected transient java.util.Hashtable __icl_ = new java.util.Hashtable(1);
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_entry__kindftptest_FTPProxyTestSuite(Thread thread, String loc)  {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/     __check_invariant____kindftptest_FTPProxyTestSuite(loc);
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_exit__kindftptest_FTPProxyTestSuite(Thread thread, String loc)  {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if (((Integer)__icl_.get(thread)).intValue() == 1 ) {
/*|*/     try {
/*|*/       __check_invariant____kindftptest_FTPProxyTestSuite(loc);
/*|*/     } finally {
/*|*/       __icl_.remove(thread); // remove from bookkeeping, before checking (resoliant wrt exceptions)
/*|*/   }}
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()-1));
/*|*/ }
/*|*/ // Default constructor automatically added to check invariant at implicit return.
/*|*/ // n.b. superclass chaining (call to super()) will be inserted by compiler.
/*|*/ public FTPProxyTestSuite()  {
/*|*/   __check_invariant____kindftptest_FTPProxyTestSuite("/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/FTPProxyTestSuite.java:57: default constructor kindftptest.FTPProxyTestSuite::FTPProxyTestSuite() does not establish all class invariants at it's exit [class kindftptest.FTPProxyTestSuite does not explicitly define a default constructor. Therefore the compiler implicitly generated a public, empty default constructor] ");
/*|*/ }
/*|*/ // Tests the invariants of the class and its superclasses.
/*|*/ // This method is public (see note below) to give subclasses (potentially in different packages),
/*|*/ // acccess to the inv of superclasses (and to let the reflection API find the.
/*|*/ // method)
/*|*/ //
/*|*/ public synchronized void __check_invariant____kindftptest_FTPProxyTestSuite( String location )  {
/*|*/ try {
/*|*/ }
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String msg = "";
/*|*/   if (ex.getClass()==java.lang.Error.class) { msg = ex.toString(); }
/*|*/   else msg = location + " exception <<"+ex+">> occured while evaluating the class INVARIANT.";
/*|*/   throw new java.lang.Error(msg);}
/*|*/ 
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
  // Public Methods

  public static void main (String[] args) {

    junit.textui.TestRunner.run(suite());
  

}

  public static Test suite() {

    TestSuite suite = new TestSuite("All FTPProxy Tests.");
    suite.addTest(FTPProxyInitialTestCases.suite());
    suite.addTest(FTPProxyReceiveTestCases.suite());
    suite.addTest(FTPProxySendTestCases.suite());
    suite.addTest(FTPProxyMiscTestCases.suite());
    TestSetup wrapper = new FTPProxyTestSetup(suite);

    

return wrapper;
  }

} // end of class FTPProxyTestSuite
