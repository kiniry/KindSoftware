/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: IDebugTestCase.java,v 1.3 2001/12/20 07:42:30 kiniry Exp $
 */

package kindftptest;

import idebug.Assert;
import idebug.Debug;
import idebug.DebugConstants;
import idebug.DebugOutput;
import junit.framework.TestCase;

/**
 * <p> An extension of the base jUnit TestCase class to integrate IDebug
 * and jUnit functionality. </p>
 *
 * <p> At this point, this class only provides a single point of access to
 * the core set of IDebug interfaces via static references. </p>
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history 8 Dec 2001 - Created class and started using jUnit.
 * @version $Revision: 1.3 $ $Date: 2001/12/20 07:42:30 $ 
 * @since KindFTP initial release.
 * @see <a href="http://www.junit.org">jUnit</a>
 * @see <a href="http://www.kindsoftware.com/products/opensource/IDebug/">IDebug</a>
 *
 * @invariant initialized implies debug != null
 * @invariant initialized implies assert != null
 * @invariant initialized implies debugConstants != null
 * @invariant initialized implies debugOutput != null
 * @invariant initialized implies debugCategory != null
 */

public class IDebugTestCase extends TestCase
{
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ // Keeps track of calling chain to avoid recursive invariant checks.
/*|*/ // Avoids inv checks in public methods that are called from private ones.
/*|*/ // Stores bookkeeping information -- key: thread, value: call level
/*|*/ protected transient java.util.Hashtable __icl_ = new java.util.Hashtable(1);
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_entry__kindftptest_IDebugTestCase(Thread thread, String loc) throws java.lang.Error {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/     __check_invariant____kindftptest_IDebugTestCase(loc);
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting and check the invariant if appropriate
/*|*/ private synchronized void __inv_check_at_exit__kindftptest_IDebugTestCase(Thread thread, String loc) throws java.lang.Error {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if (((Integer)__icl_.get(thread)).intValue() == 1 ) {
/*|*/     try {
/*|*/       __check_invariant____kindftptest_IDebugTestCase(loc);
/*|*/     } finally {
/*|*/       __icl_.remove(thread); // remove from bookkeeping, before checking (resoliant wrt exceptions)
/*|*/   }}
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()-1));
/*|*/ }
/*|*/ // Update bookkeeping of method nesting DO NOT check the invariant (i.e. for non-default constr.)
/*|*/ private synchronized void __inc_icl_at_entry__kindftptest_IDebugTestCase(Thread thread)  {
/*|*/   // perform lazy initialization after de-serialization (transient __icl_)
/*|*/   if (__icl_ == null) __icl_ = new java.util.Hashtable(1);
/*|*/   if ( !__icl_.containsKey(thread) ) {
/*|*/     __icl_.put(thread, new Integer(1));
/*|*/   }
/*|*/   else
/*|*/     __icl_.put(thread, new Integer(((Integer)__icl_.get(thread)).intValue()+1));
/*|*/ }
/*|*/ // Tests the invariants of the class and its superclasses.
/*|*/ // This method is public (see note below) to give subclasses (potentially in different packages),
/*|*/ // acccess to the inv of superclasses (and to let the reflection API find the.
/*|*/ // method)
/*|*/ //
/*|*/ public synchronized void __check_invariant____kindftptest_IDebugTestCase( String location ) throws java.lang.Error {
/*|*/ try {
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debug != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debug != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( assert != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies assert != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugConstants != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugConstants != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugOutput != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugOutput != null");
/*|*/ if (!( initialized )) // implication condition
/*|*/   { } // implication evaluates to true
/*|*/ else
/*|*/   if (!( debugCategory != null )) // the implication 
/*|*/     throw new java.lang.Error ( location + "error: invariant violated (kindftptest.IDebugTestCase): "+
/*|*/     "initialized implies debugCategory != null");}
/*|*/ catch ( RuntimeException ex ) {
/*|*/   String msg = "";
/*|*/   if (ex.getClass()==java.lang.Error.class) { msg = ex.toString(); }
/*|*/   else msg = location + " exception <<"+ex+">> occured while evaluating the class INVARIANT.";
/*|*/   throw new java.lang.Error(msg);}
/*|*/ 
/*|*/ }
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
  // Private Attributes.

  // Debugging variables.
  static Debug debug = null;
  static Assert assert = null;
  static DebugConstants debugConstants = null;
  static DebugOutput debugOutput = null;
  static String debugCategory = null;

  // Indiates that debugging variables have been initialized.
  // @modifies SINGLE-ASSIGNMENT
  static boolean initialized = false;

  public IDebugTestCase(String name)
  {
    super(name);
  
/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ __inc_icl_at_entry__kindftptest_IDebugTestCase(Thread.currentThread());
/*|*/ try {
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 

/*|*/ //#*#-------------------------------------------------------------------------------
/*|*/ } finally {
/*|*/ __inv_check_at_exit__kindftptest_IDebugTestCase(Thread.currentThread(),"/home/kiniry/Projects/KindSoftware/sandbox/KindFTP/source/kindftptest/IDebugTestCase.java:53:  just before exit kindftptest.IDebugTestCase::IDebugTestCase(java.lang.String) ");}
/*|*/ //-------------------------------------------------------------------------------#*#
/*|*/ 
}
  
} // end of class IDebugTestCase
