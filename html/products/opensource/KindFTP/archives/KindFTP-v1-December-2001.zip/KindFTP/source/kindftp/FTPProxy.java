/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: FTPProxy.java,v 1.13 2001/12/27 06:53:31 kiniry Exp $
 */

package kindftp;

import idebug.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.*;

/**
 * <p> The following implementation of the FTP protocol is written to
 * fulfill RFC 959. </p>
 *
 * <p> All of the documentation on reply codes, all state diagrams,
 * and all other FTP-specific discussion and documentation is copies
 * in whole or in part from RFC 959 by J. Postel and J. Reynolds. </p>
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Broken out into separate component to be
 * released by KindSoftware under broad OS license.
 *
 * @version $Revision: 1.13 $ $Date: 2001/12/27 06:53:31 $ 
 * @since Initial release of KindFTP
 * 
 * @design The default FTP port is 21.
 *
 * @design This version of the FTPProxy only works with FTP servers
 * that present a file structure similar to that of UNIX.  (E.g. No
 * VMS, DOS, or weird Mac FTP servers will work with this component.)
 *
 * @design Case does matter for all names (accounts, directories,
 * files, passwords, etc.).
 *
 * @design We currrently do not handle directories or filenames that
 * have quotes in them.
 *
 * @design Several methods in this class are not completely implemented
 * because most FTP servers do not support the operations and thus we have
 * no test apparatus.  The methods that have untested partial support
 * include: ACCT, SMNT, REIN, TYPE (types E and L not supported), STRU
 * (structures R and P not supported), MODE (modes B, C, and L not
 * supported), ALLO, and SITE.  Methods STOU and REST have no
 * implementation at all.
 *
 * @design Other methods are not considered complete because they have not
 * been rigorously tested.  This set includes: ABOR.
 *
 * @design NOTE!!!: that the order and arrangement of all the methods,
 * result codes, etc below is carefully chosen to reflect RFC 959's
 * organization.  Please do not reorder/reorganize any of this
 * material.
 *
 * @design This class does not support sending and receiving data on
 * the default data port (the command port).
 *
 * @todo REST is still unimplemented.
 * @todo Reconsider concurrency semantics of whole class.
 * @todo Reconsider available/read check algorithm in data transfer methods
 * (RETR, STOR, etc.).
 * @todo Reconsider bytesRead == -1 check in such methods as well.
 *
 * @see "RFC959 for more information."
 *
 * @design MDTM and SIZE are not specified in RFC 959.  They will be
 * specified in the next FTP RFC.
 *
 * @todo Look into next FTP RFC; has it been released yet?
 *
 * @invariant serverControlPort > 0
 * @invariant serverDataPort > 0
 * @invariant initialized implies (serverInetAddress != null)
 * @invariant initialized implies (debug != null)
 * @invariant initialized implies (debugOutput != null)
 * @invariant initialized implies (assert != null)
 * @invariant initialized implies (debugConstants != null)
 * @invariant state == BEGIN || state == WAIT || state == ERROR ||
 *            state == FAILURE || state == SUCCESS
 * @invariant (commandSocket != null) implies 
 *            (commandOutputStream != null) && 
 *            (commandInputStream != null) &&
 *            (PORTaddress != null) &&
 *            (PORTport > 0)
 */

public class FTPProxy
{
  // Public Attributes

  public static final int BEGIN   = 0;
  public static final int WAIT    = 1;
  public static final int ERROR   = 2;
  public static final int FAILURE = 3;
  public static final int SUCCESS = 4;
  //public static final int NOTIMPL = 5;

  // Private Attributes

  private static Debug debug = null;
  private static Assert assert = null;
  private static DebugConstants debugConstants = null;
  private static DebugOutput debugOutput = null;
  private static final String debugCategory = "NOTICE";

  private File dataFile = null;
  private Object dataObject = null;

  // The state of the proxy wrt the server state.
  private String username = null;
  private String password = null;  
  private String account = null;  
  private int state = BEGIN;
  private String systemType = null;

  // The state of the proxy independent of the server state.
  private boolean initialized = false;
  private boolean isPASV = false;
  private InetAddress PORTaddress = null;
  private int PORTport = 0;

  // The last response received from the server, its prefix, and its reply
  // code.
  private String response = null;
  private int prefix;
  private int replyCode;

  // Both the user and the server-DTPs have a default data port. The
  // user-process default data port is the same as the control connection
  // port (i.e., U). The server-process default data port is the port
  // adjacent to the control connection port (i.e., L-1).

  private static final int DEFAULT_CONTROL_PORT = 21;
  private static final int DEFAULT_DATA_PORT = 20;

  private InetAddress serverInetAddress;
  private int serverControlPort = DEFAULT_CONTROL_PORT;
  private int serverDataPort = DEFAULT_DATA_PORT;

  private Socket commandSocket;
  private BufferedWriter commandOutputStream;
  private CommandReader commandInputStream;

  private ServerSocket dataServerSocket;
  private Socket dataSocket;
  private BufferedOutputStream dataOutputStream;
  private BufferedInputStream dataInputStream;


  // Public Methods

  /**
   * <p> Build a new FTPProxy for the given server parameters. </p>
   *
   * @param address the address of the FTP server.
   * @param port the port to connect to on the server.  A port of 0
   * means connect to the default port.
   * @param debug a <code>Debug</code> object for the debugging subsystem.
   * @param debugOutput a <code>DebugOutput</code> object for the
   * debugging subsystem.
   *
   * @pre address != null
   * @pre port >= 0
   * @pre debug != null
   * @pre debugOutput != null
   *
   * @post this.debug == debug
   * @post this.debugOutput == debugOutput
   * @post assert != null
   * @post debugConstants != null
   * @post serverInetAddress == address
   * @post port == 0 implies serverControlPort == DEFAULT_CONTROL_PORT
   * @post serverDataPort == serverControlPort - 1
   */

  public FTPProxy(InetAddress address, int port, 
                  Debug debug, DebugOutput debugOutput)
  {
    serverInetAddress = address;
    if (port != 0)
      serverControlPort = port;
    serverDataPort = port - 1;
    this.debug = debug;
    this.debugOutput = debugOutput;
    assert = debug.getAssert();
    debugConstants = debug.getDebugConstants();

    debugOutput.println(debugCategory, "New FTPProxy created for '" + 
                        serverInetAddress + 
                        ":" + serverControlPort + "'.");
    initialized = true;
  }

  /**
   * @return the state of the proxy.
   *
   * @post return == BEGIN || return == WAIT || return == ERROR ||
   *       return == FAILURE || return == SUCCESS
   */

  public int getState()
  {
    return state;
  }

  /**
   * @return the prefix of the last reply.
   *
   * @post return == ReplyCodes.POSITIVE_PRELIMINARY ||
   *       return == ReplyCodes.POSITIVE_COMPLETION ||
   *       return == ReplyCodes.POSITIVE_INTERMEDIATE ||
   *       return == ReplyCodes.TRANSIENT_NEGATIVE_COMPLETION ||
   *       return == ReplyCodes.PERMANENT_NEGATIVE_COMPLETION
   */

  public int getPrefix()
  {
    return prefix;
  }

  /**
   * @return the reply code of the last server reply.
   *
   * @post return >= 100 && return <= 553
   * @todo This postcondition should probably be refined to cover exactly
   * the potential reply codes and not just the range. (?)
   */

  public int getReplyCode()
  {
    return replyCode;
  }

  /**
   * @return the last full response received from the server.
   */

  public String getLastResponse()
  {
    return response;
  }

  /**
   * <p> Build a new command connection to the server. </p>
   *
   * @exception IOException is thrown if anything goes wrong while
   * setting up the channel.
   *
   * @uses serverInetAddress, serverControlPort, 
   * @uses commandSocket, commandOutputStream, commandInputStream
   * @uses PORTaddress, PORTport
   *
   * @pre serverInetAddress != null
   * @ipost (commandSocket.valid() && 
   *         commandOutputStream.valid) && commandInputStream.valid())
   * @ipost (PORTaddress.valid() && PORTport.valid())
   */

  public void connect() throws IOException
  {
    debugOutput.println(debugCategory, 
                        "Building new connection to server '" + 
                        serverInetAddress + ":" + serverControlPort + "'.");
    commandSocket = new Socket(serverInetAddress, serverControlPort);
    // Make the command socket a no-delay socket (disables Nagel's
    // algorithm for faster ramp-up of data delivery), don't let it linger
    // (so that the port is reclaimed faster), and set the timeout at
    // 5*1,000ms (5 seconds).
    commandSocket.setTcpNoDelay(true);
    commandSocket.setSoLinger(false, 0);
    commandSocket.setSoTimeout(5*1000);
    commandOutputStream = new BufferedWriter(
             new OutputStreamWriter(commandSocket.getOutputStream()));
    commandInputStream = new CommandReader(
             new InputStreamReader(commandSocket.getInputStream()));
    try {
      PORTaddress = InetAddress.getLocalHost();
      PORTport = commandSocket.getLocalPort();
    } catch (UnknownHostException unknownHostException) {
      throw new IOException(unknownHostException.getMessage());
    }
    // Read the prelude from the server until we get a 220 or 120 response
    // per RFC959.
    while(true) {
      receive();
      if (getReplyCode() == ReplyCodes.SERVICE_READY_FOR_NEW_USER) {
        state = SUCCESS;
        break;
      }
      if (getReplyCode() == ReplyCodes.SERVICE_READY_IN_NNN_MINUTES) {
        state = WAIT;
        break;
      }
    }
    debugOutput.println(debugCategory, "Prelude: " + getLastResponse());
  }

  // ============================================================
  // Begin of FTP commands
  // ============================================================

  // Each command has a Command-Reply Sequence.  Each command is listed
  // with its possible replies; command groups are listed
  // together. Preliminary replies are listed first (with their succeeding
  // replies indented and under them), then positive and negative
  // completion, and finally intermediary replies with the remaining
  // commands from the sequence following. This listing forms the basis for
  // the state diagrams, which will be presented separately.

  /**
   * <p> Identify the user to the server. </p>
   *
   * <p> The argument field is a string identifying the user. The user
   * identification is that which is required by the server for access
   * to its file system. This command will normally be the first
   * command transmitted by the user after the control connections are
   * made (some servers may require this). Additional identification
   * information in the form of a password and/or an account command
   * may also be required by some servers. Servers may allow a new
   * USER command to be entered at any point in order to change the
   * access control and/or accounting information. This has the effect
   * of flushing any user, password, and account information already
   * supplied and beginning the login sequence again. All transfer
   * parameters are unchanged and any file transfer in progress is
   * completed under the old access control parameters. </p>
   *
   * <p> A reply code of <code>ReplyCodes.USER_LOGGED_IN</code> means
   * that the username was accepted and no password is required, thus you
   * can start issuing FTP commands.  A code of
   * <code>ReplyCodes.USER_NAME_OK</code> indicates that a call to the 
   * <code>PASS</code> method is required.  A code of
   * <code>ReplyCodes.NEED_ACCOUNT_FOR_LOGIN</code> indicates a call to
   * ACCT is necessary to login.  Anything else indicates a failure; see
   * the specific code for more information. </p>
   *
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre username != null
   * @post getReplyCode() == ReplyCodes.USER_LOGGED_IN ||
   *       getReplyCode() == ReplyCodes.NOT_LOGGED_IN ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_COMMAND ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_PARAMETERS ||
   *       getReplyCode() == 
   *         ReplyCodes.SERVICE_NOT_AVAILABLE_CLOSING_CONTROL_CONNECTION ||
   *       getReplyCode() == ReplyCodes.USER_NAME_OK ||
   *       getReplyCode() == ReplyCodes.NEED_ACCOUNT_FOR_LOGIN
   */

  public void USER(String username) throws IOException
  {
    // USER <SP> <username> <CRLF>
    // 230
    // 530
    // 500, 501, 421
    // 331, 332

    send("USER " + username);
    receive();
    if ((prefix == ReplyCodes.POSITIVE_COMPLETION) || 
        (prefix == ReplyCodes.POSITIVE_INTERMEDIATE))
      this.username = username;
    FSM0();
  }

  /**
   * <p> Send a password to the server for user authentication. </p>
   *
   * <p> The argument field is a string specifying the user's
   * password. This command must be immediately preceded by the user
   * name command, and, for some sites, completes the user's
   * identification for access control. Since password information is
   * quite sensitive, it is desirable in general to "mask" it or
   * suppress typeout. It appears that the server has no foolproof way
   * to achieve this. It is therefore the responsibility of the
   * user-FTP process to hide the sensitive password information. </p>
   *
   * <p> A reply code of <code>ReplyCodes.USER_LOGGED_IN</code> or
   * <code>ReplyCodes.COMMAND_NOT_IMPLEMENTED_SUPERFLUOUS</code> means the
   * password was accepted or was superfluous (resp.) and you can start
   * issuing FTP commands.  A code of
   * <code>ReplyCodes.NEED_ACCOUNT_FOR_LOGIN</code> means that a call to
   * the <code>ACCT</code> method is required.  Anything else indicates of
   * failure; see the specific code for more information. </p>
   *
   * @param password the password to send to the server.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre password != null
   * @post getReplyCode() == ReplyCodes.USER_LOGGED_IN ||
   *       getReplyCode() == ReplyCodes.COMMAND_NOT_IMPLEMENTED_SUPERFLUOUS ||
   *       getReplyCode() == ReplyCodes.NOT_LOGGED_IN ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_COMMAND ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_PARAMETERS ||
   *       getReplyCode() == ReplyCodes.BAD_SEQUENCE_OF_COMMANDS ||
   *       getReplyCode() == 
   *         ReplyCodes.SERVICE_NOT_AVAILABLE_CLOSING_CONTROL_CONNECTION ||
   *       getReplyCode() == ReplyCodes.NEED_ACCOUNT_FOR_LOGIN
   */

  public void PASS(String password) throws IOException
  {
    // PASS <SP> <password> <CRLF>
    // 230
    // 202
    // 530
    // 500, 501, 503, 421
    // 332

    send("PASS " + password);
    receive();
    if ((prefix == ReplyCodes.POSITIVE_COMPLETION) || 
        (prefix == ReplyCodes.POSITIVE_INTERMEDIATE))
      this.password = password;
    FSM0();
  }

  /**
   * <p> Send an account name to the server. </p>
   *
   * <p> The argument field is a string identifying the user's
   * account. The command is not necessarily related to the USER
   * command, as some sites may require an account for login and
   * others only for specific access, such as storing files. In the
   * latter case the command may arrive at any time. </p>
   *
   * <p> A reply code of <code>ReplyCodes.USER_LOGGED_IN</code> or
   * <code>ReplyCodes.COMMAND_NOT_IMPLEMENTED_SUPERFLUOUS</code> means the
   * account name was accepted or was superfluous (resp.) and you can start
   * issuing FTP commands.  A code of <code>ReplyCodes.NOT_LOGGED_IN</code>
   * means that the account name provided failed.  Anything else indicates
   * some other failure; see the specific code for more information. </p>
   *
   * @param account the account name to send to the server.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre account != null
   * @post getReplyCode() == ReplyCodes.USER_LOGGED_IN ||
   *       getReplyCode() == ReplyCodes.COMMAND_NOT_IMPLEMENTED_SUPERFLUOUS ||
   *       getReplyCode() == ReplyCodes.NOT_LOGGED_IN ||
   *       getReplyCode() == ReplyCodes.BAD_SEQUENCE_OF_COMMANDS ||
   *       ReplyCodes.isStandardError_500_501_502_421(getReplyCode())
   */

  public void ACCT(String account) throws IOException
  {
    // ACCT <SP> <account-information> <CRLF>
    // 230
    // 202
    // 530
    // 500, 501, 503, 421

    // A 502 is a possible response as well through it is erroneously not
    // documented by RFC959.

    send("ACCT " + password);
    receive();
    if (prefix == ReplyCodes.POSITIVE_COMPLETION)
      this.account = account;
    FSM1();
    //NOTIMPL();
  }

  /**
   * <p> This command allows the user to work with a different directory or
   * dataset for file storage or retrieval without altering his login or
   * accounting information. Transfer parameters are similarly
   * unchanged. The argument <code>pathname</code> is a path specifying a
   * directory or other system dependent file group designator. </p>
   *
   * <p> A reply code of
   * <code>ReplyCodes.FILE_ACTION_OK_AND_COMPLETED</code> means the command
   * succeeded.  Anything else indicates some other failure; see the
   * specific code for more information. </p>
   *
   * @param pathname the path to change to.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre pathname != null
   * @post getReplyCode() == ReplyCodes.FILE_ACTION_OK_AND_COMPLETED ||
   *       ReplyCodes.isStandardError_500_501_502_421_530(getReplyCode()) ||
   *       getReplyCode() == ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE
   */

  public void CWD(String pathname) throws IOException
  {
    // CWD <SP> <pathname> <CRLF>
    // 250
    // 500, 501, 502, 421, 530, 550

    send("CWD " + pathname);
    receive();
    FSM1();
  }

  /**
   * <p> This command is a special case of CWD, and is included to
   * simplify the implementation of programs for transferring
   * directory trees between operating systems having different
   * syntaxes for naming the parent directory. The reply codes shall
   * be identical to the reply codes of CWD. </p>
   *
   * <p> A reply code of
   * <code>ReplyCodes.FILE_ACTION_OK_AND_COMPLETED</code> means the command
   * succeeded.  Anything else indicates some other failure; see the
   * specific code for more information. </p>
   *
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @post getReplyCode() == ReplyCodes.COMMAND_OK ||
   *       ReplyCodes.isStandardError_500_501_502_421_530(getReplyCode()) ||
   *       getReplyCode() == ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE
   */

  public void CDUP() throws IOException
  {
    // CDUP <CRLF>
    // 200
    // 500, 501, 502, 421, 530, 550

    send("CDUP");
    receive();
    FSM1();
  }
  
  /**
   * <p> This command allows the user to mount a different file system data
   * structure without altering his login or accounting
   * information. Transfer parameters are similarly unchanged. The argument
   * <code>pathname</code> is a path specifying a directory or other system
   * dependent file group designator. </p>
   *
   * <p> A reply code of
   * <code>ReplyCodes.COMMAND_NOT_IMPLEMENTED_SUPERFLUOUS</code> or
   * <code>ReplyCodes.FILE_ACTION_OK_AND_COMPLETED</code> means the command
   * succeeded (perhaps because it was unnecessary in the former case).
   * Anything else indicates some other failure; see the specific code for
   * more information. </p>
   *
   * @param pathname a path specifying a directory or other system
   * dependent file group designator.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre pathname != null
   * @post getReplyCode() == ReplyCodes.COMMAND_NOT_IMPLEMENTED_SUPERFLUOUS ||
   *       getReplyCode() == ReplyCodes.FILE_ACTION_OK_AND_COMPLETED ||
   *       ReplyCodes.isStandardError_500_501_502_421_530(getReplyCode()) ||
   *       getReplyCode() == ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE
   */

  public void SMNT(String pathname) throws IOException
  {
    // SMNT <SP> <pathname> <CRLF>
    // 202, 250
    // 500, 501, 502, 421, 530, 550

    send("SMNT " + pathname);
    receive();
    FSM1();
  }
  
  /**
   * <p> This command terminates a USER and if file transfer is not in
   * progress, the server closes the control connection. If file
   * transfer is in progress, the connection will remain open for
   * result response and the server will then close it. </p>
   *
   * <p> An unexpected close on the control connection will cause the
   * server to take the effective action of an abort (ABOR) and a
   * logout (QUIT). </p>
   *
   * <p> A reply code of
   * <code>ReplyCodes.SERVICE_CLOSING_CONTROL_CONNECTION</code> means the
   * command succeeded.  Anything else indicates some other failure; see
   * the specific code for more information. </p>
   *
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @post getReplyCode() == ReplyCodes.SERVICE_CLOSING_CONTROL_CONNECTION ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_COMMAND
   */

  public void QUIT() throws IOException
  {
    // QUIT <CRLF>
    // 221
    // 500
    
    send("QUIT");
    receive();
    FSM1();
  }
  
  /**
   * <p> This command terminates a USER, flushing all I/O and account
   * information, except to allow any transfer in progress to be
   * completed. All parameters are reset to the default settings and
   * the control connection is left open. This is identical to the
   * state in which a user finds himself immediately after the control
   * connection is opened. A USER command may be expected to follow. </p>
   *
   * <p> A reply code of
   * <code>ReplyCodes.SERVICE_READY_IN_NNN_MINUTES</code> means that the
   * service isn't currently ready but will be in approximately NNN
   * minutes.  A code of <code>ReplyCodes.SERVICE_READY_FOR_NEW_USER</code>
   * indicates that the current user is terminated and all account
   * information is flushed.  Anything else indicates a failure; see the
   * specific code for more information. </p>
   *
   * <p> We currently do nothing special to handle the first case
   * above. </p>
   *
   * @todo Support replycode 120 better.
   *
   * @exception IOException is thrown if an I/O error occurs.
   * @post getReplyCode() == ReplyCodes.SERVICE_READY_IN_NNN_MINUTES ||
   *       getReplyCode() == ReplyCodes.SERVICE_READY_FOR_NEW_USER ||
   *       getReplyCode() == 
   *         ReplyCodes.SERVICE_NOT_AVAILABLE_CLOSING_CONTROL_CONNECTION ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_COMMAND ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_PARAMETERS
    */

  public void REIN() throws IOException
  {
    // REIN <CRLF>
    // 120
    // 220 (<-- looks like another error in the RFC? [double 220s])
    // 220
    // 421
    // 500, 502

    send("REIN");
    receive();
    FSM2();
    // If the service is ready for a new user we should reset our state.
    if (replyCode == ReplyCodes.SERVICE_READY_FOR_NEW_USER) {
      username = null;      password = null;
      account = null;       state = BEGIN;
      systemType = null;    isPASV = false;
      PORTaddress = null;   PORTport = 0;
      response = null;      prefix = 0;
      replyCode = 0;
    }
  }
  
  /**
   * <p> The arguments are a HOST-PORT specification for the data port
   * to be used in data connection. There are defaults for both the
   * user and server data ports, but this class does not support the
   * defaults.  The PORT command and/or the PASV command <em>must</em>
   * be used in all data transfers. </p>
   *
   * <p> A reply code of <code>ReplyCodes.COMMAND_OK</code> means the
   * command succeeded.  Anything else indicates some other failure; see
   * the specific code for more information. </p>
   *
   * @param address the address of the system that has the data port
   * (i.e. the server should connect to if not in PASV mode).
   * @param port the port of the system designated with the
   * <code>address</code> parameter.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre address != null
   * @pre port >= 0 && port <= 65536
   * @post getReplyCode() == ReplyCodes.COMMAND_OK ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_COMMAND ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_PARAMETERS ||
   *       getReplyCode() ==
   *         ReplyCodes.SERVICE_NOT_AVAILABLE_CLOSING_CONTROL_CONNECTION ||
   *       getReplyCode() == ReplyCodes.NOT_LOGGED_IN
   */

  public void PORT(InetAddress address, int port) throws IOException
  {
    // PORT <SP> <host-port> <CRLF>
    // 200
    // 500, 501, 421, 530

    byte [] ip = address.getAddress();

    send("PORT " + 
         ((ip[0] < 0) ? (ip[0]+256) : ip[0]) + 
         "," + ((ip[1] < 0) ? (ip[1]+256) : ip[1]) + 
         "," + ((ip[2] < 0) ? (ip[2]+256) : ip[2]) + 
         "," + ((ip[3] < 0) ? (ip[3]+256) : ip[3]) + 
         "," + port / 256 + "," + port % 256);
    receive();
    if (replyCode == ReplyCodes.COMMAND_OK) {
      PORTaddress = address;
      PORTport = port;
    }
    FSM1();
  }
  
  /**
   * <p> This command requests the server-DTP to "listen" on a data
   * port (which is not its default data port) and to wait for a
   * connection rather than initiate one upon receipt of a transfer
   * command. </p>
   *
   * <p> Note that the next connection-oriented command (STOR, RETR,
   * LIST, NLST, etc.) will clear the state of this value on the
   * server.  A PASV command must be issued prior to <em>every</em> data
   * command action. </p>
   *
   * <p> A reply code of <code>ReplyCodes.ENTERING_PASSIVE_MODE</code>
   * means the command succeeded.  Anything else indicates some other
   * failure; see the specific code for more information. </p>
   *
   * @exception IOException is thrown if an I/O error occurs.
   * @post getReplyCode() == ReplyCodes.ENTERING_PASSIVE_MODE ||
   *       ReplyCodes.isStandardError_500_501_502_421_530(getReplyCode()) ||
   *       getReplyCode() == ReplyCodes.NOT_LOGGED_IN
   */

  public void PASV() throws IOException
  {
    // PASV <CRLF>
    // 227
    // 500, 501, 502, 421, 530

    send("PASV");
    receive();
    
    // Reply message has the address and port that the server is listening
    // on in it and is of the form: "227 Entering Passive Mode
    // (127,0,0,1,4,70)".  We must parse this message.
    if (replyCode == ReplyCodes.ENTERING_PASSIVE_MODE) {
      isPASV = true;
      int openParen = response.indexOf("(");
      int lastParen = response.lastIndexOf(")");
      String dataToParse = response.substring(openParen + 1, lastParen);
      StringTokenizer stringTokenizer = 
        new StringTokenizer(dataToParse, ",", false);
      String newAddress = stringTokenizer.nextToken() + "." + 
        stringTokenizer.nextToken() + 
        "." + stringTokenizer.nextToken() + "." + stringTokenizer.nextToken();
      int newPort = Integer.parseInt(stringTokenizer.nextToken()) * 256 + 
        Integer.parseInt(stringTokenizer.nextToken());
      // Set serverInetAddress and serverDataPort.
      serverInetAddress = InetAddress.getByName(newAddress);
      serverDataPort = newPort;
      debugOutput.println(debugCategory, 
                          "PASV - Server is now listening on: '" + 
                          serverInetAddress + ":" + serverDataPort + "'.");
    }
    FSM1();
  }
  
  /**
   * <p> The argument specifies the representation type of data that
   * is to be transferred. </p>
   *
   * <p> A reply code of <code>ReplyCodes.COMMAND_OK</code> means the
   * command succeeded.  Anything else indicates some other failure; see
   * the specific code for more information. </p>
   *
   * @param type_code must either be 'A' for ASCII or 'I' for Image.  Most
   * servers only support ASCII and Image types; we do not support 'E'
   * (EBCDIC) or 'L' (local byte size) types.  See RFC 959 for details.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre type_code == 'A' || type_code == 'I' || 
   *      type_code == 'E' || type_code == 'L'
   * @post getReplyCode() == ReplyCodes.COMMAND_OK ||
   *       ReplyCodes.isStandardError_500_501_504_421_530(getReplyCode())
   */

  public void TYPE(char type_code) throws IOException
  {
    // TYPE <SP> <type-code> <CRLF>
    // 200
    // 500, 501, 504, 421, 530

    assert.assert((type_code == 'A' || type_code == 'I'),
                  "kindftp.FTPProxy does not currently support EBCDIC or " +
                  "non-standard byte size representation types.");
    send("TYPE " + type_code);
    receive();
    FSM1();
  }
  
  /**
   * <p> The argument is a single character code specifying file
   * structure described in the Section on Data Representation and
   * Storage in RFC 959. </p>
   *
   * <p> A reply code of <code>ReplyCodes.COMMAND_OK</code> means the
   * command succeeded.  Anything else indicates some other failure; see
   * the specific code for more information. </p>
   *
   * @param structure_code must be either 'F' for file, 'R' for
   * record, and 'P' for page.  Most servers only support file
   * structure mode; we only supports file structure mode.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre structure_code == 'F' || structure_code == 'R' || structure_code == 'P'
   * @post getReplyCode() == ReplyCodes.COMMAND_OK ||
   *       ReplyCodes.isStandardError_500_501_504_421_530(getReplyCode())
   */

  public void STRU(char structure_code) throws IOException
  {
    // STRU <SP> <structure-code> <CRLF>
    // 200
    // 500, 501, 504, 421, 530

    assert.assert(structure_code == 'F',
                  "kindftp.FTPProxy does not currently support Record or Page " +
                  "file structure mode.");
    StringBuffer command = new StringBuffer("STRU ");
    command.append(structure_code);
    send(command.toString());
    receive();
    FSM1();
  }
  
  /**
   * <p> The argument is a single character code specifying the data
   * transfer modes described in the Section on Transmission Modes in
   * RFC 959. </p>
   *
   * <p> A reply code of <code>ReplyCodes.COMMAND_OK</code> means the
   * command succeeded.  Anything else indicates some other failure; see
   * the specific code for more information. </p>
   *
   * @param mode_code must be either 'S' for stream, 'B' for block, or
   * 'C' for compressed.  Most servers only support stream mode; we
   * only support stream mode.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre mode_code == 'S' || mode_code == 'B' || mode_code == 'C'
   * @post getReplyCode() == ReplyCodes.COMMAND_OK ||
   *       ReplyCodes.isStandardError_500_501_504_421_530(getReplyCode())
   */

  public void MODE(char mode_code) throws IOException
  {
    // MODE <SP> <mode-code> <CRLF>
    // 200
    // 500, 501, 504, 421, 530

    assert.assert((mode_code != 'B' && mode_code != 'C' && mode_code != 'L'),
                  "kindftp.FTPProxy does not currently support the " +
                  "block or compressed data transfer modes.");
    StringBuffer command = new StringBuffer("MODE ");
    command.append(mode_code);
    send(command.toString());
    receive();
    FSM1();
  }
  
  /**
   * <p> This command causes the server-DTP to transfer a copy of the file,
   * specified in the <code>pathname</code> parameter, to the server- or
   * user-DTP at the other end of the data connection. The status and
   * contents of the file at the server site shall be unaffected. </p>
   *
   * <p> If the streaming parameter is <code>true</code>, then the proxy's
   * <code>getState()</code> method will return a state of
   * <code>FTPProxy.WAIT</code> and <code>getReplyCode()</code> will hold a
   * <code>ReplyCodes.POSITIVE_PRELIMINARY</code> code.  Finally, the
   * user-DTP process is expected to call <code>getInputStream()</code> and
   * handle the incoming data itself.  The channel will be closed by the
   * server when all of the data has been sent. </p>
   *
   * <p> Whether or not the transfer is
   * successful, after the data has been (successfully or not) streamed,
   * the <code>completeCommandHandshake()</code> method
   * <strong>must</strong> be called to complete the command channel
   * handshake for the transfer. </p>
   *
   * <p> If streaming is <code>false</code>, the user-DTP should call
   * <code>getDataFile()</code> when this method successfully returns. </p>
   *
   * <p> A reply code of
   * <code>ReplyCodes.DATA_CONNECTION_ALREADY_OPEN_TRANFER_STARTING</code>
   * or
   * <code>ReplyCodes.FILE_STATUS_OK_ABOUT_TO_OPEN_DATA_CONNECTION</code>
   * means that the command was accepted the data is about to arrive over
   * the data connection.  A code of
   * <code>ReplyCodes.CLOSING_DATA_CONNECTION_AFTER_SUCCESSFUL_ACTION</code>
   * or <code>ReplyCodes.FILE_ACTION_OK_AND_COMPLETED</code> indicates that
   * the data has been transferred successfully.  A code of
   * <code>ReplyCodes.RESTART_MARKER_REPLY</code> indicates a successful
   * restarted transfer has begun.  Anything else indicates a failure of
   * some kind; see the specific code for more information. </p>
   *
   * @param pathname the name of the file to retrieve.
   * @param streaming a flag that indicates if the transfer should
   * take place in streaming mode.
   * @exception IOException is thrown if an I/O error occurs.
   * @see #getInputStream
   * @see #getState
   * @see #getReplyCode
   * @see #getPrefix
   *
   * @pre pathname != null
   * @post getReplyCode() == 
   *         ReplyCodes.DATA_CONNECTION_ALREADY_OPEN_TRANFER_STARTING ||
   *       getReplyCode() == 
   *         ReplyCodes.FILE_STATUS_OK_ABOUT_TO_OPEN_DATA_CONNECTION ||
   *       getReplyCode() == ReplyCodes.RESTART_MARKER_REPLY ||
   *       getReplyCode() == 
   *         ReplyCodes.CLOSING_DATA_CONNECTION_AFTER_SUCCESSFUL_ACTION ||
   *       getReplyCode() == ReplyCodes.FILE_ACTION_OK_AND_COMPLETED ||
   *       getReplyCode() == ReplyCodes.CANNOT_OPEN_DATA_CONNECTION ||
   *       getReplyCode() == ReplyCodes.CONNECTION_CLOSED_TRANSFER_ABORTED ||
   *       getReplyCode() == ReplyCodes.ACTION_ABORTED_LOCAL_ERROR ||
   *       getReplyCode() == 
   *         ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE_FILE_BUSY ||
   *       getReplyCode() == ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_COMMAND ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_PARAMETERS ||
   *       getReplyCode() == 
   *          ReplyCodes.SERVICE_NOT_AVAILABLE_CLOSING_CONTROL_CONNECTION ||
   *       getReplyCode() == ReplyCodes.NOT_LOGGED_IN
   */

  public void RETR(String pathname, boolean streaming) throws IOException
  {
    // RETR <SP> <pathname> <CRLF>
    // 125, 150
    // (110)
    // 226, 250
    // 425, 426, 451
    // 450, 550
    // 500, 501, 421, 530

    debugOutput.println(debugCategory, "Retrieving file '" + pathname + "' " +
                        (streaming ? "in" : "NOT in") + " streaming mode.");
    // Set up the channel to read the response to the LIST command.
    buildDataChannel();
    send("RETR " + pathname);
    receive();

    // If we hear back an non-positive reply we should shut down our data
    // channel, deal with it, and fail.
    if ((prefix != ReplyCodes.POSITIVE_PRELIMINARY) &&
        (prefix != ReplyCodes.POSITIVE_COMPLETION)) {
      closeDataChannel();
      FSM2();
      return;
    }
    
    // If we hear back that the transfer has started or is complete, we
    // should read the data.
    if ((prefix == ReplyCodes.POSITIVE_PRELIMINARY) ||
        (prefix == ReplyCodes.POSITIVE_COMPLETION)) {
      // dataInputStream and dataOutputStream are valid.
      if (streaming) {
        state = WAIT;
        return;
      }

      // Create a temporary file for the data.
      dataFile = File.createTempFile("kindftp", "dat");
      debugOutput.println(debugCategory, "Temporary file = '" + dataFile + "' ");

      // We have the channel and the place to write, so just receive the
      // data from the server and write it to the file.
      FileOutputStream fileOutputStream = new FileOutputStream(dataFile);
      assert.assert(fileOutputStream != null);
      
      byte [] buffer = new byte [1024];
      int available = 0, bytesRead = 0;
      debugOutput.println(debugCategory, "Ready to begin receiving data....");
      while (true) {
        // Only read in as much as we can hold.
        available = dataInputStream.available();
        if (available > 1024)
          available = 1024;
        // If nothing is available, try to read a byte to see if we are at
        // the EOS.

        // @review kiniry - Consider this algorithm; isn't it incorrect
        // because available might have been 0 when we checked but is now
        // not and thus this read will result in a missing byte in the
        // buffer?  If this is correct, we need to rewrite NLST and RETR as
        // well.
        if (available == 0)
          if (dataInputStream.read() == -1)
            break;
        bytesRead = dataInputStream.read(buffer, 0, available);
        if (bytesRead != -1)
          fileOutputStream.write(buffer, 0, bytesRead);
        else break;
      }
      fileOutputStream.close();
      closeDataChannel();
    }

    // Complete the command channel handshake.
    completeCommandHandshake();
  }

  /**
   * <p> This command causes the server-DTP to transfer a copy of the
   * file, specified in the path parameter, to the server- or user-DTP
   * at the other end of the data connection. The status and contents
   * of the file at the server site shall be unaffected. </p>
   *
   * <p> Note that this command will only work for retrieving
   * serialized Java objects from the server. </p>
   *
   * <p> See the other RETR() method for more information. </p>
   *
   * <p> After the successful completion of this method,
   * <code>getDataObject()</code> should be called to get the transferred
   * object. </p>
   *
   * @see #RETR
   * @param pathname the name of the file to retrieve.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre pathname != null
   */

  public void RETR(String pathname) throws IOException
  {
    // RETR <SP> <pathname> <CRLF>
    // 125, 150
    // (110)
    // 226, 250
    // 425, 426, 451
    // 450, 550
    // 500, 501, 421, 530

    ObjectInputStream stream = null;
    
    // Force the data connection to be in "image" mode since an object is
    // a binary datastream.
    TYPE('I');
    debugOutput.println(debugCategory, "Retrieving file '" + pathname + 
                        "' as a serialized Java object.");
    RETR(pathname, true);

    if ((prefix == ReplyCodes.POSITIVE_PRELIMINARY) ||
        (prefix == ReplyCodes.POSITIVE_COMPLETION)) {
      stream = new ObjectInputStream(getInputStream());
      dataObject = null;
      try {
        dataObject = stream.readObject();
      } catch (ClassNotFoundException e) {
        throw new IOException("Problem while attempting to retrieve '" +
                              pathname + " as a Java serialized object: " +
                              e.getMessage());
      }
      debugOutput.println(debugCategory, "Object received successfully.");
    } else {
      dataObject = null;
      state = FAILURE;
    }
    if (stream != null)
      stream.close();

    // Complete the command channel handshake.
    completeCommandHandshake();
  }


  /**
   * <p> Store a file to the server's current directory. </p>
   *
   * <p> This command causes the server-DTP to accept the data transferred
   * via the data connection and to store the data as a file at the server
   * site. If the file specified in the <code>pathname</code> exists at the
   * server site, then its contents shall be replaced by the data being
   * transferred. A new file is created at the server site if the file
   * specified in the <code>pathname</code> does not already exist. </p>
   *
   * <p> See the main <code>STOR</code> method for more information. </p>
   *
   * @see #STOR
   * @param pathname the path to the file on the server where the data
   * should be stored.  If <code>pathname</code> has a path component
   * (i.e. is not just a filename), the path must already exist.
   * @param file a reference to the file that contains the data that
   * is sent to the server if streaming is false.  file should be null
   * if streaming is true.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre pathname != null
   * @pre file != null
   */

  public void STOR(String pathname, File file) throws IOException
  {
    STOR(pathname, false, file);
  }

  /**
   * <p> Store an object to the server's current directory. </p>
   *
   * <p> This command causes the server-DTP to accept the data transferred
   * via the data connection and to store the data as a file at the server
   * site. If the file specified in the <code>pathname</code> exists at the
   * server site, then its contents shall be replaced by the data being
   * transferred. A new file is created at the server site if the file
   * specified in the <code>pathname</code> does not already exist. </p>
   *
   * <p> See the main <code>STOR</code> method for more information. </p>
   *
   * @see #STOR
   * @see #RETR
   * @param pathname the path to the file on the server where the data
   * should be stored.  If <code>pathname</code> has a path component
   * (i.e. is not just a filename), the path must already exist.
   * @param object a reference to a serializable object that is sent
   * to the server.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre pathname != null
   * @pre object != null
   * @pre object instanceof Serializable
   */

  public void STOR(String pathname, Object object) throws IOException  
  {
    // Force the data connection to be in "image" mode since an object is
    // a binary datastream.
    TYPE('I');
    debugOutput.println(debugCategory, "Sending object '" + object + 
                        " to server as file '" + pathname + "'.");
    STOR(pathname);

    // Stream the data to the server.
    ObjectOutputStream stream = new ObjectOutputStream(getOutputStream());
    stream.writeObject(object);
    stream.flush();
    // Close channels *before* completing STOR.
    stream.close();

    // Complete the command channel handshake.
    completeCommandHandshake();
  }

  /**
   * <p> Store a file to the server's current directory. </p>
   *
   * <p> This command causes the server-DTP to accept the data transferred
   * via the data connection and to store the data as a file at the server
   * site. If the file specified in the <code>pathname</code> exists at the
   * server site, then its contents shall be replaced by the data being
   * transferred. A new file is created at the server site if the file
   * specified in the <code>pathname</code> does not already exist. </p>
   *
   * <p> If the streaming parameter is <code>true</code>, the user-DTP is
   * expected to call <code>getOutputStream()</code> and handle sending the
   * data itself. </p>
   *
   * <p> See the main <code>STOR</code> method for more information. </p>
   *
   * @param pathname the path to the file on the server where the data
   * should be stored.  If <code>pathname</code> has a path component
   * (i.e. is not just a filename), the path must already exist.
   * @exception IOException is thrown if an I/O error occurs.
   * @see #STOR
   *
   * @pre pathname != null
   */

  public void STOR(String pathname) throws IOException  
  {
    STOR(pathname, true, null);
  }

  /**
   * <p> Store a file to the server's current directory. </p>
   *
   * <p> This command causes the server-DTP to accept the data transferred
   * via the data connection and to store the data as a file at the server
   * site.  If the file specified in the <code>pathname</code> parameter
   * exists at the server site, then its contents shall be replaced by the
   * data being transferred.  A new file is created at the server site if
   * the file specified in the <code>pathname</code> does not already
   * exist. </p>
   *
   * <p> If the streaming parameter is <code>true</code>, the user-DTP is
   * expected to call <code>getOutputStream()</code> and handle sending the
   * data itself.  In this case, the <code>file</code> and
   * <code>object</code> parameters are ignored. </p>
   *
   * <p> If streaming is <code>false</code> the <code>file</code> parameter
   * should point to a legitimate data file which should not change during
   * the data transfer. </p>
   *
   * <p> The user-DTP should close the stream when the transfer has
   * completed and <strong>must</strong>, whether or not the transfer is
   * successful, after the data has been (successfully or not) streamed,
   * call the <code>completeCommandHandshake()</code> method to complete
   * the command channel handshake for the transfer. </p>
   *
   * @param pathname the path to the file on the server where the data
   * should be stored.  If <code>pathname</code> has a path component
   * (i.e. is not just a filename), the path must already exist.
   * @param streaming a flag that, if <code>true</code>, indicates that the
   * client of <code>FTPProxy</code> will be streaming the data for the
   * file through the stream returned by <code>getOutputStream()</code>.
   * @param file a reference to the file that contains the data that is
   * sent to the server if streaming is <code>false.  <code>file</code>
   * should be <code>null</code> if <code>streaming</code> is
   * <code>true</code>.
   * @exception IOException is thrown if an I/O error occurs.
   * @see #completeCommandHandshake
   *
   * @pre pathname != null
   * @pre streaming == false implies file != null
   * @post getReplyCode() == 
   *         ReplyCodes.DATA_CONNECTION_ALREADY_OPEN_TRANFER_STARTING ||
   *       getReplyCode() == 
   *         ReplyCodes.FILE_STATUS_OK_ABOUT_TO_OPEN_DATA_CONNECTION ||
   *       getReplyCode() == ReplyCodes.RESTART_MARKER_REPLY ||
   *       getReplyCode() == 
   *         ReplyCodes.CLOSING_DATA_CONNECTION_AFTER_SUCCESSFUL_ACTION ||
   *       getReplyCode() == ReplyCodes.FILE_ACTION_OK_AND_COMPLETED ||
   *       getReplyCode() == ReplyCodes.CANNOT_OPEN_DATA_CONNECTION ||
   *       getReplyCode() == ReplyCodes.CONNECTION_CLOSED_TRANSFER_ABORTED ||
   *       getReplyCode() == ReplyCodes.ACTION_ABORTED_LOCAL_ERROR ||
   *       getReplyCode() == ReplyCodes.ACTION_ABORTED_PAGE_TYPE_UNKNOWN ||
   *       getReplyCode() == 
   *         ReplyCodes.ACTION_ABORTED_EXCEEDED_STORAGE_ALLOCATION ||
   *       getReplyCode() == ReplyCodes.NEED_ACCOUNT ||
   *       getReplyCode() == 
   *         ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE_FILE_BUSY ||
   *       getReplyCode() == 
   *          ReplyCodes.ACTION_NOT_TAKEN_INSUFFICIENT_STORAGE_SPACE ||
   *       getReplyCode() == ReplyCodes.ACTION_NOT_TAKEN_FILE_NAME_NOT_ALLOWED ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_COMMAND ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_PARAMETERS ||
   *       getReplyCode() == 
   *          ReplyCodes.SERVICE_NOT_AVAILABLE_CLOSING_CONTROL_CONNECTION ||
   *       getReplyCode() == ReplyCodes.NOT_LOGGED_IN
   */

  private void STOR(String pathname, boolean streaming, File file) 
    throws IOException
  {
    // STOR <SP> <pathname> <CRLF>
    // 125, 150
    // (110)
    // 226, 250
    // 425, 426, 451, 551, 552
    // 532, 450, 452, 553
    // 500, 501, 421, 530

    // This check of file is valid because implicatory precondition.
    if (file != null)
      debugOutput.println(debugCategory, "Sending file '" + file + 
                          "' as a file named '" + pathname + 
                          "' on the server NOT in streaming mode.");
    else
      debugOutput.println(debugCategory,
            "Sending data in streaming mode to be stored as a file name '" + 
            pathname + "'.");
    // Set up the channel to read the response to the LIST command.
    buildDataChannel();
    send("STOR " + pathname);
    receive();

    // Check that we are in a good state to deal with the transfer.
    if ((prefix != ReplyCodes.POSITIVE_PRELIMINARY) &&
        (prefix != ReplyCodes.POSITIVE_COMPLETION)) {
      closeDataChannel();
      FSM2();
      return;
    }
    if (streaming) {
      state = WAIT;
      return;
    }

    // dataInputStream and dataOutputStream are valid.
    // We have the channel and the place to write, so just read the data
    // file and stream the data to the server.
    FileInputStream fileInputStream = new FileInputStream(file);
    assert.assert(fileInputStream != null);

    byte [] buffer = new byte [1024];
    int available = 0, bytesRead = 0;
    debugOutput.println(debugCategory, "Ready to begin sending data....");
    while (true) {
      // Only read in as much as we can hold.
      available = fileInputStream.available();
      if (available > 1024)
        available = 1024;
      if (available == 0)
        if (fileInputStream.read() == -1)
          break;
      bytesRead = fileInputStream.read(buffer, 0, available);
      if (bytesRead != -1)
        dataOutputStream.write(buffer, 0, bytesRead);
      else break;
    }
    dataOutputStream.flush();
    fileInputStream.close();
    closeDataChannel();
    debugOutput.println(debugCategory, "Closed all channels.");

    // Complete the command channel handshake.
    completeCommandHandshake();
  }

  /**
   * <p> This command behaves like STOR except that the resultant file
   * is to be created in the current directory under a name unique to
   * that directory. </p>
   *
   * <p> This action is currently not supported by this client nor by
   * any FTP servers that the author has tested. </p>
   *
   * @todo Find a server that supports this command so that we can
   * implement and test this method.
   * @todo Finish specification of method including the meaning of reply
   * codes and postcondition.
   *
   * @exception IOException is thrown if an I/O error occurs.
   */

  public void STOU() throws IOException
  {
    // STOU <CRLF>
    // 125, 150
    // (110)
    // 226, 250
    // 425, 426, 451, 551, 552
    // 532, 450, 452, 553
    // 500, 501, 421, 530

    assert.assert(false, "Method not implemented.");
  }

  /**
   * <p> This command causes the server-DTP to accept the data transferred
   * via the data connection and to store the data in a file at the server
   * site. If the file specified in the <code>pathname</code> parameter
   * exists at the server site, then the data shall be appended to that
   * file; otherwise the file specified shall be created at the server
   * site. </p>
   *
   * <p> Note that many FTP servers do not support the APPE operation. </p>
   *
   * @todo Finish specification of method including the meaning of reply
   * codes and postcondition.
   * @todo Implement method.
   *
   * @param pathname the path to the file on the server where the data
   * should be stored.  If this parameter has a path component (i.e. is not
   * just a filename), the path must already exist.
   * @param streaming a flag that, if true, indicates that the client
   * of FTPProxy will be streaming the data for the file through the
   * stream returned by getOutputStream().
   * @param file a reference to the file that contains the data that
   * is sent to the server if streaming is false.  file should be null
   * if streaming is true.
   * @exception IOException is thrown if an I/O error occurs.
   */

  public void APPE(String pathname, boolean streaming, File file) 
    throws IOException
  {
    // APPE <SP> <pathname> <CRLF>
    // 125, 150
    // (110)
    // 226, 250
    // 425, 426, 451, 551, 552
    // 532, 450, 550, 452, 553
    // 500, 501, 502, 421, 530

    assert.assert(false, "Method not implemented.");
  }
  
  /**
   * <p> This command may be required by some servers to reserve sufficient
   * storage to accommodate the new file to be transferred. This command
   * shall be followed by a STORe or APPEnd command. The ALLO command
   * should be treated as a NOOP (no operation) by those servers which do
   * not require that the maximum size of the file be declared before a
   * send, and those servers interested in only the maximum record or page
   * size should accept a dummy value in the first argument and ignore
   * it. </p>
   *
   * <p> Note that many servers today do not support the ALLO command. </p>
   *
   * <p> A reply code of <code>ReplyCodes.COMMAND_OK</code> or
   * <code>ReplyCodes.COMMAND_NOT_IMPLEMENTED_SUPERFLUOUS</code> means the
   * command succeeded or was superfluous respectively.  Anything else
   * indicates some other failure; see the specific code for more
   * information. </p>
   *
   * @param reservation_size the number of bytes (using the logical
   * byte size) of storage to be reserved for the file.
   * @param record_size a maximum record or page size (in logical
   * bytes) for files sent with record or page structure.  A record
   * size of 0 means that record size will not be specified in the
   * issued ALLO command.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre reservation_size >= 0 && record_size >= 0
   * @post getReplyCode() == ReplyCodes.COMMAND_OK ||
   *       getReplyCode() == ReplyCodes.COMMAND_NOT_IMPLEMENTED_SUPERFLUOUS ||
   *       ReplyCodes.isStandardError_500_501_504_421_530(getReplyCode())
   */

  public void ALLO(long reservation_size, long record_size) 
    throws IOException
  {
    // ALLO <SP> <decimal-integer> [<SP> R <SP> <decimal-integer>] <CRLF>
    // 200
    // 202
    // 500, 501, 504, 421, 530

    if (record_size > 0)
      send("ALLO " + reservation_size + " R " + record_size);
    else
      send("ALLO " + reservation_size);
    receive();
    FSM1();
  }

  /**
   * <p> Prepare for a restarted data transfer.  This command does not
   * cause file transfer but skips over the file to the specified data
   * checkpoint. This command shall be immediately followed by the
   * appropriate FTP service command which shall cause file transfer
   * to resume. </p>
   *
   * @param marker the server marker at which file transfer is to be
   * restarted.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @todo Implement this method.
   * @todo Write specification of RETR.
   */

  public void REST(byte [] marker) throws IOException
  {
    // REST <SP> <marker> <CRLF>
    // 500, 501, 502, 421, 530
    // 350

    assert.assert(false, "Method not implemented.");
  }

  /**
   * <p> This command specifies the old path of the file which is to be
   * renamed. This command must be immediately followed by a "rename to"
   * (RNTO) command specifying the new file pathname. </p>
   *
   * <p> A reply code of
   * <code>ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE_FILE_BUSY</code> or
   * <code>ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE</code> means the
   * command did not succeed because the file is either (possible)
   * temporarily or permanently unavailable for this operation.  A code of
   * <code>ReplyCodes.REQUESTED_ACTION_PENDING_MORE_INFO</code> indicates
   * that the command succeeded and is server is waiting for the
   * <code>RFTO</code> command that should immediately follow.  Any other
   * code indicates some other failure; see the specific code for more
   * information. </p>
   *
   * @param pathname the old path of the file which is to be renamed.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre pathname != null
   * @post getReplyCode() == 
   *         ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE_FILE_BUSY ||
   *       getReplyCode() == 
   *         ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE ||
   *       ReplyCodes.isStandardError_500_501_502_421_530(getReplyCode()) ||
   *       getReplyCode() == ReplyCodes.REQUESTED_ACTION_PENDING_MORE_INFO
   */

  public void RNFR(String pathname) throws IOException
  {
    // RNFR <SP> <pathname> <CRLF>
    // 450, 550
    // 500, 501, 502, 421, 530
    // 350

    send("RNFR " + pathname);
    receive();
    if (getPrefix() == ReplyCodes.POSITIVE_INTERMEDIATE)
      state = WAIT;
    else if ((getPrefix() == ReplyCodes.POSITIVE_PRELIMINARY) ||
        (getPrefix() == ReplyCodes.POSITIVE_COMPLETION))
      state = ERROR;
    else
      state = FAILURE;
  }
  
  /**
   * <p> This command specifies the new pathname of the file specified
   * in the immediately preceding "rename from" command. Together the
   * two commands cause a file to be renamed. </p>
   *
   * <p> A reply code of
   * <code>ReplyCodes.FILE_ACTION_OK_AND_COMPLETED</code> indicates that
   * the command succeeded.  A code of <code>ReplyCodes.NEED_ACCOUNT</code>
   * indicates that an account needs to be specified with the
   * <code>ACCT</code> command before this rename can complete.  A code of
   * <code>ReplyCodes.ACTION_NOT_TAKEN_FILE_NAME_NOT_ALLOWED</code>
   * indicates that the filename is not a legal filename on the server.
   * Any other code indicates some other failure; see the specific code for
   * more information. </p>
   *
   * @param pathname the new pathname of the file specified in the
   * immediately preceding "rename from" (RNFR) command.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre pathname != null
   * @post getReplyCode() == ReplyCodes.FILE_ACTION_OK_AND_COMPLETED ||
   *       getReplyCode() == ReplyCodes.NEED_ACCOUNT ||
   *       getReplyCode() == ReplyCodes.ACTION_NOT_TAKEN_FILE_NAME_NOT_ALLOWED ||
   *       ReplyCodes.isStandardError_500_501_502_421_530(getReplyCode()) ||
   *       getReplyCode() == ReplyCodes.BAD_SEQUENCE_OF_COMMANDS
   */

  public void RNTO(String pathname) throws IOException
  {
    // RNTO <SP> <pathname> <CRLF>
    // 250
    // 532, 553
    // 500, 501, 502, 503, 421, 530

    send("RNTO " + pathname);
    receive();
    if ((getPrefix() == ReplyCodes.POSITIVE_PRELIMINARY) ||
        (getPrefix() == ReplyCodes.POSITIVE_INTERMEDIATE))
      state = ERROR;
    else if (getPrefix() == ReplyCodes.POSITIVE_COMPLETION)
      state = SUCCESS;
    else
      state = FAILURE;
  }

  /**
   * <p> This command tells the server to abort the previous FTP
   * service command and any associated transfer of data. The abort
   * command may require "special action", as discussed in the Section
   * on FTP Commands (in RFC 959), to force recognition by the
   * server. No action is to be taken if the previous command has been
   * completed (including data transfer). The control connection is
   * not to be closed by the server, but the data connection must be
   * closed. </p>
   *
   * <p> There are two cases for the server upon receipt of this
   * command: (1) the FTP service command was already completed, or
   * (2) the FTP service command is still in progress. </p>
   *
   * <p> A reply code of
   * <code>ReplyCodes.DATA_CONNECTION_OPEN_NO_TRANSFER_IN_PROGRESS</code>
   * or
   * <code>ReplyCodes.CLOSING_DATA_CONNECTION_AFTER_SUCCESSFUL_ACTION</code> 
   * means the command succeeded.  Anything else indicates some other
   * failure; see the specific code for more information. </p>
   *
   * @todo Write several test cases for this method.  Are we required to
   * take some action on the datastream (e.g., closing it)?
   *
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @post getReplyCode() ==
   *         ReplyCodes.DATA_CONNECTION_OPEN_NO_TRANSFER_IN_PROGRESS ||
   *       getReplyCode() ==
   *         ReplyCodes.CLOSING_DATA_CONNECTION_AFTER_SUCCESSFUL_ACTION ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_COMMAND ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_PARAMETERS ||
   *       getReplyCode() == ReplyCodes.COMMAND_NOT_IMPLEMENTED ||
   *       getReplyCode() == 
   *         ReplyCodes.SERVICE_NOT_AVAILABLE_CLOSING_CONTROL_CONNECTION
   */

  public void ABOR() throws IOException
  {
    // ABOR <CRLF>
    // 225, 226
    // 500, 501, 502, 421

    send("ABOR");
    receive();
    FSM1();
  }
  
  /**
   * <p> This command causes the file specified in the
   * <code>pathname</code> parameter to be deleted at the server site. If
   * an extra level of protection is desired (such as the query, "Do you
   * really wish to delete?"), it should be provided by the user-FTP
   * process. </p>
   *
   * <p> <strong>WARNING:</strong> Most FTP servers do <em>not</em> support
   * deletes of non-empty directories and the FTP protocol specification
   * mentions nothing with respect to these delete semantics.  Thus, this
   * method could automatically delete whole subtrees, regardless of
   * content.  Use this method wisely... </p>
   *
   * <p> A reply code of
   * <code>ReplyCodes.FILE_ACTION_OK_AND_COMPLETED</code> means the command
   * succeeded.  A code of
   * <code>ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE_FILE_BUSY</code>
   * means that the file was busy and the client can retry later if they
   * desire.  A code of
   * <code>ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE</code> means that
   * the file is unavailable for other reasons (file not found,
   * insufficient permissions, etc.).  Anything else indicates some other
   * failure; see the specific code for more information. </p>
   *
   * @param pathname the path to be deleted at the server site.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre pathname != null
   * @post getReplyCode() == ReplyCodes.FILE_ACTION_OK_AND_COMPLETED ||
   *       getReplyCode() == 
   *         ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE_FILE_BUSY ||
   *       getReplyCode() == ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_COMMAND ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_PARAMETERS ||
   *       getReplyCode() == ReplyCodes.COMMAND_NOT_IMPLEMENTED ||
   *       getReplyCode() == 
   *         ReplyCodes.SERVICE_NOT_AVAILABLE_CLOSING_CONTROL_CONNECTION ||
   *       getReplyCode() == ReplyCodes.NOT_LOGGED_IN
   */

  public void DELE(String pathname) throws IOException
  {
    // DELE <SP> <pathname> <CRLF>
    // 250
    // 450, 550
    // 500, 501, 502, 421, 530

    send("DELE " + pathname);
    receive();
    FSM1();
  }

  /**
   * <p> This command causes the directory specified in the
   * <code>pathname</code> parameter to be removed as a directory (if the
   * path is absolute) or as a subdirectory of the current working
   * directory (if the path is relative). See Appendix II. </p>
   *
   * <p> A reply code of
   * <code>ReplyCodes.FILE_ACTION_OK_AND_COMPLETED</code> means the command
   * succeeded (perhaps because it was unnecessary in the latter case).
   * Anything else indicates some other failure; see the specific code for
   * more information. </p>
   *
   * @param pathname the path to be removed.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre pathname != null
   * @post getReplyCode() == ReplyCodes.FILE_ACTION_OK_AND_COMPLETED ||
   *       ReplyCodes.isStandardError_500_501_502_421_530(getReplyCode()) ||
   *       getReplyCode() == ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE
   */

  public void RMD(String pathname) throws IOException
  {
    // RMD <SP> <pathname> <CRLF>
    // 250
    // 500, 501, 502, 421, 530, 550

    send("RMD " + pathname);
    receive();
    FSM1();
  }
  
  /**
   * <p> This command causes the directory specified in the
   * <code>pathname</code> parameter to be created as a directory (if the
   * path is absolute) or as a subdirectory of the current working
   * directory (if the the path is relative). See Appendix II of RFC 959
   * for more information. </p>
   *
   * <p> A reply code of <code>ReplyCodes.DIRECTORY_CREATED</code> means
   * the command succeeded.  Anything else indicates some other failure;
   * see the specific code for more information. </p>
   *
   * @param pathname the path to be created.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre pathname != null
   * @post getReplyCode() == ReplyCodes.DIRECTORY_CREATED ||
   *       ReplyCodes.isStandardError_500_501_502_421_530(getReplyCode()) ||
   *       getReplyCode() == ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE
   */

  public void MKD(String pathname) throws IOException
  {
    // MKD <SP> <pathname> <CRLF>
    // 257
    // 500, 501, 502, 421, 530, 550

    send("MKD " + pathname);
    receive();
    FSM1();
  }

  /**
   * <p> This command causes the name of the current working directory
   * to be returned in the reply. See Appendix II of RFC 959 for more
   * details. </p>
   *
   * <p> A reply code of <code>ReplyCodes.DIRECTORY_CREATED</code> means
   * the command succeeded.  Anything else indicates some other failure;
   * see the specific code for more information. </p>
   *
   * <p> If this command succeeds, then the current directory can be
   * obtained by calling <code>getLastResponse()</code>. </p>
   *
   * @todo Check on this specification.  In particular, what the heck does
   * DIRECTORY_CREATED have to do with PWD?  This is how RFC959 documents
   * the command, so I'll have to cross-check with some servers.
   *
   * @exception IOException is thrown if an I/O error occurs.
   */

  public void PWD() throws IOException
  {
    // PWD <CRLF>
    // 257
    // 500, 501, 502, 421, 550

    send("PWD");
    receive();
    FSM1();
  }
  
  /** 
   * <p> This command causes a list to be sent from the server to the
   * passive DTP. If the <code>pathname</code> parameter specifies a
   * directory or other group of files, the server should transfer a list
   * of files in the specified directory. If it specifies a file then the
   * server should send current information on the file. A null argument
   * implies the user's current working or default directory. The data
   * transfer is over the data connection in type ASCII or type EBCDIC
   * (though this implementation only supports type ASCII).  The user must
   * ensure that the TYPE is appropriately ASCII or EBCDIC. Since the
   * information on a file may vary widely from system to system, this
   * information may be hard to use automatically in a program, but may be
   * quite useful to a human user. </p>
   *
   * <p> A reply code of
   * <code>ReplyCodes.DATA_CONNECTION_ALREADY_OPEN_TRANFER_STARTING</code>
   * or
   * <code>ReplyCodes.FILE_STATUS_OK_ABOUT_TO_OPEN_DATA_CONNECTION</code>
   * means that the command was accepted the data is about to arrive over
   * the data connection.  A code of
   * <code>ReplyCodes.CLOSING_DATA_CONNECTION_AFTER_SUCCESSFUL_ACTION</code>
   * or <code>ReplyCodes.FILE_ACTION_OK_AND_COMPLETED</code> indicates that
   * the data has been transferred successfully.  Anything else indicates a
   * failure of some kind; see the specific code for more information. </p>
   *
   * <p> After a successful LIST the listing is available via
   * <code>getLastResponse()</code>. </p>
   *
   * @param pathname the path to list.  A <code>null</code> implies the
   * current working directory.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @post getReplyCode() == 
   *         ReplyCodes.DATA_CONNECTION_ALREADY_OPEN_TRANFER_STARTING ||
   *       getReplyCode() == 
   *         ReplyCodes.FILE_STATUS_OK_ABOUT_TO_OPEN_DATA_CONNECTION ||
   *       getReplyCode() == 
   *         ReplyCodes.CLOSING_DATA_CONNECTION_AFTER_SUCCESSFUL_ACTION ||
   *       getReplyCode() == ReplyCodes.FILE_ACTION_OK_AND_COMPLETED ||
   *       getReplyCode() == ReplyCodes.CANNOT_OPEN_DATA_CONNECTION ||
   *       getReplyCode() == ReplyCodes.CONNECTION_CLOSED_TRANSFER_ABORTED ||
   *       getReplyCode() == ReplyCodes.ACTION_ABORTED_LOCAL_ERROR  ||
   *       ReplyCodes.isStandardError_500_501_502_421_530(getReplyCode())
   */
  
  public void LIST(String pathname) throws IOException
  {
    // LIST [<SP> <pathname>] <CRLF>
    // 125, 150
    // 226, 250
    // 425, 426, 451
    // 450
    // 500, 501, 502, 421, 530
    
    StringBuffer result = null;
    // Set up the channel to read the response to the LIST command.
    buildDataChannel();
    if (pathname == null)
      send("LIST");
    else
      send("LIST " + pathname);
    receive();
    
    // By RFC959, "at most one 100 series reply is allowed per command".
    // Thus, if we have our 100 series reply now, we are done and we can
    // continue.  Otherwise, we have an error of some kind and the FSM2
    // should set the state properly.
    if (prefix != ReplyCodes.POSITIVE_PRELIMINARY) {
      closeDataChannel();
      FSM2();
      return;
    } else {
      // dataInputStream and dataOutputStream are valid.
      result = new StringBuffer();
      byte [] buffer = new byte [1024];
      int available = 0, bytesRead = 0;
      while (true) {
        // Only read in as much as we can hold.
        available = dataInputStream.available();
        debugOutput.println(debugCategory, available + " bytes available.");
        if (available > 1024)
          available = 1024;
        // If nothing is available, try to read a byte to see if we are at
        // the EOS.

        // @review kiniry - Consider this algorithm; isn't it incorrect
        // because available might have been 0 when we checked but is now
        // not and thus this read will result in a missing byte in the
        // buffer?  If this is correct, we need to rewrite NLST and RETR as
        // well.
        if (available == 0)
          if (dataInputStream.read() == -1)
            break;
        bytesRead = dataInputStream.read(buffer, 0, available);
        debugOutput.println(debugCategory, bytesRead + " bytes read.");
        if (bytesRead != -1)
          result.append(new String(buffer, 0, bytesRead));
        else break;
      }
    }
    closeDataChannel();
    
    // Complete the command channel handshake.
    completeCommandHandshake();
  }

  /**
   * <p> This command causes a directory listing to be sent from server to
   * user site. The <code>pathname</code> parameter should specify a
   * directory or other system-specific file group descriptor; a null
   * argument implies the current directory. The server will return a
   * stream of names of files and no other information. The data will be
   * transferred in ASCII or EBCDIC type over the data connection as valid
   * pathname strings separated by <CRLF> or <NL>. (Again the user must
   * ensure that the TYPE is correct.) This command is intended to return
   * information that can be used by a program to further process the files
   * automatically. For example, in the implementation of a "multiple get"
   * function. </p>
   *
   * <p> A reply code of
   * <code>ReplyCodes.DATA_CONNECTION_ALREADY_OPEN_TRANFER_STARTING</code>
   * or
   * <code>ReplyCodes.FILE_STATUS_OK_ABOUT_TO_OPEN_DATA_CONNECTION</code>
   * means that the command was accepted the data is about to arrive over
   * the data connection.  A code of
   * <code>ReplyCodes.CLOSING_DATA_CONNECTION_AFTER_SUCCESSFUL_ACTION</code>
   * or <code>ReplyCodes.FILE_ACTION_OK_AND_COMPLETED</code> indicates that
   * the data has been transferred successfully.  Anything else indicates a
   * failure of some kind; see the specific code for more information. </p>
   *
   * <p> After a successful LIST the listing is available via
   * <code>getLastResponse()</code>. </p>
   *
   * @param pathname the path to list.  A null implies the current
   * working directory.
   * @exception IOException is thrown if an I/O error occurs.
   * @post getReplyCode() == 
   *         ReplyCodes.DATA_CONNECTION_ALREADY_OPEN_TRANFER_STARTING ||
   *       getReplyCode() == 
   *         ReplyCodes.FILE_STATUS_OK_ABOUT_TO_OPEN_DATA_CONNECTION ||
   *       getReplyCode() == 
   *         ReplyCodes.CLOSING_DATA_CONNECTION_AFTER_SUCCESSFUL_ACTION ||
   *       getReplyCode() == ReplyCodes.FILE_ACTION_OK_AND_COMPLETED ||
   *       getReplyCode() == ReplyCodes.CANNOT_OPEN_DATA_CONNECTION ||
   *       getReplyCode() == ReplyCodes.CONNECTION_CLOSED_TRANSFER_ABORTED ||
   *       getReplyCode() == ReplyCodes.ACTION_ABORTED_LOCAL_ERROR  ||
   *       ReplyCodes.isStandardError_500_501_502_421_530(getReplyCode())
   */
  
  public void NLST(String pathname) throws IOException
  {
    // NLST [<SP> <pathname>] <CRLF>
    // 125, 150
    // 226, 250
    // 425, 426, 451
    // 450
    // 500, 501, 502, 421, 530

    StringBuffer result = null;
    // Set up the channel to read the response to the NLST command.
    buildDataChannel();
    if (pathname == null)
      send("NLST");
    else
      send("NLST " + pathname);
    receive();
    
    // By RFC959, "at most one 100 series reply is allowed per command".
    // Thus, if we have our 100 series reply now, we are done and we can
    // continue.  Otherwise, we have an error of some kind and the FSM2
    // should set the state properly.
    if (prefix != ReplyCodes.POSITIVE_PRELIMINARY) {
      closeDataChannel();
      FSM2();
      return;
    } else {
      // dataInputStream and dataOutputStream are valid.
      // Read all the data into a StringBuffer.
      result = new StringBuffer();
      byte [] buffer = new byte [1024];
      int available = 0, bytesRead = 0;
      while (true) {
        // Only read in as much as we can hold.
        available = dataInputStream.available();
        debugOutput.println(debugCategory, available + " bytes available.");
        if (available > 1024)
          available = 1024;
        // If nothing is available, try to read a byte to see if we are at
        // the EOS.

        // @review kiniry - Consider this algorithm; isn't it incorrect
        // because available might have been 0 when we checked but is now
        // not and thus this read will result in a missing byte in the
        // buffer?  If this is correct, we need to rewrite NLST and RETR as
        // well.
        if (available == 0)
          if (dataInputStream.read() == -1)
            break;
        bytesRead = dataInputStream.read(buffer, 0, available);
        debugOutput.println(debugCategory, bytesRead + " bytes read.");
        if (bytesRead != -1)
          result.append(new String(buffer, 0, bytesRead));
        else break;
      }
    }
    closeDataChannel();

    // Complete the command channel handshake.
    completeCommandHandshake();
  }
  
  /**
   * <p> This command is used by the server to provide services specific to
   * his system that are essential to file transfer but not sufficiently
   * universal to be included as commands in the protocol. The nature of
   * these services and the specification of their syntax can be stated in
   * a reply to the HELP SITE command. </p>
   *
   * <p> A reply code of <code>ReplyCodes.COMMAND_OK</code> or
   * <code>ReplyCodes.COMMAND_NOT_IMPLEMENTED_SUPERFLUOUS</code> means the
   * command succeeded (perhaps because it was unnecessary in the latter
   * case).  Anything else indicates some other failure; see the specific
   * code for more information. </p>
   *
   * @param site_parameters the system-specific service specification.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre site_parameters != null
   * @post getReplyCode() == ReplyCodes.COMMAND_OK ||
   *       getReplyCode() == ReplyCodes.COMMAND_NOT_IMPLEMENTED_SUPERFLUOUS ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_COMMAND ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_PARAMETERS ||
   *       getReplyCode() == ReplyCodes.NOT_LOGGED_IN
   */

  public void SITE(String site_parameters) throws IOException
  {
    // SITE <SP> <string> <CRLF>
    // 200
    // 202
    // 500, 501, 530

    send("SITE " + site_parameters);
    receive();
    FSM1();
  }
  
  /**
   * <p> This command is used to find out the type of operating system
   * at the server. </p>
   *
   * <p> A reply code of <code>ReplyCodes.SYSTEM_TYPE</code> means that the
   * command succeeded, thus the server system type can be obtained by
   * calling getSystemType().  Anything else indicates a failure; see the
   * specific code for more information. </p>
   *
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @post getReplyCode() == ReplyCodes.SYSTEM_TYPE ||
   *       ReplyCodes.isStandardError_500_501_502_421(getReplyCode())
   */

  public void SYST() throws IOException
  {
    // SYST <CRLF>
    // 215
    // 500, 501, 502, 421

    send("SYST");
    receive();
    if (replyCode == ReplyCodes.SYSTEM_TYPE)
      systemType = replyMessage(response);
    FSM1();
  }
  
  /**
   * <p> This command shall cause a status response to be sent over
   * the control connection in the form of a reply. The command may be
   * sent during a file transfer (along with the Telnet IP and Synch
   * signals--see the Section on FTP Commands in RFC 959) in which
   * case the server will respond with the status of the operation in
   * progress, or it may be sent between file transfers. </p>
   *
   * <p> In the latter case, the command may have an argument field. If the
   * argument is a path, the command is analogous to the "list" command
   * except that data shall be transferred over the control connection. If
   * a partial path is given, the server may respond with a list of file
   * names or attributes associated with that specification. If no argument
   * is given, the server should return general status information about
   * the server FTP process. This should include current values of all
   * transfer parameters and the status of connections. </p>
   *
   * <p> A reply code of <code>ReplyCodes.STATUS_OR_HELP_REPLY</code> or
   * <code>ReplyCodes.DIRECTORY_STATUS</code> or
   * <code>ReplyCodes.FILE_STATUS</code> means that the command succeeded
   * (perhaps because it was unnecessary in the former case).  Anything
   * else indicates some other failure; see the specific code for more
   * information. </p>
   *
   * <p> If this command succeeds, <code>getLastResponse()</code> contains
   * a appropriate status message from the server.  If
   * <code>pathname</code> is non-null, an <tt>"ls -l"</tt>-like listing
   * will be returned instead. </p>
   *
   * @param pathname an optional path on which to get a status.  If
   * path is <code>null</code>, a general server status is checked.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @post getReplyCode() == ReplyCodes.STATUS_OR_HELP_REPLY ||
   *       getReplyCode() == ReplyCodes.DIRECTORY_STATUS ||
   *       getReplyCode() == ReplyCodes.FILE_STATUS ||
   *       getReplyCode() == 
   *         ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE_FILE_BUSY ||
   *       ReplyCodes.isStandardError_500_501_502_421_530(getReplyCode()) ||
   *       getReplyCode() == ReplyCodes.NOT_LOGGED_IN
   */

  public void STAT(String pathname) throws IOException
  {
    // STAT [<SP> <pathname>] <CRLF>
    // 211, 212, 213
    // 450
    // 500, 501, 502, 421, 530

    if (pathname == null)
      send("STAT");
    else
      send("STAT " + pathname);
    receive();
    FSM1();
  }
  
  /**
   * <p> This command shall cause the server to send helpful
   * information regarding its implementation status over the control
   * connection to the user. The command may take an argument (e.g.,
   * any command name) and return more specific information as a
   * response.  On most servers, the HELP command is allowed before
   * entering a USER command. The server may use this reply to specify
   * site-dependent parameters, e.g., in response to HELP SITE. </p>
   *
   * <p> A reply code of <code>ReplyCodes.STATUS_OR_HELP_REPLY</code> or
   * <code>ReplyCodes.HELP_MESSAGE</code> means the command succeeded.
   * Anything else indicates some other failure; see the specific code for
   * more information. </p>
   *
   * @param command the (optional) command to ask for help on.  A null
   * indicates that general server help is requested.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre command != null
   * @post getReplyCode() == ReplyCodes.STATUS_OR_HELP_REPLY ||
   *       getReplyCode() == ReplyCodes.HELP_MESSAGE ||
   *       ReplyCodes.isStandardError_500_501_502_421(getReplyCode())
   */

  public void HELP(String command) throws IOException
  {
    // HELP [<SP> <string>] <CRLF>
    // 211, 214
    // 500, 501, 502, 421

    if (command == null)
      send("HELP");
    else
      send("HELP " + command);
    receive();
    FSM1();
  }
  
  /**
   * <p> This command does not affect any parameters or previously
   * entered commands. It specifies no action other than that the
   * server send an OK reply. </p>
   *
   * <p> A reply code of <code>ReplyCodes.COMMAND_OK</code> means the
   * command succeeded.  Anything else indicates some other failure; see
   * the specific code for more information. </p>
   *
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @post getReplyCode() == ReplyCodes.COMMAND_OK ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_COMMAND ||
   *       getReplyCode() == 
   *         ReplyCodes.SERVICE_NOT_AVAILABLE_CLOSING_CONTROL_CONNECTION
   */

  public void NOOP() throws IOException
  {
    // NOOP <CRLF>
    // 200
    // 500, 421

    send("NOOP");
    receive();
    FSM1();
  }

  /**
   * <p> Return the last modification time for a file specified by the
   * <code>pathname</code> parameter.  If the modification time cannot be
   * determined, a <code>null</code> will be returned. </p>
   *
   * <p> A reply code of <code>ReplyCodes.FILE_STATUS</code> indicates the
   * file exists, can be read, and the server determined the last
   * modification time, thus it is the return value of this method.  A code
   * of <code>ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE</code> means
   * that the file wasn't available for some reason (it didn't exist, it
   * was unreadable, etc.).  Anything else indicates a failure of some
   * kind; see the specific code for more information. </p>
   *
   * @param pathname the path to the file to check.
   * @return a Date representing the last modification time of the
   * file, or a null.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre pathname != null
   * @post getReplyCode() == ReplyCodes.FILE_STATUS ||
   *       getReplyCode() == ReplyCodes.SYNTAX_ERROR_IN_COMMAND ||
   *       getReplyCode() == ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE
   */

  public Date MDTM(String pathname) throws IOException
  {
    // MDTM <pathname> <CRLF>
    // 213
    // 500 550

    Date Result = null;
    send("MDTM " + pathname);
    receive();

    debugOutput.println(debugCategory, "MDTM response: '" + response + "'");
    if (getReplyCode() == ReplyCodes.FILE_STATUS) {
      int year = Integer.parseInt(response.substring(0,4));
      int month = Integer.parseInt(response.substring(4,6));
      int day = Integer.parseInt(response.substring(6,8));
      int hourUTC = Integer.parseInt(response.substring(8,10));
      int minuteUTC = Integer.parseInt(response.substring(10,12));
      int secondUTC = Integer.parseInt(response.substring(12,14));
      TimeZone UTCtimezone = TimeZone.getTimeZone("UTC");
      Calendar calendar = new GregorianCalendar(UTCtimezone);
      calendar.set(year, month - 1, day, hourUTC, minuteUTC, secondUTC);
      Result = calendar.getTime();
    } else Result = null;

    return Result;
  }


  /**
   * <p> Returns the size of a file, in bytes.  If the size cannot be
   * determined, a -1 will be returned. </p>
   *
   * @param pathname the path to the file to size.
   * @return the size of of the file, in bytes.  A -1 is returned if
   * the size cannot be determined.
   * @exception IOException is thrown if an I/O error occurs.
   *
   * @pre pathname != null
   * @post return >= 0
   * @post getReplyCode() == ReplyCodes.FILE_STATUS ||
   *       getReplyCode() == ReplyCodes.ACTION_NOT_TAKEN_FILE_UNAVAILABLE
   */

  public long SIZE(String pathname) throws IOException
  {
    // SIZE <pathname> <CRLF>
    // 213
    // 550

    long Result;
    
    send("SIZE " + pathname);
    receive();
    
    if (getReplyCode() == ReplyCodes.FILE_STATUS) {
      Result = Long.parseLong(response);
    } else Result = -1;

    return Result;
  }

  // ============================================================
  // End of FTP commands
  // ============================================================

  /**
   * <p> Completes the command channel handshake after a streaming RETR
   * attempt, whether the transfer is successful or not. </p>
   *
   * @exception IOException is thrown if an I/O error occurs.
   */

  public void completeCommandHandshake() throws IOException
  {
    // Read the final command channel results of the data transfer.
    while (true) {
      if (commandInputStream.ready()) {
        debugOutput.println(debugCategory, "Reading from command channel.");
        receive();
        FSM2();
        return;
      } else try {
        Thread.currentThread().sleep(10);
        debugOutput.println(debugCategory, 
                            "Command channel wasn't ready; waiting...");
      } catch (InterruptedException ie) {
        // empty
      }
    }
  }
  
  /**
   * <p> This method allows the user-DTP to obtain the server data
   * input stream when a legitimate channel to the server exists.
   * Such a channel is normally only valid just after a streaming RETR
   * command. </p>
   *
   * @return the data input stream from the server.
   * @exception IOException is thrown if an I/O error occurs.
   */

  public BufferedInputStream getInputStream() throws IOException
  {
    return dataInputStream;
  }

  /**
   * <p> This method allows the user-DTP to obtain the server data
   * output stream when a legitimate channel to the server exists.
   * Such a channel is normally only valid just after a streaming STOR
   * command. </p>
   *
   * @return the data output stream to the server.
   * @exception IOException is thrown if an I/O error occurs.
   */

  public BufferedOutputStream getOutputStream() throws IOException
  {
    return dataOutputStream;
  }

  /**
   * <p> This method returns a reference to a file containing the data
   * that has been received from the server after a successful
   * completion of the RETR command in non-streaming mode.  This is
   * the only time this method can be called.  This file is typically
   * stored in a cache private to this class and should not be
   * deleted, manipulated, or mangled in any way.  The user-DTP should
   * deal with the file (e.g. copy it, etc.) before issuing another
   * command to the server. </p>
   *
   * @return a reference to a file retrieved from the server.  
   * @exception IOException is thrown if an I/O error occurs.
   */

  public File getDataFile() throws IOException
  {
    return dataFile;
  }

  /**
   * <p> This method returns a reference to an <code>Object</code>
   * containing the data that has been received from the server after a
   * successful completion of the RETR command in non-streaming mode.  This
   * is the only time this method can be called. </p>
   *
   * @return a reference to an object retrieved from the server.  
   * @exception IOException is thrown if an I/O error occurs.
   */

  public Object getDataObject() throws IOException
  {
    return dataObject;
  }

  // Private Methods

  /**
   * <p> Send a single message to the server via the command stream. </p>
   *
   * @param message the String to send to the server <em>without</em>
   * <tt>\n</tt> already attached.
   * @exception IOException is thrown if an I/O error occurs.
   */

  private synchronized void send(String message) 
    throws IOException
  {
    debugOutput.println(debugCategory, "Sending '" + message + "'.");
    commandOutputStream.write(message + "\n", 0, message.length() + 1);
    commandOutputStream.flush();
  }

  /**
   * <p> Receive a single message to the server via the command
   * stream. </p>
   *
   * <p> Servers can send multi-line replies.  The format for multi-line
   * replies is that the first line will begin with the exact required
   * reply code, followed immediately by a Hyphen, "-" (also known as
   * Minus), followed by text. The last line will begin with the same code,
   * followed immediately by Space <SP>, optionally some text, and the
   * Telnet end-of-line code [RFC959]. </p>
   *
   * @exception IOException is thrown if an I/O error occurs.
   * @exception InterruptedIOException is thrown if the command socket
   * times out on a read.  This typically means that the socket has
   * collapsed.
   *
   * @post response.equals(Result.toString())
   */

  private synchronized void receive() 
    throws IOException, InterruptedIOException
  {
    StringBuffer Result = new StringBuffer();

    // Get first line of response.
    receiveLoop:
    while (true) {
      if (commandInputStream.ready()) {
        response = commandInputStream.readLine();
        debugOutput.println(debugCategory, "Got a response of '" + 
                            response + "'");
        prefix = prefixCode(response);
        replyCode = replyCode(response);

        // Append the first part (or complete) message.
        Result.append(replyMessage(response));

        // If the fourth character (3rd index) of the response is a minus
        // ('-') then we have to parse a multi-line response.
        if (response.charAt(3) == '-') {
          debugOutput.println(debugCategory, "Multi-line response.");
          debugOutput.println(debugCategory, "Got a response of '" + 
                              response + "'");
          while (true) {
            if (commandInputStream.ready()) {
              response = commandInputStream.readLine();
              debugOutput.println(debugCategory, "Got a response of '" + 
                                  response + "'");
              // If the prefix is the same and is followed by a space, we
              // are done parsing.
              if ((replyCode(response) == replyCode) && 
                  (response.charAt(3) == ' ')) {
                // Add the non-prefix part of this input line to the result
                // and break.
                Result.append(replyMessage(response) + "\n");
                debugOutput.println(debugCategory, "Found end of response.");
                break receiveLoop;
              } else {
                // Otherwise, append the full line read since it has not prefix.
                Result.append(response + "\n");
              }
            } else {
              // The input stream isn't ready but we know we need to read
              // something, so we wait.
              debugOutput.println(debugCategory, "Command stream wasn't ready.");
              try {
                Thread.currentThread().sleep(100);
                debugOutput.println(debugCategory, "Waiting...");
              } catch (InterruptedException ie) {
                // empty
              }
            }
          } // while(true)
        } else break receiveLoop;
      } else try {
        // The input stream isn't ready but we know we need to read
        // something, so we wait.
        Thread.currentThread().sleep(10);
      } catch (InterruptedException ie) {
        // empty
      }
    } // while(true)
    debugOutput.println(debugCategory, "Received '" + Result + "'.");

    response = Result.toString();
  }

  /**
   * @param response the response received from the server to an FTP
   * command.
   * @return the text of this response.
   * @see "RFC 959 for more information."
   *
   * @pre response != null
   */
  private String replyMessage(String response)
  {
    return response.substring(4, response.length() - 1);
  }

  /**
   * @param response the response received from the server to an FTP
   * command.
   * @return the code of this response.
   * @see kindftp.ReplyCodes
   * @see "RFC 959 for more information."
   *
   * @pre response != null
   */

  private int replyCode(String response)
  {
    int Result = 0;
    
    if (response.length() == 0)
      Result = 0;
    if (!(Character.isDigit(response.charAt(0))))
      Result = 0;
    else
      Result = Integer.parseInt(response.substring(0,3));
    return Result;
  }

  /**
   * @param response the response received from the server to an FTP
   * command.
   * @return the prefix code of this response (i.e. the first digit of
   * the response).
   * @see #replyCodes replycodes
   * @see "RFC 959 for more information."
   *
   * @pre response != null
   * @pre response.length() >= 1
   */

  private int prefixCode(String response)
  {
    int prefix = Integer.parseInt(response.substring(0,1));
    return prefix;
  }

  /**
   * @param response the response received from the server to an FTP
   * command that contains a path (typically from a MKD or CWD
   * command).
   * @return the path component of the response (that which is between
   * the quotation marks).
   */

  private String getQuotedPath(String response)
  {
    int firstQuote = response.indexOf("\"");
    int lastQuote = response.lastIndexOf("\"");
    return response.substring(firstQuote + 1, lastQuote);
  }
  
  /**
   * <p> This method runs through the finite state machine type 0.
   * This includes commands: USER and PASS. </p>
   */

  private void FSM0()
  {
    if (prefix == ReplyCodes.POSITIVE_PRELIMINARY)
      state = ERROR;
    if (prefix == ReplyCodes.POSITIVE_COMPLETION)
      state = SUCCESS;
    if (prefix == ReplyCodes.POSITIVE_INTERMEDIATE)
      state = WAIT;
    if ((prefix == ReplyCodes.TRANSIENT_NEGATIVE_COMPLETION) ||
        (prefix == ReplyCodes.PERMANENT_NEGATIVE_COMPLETION))
      state = FAILURE;
  }

  /**
   * <p> This method runs through the finite state machine type 1
   * This includes commands: ABOR, ALLO, DELE, CWD, CDUP, SMNT, HELP, MODE,
   * NOOP, PASV, QUIT, SITE, PORT, SYST, STAT, RMD, MKD, PWD, STRU, and
   * TYPE. </p>
   */

  private void FSM1()
  {
    if ((prefix == ReplyCodes.POSITIVE_PRELIMINARY) || 
        (prefix == ReplyCodes.POSITIVE_INTERMEDIATE))
      state = ERROR;
    if (prefix == ReplyCodes.POSITIVE_COMPLETION)
      state = SUCCESS;
    if ((prefix == ReplyCodes.TRANSIENT_NEGATIVE_COMPLETION) ||
        (prefix == ReplyCodes.PERMANENT_NEGATIVE_COMPLETION))
      state = FAILURE;
  }

  /**
   * <p> This method runs through the finite state machine type 2. This
   * includes commands: APPE, LIST, NLST, REIN, RETR, STOR, and STOU. </p>
   *
   * <p> By RFC959, "at most one 100 series reply is allowed per command".
   * Thus, if we see another 100 series reply now, it is erroneous since
   * the first one would have already been received. </p>
   *
   * @exception IOException is thrown if an I/O error occurs.
   */

  private void FSM2() throws IOException
  {
    if (prefix == ReplyCodes.POSITIVE_INTERMEDIATE)
      state = ERROR;
    if (prefix == ReplyCodes.POSITIVE_COMPLETION)
      state = SUCCESS;
    if ((prefix == ReplyCodes.TRANSIENT_NEGATIVE_COMPLETION) ||
        (prefix == ReplyCodes.PERMANENT_NEGATIVE_COMPLETION))
      state = FAILURE;
  }

  /**
   * <p> Build a data channel to the server, as appropriate per most
   * recent use of PASV. </p>
   *
   * @exception IOException is thrown if anything goes wrong while
   * building the data stream to the server.
   *
   * @ipre PORTport.valid()
   * @ipost (dataSocket.valid() && 
   *         dataInputStream.valid() && dataOutputStream.valid())
   *
   * @uses isPASV, PORTport, serverInetAddress, serverDataPort
   */

  private void buildDataChannel() throws IOException
  {
    debugOutput.println(debugCategory, "Building data channel to server.");
    // If we are NOT in PASV mode, the server will contact us on
    // PORTaddress:PORTport.
    if (!isPASV) {
      debugOutput.println(debugCategory,
           "NOT in passive mode, so setting up a ServerSocket.");
      // Create on any free port.
      ServerSocket dataServerSocket = new ServerSocket(0); 
      // Set timeout at 15 seconds.
      dataServerSocket.setSoTimeout(15*1000);
      // Send PORT command to server.
      PORT(PORTaddress, dataServerSocket.getLocalPort());
      dataSocket = dataServerSocket.accept();
      debugOutput.println(debugCategory, 
                          "Heard from server, building data streams.");
      dataInputStream = 
        new BufferedInputStream(dataSocket.getInputStream());
      dataOutputStream = 
        new BufferedOutputStream(dataSocket.getOutputStream());    
      return;
    } else {
      debugOutput.println(debugCategory, 
            "In passive mode, creating socket and connecting to server at '" + 
                          serverInetAddress + ":" + serverDataPort + "'");
      // If we are in PASV mode, the server expects for us to contact it.
      dataSocket = new Socket(serverInetAddress, serverDataPort);
      debugOutput.println(debugCategory, 
                          "Connected to server, building data streams.");
      dataInputStream = new BufferedInputStream(dataSocket.getInputStream());
      dataOutputStream = 
        new BufferedOutputStream(dataSocket.getOutputStream());    
      return;
    }
  }

  /**
   * <p> Close the data channel to the server. </p>
   *
   * @exception IOException is thrown if an error or failure in the
   * protocol takes place or the network connection fails.
   *
   * @ipost ((dataInputStream == null) && 
   *         (dataOutputStream == null) && (dataSocket == null))
   * @ipost All streams to the server are closed.
   */
  
  private void closeDataChannel() throws IOException
  {
    IOException ioException = null;
    try {
      if (dataInputStream != null)
        dataInputStream.close();
    } catch (IOException ioException0) {
      // ignore
      ioException = ioException0;
    }
    try {
      if (dataOutputStream != null)
        dataOutputStream.close();
    } catch (IOException ioException1) {
      // ignore
      ioException = ioException1;
    }
    try {
      if (dataSocket != null)
        dataSocket.close();
    } catch (IOException ioException2) {
      // ignore
      ioException = ioException2;
    }
    dataInputStream = null;
    dataOutputStream = null;
    dataSocket = null;
    if (ioException != null)
      throw ioException;
  }

} // end of class FTPProxy
