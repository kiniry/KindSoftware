/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: IDebugInit.java,v 1.7 2001/12/27 06:52:26 kiniry Exp $
 */

package kindftp;

import idebug.*;

/**
 * <p> A class that centralizes initialization of the IDebug framework for
 * KindFTP. </p>
 *
 * <p> The various get* methods cannot be called until the <tt>init()</tt>
 * method has been called and has completed. </p>
 *
 * @design I'd like to be able to express "invariant stable(initialized)"
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Initial creation.
 * @version $Revision: 1.7 $ $Date: 2001/12/27 06:52:26 $ 
 * @since KindFTP initial release.
 * 
 * @todo Add support for lack of IDebug.
 *
 * @see <a href="http://www.kindsoftware.com/products/opensource/IDebug/">IDebug</a>
 * @see #init
 * @invariant initialized implies 
 *                ((debug != null) && (assert != null) &&
 *                 (debugConstants != null) && (debugOutput != null))
 */

public class IDebugInit
{
  // Private Attributes

  // Debugging subsystem variables.
  private static Debug debug;
  private static Assert assert;
  private static DebugConstants debugConstants;
  private static DebugOutput debugOutput;

  // Indiates that debugging variables have been initialized.
  // @modifies SINGLE-ASSIGNMENT
  private static boolean initialized = false;

  // Public Methods

  /**
   * <p> Initialize the debugging subsystem of KindFTP. </p>
   *
   * @post getDebug() != null
   * @post getDebugOutput() != null
   * @post getAssert() != null
   * @post getDebugConstants() != null
   * @post initialized
   */

  public static void init()
  {
    debug = new Debug();
    assert = debug.getAssert();
    debugConstants = debug.getDebugConstants();
    debugOutput = new WindowOutput(debug);
    debug.setOutputInterface(debugOutput);

    Context debugContext = new Context(debugConstants, debugOutput);
    // If you wish to add a new category to the debugging system, this
    // is where to do it.
    debugContext.addCategory("FTP", 2);
    debugContext.addCategory("TEST", 2);
    debugContext.turnOn();
    debug.addContext(debugContext);
    debug.turnOn();
    debug.setLevel(debugConstants.NOTICE_LEVEL);
    initialized = true;
  }

  /**
   * @return a reference to the <code>Debug</code> instance associated with
   * KindFTP.
   *
   * @pre initialized #IllegalStateException
   * @post return != null
   */

  public static Debug getDebug()
  {
    return debug;
  }

  /**
   * @return a reference to the implementation of <code>DebugOutput</code>
   * associated with KindFTP.
   *
   * @pre initialized #IllegalStateException
   * @post return != null
   */

  public static DebugOutput getDebugOutput()
  {
    return debugOutput;
  }
  
  /**
   * @return a reference to the implementation of <code>Assert</code>
   * associated with KindFTP.
   *
   * @pre initialized #IllegalStateException
   * @post return != null
   */

  public static Assert getAssert()
  {
    return assert;
  }
  
  /**
   * @return a reference to the implementation of
   * <code>DebugConstants</code> associated with KindFTP.
   *
   * @pre initialized #IllegalStateException
   * @post return != null
   */

  public static DebugConstants getDebugConstants()
  {
    return debugConstants;
  }
  
} // end of class IDebugInit
