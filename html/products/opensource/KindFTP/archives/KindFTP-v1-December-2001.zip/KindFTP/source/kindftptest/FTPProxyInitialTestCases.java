/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: FTPProxyInitialTestCases.java,v 1.11 2001/12/27 09:23:14 kiniry Exp $
 */

package kindftptest;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import junit.framework.Test;
import junit.framework.TestSuite;
import kindftp.FTPProxy;
import kindftp.ReplyCodes;

/**
 * <p> Test cases for all <code>FTPProxy</code> basic commands that are not
 * send and receive commands. </p>
 *
 * <p> The various get* methods cannot be called until the init() method
 * has been called and has completed. </p>
 *
 * @design I'd like to be able to express "invariant stable(initialized)"
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Initial creation.
 * @version $Revision: 1.11 $ $Date: 2001/12/27 09:23:14 $ 
 * @since KindFTP initial release.
 * 
 * @todo kiniry - Add support for lack of IDebug.
 *
 * @see <a href="http://www.kindsoftware.com/products/opensource/IDebug/">IDebug</a>
 *
 * @invariant initialized implies 
 *                ((debug != null) && (assert != null) &&
 *                 (debugConstants != null) && (debugOutput != null))
 */

public class FTPProxyInitialTestCases extends IDebugTestCase
{
  // Private Attributes.

  // Constructors

  public FTPProxyInitialTestCases(String name)
  {
    super(name);
  }

  // Public Methods

  /**
   * @design If/when we make these tests independent, this method can be
   * removed and the automatic test extraction of jUnit can be used. </p>
   */

  public static Test suite() {
    TestSuite suite = new TestSuite();
    suite.addTest(new FTPProxyInitialTestCases("testBuildProxy"));
    suite.addTest(new FTPProxyInitialTestCases("testAnnounce"));
    suite.addTest(new FTPProxyInitialTestCases("testConnect"));
    suite.addTest(new FTPProxyInitialTestCases("testAnonymousLogin"));
    suite.addTest(new FTPProxyInitialTestCases("testACCT"));
    suite.addTest(new FTPProxyInitialTestCases("testSMNT"));
    suite.addTest(new FTPProxyInitialTestCases("testSTAT"));
    suite.addTest(new FTPProxyInitialTestCases("testType"));
    suite.addTest(new FTPProxyInitialTestCases("testCurrentDirectoryStatus"));
    suite.addTest(new FTPProxyInitialTestCases("testHELP"));
    suite.addTest(new FTPProxyInitialTestCases("testHELPonCDUP"));
    suite.addTest(new FTPProxyInitialTestCases("testNOOP"));
    suite.addTest(new FTPProxyInitialTestCases("testCWDtoTmp"));
    suite.addTest(new FTPProxyInitialTestCases("testCDUP"));
    suite.addTest(new FTPProxyInitialTestCases("testCWDHome"));
    suite.addTest(new FTPProxyInitialTestCases("testREIN"));
    suite.addTest(new FTPProxyInitialTestCases("testPORT"));
    suite.addTest(new FTPProxyInitialTestCases("testPASV"));
    suite.addTest(new FTPProxyInitialTestCases("testTYPE"));
    suite.addTest(new FTPProxyInitialTestCases("testSTRU"));
    suite.addTest(new FTPProxyInitialTestCases("testMODE"));
    suite.addTest(new FTPProxyInitialTestCases("testALLO"));
    suite.addTest(new FTPProxyInitialTestCases("testCWDtest_directory"));
    suite.addTest(new FTPProxyInitialTestCases("testRename"));
    suite.addTest(new FTPProxyInitialTestCases("testMKDtest_create"));
    suite.addTest(new FTPProxyInitialTestCases("testRMD"));
    suite.addTest(new FTPProxyInitialTestCases("testMKDtest_delete"));
    suite.addTest(new FTPProxyInitialTestCases("testDELE"));
    suite.addTest(new FTPProxyInitialTestCases("testPWD"));
    suite.addTest(new FTPProxyInitialTestCases("testTYPEA"));
    suite.addTest(new FTPProxyInitialTestCases("testPASV"));
    suite.addTest(new FTPProxyInitialTestCases("testLISTdot"));
    suite.addTest(new FTPProxyInitialTestCases("testPASV"));
    suite.addTest(new FTPProxyInitialTestCases("testLISTtmp"));
    suite.addTest(new FTPProxyInitialTestCases("testPASV"));
    suite.addTest(new FTPProxyInitialTestCases("testNLSTdot"));
    suite.addTest(new FTPProxyInitialTestCases("testPASV"));
    suite.addTest(new FTPProxyInitialTestCases("testNLSTtmp"));
    suite.addTest(new FTPProxyInitialTestCases("testSITE"));

    return suite;
  }

  // Our first test suite are the following sequence of tests in exactly
  // the order listed here.

  /**
   * @post FTPProxyTestSetup.proxy != null
   */

  public void testBuildProxy()
  {
    debugOutput.println(debugCategory, "Building FTPProxy....");

    try {
      FTPProxyTestSetup.proxy = 
        new FTPProxy(InetAddress.getByName(FTPProxyTestSetup.FTPServer), 
                     FTPProxyTestSetup.FTPPort, 
                     debug, debugOutput);
    } catch (UnknownHostException uhe) {
      fail(uhe.getMessage());
    }
  }

  /**
   * <p> Announce the test is running.  This should/will probably be
   * removed soon. </p>
   */

  public void testAnnounce()
  {
    debugOutput.println(debugCategory, "===========================");
    debugOutput.println(debugCategory, "Running FTPProxy test code.");
    debugOutput.println(debugCategory, "===========================");
  }
  
  /**
   * <p> Connect to the server. </p>
   */

  public void testConnect()
  {
    try {
      // Connect to the server.
      debugOutput.println(debugCategory, "Connecting to server....");
      FTPProxyTestSetup.proxy.connect();
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }

  /**
   * <p> Anonymously login to the test server. </p>
   */
  
  public void testAnonymousLogin()
  {
    try {
      // Login to the server as anonymous.
      debugOutput.println(debugCategory, "Logging in as anonymous.");
      FTPProxyTestSetup.proxy.USER("anonymous");
      // A WAIT state indicates that the server is waiting for a password.
      assertTrue("Anonymous username must be ok.",
                 FTPProxyTestSetup.proxy.getReplyCode() == 
                 ReplyCodes.USER_NAME_OK);
      // No password should be necessary for anonymous user.
      FTPProxyTestSetup.proxy.PASS("kiniry@kindsoftware.com");
      assertTrue("User must be logged in.",
                 FTPProxyTestSetup.proxy.getReplyCode() ==
                 ReplyCodes.USER_LOGGED_IN);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }

  /**
   * <p> Issue the ACCT command to the server.  To test this we need a
   * server capable of supporting ACCT.  We do not have such at this time.
   * This should throw an exception since our server doesn't support
   * ACCT. </p>
   */
  
  public void testACCT()
  {
    try {
      debugOutput.println(debugCategory, "Attempt to issue an ACCT command.");
      FTPProxyTestSetup.proxy.ACCT(".");
      assertTrue((FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS) ||
                 (FTPProxyTestSetup.proxy.getReplyCode() == 
                  ReplyCodes.COMMAND_NOT_IMPLEMENTED));
    } catch (IOException ioe) {
      fail(ioe.getMessage());
    }
  }

  /**
   * <p> Attempt to issue an SMNT command.  This should throw an exception
   * since our server doesn't support SMNT. </p>
   */

  public void testSMNT()
  {
    try {
      debugOutput.println(debugCategory, "Attempt to issue an SMNT command.");
      FTPProxyTestSetup.proxy.SMNT(".");
      assertTrue((FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS) ||
                 (FTPProxyTestSetup.proxy.getReplyCode() == 
                  ReplyCodes.COMMAND_NOT_IMPLEMENTED));
    } catch (IOException ioe) {
      fail(ioe.getMessage());
    }
  }

  /**
   * <p> Check the server status. </p>
   */

  public void testSTAT()
  {
    try {
      debugOutput.println(debugCategory, "Checking server status.");
      FTPProxyTestSetup.proxy.STAT(null);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Check the type of server. </p>
   */

  public void testType()
  {
    try {
      debugOutput.print(debugCategory, "Requesting server type.");
      FTPProxyTestSetup.proxy.SYST();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Check the current directory status. </p>
   */

  public void testCurrentDirectoryStatus()
  {
    try {
      debugOutput.println(debugCategory, "Checking status of '.': ");
      FTPProxyTestSetup.proxy.STAT(".");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Run the general help command. </p>
   */

  public void testHELP()
  {
    try {
      debugOutput.println(debugCategory, "Asking for general help from server: ");
      FTPProxyTestSetup.proxy.HELP(null);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Run help command on the CDUP command. </p>
   */

  public void testHELPonCDUP()
  {
    try {
      debugOutput.println(debugCategory, "Asking for help from server on CDUP: ");
      FTPProxyTestSetup.proxy.HELP("CDUP");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Issuing a NOOP command. </p>
   */

  public void testNOOP()
  {
    try {
      debugOutput.println(debugCategory, "Issuing a NOOP.");
      FTPProxyTestSetup.proxy.NOOP();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Change directory to a <tt>~/tmp</tt> directory. </p>
   */

  public void testCWDtoTmp()
  {
    try {
      // Change current working directory to /tmp.
      debugOutput.println(debugCategory, 
                          "Change current working directory to ~/tmp");
      FTPProxyTestSetup.proxy.CWD("~/tmp");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }

  /**
   * <p> Go up one directory level. </p>
   */

  public void testCDUP()
  {
    try {
      debugOutput.println(debugCategory, 
                          "Change current working directory via CDUP.");
      FTPProxyTestSetup.proxy.CDUP();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Change directory to the user home directory. </p>
   */

  public void testCWDHome()
  {
    try {
      debugOutput.println(debugCategory, "Go back to home directory ('~/').");
      FTPProxyTestSetup.proxy.CWD("~/");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Attempt to issue an REIN command.  If we succeed, login again.
   * If we don't get an error, then just print the message. </p>
   *
   * @todo Need to finish this test once REIN is really done.
   */

  public void testREIN()
  {
    try {
      debugOutput.print(debugCategory, "Attempt to issue an REIN command.");
      FTPProxyTestSetup.proxy.REIN();
      if (FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS) {
        debugOutput.println(debugCategory, 
                            "Succeeded....logging in again.");
        debugOutput.println(debugCategory, 
                 ReplyCodes.convertCode(FTPProxyTestSetup.proxy.getReplyCode()));
        FTPProxyTestSetup.proxy.USER("kindftp");
        FTPProxyTestSetup.proxy.PASS("test");
      } else {
        assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.FAILURE);
        debugOutput.println(debugCategory, 
                 ReplyCodes.convertCode(FTPProxyTestSetup.proxy.getReplyCode()));
      }
    } catch (IOException ioe) {
      debugOutput.println(debugCategory, 
                          "Failed - server doesn't support REIN (OK).");
    }
  }
  
  /**
   * <p> Issue a PORT command (even though we aren't starting a connection
   * by hand). </p>
   */

  public void testPORT()
  {
    try {
      debugOutput.println(debugCategory, "Issuing a PORT command.");
      FTPProxyTestSetup.proxy.PORT(InetAddress.getByName("localhost"), 1138);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Issue a PASV command. </p>
   */

  public void testPASV()
  {
    try {
      debugOutput.println(debugCategory, "Issuing a PASV command.");
      FTPProxyTestSetup.proxy.PASV();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Switch TYPE a couple of times. Since only types A and I are
   * supported by our test server, we only switch between them. </p>
   */

  public void testTYPE()
  {
    try {
      debugOutput.println(debugCategory, "Switching to TYPE A then I.");
      FTPProxyTestSetup.proxy.TYPE('A');
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      FTPProxyTestSetup.proxy.TYPE('I');
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }

  /**
   * <p> Switch to TYPE 'A'. </p>
   */

  public void testTYPEA()
  {
    try {
      debugOutput.println(debugCategory, "Switching to TYPE A.");
      FTPProxyTestSetup.proxy.TYPE('A');
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Issue a STRU command.  Only "F" works on our test server, so that
   * is all we test right now. </p>
   */

  public void testSTRU()
  {
    try {
      debugOutput.println(debugCategory, "Issue a STRU F command.");
      FTPProxyTestSetup.proxy.STRU('F');
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Issue a MODE command.  Only "S" works on our test server, so that
   * is all we test right now. </p>
   */

  public void testMODE()
  {
    try {
      debugOutput.println(debugCategory, "Issue a MODE S command.");
      FTPProxyTestSetup.proxy.MODE('S');
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Issue a ALLO command.  It is ignored by our test server. </p>
   */

  public void testALLO()
  {
    try {
      debugOutput.println(debugCategory, "Issue a ALLO 10000 command.");
      FTPProxyTestSetup.proxy.ALLO(10000, 0);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Change to the <tt>~/test_directory</tt> directory. </p>
   */

  public void testCWDtest_directory()
  {
    try {
      debugOutput.println(debugCategory, 
                          "Change to the '~/test_directory' directory.");
      FTPProxyTestSetup.proxy.CWD("~/test_directory");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Rename the file <tt>rename_file</tt> to <tt>renamed_file</tt>,
   * then rename back. </p>
   */

  public void testRename()
  {
    try {
      debugOutput.println(debugCategory,
                          "Renaming file 'rename_file' to 'renamed_file', " +
                          "then rename back.");
      FTPProxyTestSetup.proxy.RNFR("rename_file");
      FTPProxyTestSetup.proxy.RNTO("renamed_file");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      FTPProxyTestSetup.proxy.RNFR("renamed_file");
      FTPProxyTestSetup.proxy.RNTO("rename_file");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Make a directory called <tt>test_create</tt>. </p>
   */

  public void testMKDtest_create()
  {
    try {
      debugOutput.println(debugCategory, "Make a 'test_create' directory.");
      FTPProxyTestSetup.proxy.MKD("test_create");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Remove the directory called <tt>test_create</tt>. </p>
   */

  public void testRMD()
  {
    try {
      debugOutput.println(debugCategory, "Remove the 'test_create' directory.");
      FTPProxyTestSetup.proxy.RMD("test_create");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Make a directory called <tt>test_delete</tt>. </p>
   */

  public void testMKDtest_delete()
  {
    try {
      debugOutput.println(debugCategory, "Make a 'test_delete' directory.");
      FTPProxyTestSetup.proxy.MKD("test_delete");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Delete the directory called <tt>test_delete</tt> by using DELE
   * command. </p>
   */

  public void testDELE()
  {
    try {
      debugOutput.println(debugCategory, 
                          "Deleting 'test_delete' directory with DELE.");
      FTPProxyTestSetup.proxy.DELE("test_delete");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Print out the current working directory. </p>
   */

  public void testPWD()
  {
    try {
      debugOutput.print(debugCategory, "Current working directory: ");
      FTPProxyTestSetup.proxy.PWD();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> List the current directory (<tt>.</tt>).</p>
   */

  public void testLISTdot()
  {
    try {
      debugOutput.println(debugCategory, "Listing of current directory: ");
      FTPProxyTestSetup.proxy.LIST(".");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> List the directory <tt>~/tmp</tt>. </p>
   */

  public void testLISTtmp()
  {
    try {
      FTPProxyTestSetup.proxy.PASV();
      debugOutput.println(debugCategory, "Listing of directory '~/tmp': ");
      FTPProxyTestSetup.proxy.LIST("~/tmp");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> NList the current directory (<tt>.</tt>). </p>
   */

  public void testNLSTdot()
  {
    try {
      FTPProxyTestSetup.proxy.PASV();
      debugOutput.println(debugCategory, "NList of current directory: ");
      FTPProxyTestSetup.proxy.NLST(".");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> NList the directory <tt>~/tmp</tt>. </p>
   */

  public void testNLSTtmp()
  {
    try {
      FTPProxyTestSetup.proxy.CWD("~/");
      FTPProxyTestSetup.proxy.PASV();
      debugOutput.println(debugCategory, "NList of directory '~/tmp': ");
      FTPProxyTestSetup.proxy.NLST("tmp");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      debugOutput.println(debugCategory, lastResponse());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Attempt a SITE command.  Our test server understands SITE IDLE. </p>
   */

  public void testSITE()
  {
    try {
      debugOutput.println(debugCategory, "Attempt SITE IDLE command.");
      FTPProxyTestSetup.proxy.SITE("IDLE");
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);      
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }

  // A shorthand to check the last response.

  private String lastResponse()
  {
    return FTPProxyTestSetup.proxy.getLastResponse();
  }
  
} // end of class FTPProxyInitialTests
