/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: FTPProxyMiscTestCases.java,v 1.4 2001/12/20 07:42:30 kiniry Exp $
 */

package kindftptest;

import java.io.IOException;
import java.util.Date;
import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * <p> Test commands that check the status of files on the server. </p>
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Initial creation.
 * @version $Revision: 1.4 $ $Date: 2001/12/20 07:42:30 $ 
 * @since KindFTP initial release.
 */

public class FTPProxyMiscTestCases extends IDebugTestCase
{
  // Constructors

  public FTPProxyMiscTestCases(String name)
  {
    super(name);
  }

  // Public Methods

  public static Test suite() {
    TestSuite suite = new TestSuite();
    suite.addTest(new FTPProxyMiscTestCases("testMDTM"));
    suite.addTest(new FTPProxyMiscTestCases("testSIZE"));
    return suite;
  }

  /**
   * <p> Test the MDTM command on a file
   * <tt>~/test_directory/reply_codes.ser</tt>. </p>
   */

  public void testMDTM()
  {
    Date lastModTime = null;
    
    try {
      lastModTime = 
        FTPProxyTestSetup.proxy.MDTM("~/test_directory/reply_codes.ser");
      assertNotNull(lastModTime);
      debugOutput.println(debugCategory, 
                          "Last modification time of " +
                          "'~/test_directory/reply_codes.ser' is " +
                          lastModTime);
    } catch (IOException ioe) {
      fail(ioe.getMessage());
    }
  }

  /**
   * <p> Check the size of the file
   * <tt>~/test_directory/reply_codes.ser</tt>. </p>
   */

  public void testSIZE()
  {
    long size = -1;

    try {
      size = FTPProxyTestSetup.proxy.SIZE("~/test_directory/reply_codes.ser");
      assertTrue(size != -1);
      debugOutput.println(debugCategory, 
            "Size of '~/test_directory/reply_codes.ser' is " + size);
    } catch (IOException ioe) {
      fail(ioe.getMessage());
    }
  }
  
} // end of class FTPProxyMiscTestCases
