/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: FTPProxyReceiveTestCases.java,v 1.7 2001/12/20 07:42:30 kiniry Exp $
 */

package kindftptest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import kindftp.FTPProxy;
import kindftp.ReplyCodes;

/**
 * <p> A set of blackbox tests for the RETR command. </p>
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Initial creation.
 * @version $Revision: 1.7 $ $Date: 2001/12/20 07:42:30 $ 
 * @since KindFTP initial release.
 */

public class FTPProxyReceiveTestCases extends IDebugTestCase
{
  // Constructors

  public FTPProxyReceiveTestCases(String name)
  {
    super(name);
  }

  // Public Methods

  public static Test suite() {
    TestSuite suite = new TestSuite();
    suite.addTest(new FTPProxyReceiveTestCases("testRETR_text"));
    suite.addTest(new FTPProxyReceiveTestCases("testRETR_text_streaming"));
    suite.addTest(new FTPProxyReceiveTestCases("testRETR_binary"));
    suite.addTest(new FTPProxyReceiveTestCases("testRETR_binary_streaming"));
    suite.addTest(new FTPProxyReceiveTestCases("testRETR_subdir_text"));
    suite.addTest(
          new FTPProxyReceiveTestCases("testRETR_subdir_text_streaming"));

    return suite;
  }

  /**
   * <p> Retrieve the file <tt>file.txt</tt> in non-streaming mode. </p>
   */

  public void testRETR_text()
  {
    try {
      debugOutput.println(debugCategory, 
                          "Retrieving text file 'file.txt'....");
      FTPProxyTestSetup.proxy.CWD("~/tmp/");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.RETR("file.txt", false);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
      
      // Print the contents of the received file.
      File file = FTPProxyTestSetup.proxy.getDataFile();
      assertNotNull(file);
      BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
      assertNotNull(bufferedReader);

      String line = null;
      do {
        line = bufferedReader.readLine();
        if (line != null)
          debugOutput.println(debugCategory, line);
      } while (line != null);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Retrieve the file <tt>file.txt</tt> in streaming mode. </p>
   */

  public void testRETR_text_streaming()
  {
    try {
      debugOutput.println(debugCategory, 
                          "Retrieving text file 'file.txt'....");
      FTPProxyTestSetup.proxy.CWD("~/tmp/");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.RETR("file.txt", true);
      assertTrue((FTPProxyTestSetup.proxy.getPrefix() == 
                  ReplyCodes.POSITIVE_PRELIMINARY) ||
                 (FTPProxyTestSetup.proxy.getPrefix() == 
                  ReplyCodes.POSITIVE_COMPLETION));

      // Print the contents of the file as we stream it.
      BufferedReader bufferedReader = 
        new BufferedReader(
            new InputStreamReader(FTPProxyTestSetup.proxy.getInputStream()));
      assertNotNull(bufferedReader);

      String line = null;
      do {
        line = bufferedReader.readLine();
        if (line != null)
          debugOutput.println(debugCategory, line);
    
      } while (line != null);
      bufferedReader.close();

      // Complete command handshake.
      FTPProxyTestSetup.proxy.completeCommandHandshake();
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Retrieve the binary file <tt>bar.zip</tt> in non-streaming
   * mode and check its contents. </p>
   */

  public void testRETR_binary()
  {
    try {
      debugOutput.println(debugCategory, 
                          "Retrieving zip file 'bar.zip'....");
      FTPProxyTestSetup.proxy.CWD("~/tmp/");
      FTPProxyTestSetup.proxy.TYPE('I');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.RETR("bar.zip", false);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);

      // Print the entries in the zip file.
      File file = FTPProxyTestSetup.proxy.getDataFile();
      assertNotNull(file);
      ZipFile zipFile = new ZipFile(file);
      assertNotNull(zipFile);
      
      for (Enumeration contents = zipFile.entries(); 
           contents.hasMoreElements();)
        debugOutput.println(debugCategory, contents.nextElement());
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Retrieve the binary file <tt>bar.zip</tt> in streaming mode and
   * check its contents. </p>
   */

  public void testRETR_binary_streaming()
  {
    try {
      debugOutput.println(debugCategory, 
                          "Retrieving zip file 'bar.zip'....");
      FTPProxyTestSetup.proxy.CWD("~/tmp/");
      FTPProxyTestSetup.proxy.TYPE('I');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.RETR("bar.zip", true);
      assertTrue((FTPProxyTestSetup.proxy.getPrefix() == 
                  ReplyCodes.POSITIVE_PRELIMINARY) ||
                 (FTPProxyTestSetup.proxy.getPrefix() == 
                  ReplyCodes.POSITIVE_COMPLETION));

      // Print the contents of the file as we stream it.
      ZipInputStream zipInputStream = 
        new ZipInputStream(FTPProxyTestSetup.proxy.getInputStream());
      assertNotNull(zipInputStream);

      ZipEntry zipEntry = null;
      do {
        zipEntry = zipInputStream.getNextEntry();
        if (zipEntry != null)
          debugOutput.println(debugCategory, zipEntry.toString());
      } while (zipEntry != null);
      zipInputStream.close();

      // Complete command handshake.
      FTPProxyTestSetup.proxy.completeCommandHandshake();
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Retrieve the text file <tt>tmp/file.txt</tt> in non-streaming
   * mode after changing to the home directory. </p>
   */

  public void testRETR_subdir_text()
  {
    try {
      debugOutput.println(debugCategory, 
                          "Retrieving text file 'tmp/file.txt'....");
      FTPProxyTestSetup.proxy.CWD("~/");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.RETR("tmp/file.txt", false);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);

      // Print the contents of the file.
      File file = FTPProxyTestSetup.proxy.getDataFile();
      assertNotNull(file);
      BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
      assertNotNull(bufferedReader);

      String line = null;
      do {
        line = bufferedReader.readLine();
        if (line != null)
          debugOutput.println(debugCategory, line);
      } while (line != null);
      bufferedReader.close();
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Retrieve the text file <tt>tmp/file.txt</tt> in streaming mode
   * after changing to the home directory. </p>
   */

  public void testRETR_subdir_text_streaming()
  {
    try {
      // ------------------------------------------------------------
      // Test a text file in a directory ('tmp/file.txt').
      // Test streaming mode.
      debugOutput.println(debugCategory,
                          "Retrieving text file 'tmp/file.txt'....");
      FTPProxyTestSetup.proxy.CWD("~/");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.RETR("tmp/file.txt", true);
      assertTrue((FTPProxyTestSetup.proxy.getPrefix() == 
                  ReplyCodes.POSITIVE_PRELIMINARY) ||
                 (FTPProxyTestSetup.proxy.getPrefix() == 
                  ReplyCodes.POSITIVE_COMPLETION));

      // Print the contents of the file.
      BufferedReader bufferedReader = 
        new BufferedReader(
            new InputStreamReader(FTPProxyTestSetup.proxy.getInputStream()));
      assertNotNull(bufferedReader);

      String line = null;
      do {
        line = bufferedReader.readLine();
        if (line != null)
          debugOutput.println(debugCategory, line);
      } while (line != null);
      bufferedReader.close();

      // Complete command handshake.
      FTPProxyTestSetup.proxy.completeCommandHandshake();
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }

} // end of class FTPProxyReceiveTestCases
