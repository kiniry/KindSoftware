/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: FTPProxySendTestCases.java,v 1.6 2001/12/20 07:42:30 kiniry Exp $
 */

package kindftptest;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import kindftp.FTPProxy;
import kindftp.ReplyCodes;

/**
 * <p> A set of blackbox tests for the STOR command. </p>
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Initial creation.
 * @version $Revision: 1.6 $ $Date: 2001/12/20 07:42:30 $ 
 * @since KindFTP initial release.
 */

public class FTPProxySendTestCases extends IDebugTestCase
{
  // Constructors

  public FTPProxySendTestCases(String name)
  {
    super(name);
  }

  // Public Methods

  public static Test suite() {
    TestSuite suite = new TestSuite();
    suite.addTest(new FTPProxySendTestCases("testSTOR_text"));
    suite.addTest(new FTPProxySendTestCases("testSTOR_text_streaming"));
    suite.addTest(new FTPProxySendTestCases("testSTOR_binary"));
    suite.addTest(new FTPProxySendTestCases("testSTOR_binary_streaming"));
    suite.addTest(new FTPProxySendTestCases("testSTOR_subdir_text"));
    suite.addTest(new FTPProxySendTestCases("testSTOR_subdir_text_streaming"));
    suite.addTest(new FTPProxySendTestCases("testSTOR_subdir_object"));

    return suite;
  }

  /**
   * <p> Send a text file to the server in non-streaming mode. </p>
   */

  public void testSTOR_text()
  {
    try {
      debugOutput.println(debugCategory, 
                          "Sending text file '/tmp/file.txt' " +
                          "in non-streaming mode....");
      FTPProxyTestSetup.proxy.CWD("~/test_directory");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.STOR("file_non-streaming.txt", 
                                   new File("/tmp/file.txt"));
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Send a text file to the server in streaming mode. </p>
   */

  public void testSTOR_text_streaming()
  {
    try {
      debugOutput.println(debugCategory, 
                          "Sending text file '/tmp/file.txt' " +
                          "in streaming mode....");
      FTPProxyTestSetup.proxy.CWD("~/test_directory");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.STOR("file-streaming.txt");

      // Build the streams for reading and writing the data.
      PrintWriter printWriter = 
        new PrintWriter(FTPProxyTestSetup.proxy.getOutputStream());
      BufferedReader bufferedReader = 
        new BufferedReader(new FileReader("/tmp/file.txt"));
      assertNotNull(printWriter);
      assertNotNull(bufferedReader);

      // Stream the data to the server.
      String line = null;
      do {
        line = bufferedReader.readLine();
        if (line != null)
          printWriter.println(line);
      } while (line != null);
      printWriter.flush();

      // Close channels *before* completing the command handshake.
      bufferedReader.close();
      printWriter.close();

      // Perform necessary post-streaming store command handshake.
      FTPProxyTestSetup.proxy.completeCommandHandshake();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Send a binary file to the server in non-streaming mode. </p>
   */

  public void testSTOR_binary()
  {
    try {
      FTPProxyTestSetup.proxy.CWD("~/test_directory");
      FTPProxyTestSetup.proxy.TYPE('I');
      FTPProxyTestSetup.proxy.PASV();
      debugOutput.println(debugCategory, 
                          "Sending zip file 'bar_non-streaming.zip' " +
                          "in non-streaming mode....");
      FTPProxyTestSetup.proxy.STOR("bar_non-streaming.zip", 
                                   new File("/tmp/bar.zip"));
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Send a binary file to the server in streaming mode. </p>
   */

  public void testSTOR_binary_streaming()
  {
    try {
      FTPProxyTestSetup.proxy.CWD("~/test_directory");
      FTPProxyTestSetup.proxy.TYPE('I');
      FTPProxyTestSetup.proxy.PASV();
      debugOutput.println(debugCategory, 
                          "Sending zip file 'bar_streaming.zip' in " +
                          "streaming mode....");
      FTPProxyTestSetup.proxy.STOR("bar_streaming.zip");

      // Build the streams for reading and writing the data.
      FileInputStream fileInputStream = new FileInputStream("/tmp/bar.zip");
      byte [] buffer = new byte [1024];
      int available = 0, bytesRead = 0;
      BufferedOutputStream bufferedOutputStream = 
        FTPProxyTestSetup.proxy.getOutputStream();
      assertNotNull(fileInputStream);
      assertNotNull(bufferedOutputStream);

      // Stream the data to the server.
      while (true) {
        available = fileInputStream.available();
        // Only read in as much as we can hold.
        if (available > 1024)
          available = 1024;
        if (available != 0) {
          bytesRead = fileInputStream.read(buffer, 0, available);
          if (bytesRead != -1)
            bufferedOutputStream.write(buffer, 0, bytesRead);
        } else break;
      }
      bufferedOutputStream.flush();

      // Close channels *before* completing the command handshake.
      fileInputStream.close();
      bufferedOutputStream.close();

      // Perform necessary post-streaming store command handshake.
      FTPProxyTestSetup.proxy.completeCommandHandshake();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }

  /**
   * <p> Store a text file using non-streaming mode to a subdirectory on
   * the server. </p>
   */
  
  public void testSTOR_subdir_text()
  {
    try {
      FTPProxyTestSetup.proxy.CWD("~/");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      debugOutput.println(debugCategory, 
                          "Sending text file " +
                          "'test_directory/file_dir_non-streaming.txt' " +
                          "in non-streaming mode....");
      FTPProxyTestSetup.proxy.STOR("test_directory/file_dir_non-streaming.txt", 
                                   new File("/tmp/file.txt"));
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }

  /**
   * <p> Store a text file using streaming mode to a subdirectory on the
   * server. </p>
   */
  
  public void testSTOR_subdir_text_streaming()
  {
    try {
      FTPProxyTestSetup.proxy.CWD("~/");
      FTPProxyTestSetup.proxy.TYPE('A');
      FTPProxyTestSetup.proxy.PASV();
      debugOutput.println(debugCategory, 
                          "Sending text file " +
                          "'test_directory/file_dir-streaming.txt' " +
                          "in streaming mode....");
      FTPProxyTestSetup.proxy.STOR("test_directory/file_dir-streaming.txt");

      // Build the streams for reading and writing the data.
      FileInputStream fileInputStream = new FileInputStream("/tmp/file.txt");
      byte [] buffer = new byte [1024];
      int available = 0, bytesRead = 0;
      BufferedOutputStream bufferedOutputStream = 
        FTPProxyTestSetup.proxy.getOutputStream();
      assertNotNull(fileInputStream);
      assertNotNull(bufferedOutputStream);

      // Stream the data to the server.
      while (true) {
        available = fileInputStream.available();
        // Only read in as much as we can hold.
        if (available > 1024)
          available = 1024;
        if (available != 0) {
          bytesRead = fileInputStream.read(buffer, 0, available);
          if (bytesRead != -1)
            bufferedOutputStream.write(buffer, 0, bytesRead);
        } else break;
      }
      bufferedOutputStream.flush();

      // Close channels *before* completing STOR.
      fileInputStream.close();
      bufferedOutputStream.close();

      // Perform necessary post-streaming store command handshake.
      FTPProxyTestSetup.proxy.completeCommandHandshake();
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }
  
  /**
   * <p> Store a serialized object using non-streaming mode to a
   * subdirectory on the server. </p>
   */
  
  public void testSTOR_subdir_object()
  {
    try {
      // Reply codes for debugging.
      ReplyCodes replyCodes = new ReplyCodes();
      FTPProxyTestSetup.proxy.CWD("~/");
      FTPProxyTestSetup.proxy.PASV();
      FTPProxyTestSetup.proxy.STOR("test_directory/reply_codes.ser", 
                                   replyCodes);
      assertTrue(FTPProxyTestSetup.proxy.getState() == FTPProxy.SUCCESS);
    } catch (IOException ioe){
      fail(ioe.getMessage());
    }
  }

} // end of class FTPProxySendTestCases
