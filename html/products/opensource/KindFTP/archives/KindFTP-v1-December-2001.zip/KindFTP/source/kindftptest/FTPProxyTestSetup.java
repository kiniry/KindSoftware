/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: FTPProxyTestSetup.java,v 1.7 2001/12/27 06:52:47 kiniry Exp $
 */

package kindftptest;

import idebug.Assert;
import idebug.Debug;
import idebug.DebugConstants;
import idebug.DebugOutput;
import java.io.IOException;
import java.net.InetAddress;
import junit.extensions.TestSetup;
import junit.framework.Test;
import kindftp.FTPProxy;
import kindftp.IDebugInit;

/**
 * <p> Shared setup code for the Blackbox testsuite for the class
 * <code>FTPProxy</code>. </p>
 *
 * <p> This setup code initializes IDebug components and reads in test
 * configuration information. </p>

 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history Feb 6, 2000 - Factored out of main FTPProxy class.
 * @version $Revision: 1.7 $ $Date: 2001/12/27 06:52:47 $ 
 * @since KindFTP initial release.
 * @see "RFC959 for more information."
 * @see <a href="http://www.junit.org/">jUnit</a>
 * @see <a href="http://www.kindsoftware.com/products/opensource/IDebug/">IDebug</a>
 */

public class FTPProxyTestSetup extends TestSetup
{
  // Private Attributes.

  // Default values for test server.
  private static final String defaultFTPServer = "localhost";
  private static final int defaultFTPPort = 21;
  private static final String defaultFTPUser = "kindftptest";
  private static final String defaultFTPPassword = "bekind";

  // Actual values used in testing; initially set to defaults above and
  // customized by readTestProperties().
  static String FTPServer = defaultFTPServer;
  static int FTPPort = defaultFTPPort;
  static String FTPUser = defaultFTPUser;
  static String FTPPassword = defaultFTPPassword;
  static InetAddress FTPServerInetAddress = null;
  static FTPProxy proxy = null;

  // Constructors

  public FTPProxyTestSetup(Test test)
  {
    super(test);
  }
  
  // Public Methods

  /**
   * <p> Set up the debugging subsystem then read in the blackbox test
   * configuration. </p>
   */

  public void setUp() {
    // Setup the debugging subsystem.
    setupDebug();
    // Read in customized test values.
    readTestProperties();
  }

  public void tearDown()
  {
    try {
      // Disconnect from the server.
      IDebugTestCase.debugOutput.println(IDebugTestCase.debugCategory,
                                         "Disconnect from the server....");
      if (proxy != null)
        proxy.QUIT();
    } catch (IOException ioe) {
        fail(ioe.getMessage());
    }
  }

  // Private Methods

  /**
   * <p> Setup the debugging subsystem. </p>
   *
   * @post IDebugTestCase.debug != null
   * @post IDebugTestCase.debugConstants != null
   * @post IDebugTestCase.debugOutput != null
   * @post IDebugTestCase.assert != null
   * @post IDebugTestCase.debugCategory.equals("NOTICE")
   * @post IDebugTestCase.initialized == true
   */

  private static void setupDebug()
  {
    // Setup debugging subsystem.
    IDebugInit.init();
    IDebugTestCase.debug = IDebugInit.getDebug();
    IDebugTestCase.debugConstants = IDebugInit.getDebugConstants();
    IDebugTestCase.debugOutput = IDebugInit.getDebugOutput();
    IDebugTestCase.assert = IDebugInit.getAssert();
    IDebugTestCase.debugCategory = "NOTICE";
    IDebugTestCase.initialized = true;
  }

  /**
   * <p> Read in a properties file for configuring non-default test values
   * for the following parameters for the test proxy constructor. </p>
   */

  private static void readTestProperties()
  {
    // read in a property file and set FTPServer et al to customized
    // values.
  }

} // end of class FTPProxyTestSetup
