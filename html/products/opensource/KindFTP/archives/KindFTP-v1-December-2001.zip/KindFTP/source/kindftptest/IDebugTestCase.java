/*
 * KindFTP - A Java implementation of the FTP protocol.
 * Copyright (C) 1998-2001 Joseph R. Kiniry.
 * Copyright (c) 2001 KindSoftware, LLC
 * All Rights Reserved
 *
 * $Id: IDebugTestCase.java,v 1.3 2001/12/20 07:42:30 kiniry Exp $
 */

package kindftptest;

import idebug.Assert;
import idebug.Debug;
import idebug.DebugConstants;
import idebug.DebugOutput;
import junit.framework.TestCase;

/**
 * <p> An extension of the base jUnit TestCase class to integrate IDebug
 * and jUnit functionality. </p>
 *
 * <p> At this point, this class only provides a single point of access to
 * the core set of IDebug interfaces via static references. </p>
 *
 * @author Joseph R. Kiniry <kiniry@kindsoftware.com>
 * @history 8 Dec 2001 - Created class and started using jUnit.
 * @version $Revision: 1.3 $ $Date: 2001/12/20 07:42:30 $ 
 * @since KindFTP initial release.
 * @see <a href="http://www.junit.org">jUnit</a>
 * @see <a href="http://www.kindsoftware.com/products/opensource/IDebug/">IDebug</a>
 *
 * @invariant initialized implies debug != null
 * @invariant initialized implies assert != null
 * @invariant initialized implies debugConstants != null
 * @invariant initialized implies debugOutput != null
 * @invariant initialized implies debugCategory != null
 */

public class IDebugTestCase extends TestCase
{
  // Private Attributes.

  // Debugging variables.
  static Debug debug = null;
  static Assert assert = null;
  static DebugConstants debugConstants = null;
  static DebugOutput debugOutput = null;
  static String debugCategory = null;

  // Indiates that debugging variables have been initialized.
  // @modifies SINGLE-ASSIGNMENT
  static boolean initialized = false;

  public IDebugTestCase(String name)
  {
    super(name);
  }
  
} // end of class IDebugTestCase
