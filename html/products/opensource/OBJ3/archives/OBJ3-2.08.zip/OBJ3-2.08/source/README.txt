
                      README for OBJ3 2.08 Source Tree
     _________________________________________________________________

   Welcome to the OBJ3 source tree.

Source Structure

   The source code for the OBJ3 system is found in the [1]obj3 directory.
   In  particular,  note  that  the  standard OBJ3 prelude is included as
   [2]obj3/prelude/obj3sp.obj.

   The source code for the TRIM system is found in the [3]trim directory.
   The TRIM example code and documentation are found there as well.

   Many  OBJ3 examples are included in the [4]examples directory. See the
   [5]README there for more information.

   A few miscellaneous support programs (coded in C) are available in the
   [6]support directory.

Building

  Background

   The  OBJ3 system is written in Common Lisp. Modern Common Lisp systems
   can  compile Lisp code to C, thus a compiled implementation of OBJ3 is
   quite efficient.

   The  last  major release of OBJ3 (2.0) took place in April of 1992 and
   was  built  by Timothy Winkler, one of the primary OBJ3 developers. At
   that  time, OBJ3 built properly on several Common Lisp implementations
   including:
     * CMU  CL  - Carnegie Mellon's Common Lisp's last major release (17)
       from  CMU  took place in November, 1994. CMU-CL is currently under
       development by a group of interested individuals and the [7]latest
       version  (18b)  was  made available in mid-1998. See [8]CMU Common
       Lisp Activities Page for more information.
     * LUCID  CL  (now Liquid CL from [9]Harlequin) - A commercial Common
       Lisp  implementation  that is still sold and supported. The latest
       version  at  the time of this writing is 5.0.6 (released December,
       1998).
     * Kyoto  Common  Lisp (KCL) - Was the primary Lisp platform for OBJ3
       development   in   the   early  90s.  KCL  is  a  highly  portable
       implementation of Common Lisp. KCL evolved into AKCL (Austin Kyoto
       Common  Lisp) by Bill Schelter, which then evolved into GNU Common
       Lisp.  A release of AKCL is available from [10]CMU but it is circa
       1992.  It  is  unclear  how  portable or supported AKCL is at this
       time.

   The  world  of  Common  Lisp implementations has changed over the last
   eight  years.  The primary free implementation that is widely used and
   available  today  is  GNU  Common  Lisp.  This release of OBJ3 is only
   guaranteed  to  run  under GCL 2.2.2 through 2.4.0. You can obtain GCL
   via  the  [11]FSF GNU FTP server or the primary [12]UTexas FTP server.
   Linux  users  can  obtain  references  to  various  RPMs  for  GCL via
   [13]RPMfind.net's excellent auto-index.

   Thanks go primarily to [14]Sula Ma at Oxford for the OBJ3 2.04 port to
   GCL  2.2.2.  Sula  is preparing a new branch of OBJ called "OBJ4", and
   this port was part of that work.

   We are interested in hearing if anyone ports OBJ3 to other Common Lisp
   implementations,  in particular, [15]Harlequin LispWorks and [16]Franz
   Allegro  CL.  Interested parties should look at the original OBJ3 2.04
   release  (mentioned in the [17]OBJ3 FAQ), since it contains all of the
   original  code  that  permitted  it  to  run under several Common Lisp
   implementations.  Note  that  Allegro CL 5 is now freely available for
   academic use on Windows, Linux, and FreeBSD platforms.

   For  a  good  breakdown  of  modern  Common  Lisp implementations, see
   [18]this  informative  page.  All  other  questions  about Common Lisp
   implementation are probably addressed in the [19]Lisp FAQ.

  Building

   To  build  OBJ3,  you need GCL and GNU make. Simply type "make" in the
   OBJ3  root  directory.  After  the  build completes, the OBJ3 and TRIM
   executables  will  be  found in the bin directory. After building, the
   OBJ3 distribution uses 11 MB of space.

Questions or comments?

   Please email [20]obj-feedback@kindsoftware.com.
     _________________________________________________________________

      [ [21]Index ] [ [22]Readme ] [ [23]FAQ ] [ [24]Release Notes ] [
       [25]To-Do List ] [ [26]Bug List ] [ [27]Papers ] [ Source ] [
                     [28]Bibliography ] [ [29]License ]
     _________________________________________________________________

     [30]Best Viewed With Any Browser. [31]XHTML 1.0 Checked! [32]CSS,
                             Level 2 Checked! 


    by Joseph R. Kiniry <kiniry@cs.caltech.edu>

   Last modified: Sat Dec 1 18:07:44 PST 2001

References

   1. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/source/obj3/
   2. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/source/obj3/prelude/obj3sp.obj
   3. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/source/trim/
   4. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/source/examples/
   5. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/source/examples/README.txt
   6. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/source/support/
   7. ftp://ftp2.cons.org/pub/languages/lisp/cmucl/release/
   8. http://www.cons.org/cmucl/
   9. http://www.harlequin.com/
  10. http://www.cs.cmu.edu/afs/cs/user/mkant/Public/Lisp/impl/kcl/akcl/
  11. ftp://prep.ai.mit.edu/pub/gnu/gcl/
  12. ftp://rene.ma.utexas.edu/pub/gcl/
  13. http://www.rpmfind.net/linux/RPM/gcl.html
  14. mailto:sm@comlab.ox.ac.uk
  15. http://www.harlequin.com/products/st/lisp/
  16. http://www.franz.com/
  17. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/FAQ.html
  18. http://www.elwoodcorp.com/alu/table/systems.htm
  19. http://www.faqs.org/faqs/lisp-faq/part1/preamble.html
  20. mailto:obj-feedback@kindsoftware.com
  21. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/index.html
  22. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/README.html
  23. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/FAQ.html
  24. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/RELEASE_NOTES.html
  25. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/TODO.html
  26. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/BUGS.html
  27. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/docs/index.html
  28. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/docs/obj_bib.html
  29. file://localhost/home/kiniry/Projects/KindSoftware/sandbox/OBJ3-2.08/LICENSE.html
  30. http://www.anybrowser.org/campaign/
  31. http://validator.w3.org/check/referer
  32. http://jigsaw.w3.org/css-validator/check/referer
