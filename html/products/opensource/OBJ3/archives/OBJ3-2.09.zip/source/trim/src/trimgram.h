#ifndef BISON_Y_TAB_H
# define BISON_Y_TAB_H

#ifndef YYSTYPE
typedef union
{
	int		y_arity;
	String		y_string;
	TrimMode	y_mode;
	Operator *	y_op;
	SortList *	y_sort_list;
	Instr *		y_instr;
} yystype;
# define YYSTYPE yystype
# define YYSTYPE_IS_TRIVIAL 1
#endif
# define	TIDENTIFIER	257
# define	TNORMAL	258
# define	TMATCHED	259
# define	TREDUCED	260
# define	TFAILURE	261
# define	TDONE	262
# define	TNFORM	263
# define	TLINK	264
# define	TAPPLY	265
# define	TLOAD	266
# define	TEXIT	267
# define	TABORT	268
# define	TRESTORE	269
# define	TSAVEOP	270
# define	TKILLOP	271
# define	TPUSHFRAME	272
# define	TPOPFRAME	273
# define	TMATCH	274
# define	TBIND	275
# define	TGET	276
# define	TBUILD	277
# define	TNOP	278
# define	TSET	279
# define	TIS	280
# define	TPEEK	281
# define	TJUMPT	282
# define	TJUMPF	283
# define	TJUMP	284
# define	TCALL	285
# define	TRETURN	286
# define	TSUBSORTS	287
# define	TOP	288
# define	TARROW	289


extern YYSTYPE yylval;

#endif /* not BISON_Y_TAB_H */
