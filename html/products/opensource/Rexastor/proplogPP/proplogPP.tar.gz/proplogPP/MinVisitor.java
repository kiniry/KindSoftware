import static pl.Common.*;
import pl.Pl;
import pl.CNF;

import java.util.HashMap;

/** 
 * A visitor stub for depth-first search traversal. 
 */
public abstract class MinVisitor<R> implements Pl.FVisitor<R> {
    private final HashMap<Pl.F, R> m=new HashMap<Pl.F, R>();

    R eval(Pl.F n) { 
        // memoize
        R retv=m.get(n);
        if (retv!=null) return retv;
        retv=n.accept(this); 
        m.put(n, retv);
        return retv;
    }

  public final R visit(Var node) { return visit(node, node.getFirst()); }

  public final R visit(Pl.Xor node) {
    return visit(node, eval(node.getFirst()), eval(node.getSecond()));
  }

  public final R visit(CNF.Not node) {
    return visit(node, eval(node.getFirst()));
  }

  public final R visit(Pl.Imp node) {
    return visit(node, eval(node.getFirst()), eval(node.getSecond()));
  }

  public final R visit(CNF.Or node) {
    return visit(node, eval(node.getFirst()), eval(node.getSecond()));
  }

  public final R visit(Pl.Or node) {
    return visit(node, eval(node.getFirst()), eval(node.getSecond()));
  }

  public final R visit(Pl.Not node) {
    return visit(node, eval(node.getFirst()));
  }

  public final R visit(CNF.And node) {
    return visit(node, eval(node.getFirst()), eval(node.getSecond()));
  }

  public final R visit(Pl.And node) {
    return visit(node, eval(node.getFirst()), eval(node.getSecond()));
  }
 
  public abstract R visit(Var n, String first);
  public abstract R visit(Pl.Xor n, R first, R second);
  public abstract R visit(Pl.Imp n, R first, R second);
  public abstract R visit(Pl.Or n, R first, R second);
  public abstract R visit(Pl.And n, R first, R second);
  public abstract R visit(Pl.Not n, R first);

  // run parent visit methods   
  public R visit(CNF.Not n, R first) {return visit((Pl.Not)n);}
  public R visit(CNF.Or n, R first, R second) {return visit((Pl.Or)n);}
  public R visit(CNF.And n, R first, R second) {return visit((Pl.And)n);}
}
