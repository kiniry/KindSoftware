import static pl.Pl.*; // import all constructs for Propositional Logic
import static pl.Common.*; // import all constructs common for all Logics

/**
 * A simple purely functional infix printer for Propositional Logic.
 * @author Mikolas Janota
 */
public class PP extends MinVisitor<String> {
    private static String p(String s) { return "(" + s + ")"; }

    /** Converts a given formula to  a String representation. */
    public String print(F f) { return eval(f); }

    @Override public String visit(Var v, String s)  { return s; }

    @Override public String visit(Xor n, String first, String second) 
        {return p(first) + " XOR " + p(second);}
  
    @Override public String visit(Imp n, String first, String second) 
        {return p(first) + " => " + p(second);}
  
    @Override public String visit(Or n, String first, String second) 
        {return p(first) + " OR " + p(second);}
  
    @Override public String visit(Not n, String first) 
        {return "NOT" + p(first);}
  
    @Override public String visit(And n, String first, String second) 
        {return p(first) + " AND " + p(second);}

}
