import pl.Pl; // import Propositional logic
import pl.CNF; // import CNF logic

// statically import all constructs common to both logics
import static pl.Common.*; 

/**
 * A tiny testing class for {@code PP} and subtyping on formulas.
 * @author Mikolas Janota
 */
public class TestPP {
    public static void main(String[] args) {
        // Construction is done through static functions 
        // for conciseness reasons.

        // prepare a couple of variables
        Var a=Var("a");
        Var b=Var("b");
        Var c=Var("c");

        // constructs two Propositional Logic formulas
        Pl.F f = Pl.Not(Pl.And(a, b));
        Pl.F f1 = Pl.Xor(a, c);

        // and on CNF formula
        CNF.F cnf = CNF.And(a, CNF.Not(b));

        // print via PP
        PP pp=new PP();
        System.out.println(pp.print(f));
        System.out.println(pp.print(f1));
        System.out.println(pp.print(cnf));

        // the following just shows that subtyping works as expected 
        Pl.F fFoo=cnf; // OK
        Pl.And fAnd=CNF.And(a, c); // OK
        CNF.F And1=CNF.And(a, c); // OK

        // uncommenting causes compilation error
        //        And1=fAnd;
        //        fAnd=And1;
        //        CNF.F cnfFoo=f1; // not OK
        //        CNF.F cnfBar=CNF.Or(CNF.And(a, b), c);
    }
}