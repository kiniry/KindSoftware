package pl;
/* This class is automatically generated*/
/* Do not edit*/
public class CNF { 
/* ===================== Template resources/VisitorTemplate.vm type CNF.And*/
/**
 * Visitor interface for the hierarchy under {@code CNF.And}.
 */
public interface AndVisitor<R> {
   R visit(And n);
}
/*======== Default Visitor Template ==========
class DefaultAndVisitor<R> implements AndVisitor<R> {
  R eval(And n) { return n.visit(this); }

  @Override
  public R visit(And n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
 
  @Override
  public R visit(And n, R first, R second) {
    assert false;
    return null;
  }
}
======== End of Default Visitor Template ==========*/

/* ===================== Template resources/VisitorTemplate.vm type CNF.Or*/
/**
 * Visitor interface for the hierarchy under {@code CNF.Or}.
 */
public interface OrVisitor<R> {
   R visit(Or n);
}
/*======== Default Visitor Template ==========
class DefaultOrVisitor<R> implements OrVisitor<R> {
  R eval(Or n) { return n.visit(this); }

  @Override
  public R visit(Or n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
 
  @Override
  public R visit(Or n, R first, R second) {
    assert false;
    return null;
  }
}
======== End of Default Visitor Template ==========*/

/* ===================== Template resources/VisitorTemplate.vm type CNF.Not*/
/**
 * Visitor interface for the hierarchy under {@code CNF.Not}.
 */
public interface NotVisitor<R> {
   R visit(Not n);
}
/*======== Default Visitor Template ==========
class DefaultNotVisitor<R> implements NotVisitor<R> {
  R eval(Not n) { return n.visit(this); }

  @Override
  public R visit(Not n) {
    return visit(n, eval(n.getFirst()));
  }
 
  @Override
  public R visit(Not n, R first) {
    assert false;
    return null;
  }
}
======== End of Default Visitor Template ==========*/

/* ===================== Template resources/VisitorTemplate.vm type CNF.Lit*/
/**
 * Visitor interface for the hierarchy under {@code CNF.Lit}.
 */
public interface LitVisitor<R>  extends Common.VarVisitor<R>, 
            CNF.NotVisitor<R> {
}
/*======== Default Visitor Template ==========
class DefaultLitVisitor<R> implements LitVisitor<R> {
  R eval(Lit n) { return n.visit(this); }

  @Override
  public R visit(Var n) {
    return visit(n, eval(n.getFirst()));
  }
  @Override
  public R visit(Not n) {
    return visit(n, eval(n.getFirst()));
  }
 
  @Override
  public R visit(Var n, R first) {
    assert false;
    return null;
  }
  @Override
  public R visit(Not n, R first) {
    assert false;
    return null;
  }
}
======== End of Default Visitor Template ==========*/

/* ===================== Template resources/VisitorTemplate.vm type CNF.Clause*/
/**
 * Visitor interface for the hierarchy under {@code CNF.Clause}.
 */
public interface ClauseVisitor<R>  extends CNF.OrVisitor<R>, 
            CNF.LitVisitor<R> {
}
/*======== Default Visitor Template ==========
class DefaultClauseVisitor<R> implements ClauseVisitor<R> {
  R eval(Clause n) { return n.visit(this); }

  @Override
  public R visit(Var n) {
    return visit(n, eval(n.getFirst()));
  }
  @Override
  public R visit(Not n) {
    return visit(n, eval(n.getFirst()));
  }
  @Override
  public R visit(Or n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
 
  @Override
  public R visit(Var n, R first) {
    assert false;
    return null;
  }
  @Override
  public R visit(Not n, R first) {
    assert false;
    return null;
  }
  @Override
  public R visit(Or n, R first, R second) {
    assert false;
    return null;
  }
}
======== End of Default Visitor Template ==========*/

/* ===================== Template resources/VisitorTemplate.vm type CNF.F*/
/**
 * Visitor interface for the hierarchy under {@code CNF.F}.
 */
public interface FVisitor<R>  extends CNF.AndVisitor<R>, 
            CNF.ClauseVisitor<R> {
}
/*======== Default Visitor Template ==========
class DefaultFVisitor<R> implements FVisitor<R> {
  R eval(F n) { return n.visit(this); }

  @Override
  public R visit(Var n) {
    return visit(n, eval(n.getFirst()));
  }
  @Override
  public R visit(Not n) {
    return visit(n, eval(n.getFirst()));
  }
  @Override
  public R visit(Or n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
  @Override
  public R visit(And n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
 
  @Override
  public R visit(Var n, R first) {
    assert false;
    return null;
  }
  @Override
  public R visit(Not n, R first) {
    assert false;
    return null;
  }
  @Override
  public R visit(Or n, R first, R second) {
    assert false;
    return null;
  }
  @Override
  public R visit(And n, R first, R second) {
    assert false;
    return null;
  }
}
======== End of Default Visitor Template ==========*/

/* ===================== Template resources/InterfaceTemplate.vm type CNF.And*/
public static interface And extends 
                        Pl.And,
                        CNF.F,
                         AndAcceptor
{
  //@ensures \result==1;
  /*@pure*/public int size();
  //@ requires offset < arr.length;
  //@ modifies arr[offset];
  public void copyTo(And[] arr, int offset);
  /** Getters for First. */
  public /*@pure*/CNF.F getFirst();
  /** Getters for Second. */
  public /*@pure*/CNF.F getSecond();
}
/* ===================== Template resources/InterfaceTemplate.vm type CNF.Or*/
public static interface Or extends 
                        Pl.Or,
                        CNF.Clause,
                         OrAcceptor
{
  //@ensures \result==1;
  /*@pure*/public int size();
  //@ requires offset < arr.length;
  //@ modifies arr[offset];
  public void copyTo(Or[] arr, int offset);
  /** Getters for First. */
  public /*@pure*/CNF.Clause getFirst();
  /** Getters for Second. */
  public /*@pure*/CNF.Clause getSecond();
}
/* ===================== Template resources/InterfaceTemplate.vm type CNF.Not*/
public static interface Not extends 
                        Pl.Not,
                        CNF.Lit,
                         NotAcceptor
{
  //@ensures \result==1;
  /*@pure*/public int size();
  //@ requires offset < arr.length;
  //@ modifies arr[offset];
  public void copyTo(Not[] arr, int offset);
  /** Getters for First. */
  public /*@pure*/Common.Var getFirst();
}
/* ===================== Template resources/InterfaceTemplate.vm type CNF.Lit*/
public static interface Lit extends 
          CNF.Clause,
      LitAcceptor
                    {}
/* ===================== Template resources/InterfaceTemplate.vm type CNF.Clause*/
public static interface Clause extends 
          CNF.F,
      ClauseAcceptor
                    {}
/* ===================== Template resources/InterfaceTemplate.vm type CNF.F*/
public static interface F extends 
          Pl.F,
      FAcceptor
                    {}
/* ===================== Template resources/MakerTemplate.vm type CNF.And*/
/**  Construct a new instance of the type And. */
public static And And(CNF.F first,
          CNF.F second) {
    return _And.mk(first,second);
}
/* ===================== Template resources/MakerTemplate.vm type CNF.Or*/
/**  Construct a new instance of the type Or. */
public static Or Or(CNF.Clause first,
          CNF.Clause second) {
    return _Or.mk(first,second);
}
/* ===================== Template resources/MakerTemplate.vm type CNF.Not*/
/**  Construct a new instance of the type Not. */
public static Not Not(Common.Var first) {
    return _Not.mk(first);
}
/* ===================== Template resources/MakerTemplate.vm type CNF.Lit*/
/* ===================== Template resources/MakerTemplate.vm type CNF.Clause*/
/* ===================== Template resources/MakerTemplate.vm type CNF.F*/
/* ===================== Template resources/ImplementationTemplate.vm type CNF.And*/
public static class _And implements And {
  private final CNF.F first;
  private final CNF.F second;

  // === Constructors and Factories ===
  private _And(
         CNF.F first,
         CNF.F second) {
     this.first=first;
     this.second=second;
     updateHashCode();
  }

  /**  Construct a new instance of the type _And. */
  public static _And mk(
           CNF.F first,
           CNF.F second) {
    return new _And(first, second);
  }

  // === list mimicking
  public And get(int index) {
    assert index==0;
    return this;
  }
  /*@pure*/public int size() {return 1;}
  public void copyTo(Pl.And[] arr, int offset) {
    arr[offset]=this;
  }
  public void copyTo(CNF.And[] arr, int offset) {
    arr[offset]=this;
  }

 
  // === Accessors ===
  /** Returns first. */
  public /*@pure*/CNF.F getFirst() {return first;}
  /** Returns second. */
  public /*@pure*/CNF.F getSecond() {return second;}
   // ==== Overriding inherited from Object
   @Override public _And clone() {
     return mk(first, second);
   }

   @Override public java.lang.String toString() {
     String retv= "And(";
     retv+=first;
     retv+=", ";
     retv+=second;
     retv+=")";
     return retv;
   }

   /** Implements structural equality. */
   @Override public boolean equals(Object o) {
     if (o == null) return false;
     if (!(o instanceof _And)) return false;
     _And oo = (_And)o;
     boolean retv = true;
     retv &= first==null ? oo.first == null : first.equals(oo.first);
     retv &= second==null ? oo.second == null : second.equals(oo.second);
     return retv;
   }

   private int hashCode;
   //** Since the class is immutable,  hashcode is computed just once */
   @Override public int hashCode() {
       return hashCode;
   }

   /** Stores the hash code value in {@code hashCode} */
   private void updateHashCode() {
     int hashCode = getClassName().hashCode();
     int nhc=777;        
     hashCode ^= getFirst()==null ? ++nhc : getFirst().hashCode();
     hashCode ^= getSecond()==null ? ++nhc : getSecond().hashCode();
   }

   // === Acceptors of visitors
   public <R> R accept(CNF.FVisitor<R> v) { return v.visit(this); }
   public <R> R accept(Pl.FVisitor<R> v) { return v.visit(this); }
   public <R> R accept(Pl.AndVisitor<R> v) { return v.visit(this); }
   public <R> R accept(CNF.AndVisitor<R> v) { return v.visit(this); }

   // ==== Aux
   public java.lang.String getClassName() { return "_And"; }
}

/* ===================== Template resources/ImplementationTemplate.vm type CNF.Or*/
public static class _Or implements Or {
  private final CNF.Clause first;
  private final CNF.Clause second;

  // === Constructors and Factories ===
  private _Or(
         CNF.Clause first,
         CNF.Clause second) {
     this.first=first;
     this.second=second;
     updateHashCode();
  }

  /**  Construct a new instance of the type _Or. */
  public static _Or mk(
           CNF.Clause first,
           CNF.Clause second) {
    return new _Or(first, second);
  }

  // === list mimicking
  public Or get(int index) {
    assert index==0;
    return this;
  }
  /*@pure*/public int size() {return 1;}
  public void copyTo(Pl.Or[] arr, int offset) {
    arr[offset]=this;
  }
  public void copyTo(CNF.Or[] arr, int offset) {
    arr[offset]=this;
  }

 
  // === Accessors ===
  /** Returns first. */
  public /*@pure*/CNF.Clause getFirst() {return first;}
  /** Returns second. */
  public /*@pure*/CNF.Clause getSecond() {return second;}
   // ==== Overriding inherited from Object
   @Override public _Or clone() {
     return mk(first, second);
   }

   @Override public java.lang.String toString() {
     String retv= "Or(";
     retv+=first;
     retv+=", ";
     retv+=second;
     retv+=")";
     return retv;
   }

   /** Implements structural equality. */
   @Override public boolean equals(Object o) {
     if (o == null) return false;
     if (!(o instanceof _Or)) return false;
     _Or oo = (_Or)o;
     boolean retv = true;
     retv &= first==null ? oo.first == null : first.equals(oo.first);
     retv &= second==null ? oo.second == null : second.equals(oo.second);
     return retv;
   }

   private int hashCode;
   //** Since the class is immutable,  hashcode is computed just once */
   @Override public int hashCode() {
       return hashCode;
   }

   /** Stores the hash code value in {@code hashCode} */
   private void updateHashCode() {
     int hashCode = getClassName().hashCode();
     int nhc=777;        
     hashCode ^= getFirst()==null ? ++nhc : getFirst().hashCode();
     hashCode ^= getSecond()==null ? ++nhc : getSecond().hashCode();
   }

   // === Acceptors of visitors
   public <R> R accept(Pl.OrVisitor<R> v) { return v.visit(this); }
   public <R> R accept(CNF.OrVisitor<R> v) { return v.visit(this); }
   public <R> R accept(CNF.FVisitor<R> v) { return v.visit(this); }
   public <R> R accept(Pl.FVisitor<R> v) { return v.visit(this); }
   public <R> R accept(CNF.ClauseVisitor<R> v) { return v.visit(this); }

   // ==== Aux
   public java.lang.String getClassName() { return "_Or"; }
}

/* ===================== Template resources/ImplementationTemplate.vm type CNF.Not*/
public static class _Not implements Not {
  private final Common.Var first;

  // === Constructors and Factories ===
  private _Not(
         Common.Var first) {
     this.first=first;
     updateHashCode();
  }

  /**  Construct a new instance of the type _Not. */
  public static _Not mk(
           Common.Var first) {
    return new _Not(first);
  }

  // === list mimicking
  public Not get(int index) {
    assert index==0;
    return this;
  }
  /*@pure*/public int size() {return 1;}
  public void copyTo(CNF.Not[] arr, int offset) {
    arr[offset]=this;
  }
  public void copyTo(Pl.Not[] arr, int offset) {
    arr[offset]=this;
  }

 
  // === Accessors ===
  /** Returns first. */
  public /*@pure*/Common.Var getFirst() {return first;}
   // ==== Overriding inherited from Object
   @Override public _Not clone() {
     return mk(first);
   }

   @Override public java.lang.String toString() {
     String retv= "Not(";
     retv+=first;
     retv+=")";
     return retv;
   }

   /** Implements structural equality. */
   @Override public boolean equals(Object o) {
     if (o == null) return false;
     if (!(o instanceof _Not)) return false;
     _Not oo = (_Not)o;
     boolean retv = true;
     retv &= first==null ? oo.first == null : first.equals(oo.first);
     return retv;
   }

   private int hashCode;
   //** Since the class is immutable,  hashcode is computed just once */
   @Override public int hashCode() {
       return hashCode;
   }

   /** Stores the hash code value in {@code hashCode} */
   private void updateHashCode() {
     int hashCode = getClassName().hashCode();
     int nhc=777;        
     hashCode ^= getFirst()==null ? ++nhc : getFirst().hashCode();
   }

   // === Acceptors of visitors
   public <R> R accept(CNF.LitVisitor<R> v) { return v.visit(this); }
   public <R> R accept(CNF.NotVisitor<R> v) { return v.visit(this); }
   public <R> R accept(CNF.FVisitor<R> v) { return v.visit(this); }
   public <R> R accept(Pl.NotVisitor<R> v) { return v.visit(this); }
   public <R> R accept(Pl.FVisitor<R> v) { return v.visit(this); }
   public <R> R accept(CNF.ClauseVisitor<R> v) { return v.visit(this); }

   // ==== Aux
   public java.lang.String getClassName() { return "_Not"; }
}

/* ===================== Template resources/ImplementationTemplate.vm type CNF.Lit*/

/* ===================== Template resources/ImplementationTemplate.vm type CNF.Clause*/

/* ===================== Template resources/ImplementationTemplate.vm type CNF.F*/

/* ===================== Template resources/AcceptorTemplate.vm type CNF.And*/
public interface AndAcceptor { <R> R accept(CNF.AndVisitor<R> v); }

/* ===================== Template resources/AcceptorTemplate.vm type CNF.Or*/
public interface OrAcceptor { <R> R accept(CNF.OrVisitor<R> v); }

/* ===================== Template resources/AcceptorTemplate.vm type CNF.Not*/
public interface NotAcceptor { <R> R accept(CNF.NotVisitor<R> v); }

/* ===================== Template resources/AcceptorTemplate.vm type CNF.Lit*/
public interface LitAcceptor { <R> R accept(CNF.LitVisitor<R> v); }

/* ===================== Template resources/AcceptorTemplate.vm type CNF.Clause*/
public interface ClauseAcceptor { <R> R accept(CNF.ClauseVisitor<R> v); }

/* ===================== Template resources/AcceptorTemplate.vm type CNF.F*/
public interface FAcceptor { <R> R accept(CNF.FVisitor<R> v); }

}