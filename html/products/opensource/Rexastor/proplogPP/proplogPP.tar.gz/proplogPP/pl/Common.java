package pl;
/* This class is automatically generated*/
/* Do not edit*/
public class Common { 
/* ===================== Template resources/VisitorTemplate.vm type Common.Var*/
/**
 * Visitor interface for the hierarchy under {@code Common.Var}.
 */
public interface VarVisitor<R> {
   R visit(Var n);
}
/*======== Default Visitor Template ==========
class DefaultVarVisitor<R> implements VarVisitor<R> {
  R eval(Var n) { return n.visit(this); }

  @Override
  public R visit(Var n) {
    return visit(n, eval(n.getFirst()));
  }
 
  @Override
  public R visit(Var n, R first) {
    assert false;
    return null;
  }
}
======== End of Default Visitor Template ==========*/

/* ===================== Template resources/InterfaceTemplate.vm type Common.Var*/
public static interface Var extends 
                        CNF.Lit,
                         VarAcceptor
{
  //@ensures \result==1;
  /*@pure*/public int size();
  //@ requires offset < arr.length;
  //@ modifies arr[offset];
  public void copyTo(Var[] arr, int offset);
  /** Getters for First. */
  public /*@pure*/String getFirst();
}
/* ===================== Template resources/MakerTemplate.vm type Common.Var*/
/**  Construct a new instance of the type Var. */
public static Var Var(String first) {
    return _Var.mk(first);
}
/* ===================== Template resources/ImplementationTemplate.vm type Common.Var*/
public static class _Var implements Var {
  private final String first;

  // === Constructors and Factories ===
  private _Var(
         String first) {
     this.first=first;
     updateHashCode();
  }

  /**  Construct a new instance of the type _Var. */
  public static _Var mk(
           String first) {
    return new _Var(first);
  }

  // === list mimicking
  public Var get(int index) {
    assert index==0;
    return this;
  }
  /*@pure*/public int size() {return 1;}
  public void copyTo(Common.Var[] arr, int offset) {
    arr[offset]=this;
  }

 
  // === Accessors ===
  /** Returns first. */
  public /*@pure*/String getFirst() {return first;}
   // ==== Overriding inherited from Object
   @Override public _Var clone() {
     return mk(first);
   }

   @Override public java.lang.String toString() {
     String retv= "Var(";
     retv+=first;
     retv+=")";
     return retv;
   }

   /** Implements structural equality. */
   @Override public boolean equals(Object o) {
     if (o == null) return false;
     if (!(o instanceof _Var)) return false;
     _Var oo = (_Var)o;
     boolean retv = true;
     retv &= first==null ? oo.first == null : first.equals(oo.first);
     return retv;
   }

   private int hashCode;
   //** Since the class is immutable,  hashcode is computed just once */
   @Override public int hashCode() {
       return hashCode;
   }

   /** Stores the hash code value in {@code hashCode} */
   private void updateHashCode() {
     int hashCode = getClassName().hashCode();
     int nhc=777;        
     hashCode ^= getFirst()==null ? ++nhc : getFirst().hashCode();
   }

   // === Acceptors of visitors
   public <R> R accept(Common.VarVisitor<R> v) { return v.visit(this); }
   public <R> R accept(CNF.LitVisitor<R> v) { return v.visit(this); }
   public <R> R accept(CNF.FVisitor<R> v) { return v.visit(this); }
   public <R> R accept(Pl.FVisitor<R> v) { return v.visit(this); }
   public <R> R accept(CNF.ClauseVisitor<R> v) { return v.visit(this); }

   // ==== Aux
   public java.lang.String getClassName() { return "_Var"; }
}

/* ===================== Template resources/AcceptorTemplate.vm type Common.Var*/
public interface VarAcceptor { <R> R accept(Common.VarVisitor<R> v); }

}