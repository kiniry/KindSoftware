package pl;
/* This class is automatically generated*/
/* Do not edit*/
public class Pl { 
/* ===================== Template resources/VisitorTemplate.vm type Pl.And*/
/**
 * Visitor interface for the hierarchy under {@code Pl.And}.
 */
public interface AndVisitor<R>  extends CNF.AndVisitor<R> {
   R visit(And n);
}
/*======== Default Visitor Template ==========
class DefaultAndVisitor<R> implements AndVisitor<R> {
  R eval(And n) { return n.visit(this); }

  @Override
  public R visit(And n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
  @Override
  public R visit(And n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
 
  @Override
  public R visit(And n, R first, R second) {
    assert false;
    return null;
  }
  @Override
  public R visit(And n, R first, R second) {
    assert false;
    return null;
  }
}
======== End of Default Visitor Template ==========*/

/* ===================== Template resources/VisitorTemplate.vm type Pl.Xor*/
/**
 * Visitor interface for the hierarchy under {@code Pl.Xor}.
 */
public interface XorVisitor<R> {
   R visit(Xor n);
}
/*======== Default Visitor Template ==========
class DefaultXorVisitor<R> implements XorVisitor<R> {
  R eval(Xor n) { return n.visit(this); }

  @Override
  public R visit(Xor n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
 
  @Override
  public R visit(Xor n, R first, R second) {
    assert false;
    return null;
  }
}
======== End of Default Visitor Template ==========*/

/* ===================== Template resources/VisitorTemplate.vm type Pl.Imp*/
/**
 * Visitor interface for the hierarchy under {@code Pl.Imp}.
 */
public interface ImpVisitor<R> {
   R visit(Imp n);
}
/*======== Default Visitor Template ==========
class DefaultImpVisitor<R> implements ImpVisitor<R> {
  R eval(Imp n) { return n.visit(this); }

  @Override
  public R visit(Imp n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
 
  @Override
  public R visit(Imp n, R first, R second) {
    assert false;
    return null;
  }
}
======== End of Default Visitor Template ==========*/

/* ===================== Template resources/VisitorTemplate.vm type Pl.Or*/
/**
 * Visitor interface for the hierarchy under {@code Pl.Or}.
 */
public interface OrVisitor<R>  extends CNF.OrVisitor<R> {
   R visit(Or n);
}
/*======== Default Visitor Template ==========
class DefaultOrVisitor<R> implements OrVisitor<R> {
  R eval(Or n) { return n.visit(this); }

  @Override
  public R visit(Or n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
  @Override
  public R visit(Or n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
 
  @Override
  public R visit(Or n, R first, R second) {
    assert false;
    return null;
  }
  @Override
  public R visit(Or n, R first, R second) {
    assert false;
    return null;
  }
}
======== End of Default Visitor Template ==========*/

/* ===================== Template resources/VisitorTemplate.vm type Pl.Not*/
/**
 * Visitor interface for the hierarchy under {@code Pl.Not}.
 */
public interface NotVisitor<R>  extends CNF.NotVisitor<R> {
   R visit(Not n);
}
/*======== Default Visitor Template ==========
class DefaultNotVisitor<R> implements NotVisitor<R> {
  R eval(Not n) { return n.visit(this); }

  @Override
  public R visit(Not n) {
    return visit(n, eval(n.getFirst()));
  }
  @Override
  public R visit(Not n) {
    return visit(n, eval(n.getFirst()));
  }
 
  @Override
  public R visit(Not n, R first) {
    assert false;
    return null;
  }
  @Override
  public R visit(Not n, R first) {
    assert false;
    return null;
  }
}
======== End of Default Visitor Template ==========*/

/* ===================== Template resources/VisitorTemplate.vm type Pl.F*/
/**
 * Visitor interface for the hierarchy under {@code Pl.F}.
 */
public interface FVisitor<R>  extends CNF.FVisitor<R>, 
            Pl.NotVisitor<R>, 
            Pl.XorVisitor<R>, 
            Pl.ImpVisitor<R>, 
            Pl.AndVisitor<R>, 
            Pl.OrVisitor<R> {
}
/*======== Default Visitor Template ==========
class DefaultFVisitor<R> implements FVisitor<R> {
  R eval(F n) { return n.visit(this); }

  @Override
  public R visit(Var n) {
    return visit(n, eval(n.getFirst()));
  }
  @Override
  public R visit(Xor n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
  @Override
  public R visit(Not n) {
    return visit(n, eval(n.getFirst()));
  }
  @Override
  public R visit(Imp n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
  @Override
  public R visit(Or n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
  @Override
  public R visit(Or n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
  @Override
  public R visit(Not n) {
    return visit(n, eval(n.getFirst()));
  }
  @Override
  public R visit(And n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
  @Override
  public R visit(And n) {
    return visit(n, eval(n.getFirst()), eval(n.getSecond()));
  }
 
  @Override
  public R visit(Var n, R first) {
    assert false;
    return null;
  }
  @Override
  public R visit(Xor n, R first, R second) {
    assert false;
    return null;
  }
  @Override
  public R visit(Not n, R first) {
    assert false;
    return null;
  }
  @Override
  public R visit(Imp n, R first, R second) {
    assert false;
    return null;
  }
  @Override
  public R visit(Or n, R first, R second) {
    assert false;
    return null;
  }
  @Override
  public R visit(Or n, R first, R second) {
    assert false;
    return null;
  }
  @Override
  public R visit(Not n, R first) {
    assert false;
    return null;
  }
  @Override
  public R visit(And n, R first, R second) {
    assert false;
    return null;
  }
  @Override
  public R visit(And n, R first, R second) {
    assert false;
    return null;
  }
}
======== End of Default Visitor Template ==========*/

/* ===================== Template resources/InterfaceTemplate.vm type Pl.And*/
public static interface And extends 
                        Pl.F,
                         AndAcceptor
{
  //@ensures \result==1;
  /*@pure*/public int size();
  //@ requires offset < arr.length;
  //@ modifies arr[offset];
  public void copyTo(And[] arr, int offset);
  /** Getters for First. */
  public /*@pure*/Pl.F getFirst();
  /** Getters for Second. */
  public /*@pure*/Pl.F getSecond();
}
/* ===================== Template resources/InterfaceTemplate.vm type Pl.Xor*/
public static interface Xor extends 
                        Pl.F,
                         XorAcceptor
{
  //@ensures \result==1;
  /*@pure*/public int size();
  //@ requires offset < arr.length;
  //@ modifies arr[offset];
  public void copyTo(Xor[] arr, int offset);
  /** Getters for First. */
  public /*@pure*/Pl.F getFirst();
  /** Getters for Second. */
  public /*@pure*/Pl.F getSecond();
}
/* ===================== Template resources/InterfaceTemplate.vm type Pl.Imp*/
public static interface Imp extends 
                        Pl.F,
                         ImpAcceptor
{
  //@ensures \result==1;
  /*@pure*/public int size();
  //@ requires offset < arr.length;
  //@ modifies arr[offset];
  public void copyTo(Imp[] arr, int offset);
  /** Getters for First. */
  public /*@pure*/Pl.F getFirst();
  /** Getters for Second. */
  public /*@pure*/Pl.F getSecond();
}
/* ===================== Template resources/InterfaceTemplate.vm type Pl.Or*/
public static interface Or extends 
                        Pl.F,
                         OrAcceptor
{
  //@ensures \result==1;
  /*@pure*/public int size();
  //@ requires offset < arr.length;
  //@ modifies arr[offset];
  public void copyTo(Or[] arr, int offset);
  /** Getters for First. */
  public /*@pure*/Pl.F getFirst();
  /** Getters for Second. */
  public /*@pure*/Pl.F getSecond();
}
/* ===================== Template resources/InterfaceTemplate.vm type Pl.Not*/
public static interface Not extends 
                        Pl.F,
                         NotAcceptor
{
  //@ensures \result==1;
  /*@pure*/public int size();
  //@ requires offset < arr.length;
  //@ modifies arr[offset];
  public void copyTo(Not[] arr, int offset);
  /** Getters for First. */
  public /*@pure*/Pl.F getFirst();
}
/* ===================== Template resources/InterfaceTemplate.vm type Pl.F*/
public static interface F extends 
      FAcceptor
                    {}
/* ===================== Template resources/MakerTemplate.vm type Pl.And*/
/**  Construct a new instance of the type And. */
public static And And(Pl.F first,
          Pl.F second) {
    return _And.mk(first,second);
}
/* ===================== Template resources/MakerTemplate.vm type Pl.Xor*/
/**  Construct a new instance of the type Xor. */
public static Xor Xor(Pl.F first,
          Pl.F second) {
    return _Xor.mk(first,second);
}
/* ===================== Template resources/MakerTemplate.vm type Pl.Imp*/
/**  Construct a new instance of the type Imp. */
public static Imp Imp(Pl.F first,
          Pl.F second) {
    return _Imp.mk(first,second);
}
/* ===================== Template resources/MakerTemplate.vm type Pl.Or*/
/**  Construct a new instance of the type Or. */
public static Or Or(Pl.F first,
          Pl.F second) {
    return _Or.mk(first,second);
}
/* ===================== Template resources/MakerTemplate.vm type Pl.Not*/
/**  Construct a new instance of the type Not. */
public static Not Not(Pl.F first) {
    return _Not.mk(first);
}
/* ===================== Template resources/MakerTemplate.vm type Pl.F*/
/* ===================== Template resources/ImplementationTemplate.vm type Pl.And*/
public static class _And implements And {
  private final Pl.F first;
  private final Pl.F second;

  // === Constructors and Factories ===
  private _And(
         Pl.F first,
         Pl.F second) {
     this.first=first;
     this.second=second;
     updateHashCode();
  }

  /**  Construct a new instance of the type _And. */
  public static _And mk(
           Pl.F first,
           Pl.F second) {
    return new _And(first, second);
  }

  // === list mimicking
  public And get(int index) {
    assert index==0;
    return this;
  }
  /*@pure*/public int size() {return 1;}
  public void copyTo(Pl.And[] arr, int offset) {
    arr[offset]=this;
  }

 
  // === Accessors ===
  /** Returns first. */
  public /*@pure*/Pl.F getFirst() {return first;}
  /** Returns second. */
  public /*@pure*/Pl.F getSecond() {return second;}
   // ==== Overriding inherited from Object
   @Override public _And clone() {
     return mk(first, second);
   }

   @Override public java.lang.String toString() {
     String retv= "And(";
     retv+=first;
     retv+=", ";
     retv+=second;
     retv+=")";
     return retv;
   }

   /** Implements structural equality. */
   @Override public boolean equals(Object o) {
     if (o == null) return false;
     if (!(o instanceof _And)) return false;
     _And oo = (_And)o;
     boolean retv = true;
     retv &= first==null ? oo.first == null : first.equals(oo.first);
     retv &= second==null ? oo.second == null : second.equals(oo.second);
     return retv;
   }

   private int hashCode;
   //** Since the class is immutable,  hashcode is computed just once */
   @Override public int hashCode() {
       return hashCode;
   }

   /** Stores the hash code value in {@code hashCode} */
   private void updateHashCode() {
     int hashCode = getClassName().hashCode();
     int nhc=777;        
     hashCode ^= getFirst()==null ? ++nhc : getFirst().hashCode();
     hashCode ^= getSecond()==null ? ++nhc : getSecond().hashCode();
   }

   // === Acceptors of visitors
   public <R> R accept(Pl.FVisitor<R> v) { return v.visit(this); }
   public <R> R accept(Pl.AndVisitor<R> v) { return v.visit(this); }

   // ==== Aux
   public java.lang.String getClassName() { return "_And"; }
}

/* ===================== Template resources/ImplementationTemplate.vm type Pl.Xor*/
public static class _Xor implements Xor {
  private final Pl.F first;
  private final Pl.F second;

  // === Constructors and Factories ===
  private _Xor(
         Pl.F first,
         Pl.F second) {
     this.first=first;
     this.second=second;
     updateHashCode();
  }

  /**  Construct a new instance of the type _Xor. */
  public static _Xor mk(
           Pl.F first,
           Pl.F second) {
    return new _Xor(first, second);
  }

  // === list mimicking
  public Xor get(int index) {
    assert index==0;
    return this;
  }
  /*@pure*/public int size() {return 1;}
  public void copyTo(Pl.Xor[] arr, int offset) {
    arr[offset]=this;
  }

 
  // === Accessors ===
  /** Returns first. */
  public /*@pure*/Pl.F getFirst() {return first;}
  /** Returns second. */
  public /*@pure*/Pl.F getSecond() {return second;}
   // ==== Overriding inherited from Object
   @Override public _Xor clone() {
     return mk(first, second);
   }

   @Override public java.lang.String toString() {
     String retv= "Xor(";
     retv+=first;
     retv+=", ";
     retv+=second;
     retv+=")";
     return retv;
   }

   /** Implements structural equality. */
   @Override public boolean equals(Object o) {
     if (o == null) return false;
     if (!(o instanceof _Xor)) return false;
     _Xor oo = (_Xor)o;
     boolean retv = true;
     retv &= first==null ? oo.first == null : first.equals(oo.first);
     retv &= second==null ? oo.second == null : second.equals(oo.second);
     return retv;
   }

   private int hashCode;
   //** Since the class is immutable,  hashcode is computed just once */
   @Override public int hashCode() {
       return hashCode;
   }

   /** Stores the hash code value in {@code hashCode} */
   private void updateHashCode() {
     int hashCode = getClassName().hashCode();
     int nhc=777;        
     hashCode ^= getFirst()==null ? ++nhc : getFirst().hashCode();
     hashCode ^= getSecond()==null ? ++nhc : getSecond().hashCode();
   }

   // === Acceptors of visitors
   public <R> R accept(Pl.XorVisitor<R> v) { return v.visit(this); }
   public <R> R accept(Pl.FVisitor<R> v) { return v.visit(this); }

   // ==== Aux
   public java.lang.String getClassName() { return "_Xor"; }
}

/* ===================== Template resources/ImplementationTemplate.vm type Pl.Imp*/
public static class _Imp implements Imp {
  private final Pl.F first;
  private final Pl.F second;

  // === Constructors and Factories ===
  private _Imp(
         Pl.F first,
         Pl.F second) {
     this.first=first;
     this.second=second;
     updateHashCode();
  }

  /**  Construct a new instance of the type _Imp. */
  public static _Imp mk(
           Pl.F first,
           Pl.F second) {
    return new _Imp(first, second);
  }

  // === list mimicking
  public Imp get(int index) {
    assert index==0;
    return this;
  }
  /*@pure*/public int size() {return 1;}
  public void copyTo(Pl.Imp[] arr, int offset) {
    arr[offset]=this;
  }

 
  // === Accessors ===
  /** Returns first. */
  public /*@pure*/Pl.F getFirst() {return first;}
  /** Returns second. */
  public /*@pure*/Pl.F getSecond() {return second;}
   // ==== Overriding inherited from Object
   @Override public _Imp clone() {
     return mk(first, second);
   }

   @Override public java.lang.String toString() {
     String retv= "Imp(";
     retv+=first;
     retv+=", ";
     retv+=second;
     retv+=")";
     return retv;
   }

   /** Implements structural equality. */
   @Override public boolean equals(Object o) {
     if (o == null) return false;
     if (!(o instanceof _Imp)) return false;
     _Imp oo = (_Imp)o;
     boolean retv = true;
     retv &= first==null ? oo.first == null : first.equals(oo.first);
     retv &= second==null ? oo.second == null : second.equals(oo.second);
     return retv;
   }

   private int hashCode;
   //** Since the class is immutable,  hashcode is computed just once */
   @Override public int hashCode() {
       return hashCode;
   }

   /** Stores the hash code value in {@code hashCode} */
   private void updateHashCode() {
     int hashCode = getClassName().hashCode();
     int nhc=777;        
     hashCode ^= getFirst()==null ? ++nhc : getFirst().hashCode();
     hashCode ^= getSecond()==null ? ++nhc : getSecond().hashCode();
   }

   // === Acceptors of visitors
   public <R> R accept(Pl.ImpVisitor<R> v) { return v.visit(this); }
   public <R> R accept(Pl.FVisitor<R> v) { return v.visit(this); }

   // ==== Aux
   public java.lang.String getClassName() { return "_Imp"; }
}

/* ===================== Template resources/ImplementationTemplate.vm type Pl.Or*/
public static class _Or implements Or {
  private final Pl.F first;
  private final Pl.F second;

  // === Constructors and Factories ===
  private _Or(
         Pl.F first,
         Pl.F second) {
     this.first=first;
     this.second=second;
     updateHashCode();
  }

  /**  Construct a new instance of the type _Or. */
  public static _Or mk(
           Pl.F first,
           Pl.F second) {
    return new _Or(first, second);
  }

  // === list mimicking
  public Or get(int index) {
    assert index==0;
    return this;
  }
  /*@pure*/public int size() {return 1;}
  public void copyTo(Pl.Or[] arr, int offset) {
    arr[offset]=this;
  }

 
  // === Accessors ===
  /** Returns first. */
  public /*@pure*/Pl.F getFirst() {return first;}
  /** Returns second. */
  public /*@pure*/Pl.F getSecond() {return second;}
   // ==== Overriding inherited from Object
   @Override public _Or clone() {
     return mk(first, second);
   }

   @Override public java.lang.String toString() {
     String retv= "Or(";
     retv+=first;
     retv+=", ";
     retv+=second;
     retv+=")";
     return retv;
   }

   /** Implements structural equality. */
   @Override public boolean equals(Object o) {
     if (o == null) return false;
     if (!(o instanceof _Or)) return false;
     _Or oo = (_Or)o;
     boolean retv = true;
     retv &= first==null ? oo.first == null : first.equals(oo.first);
     retv &= second==null ? oo.second == null : second.equals(oo.second);
     return retv;
   }

   private int hashCode;
   //** Since the class is immutable,  hashcode is computed just once */
   @Override public int hashCode() {
       return hashCode;
   }

   /** Stores the hash code value in {@code hashCode} */
   private void updateHashCode() {
     int hashCode = getClassName().hashCode();
     int nhc=777;        
     hashCode ^= getFirst()==null ? ++nhc : getFirst().hashCode();
     hashCode ^= getSecond()==null ? ++nhc : getSecond().hashCode();
   }

   // === Acceptors of visitors
   public <R> R accept(Pl.OrVisitor<R> v) { return v.visit(this); }
   public <R> R accept(Pl.FVisitor<R> v) { return v.visit(this); }

   // ==== Aux
   public java.lang.String getClassName() { return "_Or"; }
}

/* ===================== Template resources/ImplementationTemplate.vm type Pl.Not*/
public static class _Not implements Not {
  private final Pl.F first;

  // === Constructors and Factories ===
  private _Not(
         Pl.F first) {
     this.first=first;
     updateHashCode();
  }

  /**  Construct a new instance of the type _Not. */
  public static _Not mk(
           Pl.F first) {
    return new _Not(first);
  }

  // === list mimicking
  public Not get(int index) {
    assert index==0;
    return this;
  }
  /*@pure*/public int size() {return 1;}
  public void copyTo(Pl.Not[] arr, int offset) {
    arr[offset]=this;
  }

 
  // === Accessors ===
  /** Returns first. */
  public /*@pure*/Pl.F getFirst() {return first;}
   // ==== Overriding inherited from Object
   @Override public _Not clone() {
     return mk(first);
   }

   @Override public java.lang.String toString() {
     String retv= "Not(";
     retv+=first;
     retv+=")";
     return retv;
   }

   /** Implements structural equality. */
   @Override public boolean equals(Object o) {
     if (o == null) return false;
     if (!(o instanceof _Not)) return false;
     _Not oo = (_Not)o;
     boolean retv = true;
     retv &= first==null ? oo.first == null : first.equals(oo.first);
     return retv;
   }

   private int hashCode;
   //** Since the class is immutable,  hashcode is computed just once */
   @Override public int hashCode() {
       return hashCode;
   }

   /** Stores the hash code value in {@code hashCode} */
   private void updateHashCode() {
     int hashCode = getClassName().hashCode();
     int nhc=777;        
     hashCode ^= getFirst()==null ? ++nhc : getFirst().hashCode();
   }

   // === Acceptors of visitors
   public <R> R accept(Pl.NotVisitor<R> v) { return v.visit(this); }
   public <R> R accept(Pl.FVisitor<R> v) { return v.visit(this); }

   // ==== Aux
   public java.lang.String getClassName() { return "_Not"; }
}

/* ===================== Template resources/ImplementationTemplate.vm type Pl.F*/

/* ===================== Template resources/AcceptorTemplate.vm type Pl.And*/
public interface AndAcceptor { <R> R accept(Pl.AndVisitor<R> v); }

/* ===================== Template resources/AcceptorTemplate.vm type Pl.Xor*/
public interface XorAcceptor { <R> R accept(Pl.XorVisitor<R> v); }

/* ===================== Template resources/AcceptorTemplate.vm type Pl.Imp*/
public interface ImpAcceptor { <R> R accept(Pl.ImpVisitor<R> v); }

/* ===================== Template resources/AcceptorTemplate.vm type Pl.Or*/
public interface OrAcceptor { <R> R accept(Pl.OrVisitor<R> v); }

/* ===================== Template resources/AcceptorTemplate.vm type Pl.Not*/
public interface NotAcceptor { <R> R accept(Pl.NotVisitor<R> v); }

/* ===================== Template resources/AcceptorTemplate.vm type Pl.F*/
public interface FAcceptor { <R> R accept(Pl.FVisitor<R> v); }

}