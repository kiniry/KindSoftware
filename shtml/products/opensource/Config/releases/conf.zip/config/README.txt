To setup environment variables 
  . setenv (while being in config directory)

=== Configuration program ==
To run: 
  conf file

Examples of input files in the directory examples/.

=== SAT solver ==
To run 
  sat [-q] file

-q makes it less verbose.
Examples of input files in the directory examples_sat/.


