public class Queens {
    static void print(int column, int row) {
        System.out.print("" + (column * 100 + row));
    }

    static void print(boolean sign, int column, int row) {
        print(sign ? "+" : "-");
        print(column, row);
    }


    static void print(String s) {
        System.out.print(s);
    }
    static void println(String s) {
        System.out.println(s);
    }

    static int clauseCnt = 0;
    static void endClause() {
        println(" 0");
        clauseCnt++;
    }

    public static void main(String[] args) {
        final int N = 40;

        println("c // each column as at least 1 queen");
        for (int i = 1; i <= N; i++) {
            for (int row = 1; row <= N; row++)  {
                print(i, row); print(" "); 
            }
            endClause();
        }

        println("c // exlude queens with the same rows");        
        for (int row = 1; row <= N; row++) {
            for (int col = 1; col <= N; col++) {
                for (int col1 = col + 1; col1 <= N; col1++) {
                    print(false, col, row); print(" "); print(false, col1, row); endClause();
                }
            }
        }
        println("c // exlude queens with the same columns");        
        for (int col = 1; col <= N; col++) {
            for (int row = 1; row <= N; row++) {
                for (int row1 = row + 1; row1 <= N; row1++) {
                    print(false, col, row); print(" "); print(false, col, row1); endClause();
                }
            }
        }
        println("c // diag ");
        for (int col1 = 1; col1 <= N; col1++)  {
        for (int row1 = 1; row1 <= N; row1++)  {
        for (int col2 = 1; col2 <= N; col2++) {
        for (int row2 = 1; row2 <= N; row2++) {
                if (Math.abs(col1 - col2) == Math.abs(row1 - row2) && (col1 < col2)) {
                    print(false, col1, row1); print(" "); print(false, col2, row2); endClause();
                }
        }}}}

        System.out.println("p cnf " + N + "" + N  + " " + clauseCnt);
    }

}