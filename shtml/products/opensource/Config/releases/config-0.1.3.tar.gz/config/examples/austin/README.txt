--- Description ---

 These feature models are made available from the University of
 Texas at Austin by the Product Line Research Architecture
 research group at http://www.cs.utexas.edu/users/schwartz/

 The format of these feature models uses the GUIDSL tool
 in the AHEAD tool suite at the above URL.

 for questions or comments, contact Don Batory at
 batory@cs.utexas.edu


---- Formats --- 
 The files .m are the original feature models from University of
Texas, the .cnf files are dumps from the guidsl tool (part of the
AHEAD Tool suite), the .fm files are in the satconfig format.
The script convert.sed was used to obtain .fm from .cnf.
