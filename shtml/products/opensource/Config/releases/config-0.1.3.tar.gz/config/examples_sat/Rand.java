import java.util.*;

public class Rand {
    public static void main(String[] args) {
        Random rand = new Random();
        final int NC = 40;
        final int NV = 10;

        System.out.println("c  #var #cls");
        System.out.println("p cnf " + NV + " " + NC);
        for (int i = 0; i < NC; i++) {
            for (int lit = 0; lit < 3; lit++) {
                boolean sign = (rand.nextInt() & 1) != 0;
                int var = rand.nextInt(NV) + 1;
                System.out.print((sign ? "+" : "-") + var + " ");
            } 
            System.out.println("0");
        }

        System.out.println("%\n0");
    }
}