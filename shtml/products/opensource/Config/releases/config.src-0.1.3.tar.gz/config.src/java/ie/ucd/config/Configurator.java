package ie.ucd.config;

import java.util.*;
import ie.ucd.solver.*;

/**
 * Class implementing an interactive cofigurator for Boolean variables
 * using a SAT solver to do the reasoning.
 * @author Mikolas Janota
 */
public class Configurator {
    private /*@non_null*/Collection<Variable> vars;
    private /*@non_null*/Set<Clause> clauses;

    private /*@non_null*/Map<Variable, Set<Clause>> proofs = 
        new HashMap<Variable, Set<Clause>>();
    // literals that whose conjunction to the constrain yields a sat fla
    private  /*@non_null*/Set<Literal> possibleVals = new HashSet<Literal>(); 
    // literals that whose conjunction to the constrain yields an unsat fla
    private  /*@non_null*/Set<Literal> disabledVals = new HashSet<Literal>();

    // literals that correspond to user decisions
    private /*@non_null*/HashSet<Literal> userDecisions = new HashSet<Literal>();


    /**
     *  Constructs a new instance of Configurator.
     * @param vars the variable universum
     * @param clauses The set of fixed constraints, must be only 
     *         on the variables from {@code vars}.
     *         All the following computations will be done modolo
     *         these constraints.  
     */
    public /*@pure*/ Configurator(/*@non_null*/Collection<Variable> vars, 
                                  /*@non_null*/Set<Clause> clauses) {
        this.vars = vars;
        this.clauses = clauses;
        //TODO: check that the clauses are really on the given variables
    }

    /** Gets a set of literals corresponding to the user's decisions */
    public /*@pure non_null*/Set<Literal> getUserDecisions() { 
       return userDecisions; 
    }

    /** Returns a map from variables to explanations why they were locked.
     * A variable appears on the lefthand side iff it has been locked. */
    public /*@pure non_null*/Map<Variable, Set<Clause>> getProofs() {
        return this.proofs; 
    }


    /**
     * Computes legal domains for variables that have not been set by the user.
     * @return A map from variables to their legal domains. 
     *     A variable appears on the lefthand side iff it's not been set
     *     by the user.
     */
    public /*@non_null*/Map<Variable, Set<Boolean>> testUnassigned() {
        return testVars(getUnassigned());
    }

    /**
     * Test legal domain of all the variables.
     * @return A map from variables from their legal domains. 
     *      A variable is on the lefthand side iff it's been given 
     *      in the constructor.
     */
    public /*@non_null*/Map<Variable, Set<Boolean>> testVars() {
        return testVars(vars);
    }


    /** Asserts a user decision.
     * @param l a literal corresponding to a user decision to be asserted
     */
    public void setDecision(/*@non_null*/Literal l) {
        userDecisions.add(l);
        possibleVals.clear();
    }

    /** Asserts a user decision that a given variable must be {@code true}.
     * @param v a variable that is decided to be {@code true}
     */
    public void select(/*@non_null*/Variable v) {
        setDecision(Literal.getLiteral(true, v));
    }

    /** Asserts a user decision that a given variable must be {@code false}.
     * @param v a variable that is decided to be {@code false}
     */
    public void eliminate(/*@non_null*/Variable v) {
        setDecision(Literal.getLiteral(false, v));
    }

    /** Retract a decision made for {@code v}. 
     *  It is assumed some decision regarding {@code v} has been made. */
    public void retract(/*@non_null*/Variable v) {
        // find decision corresponding to v
        Literal decision = null;
        for (Literal l : userDecisions) {
            if (l.getVariable().equals(v)) {
                decision = l;
                break;
            }
        }
        assert decision != null;
        retract(decision);
    }

    /** Retract decision made for {@code v} 
     *  It is assumed some decision regarding {@code v} has been made. */
    public void retract(Literal decision) {
        userDecisions.remove(decision);
        disabledVals.clear();
    }


    /**
     * Compute a satisfying valuation under the current decisions and constraints.
     * @return A map from variables to their values in the valuations.
     *    A variable is on the lefthand side iff it's been specified 
     *    in the constructor. It is assumed that the current constraints
     *    are SAT.
     */
    public /*@non_null*/Map<Variable, Boolean> computeModel() {
        Solver s = new Solver();
        Set<Clause> cls = new HashSet<Clause>(clauses);
        cls.addAll(litsToUnits(userDecisions));
        s.init(cls);
        boolean r = s.solve();
        assert r;
        return s.getModel();
    }


    // Compute legal domains for the given variables.
    private Map<Variable, Set<Boolean>> testVars(Iterable<Variable> vs) {
        proofs.clear();
        Map<Variable, Set<Boolean>> retv = new HashMap<Variable, Set<Boolean>>();
        for (Variable v : vs) {
            retv.put(v, testVar(v));
        }
        return retv;
    }


    // Compute legal domain for the given variable.
    private Set<Boolean> testVar(Variable v) {
        Set<Boolean> retv = new HashSet<Boolean>(2);
        boolean canBeOne = testVal(true, v);
        boolean canBeZero = testVal(false, v);
        if (canBeOne) retv.add(true);
        if (canBeZero) retv.add(false);
        return retv;
    }

    // Compute if the given value is legal.
    private boolean testVal(boolean sign, Variable v) {
        Literal val = Literal.getLiteral(sign, v);
        if (possibleVals.contains(val)) return true;
        if (disabledVals.contains(val.not())) return false;

        Solver s = new Solver();
        Set<Clause> cls = new HashSet<Clause>(clauses);

        cls.addAll(litsToUnits(userDecisions));
        cls.addAll(litsToUnits(disabledVals));

        Clause unit = new Clause(val);
        cls.add(unit);

        s.init(cls);
        boolean retv = s.solve();
        if (retv) {
            // add the model's vals to the possible vals
            Map<Variable, Boolean> model = s.getModel();
            for (Map.Entry<Variable, Boolean> e: model.entrySet()) {
                possibleVals.add(Literal.getLiteral(e.getValue(), e.getKey()));
            }
        } else {
            // record refutation
            Set<Clause> p = s.computeProof();
            p.remove(unit); // remove the actual tested value from the proof
            proofs.put(v, p);
            disabledVals.add(val.not()); // record the impossible value
        }
        return retv;
    }

    // Returns the set of variables that have been assigned a value by user.
    private Set<Variable> getDecidedVars() {
        Set<Variable> retv = new HashSet<Variable>();
        for (Literal l : userDecisions) retv.add(l.getVariable());
        return retv;
    }

    // Returns the set of variables that haven't been assigned a value by user.
    Set<Variable> getUnassigned() {
        Set<Variable> retv = new HashSet<Variable>(vars);
        retv.removeAll(getDecidedVars());
        return retv;
    }

    // Map a collection literal to a collection of corresponding unit clauses.
    // TODO: move this somewhere else
    Set<Clause> litsToUnits(Iterable<Literal> lits) {
        HashSet<Clause> retv = new HashSet<Clause>();
        for (Literal l : lits)  {
            Clause c = new Clause();
            c.add(l);
            retv.add(c);
        }
        return retv;
    }

    private static void test1() {
        Set<Variable> vars = new HashSet<Variable>();
        Variable x = Variable.getVariable("x"); vars.add(x);
        Variable y = Variable.getVariable("y"); vars.add(y);
        Variable z = Variable.getVariable("z"); vars.add(z);
        assert vars.size() == 3;

        Set<Clause> cls = new HashSet<Clause>();
        Clause c1 = new Clause(Literal.getLiteral(false, x), 
                               Literal.getLiteral(true, y)); // x ==> y
        cls.add(c1);

        Clause c2 = new Clause(Literal.getLiteral(false, z), 
                               Literal.getLiteral(false, y)); // not(z & y)
        cls.add(c2);
        assert cls.size() == 2;

        Map<Variable, Set<Boolean>> consequence;
        // possible domains (empty domain should not occur anywhere)
        Set<Boolean> d00 = new HashSet<Boolean>();
        Set<Boolean> d01 = new HashSet<Boolean>();
        Set<Boolean> d11 = new HashSet<Boolean>();
        d00.add(false);
        d01.add(true); d01.add(false);
        d11.add(true);

        // init
        Configurator conf = new Configurator(vars, cls);

        // calculate consequence
        consequence = conf.testUnassigned();

        assert consequence.keySet().size() == 3;
        assert consequence.get(x).equals(d01);
        assert consequence.get(y).equals(d01);
        assert consequence.get(z).equals(d01);

        // assert x
        conf.select(x);

        // calculate consequence
        consequence = conf.testUnassigned();

        assert consequence.keySet().size() == 2;
        assert consequence.get(y).equals(d11);
        assert consequence.get(z).equals(d00);

        // go back by retracting the assertion of x
        conf.retract(x);

        // calculate consequence
        consequence = conf.testUnassigned();

        // all unlocked and unassigned again
        assert consequence.keySet().size() == 3;
        assert consequence.get(x).equals(d01);
        assert consequence.get(y).equals(d01);
        assert consequence.get(z).equals(d01);
    }

    /** Testing purpose only. */
    public static void main(String[] args) {
        test1();
        System.exit(0);
    }
}

