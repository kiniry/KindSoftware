package ie.ucd.config.reading;

import ie.ucd.solver.Clause;
import ie.ucd.solver.Variable;
import ie.ucd.solver.Literal;

import java.io.*;
import java.util.*;


/**
 * A simple reader of clauses.
 *
 * @author Mikolas Janota
 */
public class ClauseReader {
    private InputStream in;
    private Set<Variable> vars = new HashSet<Variable>();
    private List<Variable> varList = new LinkedList<Variable>();
    private Set<Clause> clauses = new HashSet<Clause>();
    private String errorStr = "no error";


        static boolean isLetter(char c) {
            return Character.isLetter(c) || c=='_';
        }
        static boolean isLetterOrDigit(char c) {
            return isLetter(c) || Character.isDigit(c);
        }


    public ClauseReader(InputStream in) {
        this.in = in;
    }

    private static int skipWhiteSpace(InputStreamReader r) throws IOException {
        int c;
        while ((c = r.read()) != -1) {
            if (!Character.isWhitespace(c)) break;
        }
        return c;
    }

    public ClauseReaderOutput read() throws IOException {
        InputStreamReader reader = new InputStreamReader(in);
        int clauseCounter = 0;
        while (reader.ready()) {
            int c = skipWhiteSpace(reader);
            while (c == '/') {
                while ((c = reader.read()) != -1 && c != '\n');
                c = skipWhiteSpace(reader);
            }

            String clS = "";
            while (c != -1 && c != ';') {
                clS += (char)c;
                c = reader.read();
            }
            if (c == -1 && !removeWhiteSpace(clS).equals("")) { 
                errorStr = " Garbage after the last clause "; return null; 
            }
            if (c == -1) break;
            ++clauseCounter;
            Set<Clause> cls = parseConstraint(clS);
            if (cls == null) { errorStr = "Error reading constraint " + clS; return null; }
            clauses.addAll(cls);
        }

        return new ClauseReaderOutput(varList, clauses);
    }

    public String getErrorDescription() {
        return errorStr;
    }

    private Variable getVar(String id) {
        Variable retv = Variable.getVariable(id);
        if (!vars.contains(retv)) varList.add(retv);
        vars.add(retv);
        return retv;
    }

    public  Set<Clause> parseConstraint(String constraintString) throws java.io.IOException {
        //        System.out.println("Parsing " + constraintString);
        ConstraintParser cp = new ConstraintParser(constraintString);
        return cp.parseConstraint();
    }


    private class ConstraintParser {
        private final String IFF = "IFF";
        private final String IMPL = "IMPL";
        private final String EXCL = "EXCL";

        private int pos;
        private String s;
        ConstraintParser(String s) { this.s = s; this.pos = 0;}



        private String getId() {
            String id = "";
            if  (pos < s.length() && isLetter(s.charAt(pos))) { 
                id += s.charAt(pos++); 
            } else return null;
            
            while  (pos < s.length() && isLetterOrDigit(s.charAt(pos))) 
                id += s.charAt(pos++);
            
            return id;
        }

        private void skipWhiteSpace() { 
            while (pos < s.length() && Character.isWhitespace(s.charAt(pos))) ++pos;
        }

        private Set<Clause> parseEXCL() throws java.io.IOException {
            String EXCLStr = getId(); skipWhiteSpace();
            assert EXCLStr.equals(EXCL);
            ArrayList<String> lits = new ArrayList<String>();
            ArrayList<Variable> litsIndx = new ArrayList<Variable>();
            while (pos < s.length()) {
                String lstr = getId();
                if (lstr == null) return null;
                lits.add(lstr); skipWhiteSpace();
                litsIndx.add(getVar(lstr));
            }

            Set<Clause> retv = new HashSet<Clause>();
            for (int i = 0; i < litsIndx.size() - 1; i++) {
                for (int j = i + 1; j < litsIndx.size(); j++) {
                    retv.add(Clause.createExcl(litsIndx.get(i), litsIndx.get(j)));
                }
            }

            return retv;
        }

        private Set<Clause> parseIFF() throws java.io.IOException {
            String iffStr = getId(); skipWhiteSpace();
            String aStr = getId(); skipWhiteSpace();
            String bStr = getId();
            assert iffStr.equals(IFF);
            if (aStr == null || bStr == null) return null;
            Variable a = getVar(aStr);
            Variable b = getVar(bStr);
            Set<Clause> retv = new HashSet<Clause>();
            retv.add(Clause.createImplies(a, b));
            retv.add(Clause.createImplies(b, a));
            return retv;
        }

        private Set<Clause> parseIMPL() throws java.io.IOException {
            String iffStr = getId(); skipWhiteSpace();
            String aStr = getId(); skipWhiteSpace();
            String bStr = getId();
            assert iffStr.equals(IMPL);
            if (aStr == null || bStr == null) return null;
            Variable a = getVar(aStr);
            Variable b = getVar(bStr);
            Set<Clause> retv = new HashSet<Clause>();
            retv.add(Clause.createImplies(a, b));
            return retv;
        }


        public Set<Clause> parseConstraint() throws java.io.IOException {
            skipWhiteSpace();
            String kw = getId();
            pos = 0;
            if (kw == null) return parseClause();

            skipWhiteSpace();
            if (kw.equals(IFF)) return parseIFF();
            if (kw.equals(IMPL)) return parseIMPL();
            if (kw.equals(EXCL)) return parseEXCL();

            return parseClause();
        }

        private Set<Clause> parseClause() throws java.io.IOException {
            Clause retvC = new Clause();
            pos = 0;
            while (pos < s.length()) {
                skipWhiteSpace();
                boolean sign = true;
                if (s.charAt(pos) == '!') { sign = false; pos++; }
                skipWhiteSpace();
                String id = getId();
                skipWhiteSpace();
                if (id  == null) return null;
                retvC.add(Literal.getLiteral(sign, getVar(id)));
                if (pos < s.length() && s.charAt(pos) != '|') return null;
                else ++pos;
            } 

            HashSet<Clause> retv = new HashSet<Clause>();
            retv.add(retvC);
            return retv;
        }
    }


    private static String removeWhiteSpace(String s) {
        String retv = "";
        for (int i = 0; i < s.length(); i++) {
            if (!Character.isWhitespace(s.charAt(i))) {
                retv += s.charAt(i);
            }
        }
        return retv;
    }
   
}
