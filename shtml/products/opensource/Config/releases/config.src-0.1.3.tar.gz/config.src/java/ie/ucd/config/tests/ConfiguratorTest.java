package ie.ucd.config.tests;

import static org.junit.Assert.*;
import ie.ucd.solver.Variable;

import java.util.HashSet;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ConfiguratorTest {

	private Set<Variable> vars;
	private Variable x;
	private Variable y;
	private Variable z;
	
	@Before
	public void setUp() throws Exception {
		vars = new HashSet<Variable>();
		x = Variable.getVariable("x"); vars.add(x);
		y = Variable.getVariable("y"); vars.add(y);
		z = Variable.getVariable("z"); vars.add(z);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testVarsAdd() {
		assertEquals("There should be 3 variables.", 5, vars.size());
	}
	
	@Test
	public void testSelect() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testEliminate() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRetractVariable() {
		fail("Not yet implemented"); // TODO
	}

}
