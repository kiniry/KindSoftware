
                      README for OBJ3 2.05 Source Tree
     _________________________________________________________________
   
   Welcome to the OBJ3 version 2.05 source tree.
   
Source Structure

   The source code for the OBJ3 system is found in the [1]obj3 directory.
   In particular, note that the standard OBJ3 prelude is included as
   [2]obj3/prelude/obj3sp.obj.
   
   Many OBJ3 examples are included in the [3]examples directory. See the
   [4]README there for more information.
   
   A few miscellaneous support programs (coded in C) are available in the
   [5]support directory.
   
Building

  Background
  
   The OBJ3 system is written in Common Lisp. Modern Common Lisp systems
   can compile Lisp code to C, thus a compiled implementation of OBJ3 is
   quite efficient.
   
   The last major release of OBJ3 (2.0) took place in April of 1992 and
   was built by Timothy Winkler, one of the primary OBJ3 developers. At
   that time, OBJ3 built properly on several Common Lisp implementations
   including:
     * CMU CL - Carnegie Mellon's Common Lisp's last major release (17)
       from CMU took place in November, 1994. CMU-CL is currently under
       development by a group of interested individuals and the [6]latest
       version (18b) was made available in mid-1998. See [7]CMU Common
       Lisp Activities Page for more information.
     * LUCID CL (now Liquid CL from [8]Harlequin) - A commercial Common
       Lisp implementation that is still sold and supported. The latest
       version at the time of this writing is 5.0.6 (released December,
       1998).
     * Kyoto Common Lisp (KCL) - Was the primary Lisp platform for OBJ3
       development in the early 90s. KCL is a highly portable
       implementation of Common Lisp. KCL evolved into AKCL (Austin Kyoto
       Common Lisp) by Bill Schelter, which then evolved into GNU Common
       Lisp. A release of AKCL is available from [9]CMU but it is circa
       1992. It is unclear how portable or supported AKCL is at this
       time.
       
   The world of Common Lisp implementations has changed over the last
   eight years. The primary free implementation that is widely used and
   available today is GNU Common Lisp. This release of OBJ3 is only
   guaranteed to run under GCL 2.2.2. You can obtain GCL via the [10]FSF
   GNU FTP server or the primary [11]UTexas FTP server. Note that GCL 2.3
   is not supported at this time!. Linux users can obtain references to
   various RPMs for GCL 2.2.2 via [12]RPMfind.net's excellent auto-index.
   
   Thanks go primarily to [13]Sula Ma at Oxford for this OBJ3 port to GCL
   2.2.2. Sula is preparing a new branch of OBJ called "OBJ4", and this
   port was part of that work.
   
   We are interested in hearing if anyone ports OBJ3 to other Common Lisp
   implementations, in particular, [14]Harlequin LispWorks and [15]Franz
   Allegro CL. Interested parties should look at the original OBJ3 2.04
   release (mentioned in the [16]OBJ3 FAQ), since it contains all of the
   original code that permitted it to run under several Common Lisp
   implementations. Note that Allegro CL 5 is now freely available for
   academic use on Windows, Linux, and FreeBSD platforms.
   
   For a good breakdown of modern Common Lisp implementations, see
   [17]this informative page. All other questions about Common Lisp
   implementation are probably addressed in the [18]Lisp FAQ.
   
  Building
  
   To build OBJ3, you need GCL 2.2.2 and GNU make. Simply type "make" in
   the OBJ3 root directory. After the build completes, the OBJ3
   executable will be found at OBJ3-2.05/bin/obj3. You need just under 2
   megabytes of disk space for the intermediate object files and the
   executable is just under 7 megabytes in size. Thus, all told, you
   should have about 10 Mb of storage available when building OBJ3.
   
Questions or comments?

   Please email [19]obj-feedback@kindsoftware.com.
     _________________________________________________________________
   
      [ [20]Index ] [ [21]Readme ] [ [22]FAQ ] [ [23]Release Notes ] [
       [24]To-Do List ] [ [25]Bug List ] [ [26]Papers ] [ Source ] [
                     [27]Bibliography ] [ [28]License ]
     _________________________________________________________________
   
     [29]Best Viewed With Any Browser. [30]XHTML 1.0 Checked! [31]CSS,
                             Level 2 Checked! 
   
   
    by Joseph R. Kiniry <kiniry@cs.caltech.edu>
    
   Last modified: Sun May 21 15:32:41 PDT 2000

References

   1. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/source/obj3/
   2. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/source/obj3/prelude/obj3sp.obj
   3. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/source/examples/
   4. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/source/examples/README.txt
   5. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/source/support/
   6. ftp://ftp2.cons.org/pub/languages/lisp/cmucl/release/
   7. http://www.cons.org/cmucl/
   8. http://www.harlequin.com/
   9. http://www.cs.cmu.edu/afs/cs/user/mkant/Public/Lisp/impl/kcl/akcl/
  10. ftp://prep.ai.mit.edu/pub/gnu/gcl/
  11. ftp://rene.ma.utexas.edu/pub/gcl/
  12. http://www.rpmfind.net/linux/RPM/gcl.html
  13. mailto:sm@comlab.ox.ac.uk
  14. http://www.harlequin.com/products/st/lisp/
  15. http://www.franz.com/
  16. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/FAQ.html
  17. http://www.elwoodcorp.com/alu/table/systems.htm
  18. http://www.faqs.org/faqs/lisp-faq/part1/preamble.html
  19. mailto:obj-feedback@kindsoftware.com
  20. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/index.html
  21. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/README.html
  22. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/FAQ.html
  23. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/RELEASE_NOTES.html
  24. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/TODO.html
  25. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/BUGS.html
  26. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/index.html
  27. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/obj_bib.html
  28. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/LICENSE.html
  29. http://www.anybrowser.org/campaign/
  30. http://validator.w3.org/check/referer
  31. http://jigsaw.w3.org/css-validator/check/referer
