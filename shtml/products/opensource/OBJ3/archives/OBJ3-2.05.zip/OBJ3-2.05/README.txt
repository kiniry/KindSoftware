
                            README for OBJ3 2.05
     _________________________________________________________________
   
Documentation

   Several pieces of documentation come with this OBJ3 release, including
   a [1]FAQ, [2]Release Notes, a [3]TODO list, a [4]known bug list, and
   some introductory [5]OBJ3 papers.
   
   The two canonical references for learning OBJ3 are the classic
   [6]Algebraic Semantics of Imperative Programs by Joseph A. Goguen and
   Grant Malcolm published by [7]MIT Press, and the new [8]Software
   Engineering with OBJ: Algebraic Specification in Action, edited by
   Joseph A. Goguen and Grant Malcolm, published by [9]Kluwer Academic
   Publishers in 2Q, 2000 [[10]GoguenMalcolm96-ASoIP,
   [11]GoguenMalcolm00]. The new book compiles many of the seminal
   OBJ3-related papers into one complete reference text --- we highly
   recommend it!
   
Building OBJ3

   Thanks go primarily to [12]Sula Ma at Oxford for this OBJ3 port to GCL
   2.2.2. Sula is preparing a new branch of OBJ called "OBJ4", and this
   port was part of that work.
   
   Please see the [13]source README for information on building OBJ3.
   
Using OBJ3

   The best references for getting up-to-speed with OBJ3 are listed in
   the [14]OBJ3 FAQ and are indexed in the [15]OBJ/Algebra bibliography
   included with this release. We strongly suggest reading the
   Introducing OBJ paper (a [16]draft is available via Joseph Goguen's
   [17]OBJ web page) and the two Goguen-Malcolm books. Most academic
   libraries should already have a copy of the Algebraic Semantics text
   [[18]GoguenMalcolm96]. Encourage your library to purchase a copy of
   the new Software Engineering with OBJ text [[19]GoguenMalcolm00].
   Finally, a good overview of the use of OBJ3 in teaching formal methods
   can be found in Teaching And Learning Formal Methods
   [[20]GoguenMalcolm96].
   
   For those primarily interested in parameterized programming, the paper
   [21]An Implementation-Oriented Semantics for Module Composition is a
   must-read [[22]GoguenTracz97]. For those interested in higher-order
   logics/programming/rewriting, [23]More Higher Order Programming with
   OBJ3 is a good start [[24]GoguenMalcolm00-HOP]. Other references
   include [[25]Wolfram93] and [[26]Goguen90-HOP].
   
   For users interested in extending the OBJ3 system, please see
   [[27]Winkler-NewFeatures] and [[28]WinklerMeseguer-Builtins], both of
   which are included in this release.
   
Questions or comments?

   Please email [29]obj3-feedback@kindsoftware.com if you have any
   questions, comments, or other feedback about this release. General
   OBJ3 questions should be addressed to [30]obj3@kindsoftware.com.
     _________________________________________________________________
   
   [ [31]Index ] [ Readme ] [ [32]FAQ ] [ [33]Release Notes ] [ [34]To-Do
          List ] [ [35]Bug List ] [ [36]Source ] [ [37]Papers ] [
                     [38]Bibliography ] [ [39]License ]
     _________________________________________________________________
   
     [40]Best Viewed With Any Browser. [41]XHTML 1.0 Checked! [42]CSS,
                             Level 2 Checked! 
   
   
    by Joseph R. Kiniry <kiniry@cs.caltech.edu>
    
   Last modified: Sun May 21 15:45:15 PDT 2000

References

   1. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/FAQ.html
   2. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/RELEASE_NOTES.html
   3. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/TODO.html
   4. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/BUGS.html
   5. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/index.html
   6. http://mitpress.mit.edu/book-home.tcl?isbn=026207172X
   7. http://www.mitpress.com/
   8. http://www.wkap.nl/book.htm/0-7923-7757-5
   9. http://www.wkap.nl/
  10. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/obj_bib.html#GoguenMalcolm96-ASoIP
  11. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/obj_bib.html#GoguenMalcolm00
  12. mailto:sm@comlab.ox.ac.uk
  13. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/source/README.html
  14. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/FAQ.html#documentation
  15. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/obj_bib.html
  16. http://www-cse.ucsd.edu/users/goguen/ps/iobj.ps.gz
  17. http://www-cse.ucsd.edu/users/goguen/sys/obj.html
  18. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/obj_bib.html#GoguenMalcolm96
  19. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/obj_bib.html#GoguenMalcolm00
  20. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/obj_bib.html#GoguenMalcolm96
  21. http://www-cse.ucsd.edu/users/goguen/ps/will.ps.gz
  22. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/obj_bib.html#GoguenTracz97
  23. http://www-cse.ucsd.edu/users/goguen/ps/hobj.ps.gz
  24. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/obj_bib.html#GoguenMalcolm00-HOP
  25. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/obj_bib.html#Wolfram93
  26. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/obj_bib.html#Goguen90-HOP
  27. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/obj_bib.html#Winkler-NewFeatures
  28. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/obj_bib.html#WinklerMeseguer-Builtins
  29. mailto:obj3-feedback@kindsoftware.com
  30. mailto:obj3@kindsoftware.com
  31. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/index.html
  32. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/FAQ.html
  33. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/RELEASE_NOTES.html
  34. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/TODO.html
  35. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/BUGS.html
  36. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/source/README.html
  37. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/index.html
  38. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/docs/obj_bib.html
  39. file://localhost/mnt/ext2/home/httpd/html/products/opensource/obj3/OBJ3-2.05/LICENSE.html
  40. http://www.anybrowser.org/campaign/
  41. http://validator.w3.org/check/referer
  42. http://jigsaw.w3.org/css-validator/check/referer
