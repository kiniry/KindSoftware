#ifndef BISON_Y_TAB_H
# define BISON_Y_TAB_H

#ifndef YYSTYPE
typedef union
{
	int		y_arity;
	String		y_string;
	EqMod *		y_eq_mod;
	EqList *	y_eq_list;
	Eq *		y_eq;
	EqTermList *	y_eq_term_list;
	EqTerm *	y_eq_term;
	SortOrder *	y_so;
	OpTable *	y_ot;
	Operator *	y_op;
	SortList *	y_sort_list;
} yystype;
# define YYSTYPE yystype
# define YYSTYPE_IS_TRIVIAL 1
#endif
# define	TIDENTIFIER	257
# define	TEQ	258
# define	TCQ	259
# define	TRIGHT_ARROW	260
# define	TIF	261
# define	TSUBSORTS	262
# define	TOP	263
# define	TVAR	264
# define	TARROW	265


extern YYSTYPE yylval;

#endif /* not BISON_Y_TAB_H */
