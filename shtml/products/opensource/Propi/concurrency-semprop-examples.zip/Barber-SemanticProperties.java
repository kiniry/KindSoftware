public class Barber {
  //@ assignable the_c.needsHairCut;
  //@ ensures !the_c.needsHairCut();
  public synchronized void cutHair(final Customer the_c) {}
}

public class BarberShop {
  private /*@ spec_public @*/ final Barber barber;
  private /*@ spec_public @*/ final int num_seats;

  //@ requires 0 < num_seats;
  //@ ensures barber == the_barber
  //@ ensures num_seats == the_num_seats;
  public BarberShop(final Barber the_barber, 
                    final int the_num_seats) {}

  //@ assignable the_c.needsHairCut;
  //@ ensures !the_c.needsHairCut();
  // @concurrency concurrent (num_seats + 1)
  // @concurrency failure NoSeats
  // @concurrency locks barber
  public void getHairCut(final Customer the_c)
    throws NoSeats {}
}

// @concurrency guarded this
public class Customer {
  private final BarberShop shop; 
  private boolean my_needs_hair_cut; //@ in needsHairCut;

  //@ ensures shop() == the_shop;
  //@ ensures !needsHairCut();
  public Customer(final BarberShop the_shop) {}
  
  public synchronized BarberShop shop() {}

  //@ public model non_null JMLDataGroup needsHairCut; 
  //@ in objectState;
  public synchronized boolean needsHairCut() {}

  //@ assignable needsHairCut;
  //@ ensures !needsHairCut();
  public synchronized void setHairCut() {}

  //@ requires !needsHairCut();
  //@ assignable needsHairCut;
  //@ ensures needsHairCut();
  public synchronized void regularActivities() {}

  //@ assignable needsHairCut;
  // @concurrency locks shop().barber
  public synchronized void run() {}
}