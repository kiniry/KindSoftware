public class Barber {
  //@ assignable the_c.needsHairCut;
  //@ ensures !the_c.needsHairCut();
  public synchronized void cutHair(final Customer the_c) {
    // take some time to do it right
    the_c.setHairCut();
  }
}

public class BarberShop {
  private /*@ spec_public @*/ final Barber barber;
  private /*@ spec_public @*/ final int num_seats;

  //@ requires 0 < num_seats;
  //@ ensures barber == the_barber; ensures num_seats == the_num_seats;
  public BarberShop(final Barber the_barber, final int the_num_seats) {}

  /*@ public normal_behavior
    @   requires \thread_count < \thread_limit;
    @   assignable the_c.needsHairCut;
    @   locks barber;
    @   ensures \broken ==> !the_c.needsHairCut();
    @ also public exceptional_behavior
    @   requires \thread_count == \thread_limit;
    @   assignable \nothing;
    @   signals NoSeats true; signals_only NoSeats; */
  public void getHairCut(final Customer the_c) throws NoSeats {
    barber.cutHair(the_c);
  }

  /*@ invariant \typeof(this) == \type(BarberShop) ==>
                \thread_limit("getHairCut(Customer)") == num_seats + 1; */
  /*@ invariant num_seats + 1 <= \thread_limit("getHairCut(Customer)"); */
}

public class Customer {
  private final BarberShop my_shop; 
  private boolean my_needs_hair_cut; //@ in needsHairCut;

  //@ ensures shop() == the_shop; ensures !needsHairCut();
  public Customer(final BarberShop the_shop) {}
  
  public synchronized BarberShop shop() {}

  //@ public model non_null JMLDataGroup needsHairCut; in objectState;
  public synchronized boolean needsHairCut() {}

  //@ assignable needsHairCut; ensures !needsHairCut();
  public synchronized void setHairCut() {}

  //@ requires !needsHairCut(); assignable needsHairCut; ensures needsHairCut();
  public synchronized void regularActivities() {
    // whatever the customer does between haircuts
    my_needs_hair_cut = true;
  }

  //@ assignable needsHairCut; locks shop().barber;
  public synchronized void run() {
    while (true) {
      regularActivities();
      while (my_needs_hair_cut) {
        try { my_shop.getHairCut(); } 
        catch (final NoSeats ns) { /* insufficient seats */ }
      }
    }
  }
}