class C { 
  //@ invariant I;

  //@ requires P; assignable A; ensures Q;
  // @concurrency concurrent 4
  public void m() {}
}

class C {
  //@ invariant !\broken ==> I;
  
  /*@ normal_behavior
    @   requires P; assignable A; ensures !\broken ==> Q;
    @ also normal_behavior
    @   requires \thread_count == \thread_limit; assignable A; ensures \broken; */
  public void m() {}

  /*@ invariant \typeof(this) == \type(C) ==> \thread_limit("m()") == 4; */
  //@ invariant 4 <= \thread_limit("m()");
}