class C { 
  //@ requires P; assignable A; ensures Q;
  // @concurrency concurrent 8
  // @concurrency failure E
  public void m() {}
}

class C {
  /*@ normal_behavior
    @   requires \thread_count < \thread_limit;
    @   requires P; assignable A; ensures \broken ==> Q;
    @ also exceptional_behavior
    @   requires \thread_count == \thread_limit;
    @   assignable \nothing; signals E true; signals_only E; */
  public void m() throws E {}

  /*@ invariant \typeof(this) == \type(C) ==> \thread_limit("m()") == 8; */
  //@ invariant 8 <= \thread_limit("m()");
}