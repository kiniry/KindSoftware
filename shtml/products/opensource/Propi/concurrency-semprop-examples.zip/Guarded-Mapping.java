class C { 
  //@ requires P; assignable A; ensures Q;
  // @concurrency guarded A, B, 3
  public void m() {
    // method body
  }
}

class C {
  //@ requires P; assignable A; ensures Q;
  /*@ when \lockset.has(A) & \lockset.has(B) & \lockset.has(\semaphore); */
  /*@ ensures (\lockset.has(A) <==> \old(\lockset.has(A))) &
    @         (\lockset.has(B) <==> \old(\lockset.has(B))) &
    @         (\lockset.has(\semaphore) <==> \old(\lockset.has(\semaphore))); */
  public void m() {
    commit:
    // method body
  }
  //@ initially \semaphore("m()").permits() == 3;
}