//@ locks left_fork, right_fork;
//@ when \lockset.has(left_fork) & \lockset.has(right_fork);
/*@ ensures  (\lockset.has(left_fork) <==> 
  @           \old(\lockset.has(left_fork)) &
  @          (\lockset.has(right_fork) <==> 
  @           \old(\lockset.has(right_fork))); */
public synchronized void eat() { 
  // obtain the forks in order
  /*@ commit: @*/
  // critical section
  // release the forks
}
