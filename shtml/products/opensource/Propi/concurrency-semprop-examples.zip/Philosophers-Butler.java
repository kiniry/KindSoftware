public class Butler extends Semaphore {
  //@ require 0 < the_num_phils;
  //@ ensures availablePermits() == the_num_phils - 1;
  public Butler(final int the_num_phils) {
    super(the_num_phils - 1);
  }
}

public class Fork extends Semaphore {
  //@ ensures availablePermits() == 1;
  public Fork() { super(1); }
}

public class Philosopher {
  private /*@ spec_public @*/ final Butler butler;
  private /*@ spec_public @*/ final Fork left_fork;
  private /*@ spec_public @*/ final Fork right_fork;

  //@ requires the_left_fork != the_right_fork;
  //@ ensures butler == the_butler;
  //@ ensures left_fork == the_left_fork
  //@ ensures right_fork == the_right_fork;
  public Philosopher(final Butler the_butler, 
                     final Fork the_left_fork,
                     final Fork the_right_fork) {} 

  //@ locks butler, left_fork, right_fork;
  // @concurrency guarded butler, left_fork, right_fork;
  protected synchronized void eat() { 
    // user-defined critical section
  }

  public synchronized void think() {
    // user-defined non-critical section
  }

  //@ locks butler, left_fork, right_fork;
  public synchronized void run() { 
    while (true) { think(); eat(); }
  }
}

public class Main {
  private /*@ spec_public @*/ final Fork[] forks;
  private /*@ spec_public @*/ final Philosopher[] phils;
  private /*@ spec_public @*/ final Butler butler;

  //@ ensures forks.length = the_count;
  //@ ensures phils.length = the_count;
  /*@ ensures (\forall int i, j; 
               0 <= i & i < the_count & 0 < j & j < the_count;
               phils[i].left_fork == forks[i] &
               phils[i].right_fork == forks[(i + 1) % the_count] &
               phils[i].butler == butler &
               forks[i] == forks[j] <==> i == j); @*/
  public Main(final int the_count) {
    // create everything and start threads
  }

  /*@ public invariant 
      (\forall int i: 0 <= i & i < forks.length;
       butler <# forks[i]); @*/
}