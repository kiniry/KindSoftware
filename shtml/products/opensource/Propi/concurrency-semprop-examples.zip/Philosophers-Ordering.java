public class Fork extends Semaphore {
  public final int number;
  
  //@ ensures number = the_number;
  //@ ensures availablePermits() == 1;
  public Fork(final int the_number) { 
    super(1); number = the_number;
  }
}

public class Philosopher {
  private /*@ spec_public @*/ final Fork left_fork;
  private /*@ spec_public @*/ final Fork right_fork;

  //@ requires the_left_fork != the_right_fork;
  //@ ensures left_fork == the_left_fork
  //@ ensures right_fork == the_right_fork;
  public Philosopher(final Fork the_left_fork,
                     final Fork the_right_fork) {} 

  //@ locks left_fork, right_fork;
  //@ when \lockset.has(left_fork) & \lockset.has(right_fork);
  /*@ ensures \lockset.has(left_fork) <==> 
              \old(\lockset.has(left_fork); */
  /*@ ensures \lockset().has(right_fork) <==>
              \old(\lockset.has(right_fork); */
  public synchronized void eat() { 
    // obtain the forks in order
    /*@ commit: @*/
    // critical section
  }

  public synchronized void think() { 
    // non-critical section
  }

  //@ locks left_fork, right_fork;
  public synchronized void run() {
    while (true) { think(); eat(); }
  }

  //@ public invariant this <# left_fork & this <# right_fork;
}

public class Main {
  private /*@ spec_public @*/ final Fork[] forks;
  private /*@ spec_public @*/ final Philosopher[] phils;

  //@ ensures forks.length = the_count;
  //@ ensures phils.length = the_count;
  /*@ ensures (\forall int i, j; 
               0 <= i & i < the_count & 0 < j & j < the_count;
               phils[i].left_fork == my_forks[i] &
               phils[i].right_fork == forks[(i + 1) % the_count] &
               forks[i].number == i &
               forks[i] == forks[j] <==> i == j); @*/
  public Main(final int the_count) {
    // create everything and start threads
  }

  /*@ public invariant 
      (\forall int i, j: 0 <= i & i < j & j < forks.length;
       forks[i] <# forks[j]); @*/
}
