public class ThreadCounter {
  //@ public initially active_count == 0;
  //@ public invariant 0 <= active_count;
  private /*@ spec_public @*/ int active_count;

  //@ public invariant 0 < limit;
  public final int limit;
  
  //@ public initially !broken;
  //@ public invariant limit < active_count ==> broken;
  //@ public constraint \old(broken) ==> broken;  
  private /*@ spec_public @*/ boolean broken;
  
  //@ public invariant (\forall int i; counts.containsValue(i); 0 < i);
  private /*@ spec_public @*/ final Map<Thread,Integer> counts;
  
  /*@ ensures \old(counts.get(the_thread) == null) ==>
    @           counts.get(the_thread) == 1 && active_count == \old(active_count + 1); */
  /*@ ensures \old(counts.get(the_thread) != null) ==>
    @           counts.get(the_thread) == \old(counts.get(the_thread) + 1); */
  public synchronized void threadEnter(final Thread the_thread);
  
  //@ requires counts.get(the_thread) != null; requires 0 < counts.get(the_thread);
  /*@ ensures \old(1 < counts.get(the_thread)) ==>
    @           counts.get(the_thread) == \old(counts.get(the_thread) - 1); */
  /*@ ensures \old(counts.get(the_thread) == 1) ==>
    @           counts.get(the_thread) == null && active_count == \old(active_count - 1); */
  public synchronized void threadLeave(final Thread the_thread);
}