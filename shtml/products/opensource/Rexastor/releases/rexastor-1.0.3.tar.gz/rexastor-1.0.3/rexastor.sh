#!/bin/bash

set -e

java -cp lib/ie.ucd.miko.utils.jar:lib/antlr-3.2.jar:lib/clops-0.2.2-runtime.jar:lib/google-collect-snapshot-20090211.jar:lib/jgrapht-jdk1.6.jar:lib/regexptrees.jar:lib/rexastore.jar:lib/velocity-1.6.2-dep.jar:lib/velocity-1.6.2.jar \
	ie.ucd.miko.rexastor.cli.Main $@

