#!/bin/bash

set -e

java -cp lib/antlr-3.2.jar:lib/antlr3-task.jar:lib/antlr-runtime-3.1.3.jar:lib/astgen.jar:lib/clops-0.2.2.jar:lib/clops-0.2.2-runtime.jar:lib/google-collect-1.0-rc2.jar:lib/ie.ucd.miko.utils.jar:lib/jgrapht-jdk1.6.jar:lib/velocity-1.6.2-dep.jar:lib/velocity-1.6.2.jar:lib/rexastor.jar \
	ie.ucd.miko.rexastor.cli.Main $@

